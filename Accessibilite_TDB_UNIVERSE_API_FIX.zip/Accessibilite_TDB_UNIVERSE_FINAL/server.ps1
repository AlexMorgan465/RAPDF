param([string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$Port=8787)
$ErrorActionPreference='Stop'
$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir=Join-Path $AppDir 'data'
$IndexFile=Join-Path $DataDir 'index.json'
$ScanFile=Join-Path $DataDir 'scan.json'
$DiagFile=Join-Path $DataDir 'diagnostic.json'
$JournalFile=Join-Path $DataDir 'journal.json'
if(!(Test-Path -LiteralPath $DataDir)){New-Item -ItemType Directory -Path $DataDir -Force|Out-Null}
$Utf8=New-Object Text.UTF8Encoding($false)
function Ensure-JsonFile([string]$Path,[string]$Default){if(!(Test-Path -LiteralPath $Path)){[IO.File]::WriteAllText($Path,$Default,$Utf8)}}
Ensure-JsonFile $IndexFile '[]'; Ensure-JsonFile $ScanFile '{}'; Ensure-JsonFile $DiagFile '[]'; Ensure-JsonFile $JournalFile '[]'
$Allowed=@{'A TRAITER'=@('EN COURS');'EN COURS'=@('A TRAITER','TRAITES','NON CONFORME');'TRAITES'=@('A TRAITER');'NON CONFORME'=@('A TRAITER');'A PUBLIER'=@('A TRAITER')}
function Read-JsonText([string]$Path,[string]$Default){
  try { $txt=[IO.File]::ReadAllText($Path); if([string]::IsNullOrWhiteSpace($txt)){return $Default}; $null=$txt|ConvertFrom-Json; return $txt }
  catch { return $Default }
}
function Send-Bytes($Ctx,[byte[]]$Bytes,[string]$Type,[int]$Code=200){$Ctx.Response.StatusCode=$Code;$Ctx.Response.ContentType=$Type;$Ctx.Response.ContentLength64=$Bytes.Length;$Ctx.Response.OutputStream.Write($Bytes,0,$Bytes.Length);$Ctx.Response.Close()}
function Send-Text($Ctx,[string]$Text,[string]$Type='application/json;charset=utf-8',[int]$Code=200){Send-Bytes $Ctx ([Text.Encoding]::UTF8.GetBytes($Text)) $Type $Code}
function Send-Object($Ctx,$Obj,[int]$Code=200){Send-Text $Ctx ($Obj|ConvertTo-Json -Depth 20 -Compress) 'application/json;charset=utf-8' $Code}
function Send-File($Ctx,[string]$Path,[string]$Type){if(!(Test-Path -LiteralPath $Path)){Send-Object $Ctx @{ok=$false;error='Fichier web introuvable'} 404;return};Send-Bytes $Ctx ([IO.File]::ReadAllBytes($Path)) $Type 200}
function Read-Body($Ctx){$sr=New-Object IO.StreamReader($Ctx.Request.InputStream,$Ctx.Request.ContentEncoding);try{$raw=$sr.ReadToEnd();if([string]::IsNullOrWhiteSpace($raw)){return $null};return ($raw|ConvertFrom-Json)}finally{$sr.Dispose()}}
function Read-Array([string]$Path){$txt=Read-JsonText $Path '[]';$obj=$txt|ConvertFrom-Json;return @($obj)}
function Atomic-Write([string]$Path,$Obj){$tmp=$Path+'.tmp';[IO.File]::WriteAllText($tmp,($Obj|ConvertTo-Json -Depth 20),$Utf8);if(Test-Path -LiteralPath $Path){[IO.File]::Replace($tmp,$Path,$null)}else{Move-Item -LiteralPath $tmp -Destination $Path -Force}}
function Move-Document($Body){
  $items=Read-Array $IndexFile; $it=$items|Where-Object{$_.id -eq $Body.id}|Select-Object -First 1
  if($null -eq $it){throw 'Document introuvable dans index'}
  $to=[string]$Body.to; if($Allowed[[string]$it.status] -notcontains $to){throw 'Transition interdite'}
  $entityRoot=Join-Path $Root ([string]$it.entity); $srcRoot=Join-Path $entityRoot ([string]$it.statusRootRelative); $src=Join-Path $srcRoot ([string]$it.relativePath)
  $parentRel=Split-Path -Parent ([string]$it.statusRootRelative); $searchBase=if($parentRel){Join-Path $entityRoot $parentRel}else{$entityRoot}
  $destRoot=@(Get-ChildItem -LiteralPath $searchBase -Directory -ErrorAction Stop|Where-Object{$_.Name.Trim().ToUpperInvariant() -eq $to}|Select-Object -First 1)
  if($destRoot.Count -eq 0){throw 'Dossier statut destination correspondant introuvable'}
  $dst=Join-Path $destRoot[0].FullName ([string]$it.relativePath); if(!(Test-Path -LiteralPath $src)){throw 'Dossier deja deplace'}; if(Test-Path -LiteralPath $dst){throw 'Destination existe deja'}
  $parent=Split-Path -Parent $dst;if(!(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Path $parent -Force|Out-Null};Move-Item -LiteralPath $src -Destination $dst
  $j=Read-Array $JournalFile;$j+= [pscustomobject]@{date=(Get-Date).ToString('o');id=$it.id;entity=$it.entity;document=$it.name;from=$it.status;to=$to;source='INTERFACE'};Atomic-Write $JournalFile $j
  return @{ok=$true}
}
$Listener=New-Object Net.HttpListener;$Listener.Prefixes.Add("http://localhost:$Port/");$Listener.Start();Write-Host "UNIVERSE API ONLINE : http://localhost:$Port" -ForegroundColor Green
while($Listener.IsListening){
 $Ctx=$Listener.GetContext()
 try{
  $Path=$Ctx.Request.Url.AbsolutePath
  if($Path -eq '/api/items'){
    # Compose from already validated raw JSON. This avoids PowerShell array/unary-enumeration edge cases.
    $itemsJson=Read-JsonText $IndexFile '[]';$scanJson=Read-JsonText $ScanFile '{}';$rootJson=($Root|ConvertTo-Json -Compress)
    Send-Text $Ctx ('{"root":'+$rootJson+',"scan":'+$scanJson+',"items":'+$itemsJson+'}')
  } elseif($Path -eq '/api/diagnostic'){Send-Text $Ctx (Read-JsonText $DiagFile '[]')
  } elseif($Path -eq '/api/journal'){Send-Text $Ctx (Read-JsonText $JournalFile '[]')
  } elseif($Path -eq '/api/health'){Send-Object $Ctx @{ok=$true;index=(Test-Path $IndexFile);scan=(Test-Path $ScanFile);time=(Get-Date).ToString('o')}
  } elseif($Path -eq '/api/move' -and $Ctx.Request.HttpMethod -eq 'POST'){try{Send-Object $Ctx (Move-Document (Read-Body $Ctx)) 200}catch{Send-Object $Ctx @{ok=$false;error=$_.Exception.Message} 409}
  } elseif($Path -eq '/' -or $Path -eq '/index.html'){Send-File $Ctx (Join-Path $AppDir 'index.html') 'text/html;charset=utf-8'
  } elseif($Path -eq '/style.css'){Send-File $Ctx (Join-Path $AppDir 'style.css') 'text/css;charset=utf-8'
  } elseif($Path -eq '/app.js'){Send-File $Ctx (Join-Path $AppDir 'app.js') 'application/javascript;charset=utf-8'
  } else {Send-Object $Ctx @{ok=$false;error='Not found'} 404}
 } catch {try{Send-Object $Ctx @{ok=$false;error=$_.Exception.Message;line=$_.InvocationInfo.ScriptLineNumber} 500}catch{}}
}
