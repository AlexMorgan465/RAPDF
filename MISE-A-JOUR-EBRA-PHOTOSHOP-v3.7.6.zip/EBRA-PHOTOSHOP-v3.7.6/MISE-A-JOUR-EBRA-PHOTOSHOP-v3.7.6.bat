@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Mise a jour EBRA Photoshop v3.7.6

set "UPDATE=%~dp0"
set "ROOT=%~dp0"

rem Recherche des deux applications dans le dossier courant puis son parent.
if not exist "%ROOT%EBRA-Manager\web\index.html" if exist "%ROOT%..\EBRA-Manager\web\index.html" set "ROOT=%~dp0..\"

if not exist "%ROOT%EBRA-Manager\web\index.html" goto :notfound
if not exist "%ROOT%EBRA-Press-Service\web\index.html" goto :notfound
if not exist "%UPDATE%patch\photo375.js" goto :missingpatch

echo.
echo ================================================
echo   MISE A JOUR EBRA PHOTOSHOP v3.7.6
echo ================================================
echo.
echo Fermez Agent et Manager avant de continuer.
echo Installation dans : %ROOT%
echo.

rem Sauvegarde locale des versions precedentes.
if exist "%ROOT%EBRA-Manager\web\photo375.js" copy /Y "%ROOT%EBRA-Manager\web\photo375.js" "%ROOT%EBRA-Manager\web\photo375.js.backup-v3.7.6" >nul
if exist "%ROOT%EBRA-Press-Service\web\photo375.js" copy /Y "%ROOT%EBRA-Press-Service\web\photo375.js" "%ROOT%EBRA-Press-Service\web\photo375.js.backup-v3.7.6" >nul

copy /Y "%UPDATE%patch\photo375.js" "%ROOT%EBRA-Manager\web\photo375.js" >nul || goto :failed
copy /Y "%UPDATE%patch\photo375.js" "%ROOT%EBRA-Press-Service\web\photo375.js" >nul || goto :failed

for %%F in ("%ROOT%EBRA-Manager\web\photo375.js" "%ROOT%EBRA-Press-Service\web\photo375.js") do if %%~zF LSS 1000 goto :failed

echo.
echo SUCCES : la correction d'importation des images est installee.
echo Le module lit maintenant le contenu du fichier sans utiliser file://.
echo.
echo Fermez tous les onglets EBRA dans Edge.
echo Relancez ensuite EBRA Manager et EBRA Agent.
echo.
pause
exit /b 0

:notfound
echo.
echo ERREUR : EBRA-Manager ou EBRA-Press-Service est introuvable.
echo Extrayez ce dossier de mise a jour directement a cote de :
echo   EBRA-Manager
echo   EBRA-Press-Service
echo Puis relancez ce fichier BAT.
echo.
pause
exit /b 1

:missingpatch
echo.
echo ERREUR : le fichier patch\photo375.js est absent.
echo Extrayez completement le ZIP avant de lancer la mise a jour.
echo.
pause
exit /b 1

:failed
echo.
echo ERREUR : impossible de copier ou de verifier le correctif.
echo Fermez les serveurs EBRA, verifiez les droits du dossier puis recommencez.
echo Les anciens fichiers restent disponibles avec l'extension backup-v3.7.6.
echo.
pause
exit /b 1
