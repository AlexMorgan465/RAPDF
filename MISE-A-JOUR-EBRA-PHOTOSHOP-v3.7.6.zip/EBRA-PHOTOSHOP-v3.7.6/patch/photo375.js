(()=>{'use strict';
const $=id=>document.getElementById(id),canvas=$('photo-canvas');if(!canvas)return;const ctx=canvas.getContext('2d',{willReadFrequently:true});let source=document.createElement('canvas'),sctx=source.getContext('2d',{willReadFrequently:true}),loaded=false,tool='crop',drawing=false,start=null,selection=null,history=[],future=[],original=null;
const controls=['photo-brightness','photo-contrast','photo-saturation','photo-grayscale','photo-sepia','photo-blur'];
function filters(){return`brightness(${$('photo-brightness').value}%) contrast(${$('photo-contrast').value}%) saturate(${$('photo-saturation').value}%) grayscale(${$('photo-grayscale').value}%) sepia(${$('photo-sepia').value}%) blur(${$('photo-blur').value}px)`}
function neutralFilters(){return $('photo-brightness').value==='100'&&$('photo-contrast').value==='100'&&$('photo-saturation').value==='100'&&$('photo-grayscale').value==='0'&&$('photo-sepia').value==='0'&&$('photo-blur').value==='0'}
function resetFilters(){for(const id of controls){const e=$(id);e.value=id.includes('grayscale')||id.includes('sepia')||id.includes('blur')?0:100;e.dispatchEvent(new Event('input'))}}
function fitCanvas(){const stage=canvas.closest('.photo-stage'),maxW=Math.max(120,stage.clientWidth-48),maxH=Math.max(120,Math.min(stage.clientHeight-48,window.innerHeight*.72)),scale=Math.min(1,maxW/source.width,maxH/source.height);canvas.style.width=Math.max(1,Math.round(source.width*scale))+'px';canvas.style.height=Math.max(1,Math.round(source.height*scale))+'px'}
function render(){if(!loaded)return;canvas.width=source.width;canvas.height=source.height;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.save();ctx.filter='none';ctx.globalCompositeOperation='source-over';ctx.drawImage(source,0,0);ctx.restore();canvas.style.filter=neutralFilters()?'none':filters();if(selection){ctx.save();ctx.strokeStyle='#36b9ff';ctx.lineWidth=Math.max(2,canvas.width/500);ctx.setLineDash([10,7]);ctx.fillStyle='#36b9ff20';ctx.fillRect(selection.x,selection.y,selection.w,selection.h);ctx.strokeRect(selection.x,selection.y,selection.w,selection.h);ctx.restore()}$('photo-empty').hidden=true;$('photo-wrap').hidden=false;fitCanvas();$('photo-width').value=source.width;$('photo-height').value=source.height;$('photo-status').textContent=`${source.width} × ${source.height} px · ${tool==='crop'?'Sélectionnez une zone à recadrer':tool==='brush'?'Pinceau actif':tool==='eraser'?'Gomme active':'Prêt'}`}
function snapshot(){if(!loaded)return;history.push(source.toDataURL('image/png'));if(history.length>20)history.shift();future=[]}
function restore(data){const img=new Image;img.onload=()=>{source.width=img.width;source.height=img.height;sctx=source.getContext('2d',{willReadFrequently:true});sctx.drawImage(img,0,0);selection=null;resetFilters();render()};img.src=data}
function commitFilters(){if(!loaded)return;if(neutralFilters()){canvas.style.filter='none';return}const temp=document.createElement('canvas');temp.width=source.width;temp.height=source.height;const t=temp.getContext('2d');t.filter=filters();t.drawImage(source,0,0);source=temp;sctx=source.getContext('2d',{willReadFrequently:true});canvas.style.filter='none';resetFilters()}
function point(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
function setTool(name){tool=name;selection=null;document.querySelectorAll('[data-photo-tool]').forEach(b=>b.classList.toggle('active',b.dataset.photoTool===name));render()}
function transform(kind){if(!loaded)return;snapshot();commitFilters();const out=document.createElement('canvas'),o=out.getContext('2d');if(kind==='left'||kind==='right'){out.width=source.height;out.height=source.width;o.translate(out.width/2,out.height/2);o.rotate((kind==='right'?1:-1)*Math.PI/2);o.drawImage(source,-source.width/2,-source.height/2)}else{out.width=source.width;out.height=source.height;o.translate(kind==='flipH'?out.width:0,kind==='flipV'?out.height:0);o.scale(kind==='flipH'?-1:1,kind==='flipV'?-1:1);o.drawImage(source,0,0)}source=out;sctx=source.getContext('2d',{willReadFrequently:true});render()}
async function decodeSelectedImage(file){
  if(!file)throw new Error('Aucun fichier sélectionné.');
  const bytes=await file.arrayBuffer();
  if(!bytes.byteLength)throw new Error('Le fichier sélectionné est vide.');
  const blob=new Blob([bytes],{type:file.type||'application/octet-stream'});
  if('createImageBitmap' in window){
    try{return await createImageBitmap(blob)}catch(_error){}
  }
  const dataUrl=await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(reader.result);
    reader.onerror=()=>reject(reader.error||new Error('Lecture impossible.'));
    reader.readAsDataURL(blob);
  });
  return await new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=()=>reject(new Error('Décodage impossible.'));
    img.src=dataUrl;
  });
}
$('photo-file').addEventListener('change',async e=>{
  const file=e.target.files&&e.target.files[0];if(!file)return;
  const status=$('photo-status');status.textContent='Chargement de l’image locale…';
  try{
    const img=await decodeSelectedImage(file);
    const width=img.naturalWidth||img.width,height=img.naturalHeight||img.height;
    if(!width||!height)throw new Error('Dimensions invalides.');
    source.width=width;source.height=height;
    sctx=source.getContext('2d',{willReadFrequently:true});
    sctx.clearRect(0,0,width,height);sctx.drawImage(img,0,0,width,height);
    if(typeof img.close==='function')img.close();
    loaded=true;history=[];future=[];selection=null;
    original=source.toDataURL('image/png');resetFilters();render();
  }catch(error){
    loaded=false;
    status.textContent='Impossible de charger cette image : '+(error&&error.message?error.message:'format non reconnu.');
    console.error('EBRA Photo — import local',error);
  }finally{
    e.target.value='';
  }
});
for(const id of controls){const e=$(id),out=$(id+'-value');e.oninput=()=>{out.textContent=e.value+(id==='photo-blur'?' px':'%');render()}}
document.querySelectorAll('[data-photo-tool]').forEach(b=>b.onclick=()=>setTool(b.dataset.photoTool));
document.querySelectorAll('[data-photo-transform]').forEach(b=>b.onclick=()=>transform(b.dataset.photoTransform));
canvas.onpointerdown=e=>{if(!loaded)return;const p=point(e);if(tool==='crop'){start=p;selection={x:p.x,y:p.y,w:0,h:0};drawing=true;canvas.setPointerCapture(e.pointerId);render()}else if(tool==='brush'||tool==='eraser'){snapshot();commitFilters();drawing=true;start=p;sctx.beginPath();sctx.moveTo(p.x,p.y);canvas.setPointerCapture(e.pointerId)}};
canvas.onpointermove=e=>{if(!drawing)return;const p=point(e);if(tool==='crop'){selection={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)};render()}else{sctx.lineCap='round';sctx.lineJoin='round';sctx.lineWidth=Number($('photo-brush-size').value);sctx.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';sctx.strokeStyle=$('photo-color').value;sctx.lineTo(p.x,p.y);sctx.stroke();start=p;render()}};
canvas.onpointerup=()=>{drawing=false;sctx.globalCompositeOperation='source-over'};
$('photo-apply-crop').onclick=()=>{if(!selection||selection.w<2||selection.h<2)return;snapshot();commitFilters();const x=Math.round(selection.x),y=Math.round(selection.y),w=Math.round(selection.w),h=Math.round(selection.h),out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,x,y,w,h,0,0,w,h);source=out;sctx=source.getContext('2d',{willReadFrequently:true});selection=null;render()};
$('photo-add-text').onclick=()=>{if(!loaded)return;const text=$('photo-text').value.trim();if(!text)return;snapshot();commitFilters();sctx.save();sctx.font=`700 ${Number($('photo-font-size').value)}px Segoe UI,Arial`;sctx.textAlign='center';sctx.textBaseline='middle';sctx.fillStyle=$('photo-color').value;sctx.fillText(text,source.width/2,source.height/2);sctx.restore();render()};
$('photo-resize').onclick=()=>{if(!loaded)return;const w=Math.max(1,Number($('photo-width').value)),h=Math.max(1,Number($('photo-height').value));snapshot();commitFilters();const out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,0,0,w,h);source=out;sctx=source.getContext('2d',{willReadFrequently:true});render()};
$('photo-undo').onclick=()=>{if(!history.length||!loaded)return;future.push(source.toDataURL('image/png'));restore(history.pop())};$('photo-redo').onclick=()=>{if(!future.length||!loaded)return;history.push(source.toDataURL('image/png'));restore(future.pop())};$('photo-reset').onclick=()=>{if(original){snapshot();restore(original)}};
$('photo-brush-size').oninput=e=>$('photo-brush-size-value').textContent=e.target.value+' px';
$('photo-export').onclick=()=>{if(!loaded)return;const savedSelection=selection;selection=null;render();const format=$('photo-format').value,mime=format==='jpg'?'image/jpeg':'image/png',name='EBRA-image-'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.'+format;canvas.toBlob(blob=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);selection=savedSelection;render()},mime,Number($('photo-quality').value)/100)};
setTool('crop');
window.addEventListener('resize',()=>{if(loaded)fitCanvas()});
})();
