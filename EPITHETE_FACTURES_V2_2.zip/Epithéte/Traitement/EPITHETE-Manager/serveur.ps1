﻿param([int]$Port=8776,[string]$DataDirectory='')
$ErrorActionPreference='Stop';$utf8=New-Object Text.UTF8Encoding($false);$root=Join-Path $PSScriptRoot 'web'
if ([string]::IsNullOrWhiteSpace($DataDirectory)) {$DataDirectory='\\uf11-A02\EIDS_EPITHETE_BO_CONSEILLERS\EPT\data'}
try {[IO.Directory]::CreateDirectory($DataDirectory)|Out-Null} catch {throw "Impossible d'ouvrir le dossier de données : $DataDirectory. $($_.Exception.Message)"}
$db=Join-Path $DataDirectory 'epithete-traitements.json';$lock=Join-Path $DataDirectory 'epithete.verrou';$configPath=Join-Path $DataDirectory 'epithete-config.json'
$legacyDirectory=Join-Path (Split-Path $PSScriptRoot -Parent) 'data';$legacyDb=Join-Path $legacyDirectory 'epithete-traitements.json';$legacyConfig=Join-Path $legacyDirectory 'epithete-config.json'
if(-not [IO.File]::Exists($db) -and [IO.File]::Exists($legacyDb) -and $legacyDb -ne $db){Copy-Item -LiteralPath $legacyDb -Destination $db -Force}
if(-not [IO.File]::Exists($configPath) -and [IO.File]::Exists($legacyConfig) -and $legacyConfig -ne $configPath){Copy-Item -LiteralPath $legacyConfig -Destination $configPath -Force}
function Read-Json($path,$fallback){if(-not [IO.File]::Exists($path)){return $fallback};try{$raw=[IO.File]::ReadAllText($path,$utf8);if([string]::IsNullOrWhiteSpace($raw)){return $fallback};return $raw|ConvertFrom-Json}catch{return $fallback}}
function Write-Json($path,$value){$json=ConvertTo-Json -InputObject $value -Depth 12;$bytes=$utf8.GetBytes($json);$h=[IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);try{$h.Position=0;$h.Write($bytes,0,$bytes.Length);$h.SetLength($bytes.Length);$h.Flush($true)}finally{$h.Dispose()}}
function Read-Records{$value=Read-Json $db @();if($null -eq $value){return @()};$flat=@();foreach($item in @($value)){if($item -is [Array]){$flat+=@($item)}else{$flat+=$item}};return $flat}
function Save-Records($rows){Write-Json $db @($rows)}
function Get-Config{$c=Read-Json $configPath $null;if($null -eq $c){$source='\\uf11-A01\EIDS_EPITHETE_BO_MANAGERS\Source';$c=[pscustomobject]@{sourceDirectory=$source;agents=@()}};if($null -eq $c.agents){Field $c 'agents' @()};return $c}
function With-Lock([scriptblock]$action){$g=$null;for($i=0;$i-lt 80-and $null-eq $g;$i++){try{$g=[IO.File]::Open($lock,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{Start-Sleep -Milliseconds 100}};if($null-eq $g){throw 'Données occupées. Réessayez.'};try{&$action}finally{$g.Dispose()}}
function Norm([string]$s){if($null-eq $s){return ''};$d=$s.Normalize([Text.NormalizationForm]::FormD);return (($d.ToCharArray()|Where-Object{[Globalization.CharUnicodeInfo]::GetUnicodeCategory($_)-ne 'NonSpacingMark'})-join '').ToLowerInvariant().Trim()}
function Text($v){if($null-eq $v){return ''};return [string]$v}
function Field($record,$name,$value){$record|Add-Member -NotePropertyName $name -NotePropertyValue $value -Force}
function Get-InvoiceHeader($sheet) {
 $used=$sheet.UsedRange;$lastRow=[int]$used.Row+[int]$used.Rows.Count-1;$lastCol=[int]$used.Column+[int]$used.Columns.Count-1
 for($row=1;$row-le [Math]::Min($lastRow,60);$row++) {
  $number=0;$motif=0;$etat=0;$headers=@()
  for($col=1;$col-le $lastCol;$col++) {
   $label=(Text $sheet.Cells.Item($row,$col).Text).Trim();$normalized=(Norm $label)-replace '\s+',' '
   $headers+=,[pscustomobject]@{column=$col;label=$label}
   if($normalized -in @('numero','numero de facture','n° facture','n° de facture')){$number=$col}
   if($normalized -eq 'motif'){$motif=$col}
   if($normalized -match '^etat (du |de )?traitement'){$etat=$col}
  }
  if($number) {return [pscustomobject]@{row=$row;lastRow=$lastRow;lastCol=$lastCol;number=$number;motif=$motif;etat=$etat;headers=$headers}}
 }
 return $null
}
function Import-ExcelFiles {
 $cfg=Get-Config;$folder=[string]$cfg.sourceDirectory;if(-not [IO.Directory]::Exists($folder)){throw "Dossier source introuvable : $folder"}
 $files=@(Get-ChildItem -LiteralPath $folder -File|Where-Object{$_.Extension -in @('.xlsx','.xlsm','.xls') -and -not $_.Name.StartsWith('~$')})
 if(-not $files.Count){throw 'Aucun fichier Excel trouvé dans Source à traiter.'}
 $excel=$null;$added=0;$duplicates=0;$errors=@();[array]$existing=@(Read-Records);$known=@{}
 foreach($record in $existing){if($record.numeroFacture){$known[([string]$record.sourcePath+'|FACTURE|'+([string]$record.numeroFacture).Trim())]=$record}}
 try {
  $excel=New-Object -ComObject Excel.Application;$excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.AutomationSecurity=3
  foreach($file in $files) {
   $book=$null
   try {
    $book=$excel.Workbooks.Open($file.FullName,$null,$true);$candidates=@();$seen=@{}
    foreach($sheet in @($book.Worksheets)){$h=Get-InvoiceHeader $sheet;if($h){$candidates+=,[pscustomobject]@{sheet=$sheet;header=$h;priority=([int]([bool]$h.motif)+[int]([bool]$h.etat))}}}
    if(-not $candidates.Count){$errors+="En-tête Numéro introuvable dans $($file.Name)";continue}
    foreach($candidate in @($candidates|Sort-Object priority -Descending)) {
     $sheet=$candidate.sheet;$h=$candidate.header
     for($row=$h.row+1;$row-le $h.lastRow;$row++) {
      $number=(Text $sheet.Cells.Item($row,$h.number).Text).Trim();if(-not $number){continue}
      if($seen.ContainsKey($number)){$duplicates++;continue};$seen[$number]=$true
      $key=$file.FullName+'|FACTURE|'+$number;if($known.ContainsKey($key)){continue}
      $cells=@();$client='';$type='';$motif='';$etat=''
      foreach($column in $h.headers) {
       if(-not $column.label){continue};$cell=$sheet.Cells.Item($row,$column.column);$display=(Text $cell.Text).Trim();$raw=$cell.Value2
       $cells+=,[pscustomobject]@{column=$column.column;label=$column.label;text=$display;value=$raw;numberFormat=(Text $cell.NumberFormat)}
       $label=(Norm $column.label)-replace '\s+',' '
       if($label-eq 'client'){$client=$display};if($label-eq 'type de document'){$type=$display}
       if($column.column-eq $h.motif){$motif=$display};if($column.column-eq $h.etat){$etat=$display}
      }
      $now=[DateTimeOffset]::Now.ToString('o')
      $record=[pscustomobject]@{id=[guid]::NewGuid().ToString();schema='factures-v2';sourceKey=$key;sourceFile=$file.Name;sourcePath=$file.FullName;sourceSheet=$sheet.Name;sourceRow=$row;sourceHeaderRow=$h.row;sourceValues=$cells;numeroFacture=$number;raisonSociale=$client;siret='';typeFacture=$type;dateLimite='';motif=$motif;etatTraitement=$etat;agent='';statut='À affecter';dateImport=$now;dateAffectation=$null;datePriseEnCharge=$null;dateFin=$null;dmtSecondes=$null;journal=@([pscustomobject]@{date=$now;auteur=$env:USERNAME;action='Import facture';detail=$file.Name})}
      $existing+=$record;$known[$key]=$record;$added++
     }
    }
   } catch {$errors+="$($file.Name) : $($_.Exception.Message)"}
   finally {if($book){$book.Close($false);[Runtime.InteropServices.Marshal]::ReleaseComObject($book)|Out-Null}}
  }
 } finally {if($excel){$excel.Quit();[Runtime.InteropServices.Marshal]::ReleaseComObject($excel)|Out-Null}}
 Save-Records $existing;return @{ok=$true;ajoutees=$added;fichiers=$files.Count;doublonsIgnores=$duplicates;erreurs=$errors}
}
function Export-CompletedRows {
 [array]$records=@(Read-Records);[array]$completed=@($records|Where-Object{$_.dateFin -and $_.numeroFacture -and $_.sourcePath -and $_.sourceSheet})
 if(-not $completed.Count){throw 'Aucune facture terminée à exporter.'}
 $excel=$null;$exported=0;$filesSaved=0;$errors=@()
 try {
  $excel=New-Object -ComObject Excel.Application;$excel.Visible=$false;$excel.DisplayAlerts=$false;$excel.AutomationSecurity=3
  foreach($group in @($completed|Group-Object sourcePath)) {
   $path=[string]$group.Name;if(-not [IO.File]::Exists($path)){$errors+="Fichier introuvable : $path";continue}
   $book=$null;$savedRows=@()
   try {
    $book=$excel.Workbooks.Open($path);if($book.ReadOnly){throw 'Fichier ouvert en lecture seule. Fermez-le dans Excel avant de réessayer.'}
    foreach($sheetGroup in @($group.Group|Group-Object sourceSheet)) {
     $sheet=$null;try{$sheet=$book.Worksheets.Item([string]$sheetGroup.Name)}catch{$errors+="Feuille introuvable : $($sheetGroup.Name)";continue}
     $h=Get-InvoiceHeader $sheet;if(-not $h){$errors+="En-tête Numéro introuvable : $($sheetGroup.Name)";continue}
     $targets=@{}
     for($row=$h.row+1;$row-le $h.lastRow;$row++){$num=(Text $sheet.Cells.Item($row,$h.number).Text).Trim();if($num){if(-not $targets.ContainsKey($num)){$targets[$num]=@()};$targets[$num]+=,$row}}
     $valid=@();foreach($record in @($sheetGroup.Group)){$num=([string]$record.numeroFacture).Trim();if(-not $targets.ContainsKey($num)-or @($targets[$num]).Count-ne 1){$errors+="Facture $num absente ou présente plusieurs fois dans $($sheetGroup.Name). Aucun écrasement.";continue};$valid+=,$record}
     if(-not $valid.Count){continue}
     if(-not $h.motif){$h.lastCol++;$h.motif=$h.lastCol;$sheet.Cells.Item($h.row,$h.motif).Value2='MOTIF'}
     if(-not $h.etat){$h.lastCol++;$h.etat=$h.lastCol;$sheet.Cells.Item($h.row,$h.etat).Value2='Etat du traitement ( noter Traité)'}
     foreach($record in $valid) {
      $target=[int]$targets[([string]$record.numeroFacture).Trim()][0]
      $sheet.Cells.Item($target,$h.motif).Value2=(Text $record.motif)
      $sheet.Cells.Item($target,$h.etat).Value2=(Text $record.etatTraitement)
      $savedRows+=,$record
     }
    }
    if($savedRows.Count){$book.Save();$filesSaved++;$exported+=$savedRows.Count;foreach($record in $savedRows){Field $record 'dateExport' ([DateTimeOffset]::Now.ToString('o'))}}
   } catch {$errors+="Impossible d'enregistrer ${path} : $($_.Exception.Message)"}
   finally {if($book){$book.Close($false);[Runtime.InteropServices.Marshal]::ReleaseComObject($book)|Out-Null}}
  }
 } finally {if($excel){$excel.Quit();[Runtime.InteropServices.Marshal]::ReleaseComObject($excel)|Out-Null}}
 Save-Records $records;return @{ok=$true;exportees=$exported;fichiers=$filesSaved;erreurs=$errors}
}
function State{[array]$rows=@(Read-Records);$cfg=Get-Config;$agents=@(@($cfg.agents)+@($rows|ForEach-Object{$_.agent})|Where-Object{$_}|Sort-Object -Unique);return @{application='EPITHETE MANAGER';version='2.0.0';collaborateur=$env:USERNAME;config=$cfg;agents=$agents;traitements=$rows;actualiseLe=[DateTimeOffset]::Now.ToString('o')}}
function Post($path,$data){
 if($path-eq'/api/config'){if([string]::IsNullOrWhiteSpace([string]$data.sourceDirectory)){throw 'Chemin source obligatoire.'};$cfg=Get-Config;Field $cfg 'sourceDirectory' ([string]$data.sourceDirectory);Write-Json $configPath $cfg;return @{ok=$true}}
 if($path-eq'/api/agents'){ $name=([string]$data.name).Trim().ToUpperInvariant();if(-not $name){throw 'Nom agent obligatoire.'};$cfg=Get-Config;Field $cfg 'agents' (@(@($cfg.agents)+$name)|Sort-Object -Unique);Write-Json $configPath $cfg;return @{ok=$true;name=$name}}
 if($path-eq'/api/import'){return With-Lock {Import-ExcelFiles}}
 if($path-eq'/api/export'){return With-Lock {Export-CompletedRows}}
 if($path-eq'/api/assign'){return With-Lock {[array]$rows=@(Read-Records);$ids=@($data.ids);$agent=([string]$data.agent).Trim();if(-not $agent){throw 'Nom de l agent obligatoire.'};$count=0;foreach($r in $rows){if($r.id-in $ids-and -not $r.agent-and -not $r.dateFin){Field $r 'agent' $agent;Field $r 'statut' 'Affecté';Field $r 'dateAffectation' ([DateTimeOffset]::Now.ToString('o'));Field $r 'journal' (@($r.journal)+[pscustomobject]@{date=[DateTimeOffset]::Now.ToString('o');auteur=$env:USERNAME;action='Affectation';detail=$agent});$count++}};Save-Records $rows;@{ok=$true;affectees=$count}}}
 throw 'Action inconnue.'
}
$listener=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$Port);$shutdown=$false
try{$listener.Start();while(-not$shutdown){$client=$listener.AcceptTcpClient();$stream=$client.GetStream();try{$reader=New-Object IO.StreamReader($stream,[Text.Encoding]::ASCII,$false,4096,$true);$line=$reader.ReadLine();if(-not$line){continue};$parts=$line-split' ';$method=$parts[0];$path=$parts[1];$headers=@{};while(($h=$reader.ReadLine())-ne''){if($h.Contains(':')){$p=$h-split':',2;$headers[$p[0].ToLower()]=$p[1].Trim()}};$len=if($headers['content-length']){[int]$headers['content-length']}else{0};$body=New-Object char[] $len;if($len){[void]$reader.ReadBlock($body,0,$len)};$status='200 OK';$type='application/json; charset=utf-8';if($method-eq'GET'-and$path-eq'/api/state'){$result=State}elseif($method-eq'GET'-and$path-eq'/api/health'){$result=@{application='EPITHETE MANAGER';version='2.0.0'}}elseif($method-eq'POST'-and$path-eq'/api/shutdown'){$result=@{ok=$true};$shutdown=$true}elseif($method-eq'POST'){$result=Post $path ((-join$body)|ConvertFrom-Json)}elseif($path-eq'/'-or$path-match'^/(app.js|style.css)$'){$name=if($path-eq'/'){'index.html'}else{$path.TrimStart('/')};$bytes=[IO.File]::ReadAllBytes((Join-Path $root $name));$type=if($name.EndsWith('.css')){'text/css'}elseif($name.EndsWith('.js')){'text/javascript'}else{'text/html'}}else{$status='404 Not Found';$result=@{erreur='Introuvable'}};if(-not$bytes){$bytes=$utf8.GetBytes(($result|ConvertTo-Json -Depth 12))}}catch{$status='400 Bad Request';$type='application/json';$bytes=$utf8.GetBytes((@{erreur=$_.Exception.Message}|ConvertTo-Json))};$head=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n");$stream.Write($head,0,$head.Length);$stream.Write($bytes,0,$bytes.Length);$client.Close();$bytes=$null}}finally{$listener.Stop()}
