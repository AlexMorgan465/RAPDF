function Get-AgentPresence {
    $historyPaths=if($null -ne $script:mailHistoryPaths){@($script:mailHistoryPaths)}else{@($script:mailHistoryPath)}
    $presencePaths=@($historyPaths|ForEach-Object{Join-Path ([IO.Path]::GetDirectoryName([string]$_)) 'agents-presence.json'}|Select-Object -Unique)
    $latest=@{}
    foreach($presencePath in $presencePaths){
        if(-not [IO.File]::Exists($presencePath)){continue}
        try{
            $raw=[IO.File]::ReadAllText($presencePath,$utf8)
            if([string]::IsNullOrWhiteSpace($raw)){continue}
            foreach($item in @($raw|ConvertFrom-Json)){
                if($null -eq $item){continue}
                $key=if(-not [string]::IsNullOrWhiteSpace([string]$item.cle)){[string]$item.cle}else{([string]$item.poste+'|'+[string]$item.collaborateur).ToLowerInvariant()}
                $when=try{[DateTimeOffset]::Parse([string]$item.derniereActivite)}catch{[DateTimeOffset]::MinValue}
                if(-not $latest.ContainsKey($key) -or $when -gt $latest[$key].when){$latest[$key]=@{when=$when;item=$item}}
            }
        }catch{}
    }
    $now=[DateTimeOffset]::Now
    $agents=foreach($entry in $latest.Values){
        $age=[Math]::Max(0,[Math]::Floor(($now-$entry.when).TotalSeconds))
        [pscustomobject]@{collaborateur=[string]$entry.item.collaborateur;poste=[string]$entry.item.poste;derniereActivite=$entry.when.ToString('o');secondes=$age;enLigne=([string]$entry.item.statut -eq 'En ligne' -and $age -le 60)}
    }
    return @{agents=@($agents|Sort-Object @{Expression='enLigne';Descending=$true},collaborateur);actualiseLe=$now.ToString('o');delaiEnLigneSecondes=60}
}
