function Read-Community {
    if ([string]::IsNullOrWhiteSpace([string]$script:communityPath) -or -not [IO.File]::Exists($script:communityPath)) { return @() }
    try {
        $raw=[IO.File]::ReadAllText($script:communityPath,$utf8)
        if([string]::IsNullOrWhiteSpace($raw)){return @()}
        $parsed=$raw|ConvertFrom-Json
        return @($parsed|Where-Object{$null -ne $_ -and $_ -isnot [string] -and $_.PSObject.Properties['id'] -and $_.PSObject.Properties['message']})
    } catch { throw 'Le fichier communaute.json est invalide. Renommez-le puis reessayez.' }
}
function Write-Community($rows) {
    $json=ConvertTo-Json -InputObject @($rows) -Depth 6
    $bytes=$utf8.GetBytes($json);$handle=[IO.File]::Open($script:communityPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try{$handle.Position=0;$handle.Write($bytes,0,$bytes.Length);$handle.SetLength($bytes.Length);$handle.Flush($true)}finally{$handle.Dispose()}
}
function Add-CommunityEvent($eventType,$eventMessage,$subject,$treatmentId) {
    $directory=[IO.Path]::GetDirectoryName($script:communityPath);[IO.Directory]::CreateDirectory($directory)|Out-Null
    $lock=Join-Path $directory 'communaute.verrou';$guard=$null
    for($i=0;$i -lt 50 -and $null -eq $guard;$i++){try{$guard=[IO.File]::Open($lock,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch [IO.IOException]{Start-Sleep -Milliseconds 100}}
    if($null -eq $guard){throw 'Communaute occupee. Reessayez dans quelques secondes.'}
    try{
        $event=[pscustomobject][ordered]@{id=[guid]::NewGuid().ToString();date=[DateTimeOffset]::Now.ToString('o');auteur=[string]$env:USERNAME;profil=[string]$script:applicationRole;type=[string]$eventType;message=[string]$eventMessage;sujet=[string]$subject;traitementId=[string]$treatmentId}
        $rows=@($event)+@(Read-Community);$rows=@($rows|Where-Object{$null -ne $_}|Select-Object -First 5000)
        Write-Community $rows
        return $event
    }finally{$guard.Dispose()}
}
function Get-Community {$items=@(Read-Community);return @{messages=$items;collaborateur=[string]$env:USERNAME}}
function Send-CommunityMessage($data) {
    $value=[string]$data.message
    if([string]::IsNullOrWhiteSpace($value) -or $value.Trim().Length -gt 1000){throw 'Le message doit contenir entre 1 et 1000 caracteres.'}
    $created=Add-CommunityEvent 'Message' ($value.Trim()) '' ''
    return @{ok=$true;created=$created}
}
