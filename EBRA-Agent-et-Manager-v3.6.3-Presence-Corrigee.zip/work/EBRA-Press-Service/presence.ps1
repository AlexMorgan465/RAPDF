function Read-AgentPresence {
    if (-not [IO.File]::Exists($script:presencePath)) { return @() }
    try {
        $raw=[IO.File]::ReadAllText($script:presencePath,$utf8)
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw|ConvertFrom-Json)
    } catch { return @() }
}

function Set-AgentPresence([bool]$online) {
    $directory=[IO.Path]::GetDirectoryName($script:presencePath)
    [IO.Directory]::CreateDirectory($directory)|Out-Null
    $lockFile=Join-Path $directory 'agents-presence.verrou'
    $guard=$null
    for($attempt=0;$attempt -lt 30 -and $null -eq $guard;$attempt++){
        try{$guard=[IO.File]::Open($lockFile,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch [IO.IOException]{Start-Sleep -Milliseconds 100}
    }
    if($null -eq $guard){return @{ok=$false}}
    try{
        $now=[DateTimeOffset]::Now
        $key=([string]$env:COMPUTERNAME+'|'+[string]$env:USERNAME).ToLowerInvariant()
        $rows=@(Read-AgentPresence|Where-Object{
            if($null -eq $_){return $false}
            try{($now-[DateTimeOffset]::Parse([string]$_.derniereActivite)).TotalDays -lt 7}catch{return $false}
        })
        $rows=@($rows|Where-Object{([string]$_.cle).ToLowerInvariant() -ne $key})
        $rows=@([pscustomobject][ordered]@{cle=$key;collaborateur=[string]$env:USERNAME;poste=[string]$env:COMPUTERNAME;statut=if($online){'En ligne'}else{'Hors ligne'};derniereActivite=$now.ToString('o')})+@($rows)
        $json=ConvertTo-Json -InputObject @($rows) -Depth 4
        $bytes=$utf8.GetBytes($json)
        $handle=[IO.File]::Open($script:presencePath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        try{$handle.Position=0;$handle.Write($bytes,0,$bytes.Length);$handle.SetLength($bytes.Length);$handle.Flush($true)}finally{$handle.Dispose()}
        return @{ok=$true;collaborateur=$env:USERNAME;statut=if($online){'En ligne'}else{'Hors ligne'};date=$now.ToString('o')}
    } finally {$guard.Dispose()}
}
