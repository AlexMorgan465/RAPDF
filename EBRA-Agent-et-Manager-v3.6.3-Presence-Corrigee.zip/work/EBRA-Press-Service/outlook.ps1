function Get-OutlookSession {
    try {
        $app = New-Object -ComObject Outlook.Application
        return @{ App = $app; Namespace = $app.GetNamespace('MAPI') }
    } catch {
        throw "Outlook classique est introuvable ou aucun profil Outlook n'est configure sur ce poste."
    }
}

function Get-MailConfig {
    if (-not [IO.File]::Exists($script:mailConfigPath)) {
        return [pscustomobject]@{ storeId=''; sourceFolderId=''; destinationFolderId='' }
    }
    try { return [IO.File]::ReadAllText($script:mailConfigPath, $utf8) | ConvertFrom-Json }
    catch { throw 'La configuration Outlook locale est invalide.' }
}

function Save-MailConfig($data) {
    $value = [ordered]@{
        storeId = [string]$data.storeId
        sourceFolderId = [string]$data.sourceFolderId
        destinationFolderId = [string]$data.destinationFolderId
    }
    [IO.File]::WriteAllText($script:mailConfigPath, (ConvertTo-Json $value), $utf8)
    return @{ ok=$true }
}

function Read-OutlookHistory {
    if ([string]::IsNullOrWhiteSpace([string]$script:mailHistoryPath) -or -not [IO.File]::Exists($script:mailHistoryPath)) { return @() }
    try {
        $raw=[IO.File]::ReadAllText($script:mailHistoryPath,$utf8)
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw | ConvertFrom-Json)
    } catch { throw 'Historique Outlook illisible.' }
}

function Add-OutlookHistory($action, $data, $detail) {
    if ([string]::IsNullOrWhiteSpace([string]$script:mailHistoryPath)) { return }
    $directory=[IO.Path]::GetDirectoryName($script:mailHistoryPath)
    [IO.Directory]::CreateDirectory($directory) | Out-Null
    $lockPath=Join-Path $directory 'outlook-historique.verrou'
    $guard=$null
    for ($attempt=0; $attempt -lt 50 -and $null -eq $guard; $attempt++) {
        try { $guard=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
        catch [IO.IOException] { Start-Sleep -Milliseconds 100 }
    }
    if ($null -eq $guard) { return }
    try {
        $rows=@(Read-OutlookHistory)
        $event=[pscustomobject]@{
            id=[guid]::NewGuid().ToString(); date=[DateTimeOffset]::Now.ToString('o')
            collaborateur=$env:USERNAME; profil=[string]$script:applicationRole
            action=[string]$action; sujet=[string]$data.subject
            expediteur=[string]$data.sender; emailEntryId=[string]$data.entryId
            boite=[string]$data.mailboxName; dossierSource=[string]$data.sourceFolderName
            dossierDestination=[string]$data.destinationFolderName; detail=[string]$detail
        }
        $rows=@(@($event)+@($rows) | Select-Object -First 10000)
        $json=ConvertTo-Json -InputObject @($rows) -Depth 6
        $bytes=$utf8.GetBytes($json)
        $handle=[IO.File]::Open($script:mailHistoryPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        try { $handle.Position=0; $handle.Write($bytes,0,$bytes.Length); $handle.SetLength($bytes.Length); $handle.Flush($true) }
        finally { $handle.Dispose() }
    } finally { $guard.Dispose() }
}

function Get-OutlookHistory { return @{ events=@(Read-OutlookHistory) } }

function Add-OutlookFolders($folder, $prefix, $rows) {
    $path = if ($prefix) { "$prefix / $($folder.Name)" } else { [string]$folder.Name }
    $rows.Add([pscustomobject]@{ id=[string]$folder.EntryID; name=[string]$folder.Name; path=$path })
    foreach ($child in @($folder.Folders)) { Add-OutlookFolders $child $path $rows }
}

function Get-MailState {
    $session = Get-OutlookSession
    $stores = New-Object 'System.Collections.Generic.List[object]'
    foreach ($store in @($session.Namespace.Stores)) {
        $stores.Add([pscustomobject]@{ id=[string]$store.StoreID; name=[string]$store.DisplayName })
    }
    return @{ collaborateur=$env:USERNAME; config=(Get-MailConfig); mailboxes=$stores.ToArray() }
}

function Get-MailFolders($data) {
    $session = Get-OutlookSession
    $store = @($session.Namespace.Stores) | Where-Object { $_.StoreID -eq [string]$data.storeId } | Select-Object -First 1
    if (-not $store) { throw 'Boite Outlook introuvable.' }
    $rows = New-Object 'System.Collections.Generic.List[object]'
    Add-OutlookFolders ($store.GetRootFolder()) '' $rows
    return @{ folders=$rows.ToArray() }
}

function Get-MailItem($namespace, $entryId, $storeId) {
    try { return $namespace.GetItemFromID([string]$entryId, [string]$storeId) }
    catch { throw 'E-mail introuvable. Actualisez la messagerie.' }
}

function Get-MailMessages($data, $claims) {
    $session = Get-OutlookSession
    try { $folder = $session.Namespace.GetFolderFromID([string]$data.folderId, [string]$data.storeId) }
    catch { throw 'Dossier Outlook introuvable.' }
    $items = $folder.Items
    $items.Sort('[ReceivedTime]', $true)
    $limit = [Math]::Min(200, [Math]::Max(1, [int]$data.limit))
    $rows = New-Object 'System.Collections.Generic.List[object]'
    $count = [Math]::Min($limit, $items.Count)
    for ($i=1; $i -le $count; $i++) {
        $mail = $items.Item($i)
        if ($null -eq $mail -or $mail.Class -ne 43) { continue }
        $attachments = New-Object 'System.Collections.Generic.List[object]'
        for ($j=1; $j -le $mail.Attachments.Count; $j++) {
            $att=$mail.Attachments.Item($j)
            $attachments.Add([pscustomobject]@{ index=$j; name=[string]$att.FileName })
        }
        $claim = $claims[[string]$mail.EntryID]
        $preview = [string]$mail.Body
        if ($preview.Length -gt 500) { $preview=$preview.Substring(0,500) }
        $rows.Add([pscustomobject]@{
            id=[string]$mail.EntryID; storeId=[string]$data.storeId; subject=[string]$mail.Subject
            sender=[string]$mail.SenderName; senderEmail=[string]$mail.SenderEmailAddress
            received=$mail.ReceivedTime.ToString('o'); unread=[bool]$mail.UnRead; preview=$preview
            attachments=$attachments.ToArray(); claim=$claim
        })
    }
    return @{ messages=$rows.ToArray(); folder=[string]$folder.Name }
}

function Invoke-MailAction($data) {
    $session=Get-OutlookSession
    $mail=Get-MailItem $session.Namespace $data.entryId $data.storeId
    switch ([string]$data.action) {
        'open' { $mail.Display(); Add-OutlookHistory 'Ouverture' $data ''; return @{ok=$true} }
        'reply' { $mail.Reply().Display(); Add-OutlookHistory 'Réponse ouverte' $data ''; return @{ok=$true} }
        'forward' { $mail.Forward().Display(); Add-OutlookHistory 'Transfert ouvert' $data ''; return @{ok=$true} }
        'move' {
            if ([string]::IsNullOrWhiteSpace([string]$data.destinationFolderId)) { throw 'Selectionnez un dossier destination.' }
            $destination=$session.Namespace.GetFolderFromID([string]$data.destinationFolderId,[string]$data.storeId)
            [void]$mail.Move($destination); Add-OutlookHistory 'Déplacement' $data ([string]$destination.Name); return @{ok=$true}
        }
        'attachment' {
            $index=[int]$data.attachmentIndex
            if ($index -lt 1 -or $index -gt $mail.Attachments.Count) { throw 'Piece jointe introuvable.' }
            $attachment=$mail.Attachments.Item($index)
            $safeName=[IO.Path]::GetFileName([string]$attachment.FileName)
            $folder=Join-Path ([IO.Path]::GetTempPath()) 'EBRA-Outlook'
            [IO.Directory]::CreateDirectory($folder) | Out-Null
            $target=Join-Path $folder (([guid]::NewGuid().ToString('N'))+'-'+$safeName)
            $attachment.SaveAsFile($target)
            Start-Process -FilePath $target
            Add-OutlookHistory 'Pièce jointe ouverte' $data $safeName
            return @{ok=$true}
        }
        default { throw 'Action Outlook inconnue.' }
    }
}
