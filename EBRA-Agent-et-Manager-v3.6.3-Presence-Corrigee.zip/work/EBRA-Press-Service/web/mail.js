'use strict';
let mailState={mailboxes:[],config:{},folders:[],messages:[]};
const mailDate=value=>value?new Date(value).toLocaleString('fr-FR'):'—';
function mailNotice(text,error=false){message(text,error)}
async function loadMailState(){
 const next=await api('mail/state');mailState={...mailState,...next};
 const box=$('mailbox');box.replaceChildren(new Option('Sélectionner une boîte',''));
 next.mailboxes.forEach(item=>box.add(new Option(item.name,item.id)));
 box.value=next.config.storeId||'';
 if(box.value)await loadMailFolders(true);
}
async function loadMailFolders(refreshMessages=true){
 const storeId=$('mailbox').value;if(!storeId)return;
 const result=await api('mail/folders',{storeId});mailState.folders=result.folders;
 for(const id of ['source-folder','destination-folder']){const select=$(id),selected=id==='source-folder'?mailState.config.sourceFolderId:mailState.config.destinationFolderId;select.replaceChildren(new Option('Sélectionner un dossier',''));result.folders.forEach(folder=>select.add(new Option(folder.path,folder.id)));select.value=selected||'';}
 if(refreshMessages&&$('source-folder').value)await loadMessages();
}
async function saveMailConfig(){
 const config={storeId:$('mailbox').value,sourceFolderId:$('source-folder').value,destinationFolderId:$('destination-folder').value};
 if(!config.storeId||!config.sourceFolderId||!config.destinationFolderId)throw Error('Choisissez une boîte, un dossier source et un dossier destination.');
 await api('mail/config',config);mailState.config=config;await loadMessages();mailNotice('Configuration Outlook enregistrée.');
}
async function loadMessages(){
 const storeId=$('mailbox').value,folderId=$('source-folder').value;if(!storeId||!folderId)return;
 const result=await api('mail/messages',{storeId,folderId,limit:100});mailState.messages=result.messages;renderMessages();
}
function renderMessages(){
 const list=$('mail-list');list.replaceChildren();const q=$('mail-search').value.trim().toLocaleLowerCase('fr');
 const rows=mailState.messages.filter(m=>!q||[m.subject,m.sender,m.senderEmail,m.preview].join(' ').toLocaleLowerCase('fr').includes(q));
 for(const mail of rows){const card=document.createElement('article');card.className='mail-item'+(mail.unread?' unread':'');const head=document.createElement('div');head.className='mail-head';const info=document.createElement('div');const title=document.createElement('h3');title.textContent=mail.subject||'(Sans objet)';const meta=document.createElement('p');meta.textContent=(mail.sender||mail.senderEmail||'Expéditeur inconnu')+' · '+mailDate(mail.received);info.append(title,meta);const claim=document.createElement('span');claim.className='mail-claim '+(mail.claim?'claimed':'free');claim.textContent=mail.claim?'Pris en charge par '+mail.claim.collaborateur:'Disponible';head.append(info,claim);const preview=document.createElement('p');preview.className='mail-preview';preview.textContent=mail.preview||'';const attachments=document.createElement('div');attachments.className='mail-attachments';for(const att of mail.attachments||[]){const button=document.createElement('button');button.className='attachment';button.textContent='📎 '+att.name;button.onclick=()=>mailAction(mail,'attachment',{attachmentIndex:att.index});attachments.append(button)}const actions=document.createElement('div');actions.className='mail-actions';for(const [label,action] of [['Ouvrir','open'],['Répondre','reply'],['Transférer','forward'],['Déplacer','move']]){const button=document.createElement('button');button.className='secondary';button.textContent=label;button.onclick=()=>mailAction(mail,action);actions.append(button)}const ownClaim=mail.claim&&mail.claim.collaborateur===mailState.collaborateur;const take=document.createElement('button');take.className=ownClaim?'secondary':'primary';take.textContent=ownClaim?'Libérer':mail.claim?'Déjà pris en charge':'Prendre en charge';take.disabled=!!mail.claim&&!ownClaim;take.onclick=()=>ownClaim?releaseMail(mail):claimMail(mail);actions.append(take);card.append(head,preview,attachments,actions);list.append(card)}$('mail-empty').hidden=rows.length>0;$('mail-count').textContent=rows.length+' e-mail(s)';
}
function mailMetadata(mail){const selected=id=>{const el=$(id);return el&&el.selectedIndex>=0?el.options[el.selectedIndex].text:''};return{entryId:mail.id,storeId:mail.storeId,subject:mail.subject,sender:mail.sender||mail.senderEmail,mailboxName:selected('mailbox'),sourceFolderName:selected('source-folder'),destinationFolderId:$('destination-folder').value,destinationFolderName:selected('destination-folder')}}
async function mailAction(mail,action,extra={}){try{await api('mail/action',{action,...mailMetadata(mail),...extra});if(action==='move'){mailNotice('E-mail déplacé.');await loadMessages()}}catch(error){mailNotice(error.message,true)}}
async function claimMail(mail){try{await api('mail/claim',mailMetadata(mail));mailNotice('E-mail pris en charge. Un traitement a été créé à votre nom.');await loadMessages();if(typeof refresh==='function')await refresh()}catch(error){mailNotice(error.message,true)}}
async function releaseMail(mail){try{await api('mail/release',mailMetadata(mail));mailNotice('E-mail libéré. Il peut être repris par un autre collaborateur.');await loadMessages();if(typeof refresh==='function')await refresh()}catch(error){mailNotice(error.message,true)}}
let outlookEvents=[];
async function loadMailHistory(){if(!$('outlook-history-rows'))return;const result=await api('mail/history');outlookEvents=result.events||[];renderMailHistory()}
function renderMailHistory(){if(!$('outlook-history-rows'))return;const q=$('outlook-history-search').value.trim().toLocaleLowerCase('fr'),action=$('outlook-history-action').value;const rows=outlookEvents.filter(e=>(!action||e.action===action)&&(!q||[e.collaborateur,e.action,e.sujet,e.expediteur,e.boite,e.dossierSource,e.dossierDestination,e.detail].join(' ').toLocaleLowerCase('fr').includes(q)));const tbody=$('outlook-history-rows');tbody.replaceChildren();for(const e of rows){const tr=document.createElement('tr');for(const value of [mailDate(e.date),e.collaborateur,e.action,e.sujet||'—',e.expediteur||'—',e.boite||'—',[e.dossierSource,e.dossierDestination].filter(Boolean).join(' → ')||'—',e.detail||'—']){const td=document.createElement('td');td.textContent=value;tr.append(td)}tbody.append(tr)}$('outlook-history-empty').hidden=rows.length>0;$('outlook-history-count').textContent=rows.length+' événement(s)'}
$('mailbox').addEventListener('change',()=>loadMailFolders(false).catch(e=>mailNotice(e.message,true)));
$('mail-save').addEventListener('click',()=>saveMailConfig().catch(e=>mailNotice(e.message,true)));
$('mail-refresh').addEventListener('click',()=>loadMessages().catch(e=>mailNotice(e.message,true)));
$('mail-search').addEventListener('input',renderMessages);
if($('outlook-history-search'))$('outlook-history-search').addEventListener('input',renderMailHistory);
if($('outlook-history-action'))$('outlook-history-action').addEventListener('change',renderMailHistory);
if($('outlook-history-refresh'))$('outlook-history-refresh').addEventListener('click',()=>loadMailHistory().catch(e=>mailNotice(e.message,true)));
window.loadMailState=loadMailState;window.loadMailHistory=loadMailHistory;
