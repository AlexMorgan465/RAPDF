ACCESSIBILITY UNIVERSE - TOPOLOGY FIX

Correction majeure du moteur de comptage :
- Recherche des dossiers statut jusqu'a 3 niveaux sous chaque entite.
- DIRCO\\OLD est exclu.
- CONTRATHEQUE est geree : categorie -> statut.
- ACM / CMO / COFIDIS / DIRCO / DIRCOM : arborescences profondes supportees.
- Si un sous-dossier contient un ou plusieurs fichiers => 1 document metier.
- Si des fichiers sont directement dans le dossier statut => chaque fichier = 1 document.
- Le scan continue dans les sous-dossiers meme apres avoir trouve des fichiers.
- Aucun scan automatique : lancer le scan depuis Command Center puis APPLIQUER.

Apres application du scan, Agent Orbit lit le meme index central.
