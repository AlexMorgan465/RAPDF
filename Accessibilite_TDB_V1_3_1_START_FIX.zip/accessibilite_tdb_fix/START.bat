@echo off
setlocal
cd /d "%~dp0"
title TDB Accessibilite - Serveur
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
echo.
echo ============================================================
echo Le serveur s'est arrete. Copiez l'erreur affichee ci-dessus.
echo ============================================================
pause
