V1.3.1 - correction demarrage
- Le scan reseau n'est plus execute avant la boucle HTTP.
- Le serveur devient disponible immediatement sur http://localhost:8787
- Le premier scan est declenche par le dashboard.
- Une erreur de scan n'arrete plus le serveur et remonte dans les metriques.
- START.bat garde la fenetre ouverte si PowerShell rencontre une erreur.
