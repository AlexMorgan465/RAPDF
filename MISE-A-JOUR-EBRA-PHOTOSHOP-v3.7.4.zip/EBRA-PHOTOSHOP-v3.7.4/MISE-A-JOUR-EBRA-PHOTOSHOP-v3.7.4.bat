@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Mise a jour EBRA Photoshop v3.7.4

set "UPDATE=%~dp0"
set "ROOT=%~dp0"

if not exist "%ROOT%EBRA-Manager\web\index.html" (
  if exist "%ROOT%..\EBRA-Manager\web\index.html" set "ROOT=%~dp0..\"
)

if not exist "%ROOT%EBRA-Manager\web\index.html" goto :notfound
if not exist "%ROOT%EBRA-Press-Service\web\index.html" goto :notfound

copy /Y "%UPDATE%patch\photo374.css" "%ROOT%EBRA-Manager\web\photo374.css" >nul || goto :failed
copy /Y "%UPDATE%patch\photo374.js" "%ROOT%EBRA-Manager\web\photo374.js" >nul || goto :failed
copy /Y "%UPDATE%patch\manager-index.html" "%ROOT%EBRA-Manager\web\index.html" >nul || goto :failed
copy /Y "%UPDATE%patch\manager-serveur.ps1" "%ROOT%EBRA-Manager\serveur.ps1" >nul || goto :failed

copy /Y "%UPDATE%patch\photo374.css" "%ROOT%EBRA-Press-Service\web\photo374.css" >nul || goto :failed
copy /Y "%UPDATE%patch\photo374.js" "%ROOT%EBRA-Press-Service\web\photo374.js" >nul || goto :failed
copy /Y "%UPDATE%patch\agent-index.html" "%ROOT%EBRA-Press-Service\web\index.html" >nul || goto :failed
copy /Y "%UPDATE%patch\agent-serverr.ps1" "%ROOT%EBRA-Press-Service\serverr.ps1" >nul || goto :failed

echo.
echo Mise a jour v3.7.4 terminee avec succes.
echo Fermez toutes les fenetres EBRA, puis relancez Agent et Manager.
echo.
pause
exit /b 0

:notfound
echo.
echo ERREUR : EBRA-Manager ou EBRA-Press-Service introuvable.
echo Laissez ce dossier de mise a jour a cote des deux dossiers EBRA.
echo.
pause
exit /b 1

:failed
echo.
echo ERREUR pendant la copie. Fermez EBRA puis recommencez.
echo.
pause
exit /b 1
