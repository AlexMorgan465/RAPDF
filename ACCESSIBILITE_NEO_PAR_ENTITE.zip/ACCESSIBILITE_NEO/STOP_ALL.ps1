$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$current=[Security.Principal.WindowsIdentity]::GetCurrent().Name
foreach($mode in @('agent','manager')){
 $file=Join-Path $base ('data\'+$mode+'.pid')
 if(!(Test-Path -LiteralPath $file)){continue}
 try{
   $id=[int]([IO.File]::ReadAllText($file).Trim())
   $p=Get-CimInstance Win32_Process -Filter "ProcessId=$id"
   if(!$p -or !$p.CommandLine -or !$p.CommandLine.Contains((Join-Path $base ('server-'+$mode+'.ps1')))){continue}
   $owner=$p|Invoke-CimMethod -MethodName GetOwner
   if($owner.ReturnValue -eq 0 -and ($owner.Domain+'\'+$owner.User) -ieq $current){Stop-Process -Id $id -ErrorAction Stop;Remove-Item -LiteralPath $file -Force;Write-Host "$mode arrêté"}
 }catch{Write-Warning $_.Exception.Message}
}
