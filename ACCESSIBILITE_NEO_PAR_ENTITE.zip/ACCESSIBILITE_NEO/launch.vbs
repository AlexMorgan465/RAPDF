Option Explicit
Dim shell, fso, root, mode, port, pid, instance, address, command, i, endpoint
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
mode = "agent"
If WScript.Arguments.Count > 0 Then mode = LCase(WScript.Arguments(0))
If mode <> "agent" And mode <> "manager" Then WScript.Quit
endpoint = root & "\data\" & mode & ".endpoint.json"
If shell.Run("cmd /c where pwsh.exe >nul 2>nul", 0, True) <> 0 Then
  MsgBox "PowerShell 7 est requis. Utilisez START_VISIBLE_" & UCase(mode) & ".bat pour le diagnostic.", vbExclamation, "Accessibilité"
  WScript.Quit
End If
If Not Ready() Then
  command = "pwsh.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & root & "\server-" & mode & ".ps1" & Chr(34)
  shell.Run command, 0, False
  For i = 1 To 80
    WScript.Sleep 250
    If Ready() Then Exit For
  Next
End If
If Ready() Then
  shell.Run address, 1, False
Else
  MsgBox "Démarrage impossible. Lancez START_VISIBLE_" & UCase(mode) & ".bat et consultez data\" & mode & "-error.log", vbExclamation, "Accessibilité"
End If
Function ValueOf(source, key, textValue)
  Dim pattern, hits
  Set pattern = New RegExp
  If textValue Then
    pattern.Pattern = Chr(34) & key & Chr(34) & "\s*:\s*" & Chr(34) & "([^" & Chr(34) & "]+)" & Chr(34)
  Else
    pattern.Pattern = Chr(34) & key & Chr(34) & "\s*:\s*(\d+)"
  End If
  ValueOf = ""
  If pattern.Test(source) Then
    Set hits = pattern.Execute(source)
    ValueOf = hits(0).SubMatches(0)
  End If
End Function
Function Ready()
  On Error Resume Next
  Dim raw, req, response
  Ready = False
  If Not fso.FileExists(endpoint) Then Exit Function
  raw = fso.OpenTextFile(endpoint, 1, False).ReadAll
  port = ValueOf(raw, "port", False)
  pid = ValueOf(raw, "pid", False)
  instance = ValueOf(raw, "instance", True)
  If port = "" Or pid = "" Or instance = "" Then Exit Function
  address = "http://127.0.0.1:" & port & "/"
  Set req = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  req.setTimeouts 350, 350, 350, 350
  req.Open "GET", address & "api/health", False
  req.Send
  If Err.Number = 0 And req.Status = 200 Then
    response = req.responseText
    Ready = (ValueOf(response, "mode", True) = mode And ValueOf(response, "pid", False) = pid And ValueOf(response, "instance", True) = instance)
  End If
  Err.Clear
End Function
