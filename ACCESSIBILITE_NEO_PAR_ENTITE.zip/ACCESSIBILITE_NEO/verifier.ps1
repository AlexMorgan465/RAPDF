$ErrorActionPreference='Stop'
$root=Split-Path -Parent $MyInvocation.MyCommand.Path
$failed=$false
foreach($file in @(Get-ChildItem -LiteralPath $root -Filter '*.ps1' -File)){
  $tokens=$null;$errors=$null
  [void][System.Management.Automation.Language.Parser]::ParseFile($file.FullName,[ref]$tokens,[ref]$errors)
  if($errors.Count){foreach($error in $errors){Write-Host "ERREUR $($file.Name):$($error.Extent.StartLineNumber) $($error.Message)" -ForegroundColor Red};$failed=$true}
  else{Write-Host "OK $($file.Name)" -ForegroundColor Green}
}
if($failed){exit 1}
$config=[IO.File]::ReadAllText((Join-Path $root 'config.json'),[Text.Encoding]::UTF8)|ConvertFrom-Json
foreach($property in @('sharedRoot','historyRoot','dataRoot')){
  $value=[string]$config.$property
  if(!(Test-Path -LiteralPath $value -PathType Container)){Write-Host "CHEMIN INACCESSIBLE $property : $value" -ForegroundColor Yellow}
  else{Write-Host "OK $property : $value" -ForegroundColor Green}
}
$socket=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
try{$socket.Start();Write-Host "OK port local libre : $(([Net.IPEndPoint]$socket.LocalEndpoint).Port)" -ForegroundColor Green}
finally{$socket.Stop()}
Write-Host 'Vérification terminée. Lancez START_AGENT.bat ou START_MANAGER.bat.'
