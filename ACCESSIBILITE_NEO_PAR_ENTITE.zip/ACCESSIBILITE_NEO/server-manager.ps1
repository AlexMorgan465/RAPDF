$ErrorActionPreference='Stop'
try{& (Join-Path $PSScriptRoot 'server-core.ps1') -Mode manager}
catch{
  $message=$_|Out-String
  [IO.File]::AppendAllText((Join-Path $PSScriptRoot 'data\manager-error.log'),((Get-Date).ToString('o')+"`r`n"+$message+"`r`n"),[Text.Encoding]::UTF8)
  Write-Host $message -ForegroundColor Red
  exit 1
}
