function Read-Request($client,$port){
 $client.ReceiveTimeout=10000;$client.SendTimeout=10000;$stream=$client.GetStream()
 $raw=[Collections.Generic.List[byte]]::new();$done=$false
 while($raw.Count -lt 16384){
   $one=$stream.ReadByte();if($one -lt 0){throw 'Connexion interrompue'};$raw.Add([byte]$one);$n=$raw.Count
   if($n -ge 4 -and $raw[$n-4] -eq 13 -and $raw[$n-3] -eq 10 -and $raw[$n-2] -eq 13 -and $raw[$n-1] -eq 10){$done=$true;break}
 }
 if(!$done){throw 'En-tête trop long'}
 $lines=[Text.Encoding]::ASCII.GetString($raw.ToArray()) -split "`r`n"
 $verb,$target,$protocol=$lines[0] -split ' '
 if($verb -notin @('GET','POST') -or $protocol -notlike 'HTTP/1.*' -or !$target.StartsWith('/')){throw 'Requête invalide'}
 $headers=@{};foreach($line in $lines){if($line -match '^([^:]+):\s*(.*)$'){$headers[$Matches[1]]=$Matches[2]}}
 if($headers['Host'] -notin @("localhost:$port","127.0.0.1:$port")){throw 'Hôte interdit'}
 if($verb -eq 'POST' -and $headers['Origin'] -and $headers['Origin'] -notin @("http://localhost:$port","http://127.0.0.1:$port")){throw 'Origine interdite'}
 if($headers['Transfer-Encoding']){throw 'Transfert fragmenté interdit'}
 $size=0L
 if($headers['Content-Length'] -and ![long]::TryParse($headers['Content-Length'],[ref]$size)){throw 'Taille invalide'}
 if($size -lt 0 -or $size -gt 42000000){throw 'Requête trop volumineuse'}
 $bytes=[byte[]]::new([int]$size);$offset=0
 while($offset -lt $size){$count=$stream.Read($bytes,$offset,[int]($size-$offset));if(!$count){throw 'Données incomplètes'};$offset+=$count}
 $url=[uri]('http://localhost'+$target)
 return @{verb=$verb;path=$url.AbsolutePath;query=[System.Web.HttpUtility]::ParseQueryString($url.Query);headers=$headers;body=$bytes}
}
function Reply($client,$code,$contentType,[byte[]]$body,$extra=@{}){
 try{
   $reason=switch($code){200{'OK'}304{'Not Modified'}400{'Bad Request'}403{'Forbidden'}404{'Not Found'}409{'Conflict'}413{'Payload Too Large'}default{'Error'}}
   if($code -eq 304){$body=[byte[]]@()}
   $head="HTTP/1.1 $code $reason`r`nContent-Type: $contentType`r`nContent-Length: $($body.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`n"
   foreach($key in $extra.Keys){$value=([string]$extra[$key]) -replace "[`r`n]",'';$head+="${key}: $value`r`n"}
   $head+="`r`n";$stream=$client.GetStream();$h=[Text.Encoding]::ASCII.GetBytes($head);$stream.Write($h,0,$h.Length)
   if($body.Length){$stream.Write($body,0,$body.Length)};$stream.Flush()
 }finally{$client.Close()}
}
function Reply-Json($client,$value,$code=200){Reply $client $code 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $value -Depth 16 -Compress)))}
function Body-Json($req){if(!$req.body.Length){return [pscustomobject]@{}};return ([Text.Encoding]::UTF8.GetString($req.body)|ConvertFrom-Json)}
