param([int]$Port=8776,[string]$DataDirectory='')
$ErrorActionPreference='Stop';$utf8=New-Object Text.UTF8Encoding($false);$root=Join-Path $PSScriptRoot 'web'
if ([string]::IsNullOrWhiteSpace($DataDirectory)) {$DataDirectory='\\uf11\pu01\ACCESSIBILIT'+[char]0x00C9+'_CONSEILLERS\Epith'+[char]0x00E8+'te\data'}
try {[IO.Directory]::CreateDirectory($DataDirectory)|Out-Null} catch {throw "Impossible d'ouvrir le dossier de données : $DataDirectory. $($_.Exception.Message)"}
$db=Join-Path $DataDirectory 'epithete-traitements.json';$lock=Join-Path $DataDirectory 'epithete.verrou';$configPath=Join-Path $DataDirectory 'epithete-config.json'
$legacyDirectory=Join-Path (Split-Path $PSScriptRoot -Parent) 'data';$legacyDb=Join-Path $legacyDirectory 'epithete-traitements.json';$legacyConfig=Join-Path $legacyDirectory 'epithete-config.json'
if(-not [IO.File]::Exists($db) -and [IO.File]::Exists($legacyDb) -and $legacyDb -ne $db){Copy-Item -LiteralPath $legacyDb -Destination $db -Force}
if(-not [IO.File]::Exists($configPath) -and [IO.File]::Exists($legacyConfig) -and $legacyConfig -ne $configPath){Copy-Item -LiteralPath $legacyConfig -Destination $configPath -Force}
function Read-Json($path,$fallback){if(-not [IO.File]::Exists($path)){return $fallback};try{$raw=[IO.File]::ReadAllText($path,$utf8);if([string]::IsNullOrWhiteSpace($raw)){return $fallback};return $raw|ConvertFrom-Json}catch{return $fallback}}
function Write-Json($path,$value){$json=ConvertTo-Json -InputObject $value -Depth 12;$bytes=$utf8.GetBytes($json);$h=[IO.File]::Open($path,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None);try{$h.Position=0;$h.Write($bytes,0,$bytes.Length);$h.SetLength($bytes.Length);$h.Flush($true)}finally{$h.Dispose()}}
function Read-Records{$value=Read-Json $db @();if($null -eq $value){return @()};$flat=@();foreach($item in @($value)){if($item -is [Array]){$flat+=@($item)}else{$flat+=$item}};return $flat}
function Save-Records($rows){Write-Json $db @($rows)}
function Get-Config{$c=Read-Json $configPath $null;if($null -eq $c){$source='\\uf11\pu01\ACCESSIBILIT'+[char]0x00C9+'_CONSEILLERS\Epith'+[char]0x00E8+'te\Source';$c=[pscustomobject]@{sourceDirectory=$source;agents=@()}};if($null -eq $c.agents){Field $c 'agents' @()};return $c}
function With-Lock([scriptblock]$action){$g=$null;for($i=0;$i-lt 80-and $null-eq $g;$i++){try{$g=[IO.File]::Open($lock,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{Start-Sleep -Milliseconds 100}};if($null-eq $g){throw 'Données occupées. Réessayez.'};try{&$action}finally{$g.Dispose()}}
function Norm([string]$s){if($null-eq $s){return ''};$d=$s.Normalize([Text.NormalizationForm]::FormD);return (($d.ToCharArray()|Where-Object{[Globalization.CharUnicodeInfo]::GetUnicodeCategory($_)-ne 'NonSpacingMark'})-join '').ToLowerInvariant().Trim()}
function Text($v){if($null-eq $v){return ''};return [string]$v}
function Field($record,$name,$value){$record|Add-Member -NotePropertyName $name -NotePropertyValue $value -Force}
function Import-ExcelFiles {
 $cfg=Get-Config;$folder=[string]$cfg.sourceDirectory;if(-not [IO.Directory]::Exists($folder)){throw "Dossier source introuvable : $folder"}
 $files=@(Get-ChildItem -LiteralPath $folder -File|Where-Object{$_.Extension -in @('.xlsx','.xlsm','.xls') -and -not $_.Name.StartsWith('~$')})
 if(-not $files.Count){throw 'Aucun fichier Excel trouvé dans Source à traiter.'}
 $excel=$null;$added=0;[array]$existing=@(Read-Records);$known=@{};foreach($r in $existing){$known[[string]$r.sourceKey]=$true}
 try{$excel=New-Object -ComObject Excel.Application;$excel.Visible=$false;$excel.DisplayAlerts=$false
  foreach($file in $files){$book=$null;try{$book=$excel.Workbooks.Open($file.FullName,$null,$true);foreach($sheet in @($book.Worksheets)){$used=$sheet.UsedRange;$rows=[int]$used.Rows.Count;$cols=[int]$used.Columns.Count;$header=0;$map=@{};for($r=1;$r-le [Math]::Min($rows,60);$r++){for($c=1;$c-le $cols;$c++){$v=Norm (Text $sheet.Cells.Item($r,$c).Text);if($v-match 'siret'){$map.siret=$c};if($v-match 'raison sociale'){$map.raison=$c};if($v-match 'facture'){$map.type=$c};if($v-match 'date limite'){$map.date=$c}};if($map.siret-and $map.raison){$header=$r;break}};if(-not $header){continue}
    $info=@{nomCsp='';contratBad='';idtConnexion='';mdpCsp='';numeroAbonneCsp='';iban=''};for($r=1;$r-lt $header;$r++){for($c=1;$c-le [Math]::Min($cols,5);$c++){$label=Norm (Text $sheet.Cells.Item($r,$c).Text);$value='';for($x=$c+1;$x-le [Math]::Min($cols,$c+3);$x++){if(-not [string]::IsNullOrWhiteSpace((Text $sheet.Cells.Item($r,$x).Text))){$value=Text $sheet.Cells.Item($r,$x).Text;break}};if($label-match 'coordonnees du csp|^nom csp$'){$info.nomCsp=$value};if($label-match 'contrat bad'){$info.contratBad=$value};if($label-match 'idt.*connexion|identifiant.*connexion'){$info.idtConnexion=$value};if($label-match 'mdp csp|mot de passe csp'){$info.mdpCsp=$value};if($label-match 'abonne csp'){$info.numeroAbonneCsp=$value};if($label-match 'iban'){$info.iban=$value}}}
    for($r=$header+1;$r-le $rows;$r++){$siret=Text $sheet.Cells.Item($r,$map.siret).Text;$raison=Text $sheet.Cells.Item($r,$map.raison).Text;if([string]::IsNullOrWhiteSpace($siret)-and[string]::IsNullOrWhiteSpace($raison)){continue};$key=$file.FullName+'|'+$sheet.Name+'|'+$r;if($known.ContainsKey($key)){continue};$type=if($map.type){Text $sheet.Cells.Item($r,$map.type).Text}else{''};$deadline=if($map.date){Text $sheet.Cells.Item($r,$map.date).Text}else{''};$now=[DateTimeOffset]::Now.ToString('o');$existing+=[pscustomobject]@{id=[guid]::NewGuid().ToString();sourceKey=$key;sourceFile=$file.Name;sourcePath=$file.FullName;sourceSheet=$sheet.Name;sourceRow=$r;nomCsp=$info.nomCsp;contratBadSource=$info.contratBad;idtConnexionSource=$info.idtConnexion;mdpCspSource=$info.mdpCsp;numeroAbonneCspSource=$info.numeroAbonneCsp;ibanSource=$info.iban;raisonSociale=$raison;siret=$siret;typeFacture=$type;dateLimite=$deadline;agent='';statut='À affecter';dateImport=$now;dateAffectation=$null;datePriseEnCharge=$null;dateFin=$null;dmtSecondes=$null;numeroAbonne='';idt='';motDePasse='';contratBad='';csp='';commentaire='';journal=@([pscustomobject]@{date=$now;auteur=$env:USERNAME;action='Import';detail=$file.Name})};$known[$key]=$true;$added++}
   }}finally{if($book){$book.Close($false)}}}
 }finally{if($excel){$excel.Quit();[Runtime.InteropServices.Marshal]::ReleaseComObject($excel)|Out-Null}}
 Save-Records $existing;return @{ok=$true;ajoutees=$added;fichiers=$files.Count}
}
function Export-CompletedRows {
 [array]$records=@(Read-Records)
 [array]$completed=@($records|Where-Object{$_.dateFin -and $_.sourcePath -and $_.sourceSheet})
 if(-not $completed.Count){throw 'Aucun traitement terminé à exporter.'}
 $excel=$null;$exported=0;$filesSaved=0;$errors=@()
 try {
  $excel=New-Object -ComObject Excel.Application;$excel.Visible=$false;$excel.DisplayAlerts=$false
  foreach($group in @($completed|Group-Object sourcePath)){
   $path=[string]$group.Name
   if(-not [IO.File]::Exists($path)){$errors+="Fichier introuvable : $path";continue}
   $book=$null
   try {
    $book=$excel.Workbooks.Open($path)
    foreach($sheetGroup in @($group.Group|Group-Object sourceSheet)){
     $sheet=$null
     try{$sheet=$book.Worksheets.Item([string]$sheetGroup.Name)}catch{$errors+="Feuille introuvable : $($sheetGroup.Name) dans $path";continue}
     $used=$sheet.UsedRange;$maxRows=[int]$used.Rows.Count;$maxCols=[int]$used.Columns.Count;$header=0;$siretCol=0;$columns=@{}
     for($row=1;$row-le [Math]::Min($maxRows,60);$row++){
      $candidate=@{}
      for($col=1;$col-le $maxCols;$col++){
       $label=Norm (Text $sheet.Cells.Item($row,$col).Text)
       if($label-match 'siret'){$candidate.siret=$col}
       if($label-match 'abonne.*facture|^n.*abonne$'){$candidate.numeroAbonne=$col}
       if($label-match '^identifiant$|^idt$'){$candidate.idt=$col}
       if($label-match '^mdp$|mot de passe'){$candidate.motDePasse=$col}
       if($label-match 'contrat b.*d|contrat bad'){$candidate.contratBad=$col}
       if($label-match 'rattachement.*csp|^csp$'){$candidate.csp=$col}
       if($label-match 'commentaire'){$candidate.commentaire=$col}
      }
      if($candidate.siret){$header=$row;$siretCol=$candidate.siret;$columns=$candidate;break}
     }
     if(-not $header){$errors+="En-tête SIRET introuvable : $($sheetGroup.Name)";continue}
     $labels=@{numeroAbonne='N° Abonné e-factures';idt='Identifiant';motDePasse='Mdp';contratBad='Contrat B@D';csp='Rattachement au contrat CSP (O/N)';commentaire='Commentaire'}
     foreach($key in @('numeroAbonne','idt','motDePasse','contratBad','csp','commentaire')){if(-not $columns[$key]){$maxCols++;$columns[$key]=$maxCols;$sheet.Cells.Item($header,$maxCols).Value2=$labels[$key]}}
     foreach($record in @($sheetGroup.Group)){
      $target=0;$wanted=(Text $record.siret).Replace(' ','')
      for($row=$header+1;$row-le [Math]::Max($maxRows,[int]$record.sourceRow);$row++){if((Text $sheet.Cells.Item($row,$siretCol).Text).Replace(' ','') -eq $wanted){$target=$row;break}}
      if(-not $target){$target=[int]$record.sourceRow}
      if($target-le $header){$errors+="Ligne source introuvable pour $($record.raisonSociale)";continue}
      $sheet.Cells.Item($target,$columns.numeroAbonne).Value2=(Text $record.numeroAbonne)
      $sheet.Cells.Item($target,$columns.idt).Value2=(Text $record.idt)
      $sheet.Cells.Item($target,$columns.motDePasse).Value2=(Text $record.motDePasse)
      $sheet.Cells.Item($target,$columns.contratBad).Value2=(Text $record.contratBad)
      $sheet.Cells.Item($target,$columns.csp).Value2=(Text $record.csp)
      $sheet.Cells.Item($target,$columns.commentaire).Value2=(Text $record.commentaire)
      Field $record 'dateExport' ([DateTimeOffset]::Now.ToString('o'));$exported++
     }
    }
    $book.Save();$filesSaved++
   } catch {$errors+="Impossible d'enregistrer $path : $($_.Exception.Message)"}
   finally {if($book){$book.Close($false);[Runtime.InteropServices.Marshal]::ReleaseComObject($book)|Out-Null}}
  }
 } finally {if($excel){$excel.Quit();[Runtime.InteropServices.Marshal]::ReleaseComObject($excel)|Out-Null}}
 Save-Records $records
 return @{ok=$true;exportees=$exported;fichiers=$filesSaved;erreurs=$errors}
}
function State{[array]$rows=@(Read-Records);$cfg=Get-Config;$agents=@(@($cfg.agents)+@($rows|ForEach-Object{$_.agent})|Where-Object{$_}|Sort-Object -Unique);return @{application='EPITHETE MANAGER';version='1.2.0';collaborateur=$env:USERNAME;config=$cfg;agents=$agents;traitements=$rows;actualiseLe=[DateTimeOffset]::Now.ToString('o')}}
function Post($path,$data){
 if($path-eq'/api/config'){if([string]::IsNullOrWhiteSpace([string]$data.sourceDirectory)){throw 'Chemin source obligatoire.'};$cfg=Get-Config;Field $cfg 'sourceDirectory' ([string]$data.sourceDirectory);Write-Json $configPath $cfg;return @{ok=$true}}
 if($path-eq'/api/agents'){ $name=([string]$data.name).Trim().ToUpperInvariant();if(-not $name){throw 'Nom agent obligatoire.'};$cfg=Get-Config;Field $cfg 'agents' (@(@($cfg.agents)+$name)|Sort-Object -Unique);Write-Json $configPath $cfg;return @{ok=$true;name=$name}}
 if($path-eq'/api/import'){return With-Lock {Import-ExcelFiles}}
 if($path-eq'/api/export'){return With-Lock {Export-CompletedRows}}
 if($path-eq'/api/assign'){return With-Lock {[array]$rows=@(Read-Records);$ids=@($data.ids);$agent=([string]$data.agent).Trim();if(-not $agent){throw 'Nom de l agent obligatoire.'};$count=0;foreach($r in $rows){if($r.id-in $ids-and -not $r.agent-and -not $r.dateFin){Field $r 'agent' $agent;Field $r 'statut' 'Affecté';Field $r 'dateAffectation' ([DateTimeOffset]::Now.ToString('o'));Field $r 'journal' (@($r.journal)+[pscustomobject]@{date=[DateTimeOffset]::Now.ToString('o');auteur=$env:USERNAME;action='Affectation';detail=$agent});$count++}};Save-Records $rows;@{ok=$true;affectees=$count}}}
 throw 'Action inconnue.'
}
$listener=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$Port);$shutdown=$false
try{$listener.Start();while(-not$shutdown){$client=$listener.AcceptTcpClient();$stream=$client.GetStream();try{$reader=New-Object IO.StreamReader($stream,[Text.Encoding]::ASCII,$false,4096,$true);$line=$reader.ReadLine();if(-not$line){continue};$parts=$line-split' ';$method=$parts[0];$path=$parts[1];$headers=@{};while(($h=$reader.ReadLine())-ne''){if($h.Contains(':')){$p=$h-split':',2;$headers[$p[0].ToLower()]=$p[1].Trim()}};$len=if($headers['content-length']){[int]$headers['content-length']}else{0};$body=New-Object char[] $len;if($len){[void]$reader.ReadBlock($body,0,$len)};$status='200 OK';$type='application/json; charset=utf-8';if($method-eq'GET'-and$path-eq'/api/state'){$result=State}elseif($method-eq'GET'-and$path-eq'/api/health'){$result=@{application='EPITHETE MANAGER';version='1.0.0'}}elseif($method-eq'POST'-and$path-eq'/api/shutdown'){$result=@{ok=$true};$shutdown=$true}elseif($method-eq'POST'){$result=Post $path ((-join$body)|ConvertFrom-Json)}elseif($path-eq'/'-or$path-match'^/(app.js|style.css)$'){$name=if($path-eq'/'){'index.html'}else{$path.TrimStart('/')};$bytes=[IO.File]::ReadAllBytes((Join-Path $root $name));$type=if($name.EndsWith('.css')){'text/css'}elseif($name.EndsWith('.js')){'text/javascript'}else{'text/html'}}else{$status='404 Not Found';$result=@{erreur='Introuvable'}};if(-not$bytes){$bytes=$utf8.GetBytes(($result|ConvertTo-Json -Depth 12))}}catch{$status='400 Bad Request';$type='application/json';$bytes=$utf8.GetBytes((@{erreur=$_.Exception.Message}|ConvertTo-Json))};$head=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n");$stream.Write($head,0,$head.Length);$stream.Write($bytes,0,$bytes.Length);$client.Close();$bytes=$null}}finally{$listener.Stop()}
