ACCESSIBILITY BANK DESK
- Nouvelle interface bancaire / back-office professionnelle.
- Backend repris de FAST FIXED qui se lançait.
- Correction syntaxique des throw PowerShell.
- Workflow: A TRAITER -> EN COURS -> TRAITES/NON CONFORME; NC -> TRAITES.
- Historique de session dans l'interface.
- TACTICAL_PRIVATE.html conserve la version orbitale personnelle.
Lancer START_ACCESSIBILITY_DESK.bat.
