@echo off
cd /d "%~dp0"
title Accessibilite TDB V2
if exist data\STOP del /q data\STOP >nul 2>&1
start "TDB Scanner" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scanner.ps1"
timeout /t 1 /nobreak >nul
start "" http://localhost:8787
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
echo.
echo Le serveur s'est arrete. Appuyez sur une touche.
pause >nul
