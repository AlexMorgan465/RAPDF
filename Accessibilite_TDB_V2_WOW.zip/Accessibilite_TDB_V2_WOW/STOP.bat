@echo off
cd /d "%~dp0"
echo stop>data\STOP
echo Le scanner s'arretera. Fermez aussi la fenetre du serveur TDB.
pause
