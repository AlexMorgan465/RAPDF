$ErrorActionPreference='Stop'
$url='http://127.0.0.1:8766'
function Ready {
    try { return ((Invoke-RestMethod "$url/api/health" -TimeoutSec 2).version -eq '3.6.0') } catch { return $false }
}
try {
    if (-not (Ready)) {
        $errorLog=Join-Path $PSScriptRoot 'manager-erreur.log'
        $outputLog=Join-Path $PSScriptRoot 'manager-sortie.log'
        $previous = $null
        try { $previous = Invoke-RestMethod "$url/api/health" -TimeoutSec 2 } catch {}
        if ($previous -and $previous.application -eq 'EBRA MANAGER') {
            $serverIds = @(netstat.exe -ano -p tcp | ForEach-Object {
                if ($_ -match '^\s*TCP\s+127\.0\.0\.1:8766\s+0\.0\.0\.0:0\s+\S+\s+(\d+)\s*$') { [int]$matches[1] }
            } | Select-Object -Unique)
            if ($serverIds.Count -ne 1) { throw 'Fermez l ancien serveur manager avant de relancer.' }
            $process = Get-Process -Id $serverIds[0] -ErrorAction Stop
            if ($process.ProcessName -notin @('powershell','pwsh')) { throw 'Le port 8766 est utilise par une autre application.' }
            Stop-Process -Id $process.Id -ErrorAction Stop
            $process.WaitForExit(5000) | Out-Null
        }
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $PSScriptRoot 'serveur.ps1') + '"') -RedirectStandardError $errorLog -RedirectStandardOutput $outputLog
        $ready=$false
        for($i=0;$i -lt 20;$i++){Start-Sleep -Milliseconds 400;if(Ready){$ready=$true;break}}
        if(-not $ready){$detail='';if(Test-Path $errorLog){$detail=(Get-Content -LiteralPath $errorLog -Raw -ErrorAction SilentlyContinue)};throw "Le serveur manager ne demarre pas. $detail Consultez aussi manager-erreur.log dans ce dossier."}
    }
    Start-Process $url
} catch { Add-Type -AssemblyName PresentationFramework;[System.Windows.MessageBox]::Show($_.Exception.Message,'EBRA MANAGER') | Out-Null }
