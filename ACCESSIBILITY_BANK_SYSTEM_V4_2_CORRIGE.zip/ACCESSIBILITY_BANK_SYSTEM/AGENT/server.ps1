﻿param([int]$Port=8788,[string]$RootPath='',[switch]$NoBrowser,[string]$AuditFile='')
. (Join-Path $PSScriptRoot '..\COMMON\settings.ps1')
if(!$RootPath){$RootPath=$SharedRoot}
& (Join-Path $PSScriptRoot '..\COMMON\server.ps1') -Port $Port -RootPath $RootPath -Role 'AGENT' -AppPath $PSScriptRoot -NoBrowser:$NoBrowser -AuditFile $AuditFile
