param([int]$Port=8775,[string]$DataDirectory='')
$ErrorActionPreference='Stop';$utf8=New-Object Text.UTF8Encoding($false);$root=Join-Path $PSScriptRoot 'web'
if ([string]::IsNullOrWhiteSpace($DataDirectory)) {$DataDirectory='\\uf11\pu01\ACCESSIBILIT'+[char]0x00C9+'_CONSEILLERS\Epith'+[char]0x00E8+'te\data'}
try {[IO.Directory]::CreateDirectory($DataDirectory)|Out-Null} catch {throw "Impossible d'ouvrir le dossier de données : $DataDirectory. $($_.Exception.Message)"}
$db=Join-Path $DataDirectory 'epithete-traitements.json';$lock=Join-Path $DataDirectory 'epithete.verrou'
function Read-Rows{if(-not [IO.File]::Exists($db)){return @()};try{$value=[IO.File]::ReadAllText($db,$utf8)|ConvertFrom-Json;$flat=@();foreach($item in @($value)){if($item -is [Array]){$flat+=@($item)}else{$flat+=$item}};return $flat}catch{return @()}}
function Save-Rows($rows) {
    $json = ConvertTo-Json -InputObject @($rows) -Depth 12
    $bytes = $utf8.GetBytes($json)
    $h = [IO.File]::Open($db,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
    try {
        $h.Position = 0
        $h.Write($bytes,0,$bytes.Length)
        $h.SetLength($bytes.Length)
        $h.Flush($true)
    } finally {
        $h.Dispose()
    }
}
function Field($r,$n,$v) {
    $r | Add-Member -NotePropertyName $n -NotePropertyValue $v -Force
}
function Required($v,$name) {
    $s = ([string]$v).Trim()
    if (-not $s) { throw "$name est obligatoire." }
    if ($s.Length -gt 500) { throw "$name est trop long." }
    return $s
}
function Locked([scriptblock]$a) {
    $g = $null
    for ($i = 0; $i -lt 80 -and $null -eq $g; $i++) {
        try {
            $g = [IO.File]::Open($lock,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        } catch {
            Start-Sleep -Milliseconds 100
        }
    }
    if ($null -eq $g) { throw 'Données occupées.' }
    try { & $a } finally { $g.Dispose() }
}
function State{[array]$all=@(Read-Rows);$mine=@($all|Where-Object{([string]$_.agent).Equals([string]$env:USERNAME,[StringComparison]::OrdinalIgnoreCase)});return @{application='EPITHETE AGENT';version='1.1.0';collaborateur=$env:USERNAME;traitements=$mine;actualiseLe=[DateTimeOffset]::Now.ToString('o')}}
function Post($path,$data){return Locked{[array]$rows=@(Read-Rows);$r=$rows|Where-Object{$_.id -eq $data.id}|Select-Object -First 1;if(-not $r){throw'Ligne introuvable.'};if(-not ([string]$r.agent).Equals([string]$env:USERNAME,[StringComparison]::OrdinalIgnoreCase)){throw'Cette ligne est affectée à un autre agent.'};$now=[DateTimeOffset]::Now;if($path -eq '/api/start'){if($r.datePriseEnCharge -or $r.dateFin){throw'Cette ligne ne peut pas être démarrée.'};if(@($rows|Where-Object{$_.datePriseEnCharge -and -not $_.dateFin -and ([string]$_.agent).Equals([string]$env:USERNAME,[StringComparison]::OrdinalIgnoreCase)}).Count){throw'Vous avez déjà un traitement en cours.'};Field $r 'statut' 'EN_COURS';Field $r 'datePriseEnCharge' $now.ToString('o');Field $r 'journal' (@($r.journal)+[pscustomobject]@{date=$now.ToString('o');auteur=$env:USERNAME;action='Prise en charge';detail=$r.raisonSociale})}
 elseif ($path -eq '/api/finish') {if (-not $r.datePriseEnCharge -or $r.dateFin) {throw 'Traitement non démarré.'};Field $r 'numeroAbonne' (Required $data.numeroAbonne 'N° Abonné');Field $r 'idt' (Required $data.idt 'IDT');Field $r 'motDePasse' (Required $data.motDePasse 'Mot de passe');Field $r 'contratBad' (Required $data.contratBad 'Contrat BAD');Field $r 'csp' (Required $data.csp 'CSP');Field $r 'commentaire' ([string]$data.commentaire).Trim();$sec=[Math]::Max(0,[Math]::Floor(($now-[DateTimeOffset]::Parse([string]$r.datePriseEnCharge)).TotalSeconds));Field $r 'dmtSecondes' $sec;Field $r 'dateFin' $now.ToString('o');Field $r 'statut' 'TERMINE';Field $r 'journal' (@($r.journal)+[pscustomobject]@{date=$now.ToString('o');auteur=$env:USERNAME;action='Traitement terminé';detail=('DMT '+$sec+' secondes')})
 }else{throw'Action inconnue.'};Save-Rows $rows;@{ok=$true}}}
$listener=New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback,$Port);$shutdown=$false
try{$listener.Start();while(-not$shutdown){$client=$listener.AcceptTcpClient();$stream=$client.GetStream();try{$reader=New-Object IO.StreamReader($stream,[Text.Encoding]::ASCII,$false,4096,$true);$line=$reader.ReadLine();if(-not$line){continue};$parts=$line-split' ';$method=$parts[0];$path=$parts[1];$headers=@{};while(($h=$reader.ReadLine())-ne''){if($h.Contains(':')){$p=$h-split':',2;$headers[$p[0].ToLower()]=$p[1].Trim()}};$len=if($headers['content-length']){[int]$headers['content-length']}else{0};$body=New-Object char[] $len;if($len){[void]$reader.ReadBlock($body,0,$len)};$status='200 OK';$type='application/json';if($method-eq'GET'-and$path-eq'/api/state'){$result=State}elseif($method-eq'GET'-and$path-eq'/api/health'){$result=@{application='EPITHETE AGENT';version='1.0.0'}}elseif($method-eq'POST'-and$path-eq'/api/shutdown'){$result=@{ok=$true};$shutdown=$true}elseif($method-eq'POST'){$result=Post $path ((-join$body)|ConvertFrom-Json)}elseif($path-eq'/'-or$path-match'^/(app.js|style.css)$'){$name=if($path-eq'/'){'index.html'}else{$path.TrimStart('/')};$bytes=[IO.File]::ReadAllBytes((Join-Path $root $name));$type=if($name.EndsWith('.css')){'text/css'}elseif($name.EndsWith('.js')){'text/javascript'}else{'text/html'}}else{$status='404 Not Found';$result=@{erreur='Introuvable'}};if(-not$bytes){$bytes=$utf8.GetBytes(($result|ConvertTo-Json -Depth 12))}}catch{$status='400 Bad Request';$bytes=$utf8.GetBytes((@{erreur=$_.Exception.Message}|ConvertTo-Json))};$head=[Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $status`r`nContent-Type: $type; charset=utf-8`r`nContent-Length: $($bytes.Length)`r`nCache-Control: no-store`r`nConnection: close`r`n`r`n");$stream.Write($head,0,$head.Length);$stream.Write($bytes,0,$bytes.Length);$client.Close();$bytes=$null}}finally{$listener.Stop()}
