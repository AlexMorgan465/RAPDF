AGENT ORBIT - FAST STATE EDITION

1. Lance START_AGENT_ORBIT.bat.
2. Au TOUT PREMIER lancement seulement, clique FULL RESCAN pour initialiser les compteurs centraux.
3. Ensuite, /api/counts ne scanne PLUS le DP : il lit un minuscule fichier .agent_orbit_counts.json partagé à la racine du DP.
4. Chaque déplacement met à jour ce fichier immédiatement. Les autres agents voient les compteurs au refresh (1 seconde) sans rescanner les dossiers.
5. ENGAGE charge uniquement la branche choisie (entité + statut + sous-entité).
6. FULL RESCAN sert uniquement à recalibrer si quelqu'un modifie les dossiers en dehors d'Agent Orbit.
7. Leave Universe ferme le serveur local.
