﻿$ErrorActionPreference = 'Stop'
$url = 'http://127.0.0.1:8765'
function Ready {
    try { $state = Invoke-RestMethod "$url/api/state" -TimeoutSec 2; $release=Invoke-RestMethod "$url/api/release/361" -TimeoutSec 2; return ($state.version -eq '3.2.0' -and $release.ok) } catch { return $false }
}
try {
    if (-not (Ready)) {
        # Replace only the legacy EBRA instance bound to our localhost port.
        $previous = $null
        try { $previous = Invoke-RestMethod "$url/api/state" -TimeoutSec 2 } catch {}
        if ($previous -and $previous.application -eq 'EBRA PRESS SERVICE') {
            # netstat does not require the CIM permissions used by Get-NetTCPConnection.
            $serverIds = @(netstat.exe -ano -p tcp | ForEach-Object {
                if ($_ -match '^\s*TCP\s+127\.0\.0\.1:8765\s+0\.0\.0\.0:0\s+\S+\s+(\d+)\s*$') { [int]$matches[1] }
            } | Select-Object -Unique)
            if ($serverIds.Count -ne 1) { throw 'Fermez votre session Windows puis relancez Lancer.bat pour remplacer l ancien serveur.' }
            foreach ($serverId in $serverIds) {
                $serverProcess = Get-Process -Id $serverId -ErrorAction Stop
                if ($serverProcess.ProcessName -notin @('powershell', 'pwsh')) { throw 'Le port 8765 est utilise par une autre application.' }
                Stop-Process -Id $serverProcess.Id -ErrorAction Stop
                $serverProcess.WaitForExit(5000) | Out-Null
            }
        }
        Start-Process powershell.exe -WindowStyle Hidden -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $PSScriptRoot 'serverr.ps1') + '"')
        $ready = $false
        for ($i = 0; $i -lt 20; $i++) { Start-Sleep -Milliseconds 400; if (Ready) { $ready = $true; break } }
        if (-not $ready) { throw 'Le serveur local ne demarre pas. Verifiez que le port 8765 est libre et que le dossier \\uf11pu01\ACCESSIBILITÉ_ CONSEILLERS\EBRA SERVICE\EBRA SERVICE est accessible. Pour diagnostiquer, lancez serverr.ps1 dans PowerShell.' }
    }
    Start-Process $url
} catch { Add-Type -AssemblyName PresentationFramework; [System.Windows.MessageBox]::Show($_.Exception.Message, 'EBRA PRESS SERVICE') | Out-Null }
