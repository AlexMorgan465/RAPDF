@echo off
setlocal
set /p "TARGET=Chemin du dossier ACCESSIBILITY_BANK_SYSTEM existant : "
if not exist "%TARGET%\AGENT\server.ps1" goto fail
echo Fermez les deux serveurs avant de continuer.
pause
for %%F in (common.ps1 SELF_TEST.ps1 TEST_LOCAL.bat) do copy /y "%~dp0%%F" "%TARGET%\%%F" >nul
for %%R in (AGENT MANAGER) do (
 copy /y "%TARGET%\%%R\index.html" "%TARGET%\%%R\index.avant_v53.html" >nul
 copy /y "%~dp0%%R\index.html" "%TARGET%\%%R\index.html" >nul
 if errorlevel 1 goto fail
 copy /y "%~dp0%%R\server.ps1" "%TARGET%\%%R\server.ps1" >nul
 if errorlevel 1 goto fail
 copy /y "%~dp0%%R\START_%%R.bat" "%TARGET%\%%R\START_%%R.bat" >nul
 copy /y "%~dp0%%R\START_DEBUG.bat" "%TARGET%\%%R\START_DEBUG.bat" >nul
)
echo Mise a jour terminee. CONFIG.ps1 et DATA conserves.
echo Relancez les deux serveurs puis faites Ctrl+F5 et actualisez le stock manager.
pause
exit /b 0
:fail
echo Echec. Verifiez le chemin et les droits de copie.
pause
exit /b 1
