﻿$Schema=[ordered]@{
"ACM"=@{Mode="STATUS_FIRST";Branches=@("ASS-BIENS","ASS-COMPTA-CONTENTIEUX","ASS-EMPRUNTEURS","ASS-INDEMN-BIENS-PERS","ASS-PERS-COLL","ASS-PERS-IND","ASS-PROTECTION-JUR","ASS-VIE-EPARGNE-RET\MONABANQ - VIE","ASS-VIE-EPARGNE-RET\RETRAITE COLLECTIVE")}
"Bouygues telecom"=@{Mode="SIMPLE";Branches=@("")}
"CIC CIB ASSET SERVICING"=@{Mode="STATUS_FIRST";Branches=@("Agence Clientèle Déposée")}
"CMMABN"=@{Mode="SIMPLE";Branches=@("")}
"CMO"=@{Mode="STATUS_FIRST";Branches=@("BAD","Cartes bancaires","Compte courant","Epargne bancaire","Epargne financière","Packages","Tarif")}
"COFIDIS FRANCE"=@{Mode="STATUS_FIRST";Branches=@("COFIDIS FRANCE-DMA\DMA – Agence WEB","COFIDIS FRANCE-DMA\DMA – Marque et Stratégie","COFIDIS FRANCE-DMA\DMA – Performance Digitale","COFIDIS FRANCE-DPA\DPA – Domaine Marketing","COFIDIS FRANCE-DPA\DPA – Service Marketing","COFIDIS FRANCE-DPA\DPA – Service Relation")}
"CONTRATHEQUE"=@{Mode="CATEGORY_FIRST";Branches=@("CONDITIONS GENERALES","DOCUMENT D'INFORMATION TARIFAIRE","GARANTIES","POLITIQUE DE PROTECTION")}
"CREATIS"=@{Mode="SIMPLE";Branches=@("")}
"DIRCO"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"DIRCOM"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"MONABANQ"=@{Mode="SIMPLE";Branches=@("")}
}
$Statuses=@("A TRAITER","EN COURS","NON CONFORME","TRAITES")
function J($o){$o|ConvertTo-Json -Depth 8 -Compress}
function Send($c,$code,$o){$b=[Text.Encoding]::UTF8.GetBytes((J $o));$c.Response.StatusCode=$code;$c.Response.ContentType="application/json; charset=utf-8";$c.Response.Headers["Cache-Control"]="no-store";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Q($r){$h=@{};if($r.Url.Query.Length-gt 1){foreach($p in $r.Url.Query.Substring(1).Split("&")){$k=$p.Split("=",2);if($k.Count-eq 2){$h[[Uri]::UnescapeDataString($k[0])] = [Uri]::UnescapeDataString(($k[1]-replace '\+',' '))}}};$h}
function Body($r){$sr=New-Object IO.StreamReader($r.InputStream,$r.ContentEncoding);$t=$sr.ReadToEnd();$sr.Close();if(!$t){return @{}};$t|ConvertFrom-Json}
function BranchPath($e,$s,$b){
 if(!$Schema.Contains($e)){throw "Entité inconnue: $e"}; if($Statuses-notcontains$s){throw "Statut invalide"}
 if(@($Schema[$e].Branches) -notcontains [string]$b){throw "Sous-entité invalide"};$cfg=$Schema[$e];$p=Join-Path $RootPath $e
 if($cfg.Mode-eq"CATEGORY_FIRST"){if(!$b){throw "Sous-entité requise"};return Join-Path (Join-Path $p $b) $s}
 $p=Join-Path $p $s;if($b){$p=Join-Path $p $b};$p
}

$DataPath=[IO.Path]::GetFullPath($DataPath)
$dpFull=[IO.Path]::GetFullPath($RootPath).TrimEnd('\')
if($DataPath.TrimEnd('\').Equals($dpFull,[StringComparison]::OrdinalIgnoreCase) -or $DataPath.StartsWith($dpFull+'\',[StringComparison]::OrdinalIgnoreCase)){throw "DATA doit être hors du DP documentaire"}
[IO.Directory]::CreateDirectory($DataPath)|Out-Null
$StoreFile=Join-Path $DataPath 'catalogue.json'
$LockFile=Join-Path $DataPath 'catalogue.lock'
$BackupFile=Join-Path $DataPath 'catalogue.backup.json'
function ReadStoredJson($path){
 $candidate=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
 if($null-eq$candidate -or $candidate.PSObject.Properties.Name -notcontains 'documents' -or $candidate.PSObject.Properties.Name -notcontains 'history'){throw 'Format de catalogue invalide'}
 return $candidate
}
function ReadCatalogue(){
 if([IO.File]::Exists($StoreFile)){
  try{return (ReadStoredJson $StoreFile)}catch{
   if(![IO.File]::Exists($BackupFile)){throw 'Catalogue illisible. Aucune sauvegarde disponible : les donnees ne sont pas reinitialisees.'}
   $saved=ReadStoredJson $BackupFile
   [IO.File]::Copy($BackupFile,$StoreFile,$true);return $saved
  }
 }
 if([IO.File]::Exists($BackupFile)){
  $saved=ReadStoredJson $BackupFile
  [IO.File]::Copy($BackupFile,$StoreFile,$false);return $saved
 }
 return $null
}
function SaveCatalogue($db){
 # Tous les lecteurs/ecrivains passent par le verrou partage de WithStore.
 # Renommages dans DATA, sans File.Replace (incompatible dans la livraison V5).
 $tmp=Join-Path $DataPath ('catalogue.'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{
  [IO.File]::WriteAllText($tmp,($db|ConvertTo-Json -Depth 20 -Compress),(New-Object Text.UTF8Encoding($false)))
  if([IO.File]::Exists($StoreFile)){
   if([IO.File]::Exists($BackupFile)){[IO.File]::Delete($BackupFile)}
   [IO.File]::Move($StoreFile,$BackupFile)
  }
  try{[IO.File]::Move($tmp,$StoreFile)}catch{
   if(![IO.File]::Exists($StoreFile) -and [IO.File]::Exists($BackupFile)){[IO.File]::Copy($BackupFile,$StoreFile,$false)}
   throw
  }
 }finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
}
function Agent(){[Environment]::UserName}
function WithStore($action,[bool]$save=$true){
 $lock=$null;$limit=(Get-Date).AddSeconds(15)
 while(!$lock){try{$lock=[IO.File]::Open($LockFile,'OpenOrCreate','ReadWrite','None')}catch{if((Get-Date)-gt$limit){throw "Données occupées, réessayez"};Start-Sleep -Milliseconds 80}}
 $script:Rollback=$null;$script:Undo=@()
 try{
  $db=ReadCatalogue
  if($db){foreach($doc in $db.documents){foreach($field in @('folderCreated','billingDate','originalName','originalArchive')){if($doc.PSObject.Properties.Name-notcontains$field){$doc|Add-Member -NotePropertyName $field -NotePropertyValue $null}}}}
  if($null-eq$db){
   $legacy=@();$legacyFile=Join-Path $RootPath '.accessibility_history\operations.jsonl'
   if([IO.File]::Exists($legacyFile)){foreach($line in [IO.File]::ReadLines($legacyFile)){if($line.Trim()){try{$legacy+=($line|ConvertFrom-Json)}catch{}}}}
   $db=[pscustomobject]@{documents=@();history=$legacy;at=$null}
  }
  $answer=& $action $db
  if(!$save){return $answer}
  SaveCatalogue $db
  $script:Rollback=$null;$script:Undo=@()
  return $answer
 }catch{
  $failure=$_.Exception.Message
  if($script:Rollback){
   try{if([IO.Directory]::Exists($script:Rollback.to)){[IO.Directory]::Move($script:Rollback.to,$script:Rollback.from)}elseif([IO.File]::Exists($script:Rollback.to)){[IO.File]::Move($script:Rollback.to,$script:Rollback.from)}}catch{throw "Journal non enregistré et retour impossible : $failure. Vérifiez le document déplacé."}
  }
  for($i=$script:Undo.Count-1;$i-ge 0;$i--){$u=$script:Undo[$i];try{if($u.kind-eq'restore'){if(Test-Path -LiteralPath $u.to){Remove-Item -LiteralPath $u.to -Recurse -Force -ErrorAction Stop};Copy-Item -LiteralPath $u.from -Destination $u.to -Recurse -ErrorAction Stop;Remove-Item -LiteralPath $u.from -Recurse -Force -ErrorAction Stop}elseif(Test-Path -LiteralPath $u.path){Remove-Item -LiteralPath $u.path -Recurse -Force -ErrorAction Stop}}catch{throw "Action interrompue : $failure. Retour incomplet : $($_.Exception.Message)"}}
  throw $failure
 }finally{$script:Rollback=$null;$script:Undo=@();$lock.Dispose()}
}
function FindDoc($db,$e,$b,$n){@($db.documents|Where-Object{$_.entity-eq$e -and $_.branch-eq$b -and $_.name-eq$n})|Select-Object -First 1}
function Register($db,$e,$b,$s,$item){
 $doc=FindDoc $db $e $b $item.Name;$now=(Get-Date).ToString('o')
 if(!$doc){$price=9;if(@('DIRCO','CMMABN','CIC CIB ASSET SERVICING')-contains$e){$price=4.5}
 $doc=[pscustomobject]@{id=[guid]::NewGuid().ToString();entity=$e;branch=$b;name=$item.Name;kind=$(if($item.PSIsContainer){'Dossier'}else{'Fichier'});deposit=$item.LastWriteTime.ToString('o');modified=$item.LastWriteTime.ToString('o');status=$s;statusSince=$now;durations=[pscustomobject]@{'A TRAITER'=0;'EN COURS'=0;'NON CONFORME'=0;'TRAITES'=0};priority=$false;complex=$false;complexComment='';unitPrice=$price;present=$true;completed=$null;folderCreated=$null;billingDate=$null;originalName=$null;originalArchive=$null;started=$null;agent='';ncComment=''}
 $last=@($db.history|Where-Object{$_.entity-eq$e -and $_.branch-eq$b -and $_.name-eq$item.Name}|Sort-Object timestamp -Descending)|Select-Object -First 1
 if($last -and $last.to-eq$s){$doc.statusSince=$last.timestamp;$doc.started=$last.started;$doc.agent=$last.agent;if($s-eq'TRAITES'){$doc.completed=$last.timestamp};if($s-eq'NON CONFORME'){$doc.ncComment=$last.comment}}
 $db.documents=@($db.documents)+@($doc)
 }else{
  if($doc.status-ne$s){$old=$doc.status;$doc.durations.$old += [Math]::Max(0,((Get-Date)-[datetime]$doc.statusSince).TotalMinutes);$doc.status=$s;$doc.statusSince=$now;if($s-eq'TRAITES'){$doc.completed=$now}}
  $doc.modified=$item.LastWriteTime.ToString('o');$doc.present=$true
 }
 if($item.PSIsContainer -and @('TRAITES','NON CONFORME')-contains$s){if(!$doc.folderCreated){$doc.folderCreated=$item.CreationTime.ToString('o')};if(!$doc.billingDate){$doc.billingDate=$doc.folderCreated};if(!$doc.completed -and $s-eq'TRAITES'){$doc.completed=$doc.folderCreated}}
 return $doc
}
function Inventory($db,$e,$s,$b){
 $p=BranchPath $e $s $b
 if(![IO.Directory]::Exists($p)){return @()}
 $items=@(Get-ChildItem -LiteralPath $p -ErrorAction Stop)
 foreach($d in @($db.documents|Where-Object{$_.entity-eq$e -and $_.branch-eq$b -and $_.status-eq$s})){$d.present=$false}
 $out=@();foreach($i in $items){$out+=Register $db $e $b $s $i};return $out
}
function CountsFrom($db){$a=@();foreach($e in $Schema.Keys){$c=[ordered]@{};foreach($s in @('A TRAITER','EN COURS','NON CONFORME')){$c[$s]=@($db.documents|Where-Object{$_.entity-eq$e -and $_.status-eq$s -and $_.present}).Count};$a+=@{entity=$e;counts=$c;total=($c['A TRAITER']+$c['EN COURS']+$c['NON CONFORME'])}};return @{entities=$a;initialized=($null-ne$db.at);at=$db.at}}
function Counts(){WithStore {param($db) CountsFrom $db} $false}
function FullScan(){WithStore {param($db) foreach($e in $Schema.Keys){foreach($s in $Statuses){foreach($b in $Schema[$e].Branches){$null=Inventory $db $e $s $b}}};$db.at=(Get-Date).ToString('o');CountsFrom $db}}
function Items($e,$s,$b){WithStore {param($db) @{items=@(Inventory $db $e $s $b);path=(BranchPath $e $s $b)}}}
function ReadHistory(){WithStore {param($db) @($db.history|Sort-Object timestamp -Descending)} $false}
function Documents(){WithStore {param($db) @{documents=@($db.documents);history=@($db.history);at=$db.at;agent=(Agent)} } $false}
function UpdateDoc($body){WithStore {param($db)
 $d=@($db.documents|Where-Object{$_.id-eq$body.id})|Select-Object -First 1;if(!$d){throw 'Document inconnu'}
 foreach($k in @('priority','complex','complexComment','unitPrice','completed','deposit')){if($body.PSObject.Properties.Name-contains$k){
  if($k-eq'priority' -or $k-eq'unitPrice' -or $k-eq'completed' -or $k-eq'deposit'){if($Role-ne'MANAGER'){throw 'Action réservée au manager'}}
  if($k-eq'deposit'){$d.deposit=([datetime]$body.$k).ToString('o')}elseif($k-eq'completed'){if(@('TRAITES','NON CONFORME')-notcontains$d.status){throw 'Document non traité'}; $d.completed=([datetime]$body.$k).ToString('o')}elseif($k-eq'unitPrice'){if([double]$body.$k-lt 0 -or [double]::IsNaN([double]$body.$k) -or [double]::IsInfinity([double]$body.$k)){throw 'Prix invalide'};$d.$k=[double]$body.$k}else{$d.$k=$body.$k}
 }}
 if($d.complex -and !([string]$d.complexComment).Trim()){throw 'Commentaire requis pour un document complexe'}
 @{ok=$true}
}}
function Safe($n){if(!$n -or $n.Contains('..') -or $n.Contains('\') -or $n.Contains('/')){throw 'Nom invalide'};return $n}

function DesktopPath(){[Environment]::GetFolderPath([Environment+SpecialFolder]::DesktopDirectory)}
function ChooseFolder(){
 if($Role-ne'AGENT'){throw 'Choix de dossier reserve au poste agent'}
 Add-Type -AssemblyName System.Windows.Forms
 $dialog=New-Object System.Windows.Forms.FolderBrowserDialog
 $dialog.Description='Choisissez sur votre Bureau le dossier contenant les fichiers traites.'
 $dialog.SelectedPath=DesktopPath;$dialog.ShowNewFolderButton=$false
 try{if($dialog.ShowDialog()-eq[Windows.Forms.DialogResult]::OK){return @{path=$dialog.SelectedPath;cancelled=$false}};return @{cancelled=$true}}finally{$dialog.Dispose()}
}
function ValidateLocalFolder($path,$name){
 if(!$path -or ![IO.Directory]::Exists($path)){throw 'Choisissez le dossier traite sur votre Bureau'}
 $full=[IO.Path]::GetFullPath($path).TrimEnd('\');$desktop=[IO.Path]::GetFullPath((DesktopPath)).TrimEnd('\')
 if(!([IO.Path]::GetDirectoryName($full)).Equals($desktop,[StringComparison]::OrdinalIgnoreCase)){throw 'Le dossier doit etre directement sur votre Bureau'}
 $folder=Get-Item -LiteralPath $full
 if($folder.Attributes-band[IO.FileAttributes]::ReparsePoint){throw 'Selectionnez un dossier reel, pas un raccourci'}
 $expected=[IO.Path]::GetFileNameWithoutExtension($name)
 if($folder.Name-ne$name -and $folder.Name-ne$expected){throw "Nom du dossier incorrect. Attendu : $expected (ou $name)"}
 if(@(Get-ChildItem -LiteralPath $full -Force).Count-eq 0){throw 'Le dossier choisi est vide'}
 return $folder
}

function MoveOne($b){WithStore {param($db)
 $n=Safe ([string]$b.name);if($b.from-eq$b.to){throw 'Choisissez un autre statut'}
 $srcD=BranchPath ([string]$b.entity) ([string]$b.from) ([string]$b.branch);$dstD=BranchPath ([string]$b.entity) ([string]$b.to) ([string]$b.branch)
 if(![IO.Directory]::Exists($dstD)){throw 'Dossier destination absent : aucun dossier créé dans le DP'}
 $src=Join-Path $srcD $n;$dst=Join-Path $dstD $n;$local=$null
 if($Role-eq'AGENT' -and $b.from-eq'EN COURS' -and @('TRAITES','NON CONFORME')-contains$b.to){$local=ValidateLocalFolder ([string]$b.localFolder) $n;$dst=Join-Path $dstD $local.Name}

 if(!([IO.Directory]::Exists($src)-or[IO.File]::Exists($src))){throw 'Document déjà pris ou déplacé'}
 if([IO.Directory]::Exists($dst)-or[IO.File]::Exists($dst)){throw 'Existe déjà à destination'}
 if($b.to-eq'NON CONFORME' -and !([string]$b.comment).Trim()){throw 'Commentaire de non-conformité requis'}
 $d=Register $db ([string]$b.entity) ([string]$b.branch) ([string]$b.from) (Get-Item -LiteralPath $src)
 $now=Get-Date;$duration=[Math]::Max(0,($now-[datetime]$d.statusSince).TotalMinutes);$dmt=$null
 if($d.started -and @('TRAITES','NON CONFORME')-contains$b.to){$dmt=[Math]::Round(($now-[datetime]$d.started).TotalMinutes,2)}
 $desktopCopy=$null
 if($Role-eq'AGENT' -and $b.to-eq'EN COURS'){
  $desktopCopy=Join-Path (DesktopPath) $n
  if(Test-Path -LiteralPath $desktopCopy){throw 'Un element du meme nom existe deja sur votre Bureau. Renommez-le ou deplacez-le avant la PEC.'}
  $script:Undo+=@{kind='delete';path=$desktopCopy}
  Copy-Item -LiteralPath $src -Destination $desktopCopy -Recurse -ErrorAction Stop
 }
 if($local){
  $archiveRoot=Join-Path $DataPath 'ORIGINAUX';[IO.Directory]::CreateDirectory($archiveRoot)|Out-Null
  $archive=Join-Path $archiveRoot ([guid]::NewGuid().ToString('N')+'_'+$n)
  $script:Undo+=@{kind='delete';path=$dst}
  Copy-Item -LiteralPath $local.FullName -Destination $dst -Recurse -ErrorAction Stop
  Copy-Item -LiteralPath $src -Destination $archive -Recurse -ErrorAction Stop
  $script:Undo+=@{kind='restore';from=$archive;to=$src}
  Remove-Item -LiteralPath $src -Recurse -Force -ErrorAction Stop
  $d.originalName=$n;$d.originalArchive=$archive;$d.name=$local.Name;$d.kind='Dossier'
  $d.folderCreated=$local.CreationTime.ToString('o');$d.billingDate=$d.folderCreated
 }else{
  if([IO.Directory]::Exists($src)){[IO.Directory]::Move($src,$dst)}else{[IO.File]::Move($src,$dst)}
  $script:Rollback=@{from=$src;to=$dst}
 }

 $d.durations.([string]$b.from)+=$duration;$d.status=[string]$b.to;$d.statusSince=$now.ToString('o');$d.agent=Agent
 if($b.to-eq'EN COURS'){$d.started=$now.ToString('o')}
 if($b.to-eq'TRAITES'){$d.completed=$now.ToString('o');$d.priority=$false}else{$d.completed=$null}
 if($b.to-eq'NON CONFORME'){$d.ncComment=[string]$b.comment}
 $db.history=@($db.history)+@([pscustomobject]@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=$now.ToString('o');agent=(Agent);entity=$d.entity;branch=$d.branch;from=[string]$b.from;to=[string]$b.to;name=$n;started=$d.started;dmt_minutes=$dmt;status_minutes=[Math]::Round($duration,2);comment=[string]$b.comment;complex=$d.complex;complexComment=$d.complexComment})
 @{ok=$true;started=$d.started;desktopCopy=$desktopCopy}
}}
