﻿$ErrorActionPreference='Stop'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('BankSystem-Test-'+[guid]::NewGuid().ToString('N'))
$RootPath=Join-Path $testRoot 'DP test'
$DataPath=Join-Path $testRoot 'Donnees test'
$Role='MANAGER'
try{
 [IO.Directory]::CreateDirectory($RootPath)|Out-Null
 . (Join-Path $PSScriptRoot 'common.ps1')

 # Reproduit une requete JSON UTF-8 dont ContentEncoding Windows est incorrect.
 foreach($branch in $Schema['COFIDIS FRANCE'].Branches){
  $payload=[pscustomobject]@{entity='COFIDIS FRANCE';branch=$branch;name='Document energie.pdf';from='A TRAITER';to='EN COURS'}
  $bytes=[Text.Encoding]::UTF8.GetBytes((J $payload))
  $stream=[IO.MemoryStream]::new($bytes)
  $request=[pscustomobject]@{InputStream=$stream;ContentEncoding=[Text.Encoding]::ASCII}
  $decoded=Body $request
  if($decoded.branch-cne$branch){throw 'Branche COFIDIS alteree par le decodage JSON'}
  $null=BranchPath $decoded.entity $decoded.from $decoded.branch
  $null=BranchPath $decoded.entity $decoded.to $decoded.branch
 }
 $src=BranchPath 'ACM' 'A TRAITER' 'ASS-BIENS'
 $dst=BranchPath 'ACM' 'EN COURS' 'ASS-BIENS'
 [IO.Directory]::CreateDirectory($src)|Out-Null
 [IO.Directory]::CreateDirectory($dst)|Out-Null
 $file=Join-Path $src 'Document test.pdf'
 [IO.File]::WriteAllText($file,'Test uniquement')
 $first=Items 'ACM' 'A TRAITER' 'ASS-BIENS'
 $deposit=$first.items[0].deposit;$id=$first.items[0].id
 $null=UpdateDoc ([pscustomobject]@{id=$id;priority=$true})
 $again=Items 'ACM' 'A TRAITER' 'ASS-BIENS'
 if($again.items[0].deposit-ne$deposit){throw 'Date de depot modifiee'}
 if(!$again.items[0].priority){throw 'Priorite perdue'}
 # Relecture et restauration de la derniere sauvegarde valide.
 [IO.File]::WriteAllText($StoreFile,'JSON interrompu')
 $recovered=Documents
 if($recovered.documents.Count-ne 1){throw 'Recuperation du catalogue echouee'}
 $null=Items 'ACM' 'A TRAITER' 'ASS-BIENS'
 $null=MoveOne ([pscustomobject]@{entity='ACM';branch='ASS-BIENS';name='Document test.pdf';from='A TRAITER';to='EN COURS';comment=''})
 $moved=Documents
 if($moved.documents[0].deposit-ne$deposit -or $moved.documents[0].status-ne'EN COURS'){throw 'Mouvement ou date invalide'}
 $refused=$false
 try{$null=MoveOne ([pscustomobject]@{entity='ACM';branch='ASS-BIENS';name='Document test.pdf';from='A TRAITER';to='EN COURS';comment=''})}catch{$refused=$true}
 if(!$refused){throw 'Double PEC acceptee'}
 if(@(Get-ChildItem -LiteralPath $RootPath -Recurse -File|Where-Object{$_.Name-ne'Document test.pdf'}).Count){throw 'Fichier de suivi cree dans le DP test'}
 Write-Host 'OK : encodage des six branches COFIDIS, sauvegardes successives, restauration, depot fige, priorite, mouvement, double PEC refusee, aucun fichier de suivi dans DP.' -ForegroundColor Green
}finally{if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}}
