﻿$ErrorActionPreference='Stop'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('Calendar-Test-'+[guid]::NewGuid().ToString('N'))
$RootPath=Join-Path $testRoot 'DP'
$DataPath=Join-Path $testRoot 'DATA'
$Role='MANAGER'
function AssertCalendar($condition,$message){if(!$condition){throw $message}}
try{
 [IO.Directory]::CreateDirectory($RootPath)|Out-Null
 . (Join-Path $PSScriptRoot 'common.ps1')
 . (Join-Path $PSScriptRoot 'CALENDAR\calendar.ps1')
 $initial=GetCalendar
 AssertCalendar ($initial.revision-eq0-and$null-eq$initial.published) 'Calendrier initial invalide'
 $null=WithStore {param($db);$db.documents=@([pscustomobject]@{id='d1';name='Test.pdf';entity='ACM';branch='ASS-BIENS';status='A TRAITER';present=$true;deposit='2026-10-01';priority=$true;complex=$false;unitPrice=9});return @{ok=$true}} $true
 $cfg=[pscustomobject]@{rulesVersion=2;friday=[pscustomobject]@{startTime='08:00';endTime='17:00';breaks=@([pscustomobject]@{start='10:15';end='10:35'},[pscustomobject]@{start='12:30';end='13:30'},[pscustomobject]@{start='15:30';end='15:50'})};start='2026-10-12';end='2026-10-16';startTime='08:00';endTime='18:00';workdays=@(1,2,3,4,5);breaks=@([pscustomobject]@{start='10:15';end='10:30'},[pscustomobject]@{start='12:30';end='13:30'},[pscustomobject]@{start='15:30';end='16:00'});agents=@([pscustomobject]@{id='a1';name='Agent test';session=(Agent)});rates=[pscustomobject]@{ACM=[pscustomobject]@{price=9;complexFactor=1;due=''}};exceptions=@();overrides=@()}
 $slots=@(CalendarSlots $cfg 'a1' '2026-10-12');$capacity=($slots|ForEach-Object{$_.end-$_.start}|Measure-Object -Sum).Sum
 AssertCalendar ($capacity-eq495) 'Capacite differente de 8 h 15'
 $friday=(@(CalendarSlots $cfg 'a1' '2026-10-16')|ForEach-Object{$_.end-$_.start}|Measure-Object -Sum).Sum
 AssertCalendar ($friday-eq440) 'Vendredi different de 7 h 20'
 AssertCalendar (@(CalendarSlots $cfg 'a1' '2026-10-17').Count-eq0) 'Weekend planifiable par defaut'
 $saved=UpdateCalendar ([pscustomobject]@{action='draft';revision=0;config=$cfg})
 AssertCalendar ($saved.revision-eq1-and$null-eq$saved.published) 'Brouillon publie par erreur'
 $state=GetCalendar
 $plan=[pscustomobject]@{config=$cfg;assignments=@([pscustomobject]@{id='d1';name='Test.pdf';entity='ACM';branch='ASS-BIENS';agent='a1';minutes=540;price=9;due='';start='2026-10-12T08:00';end='2026-10-13T08:45';late=$false;priority=$true;complex=$false;segments=@([pscustomobject]@{date='2026-10-12';start=480;end=615},[pscustomobject]@{date='2026-10-12';start=630;end=750},[pscustomobject]@{date='2026-10-12';start=810;end=930},[pscustomobject]@{date='2026-10-12';start=960;end=1080},[pscustomobject]@{date='2026-10-13';start=480;end=525})});unplanned=@();sourceCount=1;plannedMinutes=540;totalValue=9;generated='2026-10-09T12:00:00Z'}
 $body=[pscustomobject]@{action='publish';revision=1;stockToken=$state.stockToken;plan=$plan}
 $ok=UpdateCalendar $body
 AssertCalendar ($ok.revision-eq2-and$ok.published.assignments.Count-eq1) 'Publication invalide'
 $refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Revision obsolete acceptee'
 $Role='AGENT';$view=GetCalendar;AssertCalendar ($null-ne$view.published-and!$view.ContainsKey('draft')) 'Brouillon visible aux agents'
 $refused=$false;try{$null=UpdateCalendar ([pscustomobject]@{action='draft';revision=2;config=$cfg})}catch{$refused=$true};AssertCalendar $refused 'Agent autorise a publier'
 $Role='MANAGER';$body.revision=2;$body.plan.assignments[0].segments[0].start=750;$body.plan.assignments[0].segments[0].end=810
 $refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Reservation pendant le dejeuner acceptee'
 $body.plan.assignments[0].segments[0].start=480;$body.plan.assignments[0].segments[0].end=615
 $body.plan.assignments=@($body.plan.assignments[0],$body.plan.assignments[0]);$refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Double document accepte'
 $body.plan.assignments=@($body.plan.assignments[0]);$body.stockToken='obsolete';$refused=$false;try{$null=UpdateCalendar $body}catch{$refused=$true};AssertCalendar $refused 'Stock obsolete accepte'
 $catalog=Documents;AssertCalendar ($catalog.documents[0].status-eq'A TRAITER') 'Document deplace par le calendrier'
 AssertCalendar (@(Get-ChildItem -LiteralPath $RootPath -Recurse -Force).Count-eq0) 'Fichier ajoute au DP'
 Write-Host 'OK : capacite, pauses, weekend, brouillon prive, publication partagee, controles de role/revision/stock, doublons refuses, DP intact.' -ForegroundColor Green
}finally{if(Test-Path -LiteralPath $testRoot){Remove-Item -LiteralPath $testRoot -Recurse -Force}}
