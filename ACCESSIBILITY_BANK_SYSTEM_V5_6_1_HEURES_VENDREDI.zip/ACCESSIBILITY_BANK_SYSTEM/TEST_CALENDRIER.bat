@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CALENDAR_TEST.ps1"
pause
