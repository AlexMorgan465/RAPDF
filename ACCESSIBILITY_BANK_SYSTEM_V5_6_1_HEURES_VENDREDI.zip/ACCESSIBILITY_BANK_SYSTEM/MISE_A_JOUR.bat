@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UPDATE_CALENDAR.ps1"
if errorlevel 1 echo La mise a jour n'a pas abouti. Consultez le message ci-dessus.
pause
