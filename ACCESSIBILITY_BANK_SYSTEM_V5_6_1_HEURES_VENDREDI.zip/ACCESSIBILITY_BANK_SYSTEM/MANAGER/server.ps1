﻿param([int]$Port=8790,[string]$RootPath="\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE",[string]$DataPath=(Join-Path (Split-Path $PSScriptRoot -Parent) 'DATA'))
$ErrorActionPreference='Stop'
$ConfigFile=Join-Path (Split-Path $PSScriptRoot -Parent) 'CONFIG.ps1'
if(Test-Path -LiteralPath $ConfigFile){. $ConfigFile}
$Role='MANAGER'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'common.ps1')
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'CALENDAR\calendar.ps1')

$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Start-Process "http://localhost:$Port/"
try{$run=$true;while($run){$c=$l.GetContext();try{$r=$c.Request;$p=$r.Url.AbsolutePath
 if($p-eq'/'){$f=Join-Path $PSScriptRoot 'index.html';$bytes=[IO.File]::ReadAllBytes($f);$c.Response.ContentType='text/html; charset=utf-8';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue}
 if($p-eq'/api/calendar' -and $r.HttpMethod-eq'GET'){Send $c 200 (GetCalendar);continue}
 if($p-eq'/api/calendar' -and $r.HttpMethod-eq'POST'){Send $c 200 (UpdateCalendar (Body $r));continue}
 $calendarAssets=@{'/assets/calendar.js'='calendar.js';'/assets/calendar-view.js'='calendar-view.js';'/assets/calendar.css'='calendar.css'}
 $calendarAssets['/assets/calendar-manager.js']='calendar-manager.js'
 if($r.HttpMethod-eq'GET' -and $calendarAssets.ContainsKey($p)){$file=Join-Path (Join-Path (Split-Path $PSScriptRoot -Parent) 'CALENDAR') $calendarAssets[$p];$bytes=[IO.File]::ReadAllBytes($file);$c.Response.ContentType=$(if($p.EndsWith('.css')){'text/css; charset=utf-8'}else{'application/javascript; charset=utf-8'});$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue}
 if($p-eq'/api/ping'){Send $c 200 @{ok=$true;exists=[IO.Directory]::Exists($RootPath);agent=(Agent)};continue}
 if($p-eq'/api/schema'){$x=@();foreach($e in $Schema.Keys){$x+=@{entity=$e;mode=$Schema[$e].Mode;branches=@($Schema[$e].Branches)}};Send $c 200 @{entities=$x};continue}
 if($p-eq'/api/counts'){Send $c 200 (Counts);continue}
 if($p-eq'/api/documents'){Send $c 200 (Documents);continue}
 if($p-eq'/api/history'){Send $c 200 @{agent=(Agent);history=@(ReadHistory)};continue}
 if($p-eq'/api/fullscan' -and $r.HttpMethod-eq'POST'){Send $c 200 (FullScan);continue}
 if($p-eq'/api/items'){$q=Q $r;Send $c 200 (Items $q.entity $q.status $q.branch);continue}
 if($p-eq'/api/document' -and $r.HttpMethod-eq'POST'){Send $c 200 (UpdateDoc (Body $r));continue}
 if($p-eq'/api/choose-folder' -and $r.HttpMethod-eq'POST'){Send $c 200 (ChooseFolder);continue}
 if($p-eq'/api/move' -and $r.HttpMethod-eq'POST'){Send $c 200 (MoveOne (Body $r));continue}
 if($p-eq'/api/leave' -and $r.HttpMethod-eq'POST'){Send $c 200 @{ok=$true};$run=$false;continue}
 Send $c 404 @{error='Route inconnue'}
 }catch{try{Send $c 500 @{error=$_.Exception.Message}}catch{}}}}finally{$l.Stop();$l.Close()}
