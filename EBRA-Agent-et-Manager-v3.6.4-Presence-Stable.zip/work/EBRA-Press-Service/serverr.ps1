﻿param([int]$Port = 8765, [string]$DataDirectory = '\\uf11pu01\ACCESSIBILITÉ_ CONSEILLERS\EBRA SERVICE\EBRA SERVICE')
$ErrorActionPreference = 'Stop'
$utf8 = New-Object System.Text.UTF8Encoding($false)
$root = Join-Path $PSScriptRoot 'web'
$script:mailConfigPath = Join-Path $PSScriptRoot 'outlook-config.json'
$script:mailHistoryPath = Join-Path $DataDirectory 'outlook-historique.json'
$script:communityPath = Join-Path $DataDirectory 'communaute.json'
$presenceIdentity=(([string]$env:COMPUTERNAME+'-'+[string]$env:USERNAME) -replace '[^A-Za-z0-9_.-]','_')
$script:presencePath = Join-Path $DataDirectory ('agents-presence-'+$presenceIdentity+'.json')
$script:applicationRole = 'Agent'
. (Join-Path $PSScriptRoot 'outlook.ps1')
. (Join-Path $PSScriptRoot 'community.ps1')
. (Join-Path $PSScriptRoot 'presence.ps1')
[IO.Directory]::CreateDirectory($DataDirectory) | Out-Null
$database = Join-Path $DataDirectory 'traitements.json'
$lockPath = Join-Path $DataDirectory 'traitements.verrou'
$mutex = New-Object Threading.Mutex($false, ('Local\EbraPressService' + $Port))
if (-not $mutex.WaitOne(0)) { exit }
function Save-Records($records) {
    $json = ConvertTo-Json -InputObject @($records) -Depth 8
    $payload = $utf8.GetBytes($json)
    $handle = $null
    $snapshot = $null
    $backup = $null
    $changed = $false
    try {
        # Open without truncation: no rename/delete rights required on SMB.
        $handle = [IO.File]::Open($database, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        if ($handle.Length -gt 0) {
            $snapshot = New-Object byte[] ([int]$handle.Length)
            $offset = 0
            while ($offset -lt $snapshot.Length) {
                $count = $handle.Read($snapshot, $offset, $snapshot.Length - $offset)
                if ($count -eq 0) { throw 'Lecture incomplete du fichier existant.' }
                $offset += $count
            }
            $backup = $database + '.avant-enregistrement-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N') + '.bak'
            # Never alter the database unless its backup has been saved.
            [IO.File]::WriteAllBytes($backup, $snapshot)
        }
        $handle.Position = 0
        $changed = $true
        $handle.Write($payload, 0, $payload.Length)
        $handle.SetLength($payload.Length)
        $handle.Flush($true)
    } catch {
        $detail = $_.Exception.Message
        $recovery = ''
        if ($changed -and $null -ne $snapshot) {
            try {
                $handle.Position = 0
                $handle.Write($snapshot, 0, $snapshot.Length)
                $handle.SetLength($snapshot.Length)
                $handle.Flush($true)
                $recovery = ' La version precedente a ete restauree.'
            } catch {
                $recovery = " Restauration automatique impossible. Arretez le serveur et restaurez la sauvegarde : $backup"
            }
        }
        throw "Enregistrement impossible dans $database. Verifiez les droits de modification et de creation de fichiers dans ce dossier et fermez les programmes utilisant le JSON.$recovery Detail : $detail"
    } finally {
        if ($null -ne $handle) { $handle.Dispose() }
    }
}
function Read-Records {
    if (-not [IO.File]::Exists($database)) { return }
    $raw = [IO.File]::ReadAllText($database, $utf8)
    if (-not $raw.Trim().StartsWith('[')) { throw 'Le fichier JSON est invalide. Restaurez la sauvegarde .bak.' }
    $parsed = $raw | ConvertFrom-Json
    # Windows PowerShell 5.1 can emit a decorated array as a single pipeline
    # object. Enumerate explicitly, including wrappers written by version 1.
    Expand-Records $parsed
}
function Expand-Records($items) {
    foreach ($item in $items) {
        if ($null -eq $item) { throw 'Entree JSON vide : aucune donnee ne sera ecrasee.' }
        if ($item -is [array]) { Expand-Records $item }
        elseif ($item.PSObject.Properties['id']) { Write-Output $item }
        elseif ($item.PSObject.Properties['value'] -and $item.PSObject.Properties['Count']) {
            $script:needsMigration = $true
            Expand-Records $item.value
        } else { throw 'Structure JSON inconnue : aucune donnee ne sera ecrasee.' }
    }
}
function Optional($value, $max) {
    if ($null -eq $value) { return '' }
    if ($value -isnot [string] -or $value.Length -gt $max) { throw 'Champ trop long.' }
    return $value.Trim()
}
function Set-Field($record, $name, $value) { $record | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force }
function Audit($record, $action, $details) {
    $entries = @()
    if ($record.PSObject.Properties['journal']) { $entries = @($record.journal | Where-Object { $null -ne $_ }) }
    Set-Field $record 'journal' @($entries + [pscustomobject]@{ date = [DateTimeOffset]::Now.ToString('o'); collaborateur = $env:USERNAME; action = $action; details = $details })
}
function Verify-Fields($data) {
    if ($data.type -notin @('Avis de décès','Remerciements','Anniversaire de décès Messe Anniversaire','Avis de Messe','Messe de Quarantaine','Souvenir','Entreprise-collectivités-associations','Anniversaire','Erratum','Messe de trentaine','Hommage')) { throw 'Selectionnez un type valide.' }
    if ($data.origine -notin @('Front','Back','Web')) { throw 'Selectionnez une origine valide.' }
    if ($data.titre -notin @('DNA','ALS','LDL','LER','LRL','VOM','LPR','JSL','LBP')) { throw 'Selectionnez un titre valide.' }
    [void](Optional $data.numeroOrdre 200); [void](Optional $data.client 200); [void](Optional $data.numeroClient 200)
}
function Verify-EditableFields($data) {
    if (-not [string]::IsNullOrWhiteSpace([string]$data.type) -and $data.type -notin @('Avis de décès','Remerciements','Anniversaire de décès Messe Anniversaire','Avis de Messe','Messe de Quarantaine','Souvenir','Entreprise-collectivités-associations','Anniversaire','Erratum','Messe de trentaine','Hommage')) { throw 'Type invalide.' }
    if (-not [string]::IsNullOrWhiteSpace([string]$data.origine) -and $data.origine -notin @('Front','Back','Web')) { throw 'Origine invalide.' }
    if (-not [string]::IsNullOrWhiteSpace([string]$data.titre) -and $data.titre -notin @('DNA','ALS','LDL','LER','LRL','VOM','LPR','JSL','LBP')) { throw 'Titre invalide.' }
}
function Required($value, $max) {
    if ($value -isnot [string] -or [string]::IsNullOrWhiteSpace($value) -or $value.Length -gt $max) { throw 'Champ obligatoire manquant ou trop long.' }
    return $value.Trim()
}
function Get-MailClaims($records) {
    $claims=@{}
    foreach($record in @($records)) {
        if ($record.statut -eq 'En cours' -and $record.PSObject.Properties['emailEntryId'] -and -not [string]::IsNullOrWhiteSpace([string]$record.emailEntryId)) {
            $claims[[string]$record.emailEntryId]=[pscustomobject]@{ collaborateur=[string]$record.collaborateur; statut=[string]$record.statut; traitementId=[string]$record.id; date=[string]$record.datePriseEnCharge }
        }
    }
    return $claims
}
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
    $script:needsMigration = $false
    $initialRecords = @(Read-Records)
    if ($script:needsMigration) {
        $backup = $database + '.avant-correction-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '.bak'
        [IO.File]::Copy($database, $backup, $false)
        Save-Records $initialRecords
    }
    # Legacy ghost treatments must not occupy the live work queue. Keep them
    # for review, with their original dates and comments, rather than closing
    # them with fabricated processing durations.
    $legacyIds = @{}
    foreach ($legacyBackup in Get-ChildItem -LiteralPath $DataDirectory -Filter 'traitements.json.avant-correction-*.bak') {
        $legacyData = [IO.File]::ReadAllText($legacyBackup.FullName, $utf8) | ConvertFrom-Json
        foreach ($legacyRecord in @(Expand-Records $legacyData)) { $legacyIds[$legacyRecord.id] = $true }
    }
    $recovered = @($initialRecords | Where-Object { $_.statut -eq 'En cours' -and $legacyIds.ContainsKey($_.id) })
    if ($recovered.Count -gt 0) {
        [IO.File]::Copy($database, ($database + '.avant-deblocage-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '.bak'), $false)
        foreach ($record in $recovered) {
            $record.statut = 'A verifier'
            $record | Add-Member -NotePropertyName motifVerification -NotePropertyValue 'Ancienne trace issue du bug initial ; retiree de la file active sans inventer de date de fin.' -Force
            $record | Add-Member -NotePropertyName dateArchivage -NotePropertyValue ([DateTimeOffset]::Now.ToString('o')) -Force
        }
        Save-Records $initialRecords
    }
    $script:shutdownRequested=$false
    try { Set-AgentPresence $true|Out-Null } catch { }
    $lastPresenceSignal=[DateTimeOffset]::MinValue
    while (-not $script:shutdownRequested) {
        $now=[DateTimeOffset]::Now
        if (($now-$lastPresenceSignal).TotalSeconds -ge 5) {
            try { Set-AgentPresence $true|Out-Null } catch { }
            $lastPresenceSignal=$now
        }
        if (-not $listener.Pending()) {
            Start-Sleep -Milliseconds 250
            continue
        }
        $client = $listener.AcceptTcpClient()
        $client.ReceiveTimeout = 5000
        $client.SendTimeout = 5000
        $stream = $client.GetStream()
        try {
            $header = New-Object 'System.Collections.Generic.List[byte]'
            while ($header.Count -lt 16384) {
                $b = $stream.ReadByte()
                if ($b -lt 0) { throw 'Connexion interrompue.' }
                $header.Add([byte]$b)
                $n = $header.Count
                if ($n -ge 4 -and $header[$n-4] -eq 13 -and $header[$n-3] -eq 10 -and $header[$n-2] -eq 13 -and $header[$n-1] -eq 10) { break }
            }
            $lines = [Text.Encoding]::ASCII.GetString($header.ToArray()) -split "`r`n"
            $request = $lines[0] -split ' '
            $method = $request[0]; $path = $request[1]
            $headers = @{}
            foreach ($line in $lines | Select-Object -Skip 1) {
                if ($line.Contains(':')) { $pair = $line -split ':', 2; $headers[$pair[0].ToLowerInvariant()] = $pair[1].Trim() }
            }
            if ($headers['host'] -notin @("127.0.0.1:$Port", "localhost:$Port")) { throw 'Hote non autorise.' }
            $length = 0
            if ($headers.ContainsKey('content-length')) { $length = [int]$headers['content-length'] }
            if ($length -lt 0 -or $length -gt 32768 -or $headers.ContainsKey('transfer-encoding')) { throw 'Requete non prise en charge.' }
            $body = New-Object byte[] $length
            $offset = 0
            while ($offset -lt $length) { $read = $stream.Read($body, $offset, $length - $offset); if ($read -eq 0) { throw 'Requete incomplete.' }; $offset += $read }
            $status = '200 OK'; $type = 'application/json; charset=utf-8'
            if ($method -eq 'GET' -and $path -eq '/api/release/364') {
                $result=@{ok=$true;release='3.6.4'}
            } elseif ($method -eq 'GET' -and $path -eq '/api/state') {
                Set-AgentPresence $true|Out-Null
                $result = @{ application = 'EBRA PRESS SERVICE'; version = '3.2.0'; collaborateur = $env:USERNAME; traitements = @(Read-Records); chemin = $database }
            } elseif ($method -eq 'GET' -and $path -eq '/api/presence/ping') {
                try { $result=Set-AgentPresence $true } catch { $result=@{ok=$false;erreur=$_.Exception.Message} }
            } elseif ($method -eq 'GET' -and $path -eq '/api/mail/state') {
                $result=Get-MailState
            } elseif ($method -eq 'GET' -and $path -eq '/api/community') {
                $result=Get-Community
            } elseif ($method -eq 'POST' -and $path -eq '/api/community/send') {
                if ($headers['origin'] -notin @("http://127.0.0.1:$Port", "http://localhost:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                $result=Send-CommunityMessage ($utf8.GetString($body)|ConvertFrom-Json)
            } elseif ($method -eq 'POST' -and $path -eq '/api/shutdown') {
                if ($headers['origin'] -notin @("http://127.0.0.1:$Port", "http://localhost:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                try { Set-AgentPresence $false|Out-Null } catch { }
                $result=@{ok=$true;message='Serveur agent arrete.'}
                $script:shutdownRequested=$true
            } elseif ($method -eq 'POST' -and $path -in @('/api/mail/folders','/api/mail/messages','/api/mail/config','/api/mail/action')) {
                if ($headers['origin'] -notin @("http://127.0.0.1:$Port", "http://localhost:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                $inputData=$utf8.GetString($body)|ConvertFrom-Json
                if($path -eq '/api/mail/folders'){$result=Get-MailFolders $inputData}
                elseif($path -eq '/api/mail/messages'){$result=Get-MailMessages $inputData (Get-MailClaims @(Read-Records))}
                elseif($path -eq '/api/mail/config'){$result=Save-MailConfig $inputData}
                else{$result=Invoke-MailAction $inputData}
            } elseif ($method -eq 'POST' -and $path -in @('/api/start', '/api/finish', '/api/update', '/api/validate', '/api/mail/claim', '/api/mail/release')) {
                if ($headers['origin'] -notin @("http://127.0.0.1:$Port", "http://localhost:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                $inputData = $utf8.GetString($body) | ConvertFrom-Json
                # A share-wide lock covers the entire read/edit/write transaction across PCs.
                $guard = $null
                for ($attempt = 0; $attempt -lt 60 -and $null -eq $guard; $attempt++) {
                    try { $guard = [IO.File]::Open($lockPath, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None) }
                    catch [IO.IOException] { Start-Sleep -Milliseconds 100 }
                }
                if ($null -eq $guard) { throw 'Dossier occupe : reessayez dans quelques secondes.' }
                try {
                    $records = @(Read-Records)
                    $now = [DateTimeOffset]::Now
                    if ($path -eq '/api/mail/claim') {
                        if ([string]::IsNullOrWhiteSpace([string]$inputData.entryId)) { throw 'E-mail invalide.' }
                        $existing=@($records|Where-Object{$_.emailEntryId -eq [string]$inputData.entryId -and $_.statut -eq 'En cours'})|Select-Object -First 1
                        if($existing){throw "Cet e-mail est deja pris en charge par $($existing.collaborateur)."}
                        if (@($records | Where-Object { $_.statut -eq 'En cours' -and $_.collaborateur -eq $env:USERNAME }).Count -gt 0) { throw 'Vous avez deja un traitement en cours.' }
                        $record=[pscustomobject]@{id=[guid]::NewGuid().ToString();type='';titre='';origine='Back';numeroOrdre='';client=[string]$inputData.sender;numeroClient='';commentaire='';datePriseEnCharge=$now.ToString('o');dateFin=$null;dmtSecondes=$null;dmt=$null;collaborateur=$env:USERNAME;statut='En cours';validationPar=$null;dateValidation=$null;revision=1;journal=@();emailEntryId=[string]$inputData.entryId;emailStoreId=[string]$inputData.storeId;emailSujet=[string]$inputData.subject;emailExpediteur=[string]$inputData.sender;emailMailboxName=[string]$inputData.mailboxName;emailSourceFolderName=[string]$inputData.sourceFolderName}
                        Audit $record 'Prise en charge e-mail' ([string]$inputData.subject)
                        Add-OutlookHistory 'Prise en charge' $inputData ('Traitement '+$record.id)
                        Add-CommunityEvent 'Prise en charge' ("$($env:USERNAME) a pris en charge un e-mail.") ([string]$inputData.subject) $record.id | Out-Null
                        $records += $record
                    } elseif ($path -eq '/api/mail/release') {
                        $record=@($records|Where-Object{$_.emailEntryId -eq [string]$inputData.entryId -and $_.statut -eq 'En cours'})|Select-Object -First 1
                        if(-not $record){throw 'Aucune prise en charge active pour cet e-mail.'}
                        if([string]$record.collaborateur -ne $env:USERNAME){throw "Seul $($record.collaborateur) peut liberer cet e-mail."}
                        Set-Field $record 'statut' 'Libere';Set-Field $record 'dateFin' $now.ToString('o');Set-Field $record 'commentaire' 'Prise en charge liberee.'
                        Audit $record 'Liberation e-mail' ([string]$inputData.subject);Add-OutlookHistory 'Libération' $inputData ('Traitement '+$record.id)
                        Add-CommunityEvent 'Libération' ("$($env:USERNAME) a libere un e-mail.") ([string]$inputData.subject) $record.id | Out-Null
                    } elseif ($path -eq '/api/start') {
                        Verify-Fields $inputData
                        if (@($records | Where-Object { $_.statut -eq 'En cours' -and $_.collaborateur -eq $env:USERNAME }).Count -gt 0) { throw 'Vous avez deja un traitement en cours.' }
                        $record = [pscustomobject]@{ id = [guid]::NewGuid().ToString(); type = $inputData.type; titre = $inputData.titre; origine = $inputData.origine; numeroOrdre = (Optional $inputData.numeroOrdre 200); client = (Optional $inputData.client 200); numeroClient = (Optional $inputData.numeroClient 200); commentaire = ''; datePriseEnCharge = $now.ToString('o'); dateFin = $null; dmtSecondes = $null; dmt = $null; collaborateur = $env:USERNAME; statut = 'En cours'; validationPar = $null; dateValidation = $null; revision = 1; journal = @() }
                        Audit $record 'Creation' 'Traitement lance.'
                        $records += $record
                    } else {
                        $record = $records | Where-Object { $_.id -eq $inputData.id } | Select-Object -First 1
                        if (-not $record) { throw 'Traitement introuvable.' }
                        if ([string]$record.collaborateur -ne [string]$env:USERNAME) { throw 'Vous pouvez modifier ou valider uniquement vos propres traitements.' }
                        if ($null -eq $inputData.revision -or [int]$inputData.revision -ne [int]$record.revision) { throw 'Ce traitement a ete modifie depuis votre derniere lecture. Actualisez avant de recommencer.' }
                        if ($path -eq '/api/finish') {
                            if ($record.statut -ne 'En cours') { throw 'Ce traitement est deja termine.' }
                            if(-not [string]::IsNullOrWhiteSpace([string]$record.emailEntryId)){$inputData.origine='Back'}
                            Verify-Fields $inputData
                            Set-Field $record 'type' ([string]$inputData.type)
                            Set-Field $record 'origine' ([string]$inputData.origine)
                            Set-Field $record 'titre' ([string]$inputData.titre)
                            Set-Field $record 'numeroOrdre' (Optional $inputData.numeroOrdre 200)
                            Set-Field $record 'client' (Optional $inputData.client 200)
                            Set-Field $record 'numeroClient' (Optional $inputData.numeroClient 200)
                            Set-Field $record 'commentaire' (Required $inputData.commentaire 5000)
                            if(-not [string]::IsNullOrWhiteSpace([string]$record.emailEntryId)){
                                $mailConfig=Get-MailConfig
                                if([string]::IsNullOrWhiteSpace([string]$mailConfig.destinationFolderId)){throw 'Configurez le dossier destination Outlook avant de terminer.'}
                                $moveData=[pscustomobject]@{action='move';entryId=[string]$record.emailEntryId;storeId=[string]$record.emailStoreId;subject=[string]$record.emailSujet;sender=[string]$record.emailExpediteur;mailboxName=[string]$record.emailMailboxName;sourceFolderName=[string]$record.emailSourceFolderName;destinationFolderId=[string]$mailConfig.destinationFolderId;destinationFolderName='Dossier destination configure'}
                                Invoke-MailAction $moveData | Out-Null
                            }
                            $seconds = [Math]::Max(0, [Math]::Floor(($now - [DateTimeOffset]::Parse($record.datePriseEnCharge)).TotalSeconds))
                            Set-Field $record 'dateFin' $now.ToString('o'); Set-Field $record 'dmtSecondes' $seconds
                            Set-Field $record 'dmt' ('{0:00}:{1:00}:{2:00}' -f [int][Math]::Floor($seconds / 3600), [int][Math]::Floor(($seconds % 3600) / 60), [int]($seconds % 60))
                            Set-Field $record 'statut' 'Termine'
                            Audit $record 'Cloture' 'Traitement termine.'
                        } elseif ($path -eq '/api/update') {
                            Verify-EditableFields $inputData
                            $changes = New-Object 'System.Collections.Generic.List[string]'
                            foreach ($name in @('type','origine','titre','numeroOrdre','client','numeroClient','commentaire')) {
                                $value = if ($name -eq 'commentaire') { Optional $inputData.$name 5000 } elseif ($name -in @('numeroOrdre','client','numeroClient')) { Optional $inputData.$name 200 } else { $inputData.$name }
                                $old = [string]$record.$name
                                if ($old -cne [string]$value) { $changes.Add("$name : [$old] -> [$value]"); Set-Field $record $name $value }
                            }
                            if ($changes.Count -eq 0) { throw 'Aucune modification detectee.' }
                            Set-Field $record 'validationPar' $null; Set-Field $record 'dateValidation' $null
                            Audit $record 'Modification' ($changes -join '; ')
                        } else {
                            if ($record.statut -eq 'En cours') { throw 'Terminez le traitement avant de le valider.' }
                            if (-not $record.type -or -not $record.origine -or -not $record.titre) { throw 'Completez Type, Origine et Titre avant validation.' }
                            Set-Field $record 'validationPar' $env:USERNAME
                            Set-Field $record 'dateValidation' $now.ToString('o')
                            Audit $record 'Validation' 'Traitement valide.'
                        }
                        Set-Field $record 'revision' ([int]$record.revision + 1)
                    }
                    Save-Records $records
                    $result = @{ ok = $true }
                } finally { $guard.Dispose() }
            } elseif ($method -eq 'GET' -and $path -eq '/agent-actions.css') {
                $type='text/css; charset=utf-8';$bytes=[IO.File]::ReadAllBytes((Join-Path $root 'agent-actions.css'))
            } elseif ($method -eq 'GET' -and $path -eq '/extensions.css') {
                $type='text/css; charset=utf-8';$bytes=[IO.File]::ReadAllBytes((Join-Path $root 'extensions.css'))
            } elseif ($method -eq 'GET' -and $path -in @('/', '/app.js', '/mail.js', '/community.js', '/theme.js', '/style.css', '/mail.css', '/community.css', '/modern.css', '/dark-extra.css')) {
                $file = @{ '/' = 'index.html'; '/app.js' = 'app.js'; '/mail.js' = 'mail.js'; '/community.js'='community.js'; '/theme.js'='theme.js'; '/style.css' = 'style.css'; '/mail.css' = 'mail.css'; '/community.css'='community.css'; '/modern.css'='modern.css'; '/dark-extra.css'='dark-extra.css' }[$path]
                $type = @{ '/' = 'text/html; charset=utf-8'; '/app.js' = 'text/javascript; charset=utf-8'; '/mail.js' = 'text/javascript; charset=utf-8'; '/community.js'='text/javascript; charset=utf-8'; '/theme.js'='text/javascript; charset=utf-8'; '/style.css' = 'text/css; charset=utf-8'; '/mail.css' = 'text/css; charset=utf-8'; '/community.css'='text/css; charset=utf-8'; '/modern.css'='text/css; charset=utf-8'; '/dark-extra.css'='text/css; charset=utf-8' }[$path]
                $bytes = [IO.File]::ReadAllBytes((Join-Path $root $file))
            } else { $status = '404 Not Found'; $result = @{ erreur = 'Ressource introuvable.' } }
            if ($type.StartsWith('application/json')) { $bytes = $utf8.GetBytes((ConvertTo-Json -InputObject $result -Depth 10)) }
        } catch { $status = '400 Bad Request'; $type = 'application/json; charset=utf-8'; $bytes = $utf8.GetBytes((@{ erreur = $_.Exception.Message } | ConvertTo-Json)) }
        try {
            $response = "HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nContent-Security-Policy: default-src 'self'; frame-ancestors 'none'; base-uri 'none'`r`n`r`n"
            $prefix = [Text.Encoding]::ASCII.GetBytes($response)
            $stream.Write($prefix, 0, $prefix.Length); $stream.Write($bytes, 0, $bytes.Length)
        } catch {} finally { $client.Close() }
    }
} finally { try { Set-AgentPresence $false|Out-Null } catch { }; $listener.Stop(); $mutex.ReleaseMutex(); $mutex.Dispose() }
