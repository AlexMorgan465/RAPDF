function Read-AgentPresence {
    if (-not [IO.File]::Exists($script:presencePath)) { return @() }
    try {
        $raw=[IO.File]::ReadAllText($script:presencePath,$utf8)
        if ([string]::IsNullOrWhiteSpace($raw)) { return @() }
        return @($raw|ConvertFrom-Json)
    } catch { return @() }
}

function Set-AgentPresence([bool]$online) {
    $directory=[IO.Path]::GetDirectoryName($script:presencePath)
    [IO.Directory]::CreateDirectory($directory)|Out-Null
    $now=[DateTimeOffset]::Now
    $key=([string]$env:COMPUTERNAME+'|'+[string]$env:USERNAME).ToLowerInvariant()
    try{
        $row=[pscustomobject][ordered]@{cle=$key;collaborateur=[string]$env:USERNAME;poste=[string]$env:COMPUTERNAME;statut=if($online){'En ligne'}else{'Hors ligne'};derniereActivite=$now.ToString('o')}
        $json=ConvertTo-Json -InputObject @($row) -Depth 4
        $bytes=$utf8.GetBytes($json)
        $handle=[IO.File]::Open($script:presencePath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)
        try{$handle.Position=0;$handle.Write($bytes,0,$bytes.Length);$handle.SetLength($bytes.Length);$handle.Flush($true)}finally{$handle.Dispose()}
        return @{ok=$true;collaborateur=$env:USERNAME;statut=if($online){'En ligne'}else{'Hors ligne'};date=$now.ToString('o')}
    } catch { return @{ok=$false;collaborateur=$env:USERNAME;erreur=$_.Exception.Message} }
}
