param([int]$Port = 8766, [string]$ConfigPath = (Join-Path $PSScriptRoot 'config.json'))
$ErrorActionPreference = 'Stop'
$utf8 = New-Object Text.UTF8Encoding($false)
$root = Join-Path $PSScriptRoot 'web'
$lockName = 'traitements.verrou'
$script:mailConfigPath = Join-Path $PSScriptRoot 'outlook-config.json'
$script:mailHistoryPath = Join-Path $PSScriptRoot 'outlook-historique.json'
$script:mailHistoryPaths = @($script:mailHistoryPath)
$script:communityPath = Join-Path $PSScriptRoot 'communaute.json'
$script:applicationRole = 'Manager'
. (Join-Path $PSScriptRoot 'outlook.ps1')
. (Join-Path $PSScriptRoot 'community.ps1')
. (Join-Path $PSScriptRoot 'presence.ps1')
$mutex = New-Object Threading.Mutex($false, ('Local\EbraManager' + $Port))
if (-not $mutex.WaitOne(0)) { exit }
function Read-Config {
    $config = [IO.File]::ReadAllText($ConfigPath, $utf8) | ConvertFrom-Json
    return $config
}
function Update-MailHistoryPath {
    $config=Read-Config
    $directories = New-Object 'System.Collections.Generic.List[string]'
    foreach ($source in @($config.sources)) {
        if ([string]::IsNullOrWhiteSpace([string]$source)) { continue }
        try {
            $fullPath=[IO.Path]::GetFullPath([string]$source)
            $directory=if([IO.Directory]::Exists($fullPath)){$fullPath}else{[IO.Path]::GetDirectoryName($fullPath)}
            if (-not [string]::IsNullOrWhiteSpace($directory) -and -not $directories.Contains($directory)) { $directories.Add($directory) }
        } catch { }
    }
    if ($directories.Count -gt 0) {
        $script:mailHistoryPaths=@($directories | ForEach-Object { Join-Path $_ 'outlook-historique.json' })
        $script:mailHistoryPath=$script:mailHistoryPaths[0]
        $script:communityPath=Join-Path $directories[0] 'communaute.json'
    } else {
        $script:mailHistoryPaths=@($script:mailHistoryPath)
    }
}
function Expand-Records($items) {
    foreach ($item in $items) {
        if ($null -eq $item) { continue }
        if ($item -is [array]) { Expand-Records $item }
        elseif ($item.PSObject.Properties['id']) { Write-Output $item }
        elseif ($item.PSObject.Properties['value']) { Expand-Records $item.value }
        else { throw 'Le JSON ne contient pas des traitements EBRA.' }
    }
}
function Get-Dashboard {
    $config = Read-Config
    $issues = New-Object 'System.Collections.Generic.List[object]'
    $diagnostics = New-Object 'System.Collections.Generic.List[object]'
    $seenFiles = @{}; $unique = @{}; $duplicates = 0; $fileCount = 0
    foreach ($source in @($config.sources)) {
        $diagnostic = [pscustomobject]@{ chemin = $source; fichiers = 0; traitements = 0; erreurs = 0 }
        $diagnostics.Add($diagnostic)
        try {
            if (-not (Test-Path -LiteralPath $source)) { throw 'Dossier ou fichier inaccessible.' }
            $item = Get-Item -LiteralPath $source
            if ($item.PSIsContainer) {
                $scanErrors = @()
                $files = @(Get-ChildItem -LiteralPath $source -Filter '*.json' -File -Recurse:([bool]$config.recursive) -ErrorAction SilentlyContinue -ErrorVariable scanErrors | Select-Object -First 5001)
                foreach ($scanError in $scanErrors) { $issues.Add([pscustomobject]@{source=$source;message=$scanError.Exception.Message}); $diagnostic.erreurs++ }
                if ($files.Count -gt 5000) { throw 'Plus de 5000 fichiers JSON : choisissez un dossier plus precis.' }
            } else { $files = @($item) }
            foreach ($file in $files) {
                if ($file.Extension -ne '.json' -or $file.Name -eq 'outlook-historique.json' -or $file.Name -eq 'outlook-config.json' -or $seenFiles.ContainsKey($file.FullName)) { continue }
                $seenFiles[$file.FullName] = $true
                $fileCount++; $diagnostic.fichiers++
                try {
                    if ($file.Length -gt 25MB) { throw 'Fichier trop volumineux (limite 25 Mo par fichier).' }
                    # Source files are opened only for reading, never repaired or rewritten.
                    $raw = [IO.File]::ReadAllText($file.FullName, $utf8)
                    $parsed = $raw | ConvertFrom-Json
                    $records = @(Expand-Records $parsed)
                    foreach ($r in $records) {
                        if ([string]::IsNullOrWhiteSpace([string]$r.id)) { throw 'Identifiant de traitement absent.' }
                        $collab = [string]$r.collaborateur
                        if ([string]::IsNullOrWhiteSpace($collab)) { $collab = 'Non renseigne' }
                        $statut = [string]$r.statut
                        if ($statut -eq "Termin$([char]0xE9)") { $statut = 'Termine' }
                        if ($statut -eq "$([char]0xC0) v$([char]0xE9)rifier") { $statut = 'A verifier' }
                        $seconds = $null
                        if ($null -ne $r.dmtSecondes) {
                            $number = 0.0
                            if ([double]::TryParse([string]$r.dmtSecondes, [ref]$number) -and $number -ge 0) { $seconds = $number }
                        }
                        $record = [pscustomobject]@{
                            id = [string]$r.id; collaborateur = $collab; type = [string]$r.type
                            titre = [string]$r.titre; origine = [string]$r.origine; commentaire = [string]$r.commentaire
                            numeroOrdre = [string]$r.numeroOrdre; client = [string]$r.client; numeroClient = [string]$r.numeroClient
                            validationPar = [string]$r.validationPar; dateValidation = $r.dateValidation; revision = [int]$r.revision; journal = @($r.journal | Where-Object { $null -ne $_ })
                            emailEntryId = [string]$r.emailEntryId; emailStoreId = [string]$r.emailStoreId; emailSujet = [string]$r.emailSujet; emailExpediteur = [string]$r.emailExpediteur
                            statut = $statut; datePriseEnCharge = $r.datePriseEnCharge; dateFin = $r.dateFin
                            dmtSecondes = $seconds; dmt = $r.dmt; motifVerification = [string]$r.motifVerification
                            fichierSource = $file.FullName; modificationSource = $file.LastWriteTimeUtc.ToString('o')
                        }
                        $key = $file.FullName + '|' + $r.id
                        if ($unique.ContainsKey($key)) {
                            $duplicates++
                            if ([DateTime]::Parse($record.modificationSource) -le [DateTime]::Parse($unique[$key].modificationSource)) { continue }
                        }
                        $unique[$key] = $record
                        $diagnostic.traitements++
                    }
                } catch { $issues.Add([pscustomobject]@{source=$file.FullName;message=$_.Exception.Message}); $diagnostic.erreurs++ }
            }
        } catch { $issues.Add([pscustomobject]@{source=$source;message=$_.Exception.Message}); $diagnostic.erreurs++ }
    }
    return @{ application = 'EBRA MANAGER'; version = '3.6.4'; collaborateur=$env:USERNAME; actualiseLe = [DateTimeOffset]::Now.ToString('o'); traitements = @($unique.Values | Sort-Object datePriseEnCharge -Descending); sources = $diagnostics.ToArray(); erreurs = $issues.ToArray(); fichiers = $fileCount; doublons = $duplicates; recursive = [bool]$config.recursive }
}
function Get-MailClaimsFromDashboard {
    $claims=@{}
    foreach($record in @((Get-Dashboard).traitements)) {
        if($record.statut -eq 'En cours' -and -not [string]::IsNullOrWhiteSpace([string]$record.emailEntryId)){$claims[[string]$record.emailEntryId]=[pscustomobject]@{collaborateur=$record.collaborateur;statut=$record.statut;traitementId=$record.id;date=$record.datePriseEnCharge}}
    }
    return $claims
}
function Save-Records($records) {
    $json = ConvertTo-Json -InputObject @($records) -Depth 8
    $payload = $utf8.GetBytes($json)
    $handle = $null
    $snapshot = $null
    $backup = $null
    $changed = $false
    try {
        # Open without truncation: no rename/delete rights required on SMB.
        $handle = [IO.File]::Open($database, [IO.FileMode]::OpenOrCreate, [IO.FileAccess]::ReadWrite, [IO.FileShare]::None)
        if ($handle.Length -gt 0) {
            $snapshot = New-Object byte[] ([int]$handle.Length)
            $offset = 0
            while ($offset -lt $snapshot.Length) {
                $count = $handle.Read($snapshot, $offset, $snapshot.Length - $offset)
                if ($count -eq 0) { throw 'Lecture incomplete du fichier existant.' }
                $offset += $count
            }
            $backup = $database + '.avant-enregistrement-' + [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff') + '-' + [guid]::NewGuid().ToString('N') + '.bak'
            # Never alter the database unless its backup has been saved.
            [IO.File]::WriteAllBytes($backup, $snapshot)
        }
        $handle.Position = 0
        $changed = $true
        $handle.Write($payload, 0, $payload.Length)
        $handle.SetLength($payload.Length)
        $handle.Flush($true)
    } catch {
        $detail = $_.Exception.Message
        $recovery = ''
        if ($changed -and $null -ne $snapshot) {
            try {
                $handle.Position = 0
                $handle.Write($snapshot, 0, $snapshot.Length)
                $handle.SetLength($snapshot.Length)
                $handle.Flush($true)
                $recovery = ' La version precedente a ete restauree.'
            } catch {
                $recovery = " Restauration automatique impossible. Arretez le serveur et restaurez la sauvegarde : $backup"
            }
        }
        throw "Enregistrement impossible dans $database. Verifiez les droits de modification et de creation de fichiers dans ce dossier et fermez les programmes utilisant le JSON.$recovery Detail : $detail"
    } finally {
        if ($null -ne $handle) { $handle.Dispose() }
    }
}
function Optional($value, $max) {
    if ($null -eq $value) { return '' }
    if ($value -isnot [string] -or $value.Length -gt $max) { throw 'Champ trop long.' }
    return $value.Trim()
}
function Set-Field($record, $name, $value) { $record | Add-Member -NotePropertyName $name -NotePropertyValue $value -Force }
function Audit($record, $action, $details) {
    $entries = @()
    if ($record.PSObject.Properties['journal']) { $entries = @($record.journal | Where-Object { $null -ne $_ }) }
    Set-Field $record 'journal' @($entries + [pscustomobject]@{ date = [DateTimeOffset]::Now.ToString('o'); collaborateur = $env:USERNAME; action = $action; details = $details })
}
function Verify-Fields($data) {
    if ($data.type -notin @('Avis de décès','Remerciements','Anniversaire de décès Messe Anniversaire','Avis de Messe','Messe de Quarantaine','Souvenir','Entreprise-collectivités-associations','Anniversaire','Erratum','Messe de trentaine','Hommage')) { throw 'Selectionnez un type valide.' }
    if ($data.origine -notin @('Front','Back','Web')) { throw 'Selectionnez une origine valide.' }
    if ($data.titre -notin @('DNA','ALS','LDL','LER','LRL','VOM','LPR','JSL','LBP')) { throw 'Selectionnez un titre valide.' }
}
function Verify-EditableFields($data) {
    if (-not [string]::IsNullOrWhiteSpace([string]$data.type) -and $data.type -notin @('Avis de décès','Remerciements','Anniversaire de décès Messe Anniversaire','Avis de Messe','Messe de Quarantaine','Souvenir','Entreprise-collectivités-associations','Anniversaire','Erratum','Messe de trentaine','Hommage')) { throw 'Type invalide.' }
    if (-not [string]::IsNullOrWhiteSpace([string]$data.origine) -and $data.origine -notin @('Front','Back','Web')) { throw 'Origine invalide.' }
    if (-not [string]::IsNullOrWhiteSpace([string]$data.titre) -and $data.titre -notin @('DNA','ALS','LDL','LER','LRL','VOM','LPR','JSL','LBP')) { throw 'Titre invalide.' }
}
function Edit-Record($inputData, $action) {
    $config = Read-Config
    $target = [string]$inputData.fichierSource
    if ($target -notmatch '\.json$' -or -not [IO.File]::Exists($target)) { throw 'Fichier source introuvable.' }
    # Only explicitly configured sources are editable; a scanned directory grants
    # access only to JSON files inside that directory.
    $allowed = $false
    $full = [IO.Path]::GetFullPath($target)
    foreach ($source in @($config.sources)) {
        $base = [IO.Path]::GetFullPath([string]$source)
        if ($full.Equals($base, [StringComparison]::OrdinalIgnoreCase)) { $allowed = $true }
        elseif ([IO.Directory]::Exists($base) -and $full.StartsWith(($base.TrimEnd('\') + '\'), [StringComparison]::OrdinalIgnoreCase)) { $allowed = $true }
    }
    if (-not $allowed) { throw 'Fichier hors des sources configurees.' }
    $script:database = $full
    $lockPath = Join-Path ([IO.Path]::GetDirectoryName($full)) $lockName
    $guard = $null
    for ($attempt=0; $attempt -lt 60 -and $null -eq $guard; $attempt++) {
        try { $guard = [IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
        catch [IO.IOException] { Start-Sleep -Milliseconds 100 }
    }
    if ($null -eq $guard) { throw 'Dossier occupe. Reessayez.' }
    try {
        $raw = [IO.File]::ReadAllText($full, $utf8)
        if (-not $raw.Trim().StartsWith('[')) { throw 'Structure JSON non prise en charge pour modification.' }
        $records = @(Expand-Records ($raw | ConvertFrom-Json))
        $matches = @($records | Where-Object { $_.id -eq $inputData.id })
        if ($matches.Count -ne 1) { throw 'Identifiant introuvable ou duplique dans le fichier.' }
        $record = $matches[0]
        if ($null -eq $inputData.revision -or [int]$inputData.revision -ne [int]$record.revision) { throw 'Traitement modifie depuis la derniere lecture. Actualisez la page.' }
        if ($action -eq 'update') {
            Verify-EditableFields $inputData
            $changes = New-Object 'System.Collections.Generic.List[string]'
            foreach ($name in @('type','origine','titre','numeroOrdre','client','numeroClient','commentaire')) {
                $max = if ($name -eq 'commentaire') { 5000 } else { 200 }
                $value = if ($name -in @('type','origine','titre')) { [string]$inputData.$name } else { Optional $inputData.$name $max }
                $old = [string]$record.$name
                if ($old -cne $value) { $changes.Add("$name : [$old] -> [$value]"); Set-Field $record $name $value }
            }
            if ($changes.Count -eq 0) { throw 'Aucune modification detectee.' }
            Set-Field $record 'validationPar' $null
            Set-Field $record 'dateValidation' $null
            Audit $record 'Modification' ($changes -join '; ')
        } else {
            if ($record.statut -eq 'En cours') { throw 'Terminez le traitement avant validation.' }
            if (-not $record.type -or -not $record.origine -or -not $record.titre) { throw 'Renseignez Type, Origine et Titre avant validation.' }
            Set-Field $record 'validationPar' $env:USERNAME
            Set-Field $record 'dateValidation' ([DateTimeOffset]::Now.ToString('o'))
            Audit $record 'Validation' 'Traitement valide.'
        }
        Set-Field $record 'revision' ([int]$record.revision + 1)
        Save-Records $records
        return @{ok=$true}
    } finally { $guard.Dispose() }
}
function Claim-ManagerMail($inputData) {
    $config=Read-Config
    $target=@($config.sources|Where-Object{[string]$_ -match '\.json$'})|Select-Object -First 1
    if(-not $target){throw 'Configurez un fichier traitements.json dans Sources JSON avant la prise en charge.'}
    $script:database=[IO.Path]::GetFullPath([string]$target)
    $lockPath=Join-Path ([IO.Path]::GetDirectoryName($script:database)) $lockName
    $guard=$null
    for ($attempt = 0; $attempt -lt 60 -and $null -eq $guard; $attempt++) { try { $guard=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) } catch [IO.IOException] { Start-Sleep -Milliseconds 100 } }
    if ($null -eq $guard) { throw 'Dossier occupe. Reessayez.' }
    try{
        $records=@()
        if([IO.File]::Exists($script:database)){$records=@(Expand-Records ([IO.File]::ReadAllText($script:database,$utf8)|ConvertFrom-Json))}
        $existing=@($records|Where-Object{$_.emailEntryId -eq [string]$inputData.entryId -and $_.statut -eq 'En cours'})|Select-Object -First 1
        if($existing){throw "Cet e-mail est deja pris en charge par $($existing.collaborateur)."}
        if (@($records | Where-Object { $_.statut -eq 'En cours' -and $_.collaborateur -eq $env:USERNAME }).Count -gt 0) { throw 'Vous avez deja un traitement en cours.' }
        $now=[DateTimeOffset]::Now
        $record=[pscustomobject]@{id=[guid]::NewGuid().ToString();type='';titre='';origine='Back';numeroOrdre='';client=[string]$inputData.sender;numeroClient='';commentaire='';datePriseEnCharge=$now.ToString('o');dateFin=$null;dmtSecondes=$null;dmt=$null;collaborateur=$env:USERNAME;statut='En cours';validationPar=$null;dateValidation=$null;revision=1;journal=@([pscustomobject]@{date=$now.ToString('o');collaborateur=$env:USERNAME;action='Prise en charge e-mail';details=[string]$inputData.subject});emailEntryId=[string]$inputData.entryId;emailStoreId=[string]$inputData.storeId;emailSujet=[string]$inputData.subject;emailExpediteur=[string]$inputData.sender;emailMailboxName=[string]$inputData.mailboxName;emailSourceFolderName=[string]$inputData.sourceFolderName}
        $records+=$record
        Save-Records $records
        Add-OutlookHistory 'Prise en charge' $inputData ('Traitement '+$record.id)
        Add-CommunityEvent 'Prise en charge' ("$($env:USERNAME) a pris en charge un e-mail.") ([string]$inputData.subject) $record.id | Out-Null
        return @{ok=$true;traitementId=$record.id}
    }finally{$guard.Dispose()}
}
function Release-ManagerMail($inputData) {
    $config=Read-Config;$target=@($config.sources|Where-Object{[string]$_ -match '\.json$'})|Select-Object -First 1
    if(-not $target){throw 'Configurez un fichier traitements.json dans Sources JSON.'}
    $script:database=[IO.Path]::GetFullPath([string]$target);$lockPath=Join-Path ([IO.Path]::GetDirectoryName($script:database)) $lockName;$guard=$null
    for($i=0;$i -lt 60 -and $null -eq $guard;$i++){try{$guard=[IO.File]::Open($lockPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch [IO.IOException]{Start-Sleep -Milliseconds 100}}
    if($null -eq $guard){throw 'Dossier occupe. Reessayez.'}
    try{$records=@(Expand-Records ([IO.File]::ReadAllText($script:database,$utf8)|ConvertFrom-Json));$record=@($records|Where-Object{$_.emailEntryId -eq [string]$inputData.entryId -and $_.statut -eq 'En cours'})|Select-Object -First 1;if(-not $record){throw 'Aucune prise en charge active.'};if([string]$record.collaborateur -ne $env:USERNAME){throw "Seul $($record.collaborateur) peut liberer cet e-mail."};Set-Field $record 'statut' 'Libere';Set-Field $record 'dateFin' ([DateTimeOffset]::Now.ToString('o'));Set-Field $record 'commentaire' 'Prise en charge liberee.';Audit $record 'Liberation e-mail' ([string]$inputData.subject);Set-Field $record 'revision' ([int]$record.revision+1);Save-Records $records;Add-OutlookHistory 'Libération' $inputData ('Traitement '+$record.id);Add-CommunityEvent 'Libération' ("$($env:USERNAME) a libere un e-mail.") ([string]$inputData.subject) $record.id|Out-Null;return @{ok=$true}}finally{$guard.Dispose()}
}
function Save-Config($inputData) {
    if ($null -eq $inputData.sources -or @($inputData.sources).Count -gt 50) { throw 'Indiquez au maximum 50 sources.' }
    $sources = @()
    foreach ($source in @($inputData.sources)) {
        if ($source -isnot [string] -or $source -notmatch '^(?:[a-zA-Z]:[\\/]|\\\\[^\\]+\\[^\\]+)' -or $source.Length -gt 1024) { throw 'Utilisez un chemin Windows absolu ou un partage reseau UNC.' }
        $sources += $source.Trim()
    }
    $newConfig = @{sources=@($sources | Select-Object -Unique);recursive=[bool]$inputData.recursive}
    $temp = $ConfigPath + '.tmp'
    [IO.File]::WriteAllText($temp, (ConvertTo-Json -InputObject $newConfig -Depth 4), $utf8)
    [IO.File]::Replace($temp, $ConfigPath, ($ConfigPath + '.bak'))
    Update-MailHistoryPath
}
Update-MailHistoryPath
$listener = New-Object Net.Sockets.TcpListener([Net.IPAddress]::Loopback, $Port)
try {
    $listener.Start()
    $script:shutdownRequested=$false
    while (-not $script:shutdownRequested) {
        $client = $listener.AcceptTcpClient(); $client.ReceiveTimeout = 2000; $client.SendTimeout = 10000
        $stream = $client.GetStream()
        try {
            $buffer = New-Object 'System.Collections.Generic.List[byte]'
            $ended = $false
            while ($buffer.Count -lt 16384) {
                $b = $stream.ReadByte(); if ($b -lt 0) { throw 'Connexion fermee.' }; $buffer.Add([byte]$b)
                $n = $buffer.Count
                if ($n -ge 4 -and $buffer[$n-4] -eq 13 -and $buffer[$n-3] -eq 10 -and $buffer[$n-2] -eq 13 -and $buffer[$n-1] -eq 10) { $ended=$true; break }
            }
            if (-not $ended) { throw 'Entete trop volumineux.' }
            $lines = [Text.Encoding]::ASCII.GetString($buffer.ToArray()) -split "`r`n"
            $request = $lines[0] -split ' '; $method = $request[0]; $path = $request[1]
            $headers = @{}
            foreach ($line in $lines | Select-Object -Skip 1) { if ($line.Contains(':')) { $p=$line -split ':',2; $headers[$p[0].ToLowerInvariant()]=$p[1].Trim() } }
            if ($headers['host'] -notin @("localhost:$Port", "127.0.0.1:$Port")) { throw 'Hote non autorise.' }
            $length = 0; if ($headers.ContainsKey('content-length')) { $length=[int]$headers['content-length'] }
            if ($length -lt 0 -or $length -gt 65536 -or $headers.ContainsKey('transfer-encoding')) { throw 'Requete non prise en charge.' }
            $body = New-Object byte[] $length; $offset=0
            while ($offset -lt $length) { $read=$stream.Read($body,$offset,$length-$offset); if($read -eq 0){throw 'Corps incomplet.'}; $offset+=$read }
            $status='200 OK'; $type='application/json; charset=utf-8'
            if ($method -eq 'GET' -and $path -eq '/api/health') { $result=@{application='EBRA MANAGER';version='3.6.4'} }
            elseif ($method -eq 'GET' -and $path -eq '/api/state') { $result=Get-Dashboard }
            elseif ($method -eq 'GET' -and $path -eq '/api/presence') { $result=Get-AgentPresence }
            elseif ($method -eq 'GET' -and $path -eq '/api/mail/state') { $result=Get-MailState }
            elseif ($method -eq 'GET' -and $path -eq '/api/mail/history') { $result=Get-OutlookHistory }
            elseif ($method -eq 'GET' -and $path -eq '/api/community') { $result=Get-Community }
            elseif ($method -eq 'POST' -and $path -eq '/api/community/send') { if ($headers['origin'] -notin @("http://localhost:$Port","http://127.0.0.1:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' };$result=Send-CommunityMessage ($utf8.GetString($body)|ConvertFrom-Json) }
            elseif ($method -eq 'POST' -and $path -eq '/api/shutdown') { if ($headers['origin'] -notin @("http://localhost:$Port","http://127.0.0.1:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' };$result=@{ok=$true;message='Serveur manager arrete.'};$script:shutdownRequested=$true }
            elseif ($method -eq 'POST' -and $path -eq '/api/config') {
                if ($headers['origin'] -notin @("http://localhost:$Port","http://127.0.0.1:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                Save-Config ($utf8.GetString($body) | ConvertFrom-Json)
                $result=@{ok=$true}
            } elseif ($method -eq 'POST' -and $path -in @('/api/update','/api/validate')) {
                if ($headers['origin'] -notin @("http://localhost:$Port","http://127.0.0.1:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                $result=Edit-Record ($utf8.GetString($body) | ConvertFrom-Json) ($path.Substring(5))
            } elseif ($method -eq 'POST' -and $path -in @('/api/mail/folders','/api/mail/messages','/api/mail/config','/api/mail/action','/api/mail/claim','/api/mail/release')) {
                if ($headers['origin'] -notin @("http://localhost:$Port","http://127.0.0.1:$Port") -or $headers['x-ebra-request'] -ne '1') { throw 'Origine non autorisee.' }
                $inputData=$utf8.GetString($body)|ConvertFrom-Json
                if ($path -eq '/api/mail/folders') { $result=Get-MailFolders $inputData }
                elseif ($path -eq '/api/mail/messages') { $result=Get-MailMessages $inputData (Get-MailClaimsFromDashboard) }
                elseif ($path -eq '/api/mail/config') { $result=Save-MailConfig $inputData }
                elseif ($path -eq '/api/mail/claim') { $result=Claim-ManagerMail $inputData }
                elseif ($path -eq '/api/mail/release') { $result=Release-ManagerMail $inputData }
                else{$result=Invoke-MailAction $inputData}
            } elseif ($method -eq 'GET' -and $path -eq '/extensions.css') {
                $type='text/css; charset=utf-8';$bytes=[IO.File]::ReadAllBytes((Join-Path $root 'extensions.css'))
            } elseif ($method -eq 'GET' -and $path -in @('/','/app.js','/mail.js','/community.js','/theme.js','/style.css','/mail.css','/community.css','/history.css','/modern.css','/dark-extra.css')) {
                $file=@{'/'='index.html';'/app.js'='app.js';'/mail.js'='mail.js';'/community.js'='community.js';'/theme.js'='theme.js';'/style.css'='style.css';'/mail.css'='mail.css';'/community.css'='community.css';'/history.css'='history.css';'/modern.css'='modern.css';'/dark-extra.css'='dark-extra.css'}[$path]
                $type=@{'/'='text/html; charset=utf-8';'/app.js'='text/javascript; charset=utf-8';'/mail.js'='text/javascript; charset=utf-8';'/community.js'='text/javascript; charset=utf-8';'/theme.js'='text/javascript; charset=utf-8';'/style.css'='text/css; charset=utf-8';'/mail.css'='text/css; charset=utf-8';'/community.css'='text/css; charset=utf-8';'/history.css'='text/css; charset=utf-8';'/modern.css'='text/css; charset=utf-8';'/dark-extra.css'='text/css; charset=utf-8'}[$path]
                $bytes=[IO.File]::ReadAllBytes((Join-Path $root $file))
            } else { $status='404 Not Found'; $result=@{erreur='Ressource introuvable.'} }
            if ($type.StartsWith('application/json')) { $bytes=$utf8.GetBytes((ConvertTo-Json -InputObject $result -Depth 12)) }
        } catch { $status='400 Bad Request';$type='application/json; charset=utf-8';$bytes=$utf8.GetBytes((@{erreur=$_.Exception.Message}|ConvertTo-Json)) }
        try {
            $head="HTTP/1.1 $status`r`nContent-Type: $type`r`nContent-Length: $($bytes.Length)`r`nConnection: close`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nContent-Security-Policy: default-src 'self'; frame-ancestors 'none'; base-uri 'none'`r`n`r`n"
            $prefix=[Text.Encoding]::ASCII.GetBytes($head);$stream.Write($prefix,0,$prefix.Length);$stream.Write($bytes,0,$bytes.Length)
        } catch {} finally { $client.Close() }
    }
} finally { $listener.Stop();$mutex.ReleaseMutex();$mutex.Dispose() }
