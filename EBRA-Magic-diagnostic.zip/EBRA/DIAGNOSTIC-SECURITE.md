# Diagnostic de sécurité interne — EBRA

Examen statique de l'archive transmise le 1 octobre 2026. Aucun test dynamique sur le poste Windows ou le partage réseau n'a été effectué. Le renommage « Magic » ne modifie pas le modèle de segmentation local.

## Priorité haute

1. **Routes locales sans authentification effective.** Les deux serveurs écoutent sur 127.0.0.1, ce qui limite l'accès au poste, mais les GET `/api/state`, `/api/mail/state`, `/api/community` (et, côté manager, `/api/mail/history`) rendent des données sans contrôle d'identité. Les POST vérifient `Origin` et `X-Ebra-Request`, qui ne constituent pas une authentification face à un autre programme exécuté sur le même poste. Côté manager, `/api/config`, `/api/update`, `/api/validate`, `/api/mail/action` et `/api/shutdown` ont ainsi un impact élevé si un processus local non fiable les appelle. Côté agent, les actions de prise en charge et messagerie sont également exposées localement. Le `Host` vérifié et la liaison loopback ne corrigent pas ce point. Prévoir une session avec jeton aléatoire par lancement, validation serveur et droits distincts manager/agent ; le jeton doit rester inaccessible aux autres processus non autorisés autant que possible. Le port local partagé ne suffit pas à identifier un utilisateur.

2. **Exécution potentielle d'une pièce jointe Outlook.** Dans `EBRA-Manager/outlook.ps1` et `EBRA-Press-Service/outlook.ps1`, l'action `attachment` enregistre un fichier dans `%TEMP%/EBRA-Outlook` puis appelle `Start-Process` sur ce fichier. Un e-mail contenant un `.exe`, `.ps1`, `.vbs`, `.js`, `.lnk` ou autre type exécutable peut donc être lancé avec les droits de la session. Restreindre aux types approuvés, vérifier le type réel et ouvrir les fichiers non fiables dans une application isolée ; ne pas lancer automatiquement des pièces jointes arbitraires.

3. **Intégrité du code sur partage réseau.** Si les collaborateurs ont le droit d'écrire dans les répertoires des scripts `.ps1`, `.js`, `.wasm` ou du modèle `.tflite`, un changement peut exécuter du code ou modifier les résultats pour les autres. Mettre les programmes en lecture seule pour les utilisateurs, réserver l'écriture des mises à jour à un groupe contrôlé, et séparer le stockage des données. Vérifier aussi les ACL du partage et les droits NTFS.

## Priorité moyenne

4. **Sources JSON configurables.** `EBRA-Manager/serveur.ps1` accepte `/api/config` et des chemins Windows absolus/UNC puis lit leurs JSON. Des sources ajoutées par un programme local peuvent entraîner une lecture de fichiers non prévus, un balayage réseau ou une lenteur. Limiter les racines autorisées et réserver la configuration à un administrateur de l'application.

5. **Bibliothèques et modèle tiers.** Les fichiers MediaPipe sont déjà embarqués dans `web/ai`; leur provenance, leur version et leur empreinte ne sont pas vérifiables depuis cette archive. Vérifier leur origine à l'installation et contrôler les sommes SHA-256 avant déploiement. Le traitement de détourage utilise ces fichiers locaux et ne montre pas d'appel à un service cloud dans `photo375.js`.

## Protections constatées

- Écoute limitée à `IPAddress.Loopback` dans les deux serveurs.
- Liste explicite des fichiers HTTP servis ; pas de répertoire web générique exposé.
- Contrôles `Origin` et en-tête personnalisé sur les POST du navigateur ; limites de taille des requêtes.
- `Content-Security-Policy`, `X-Content-Type-Options: nosniff`, `Cache-Control: no-store`.
- Plusieurs validations des champs métier et des chemins source.

Ce diagnostic ne certifie pas la sécurité globale : il faut vérifier sur Windows les ACL, les processus effectivement lancés, le trafic réseau, Outlook et la gestion des mises à jour.
