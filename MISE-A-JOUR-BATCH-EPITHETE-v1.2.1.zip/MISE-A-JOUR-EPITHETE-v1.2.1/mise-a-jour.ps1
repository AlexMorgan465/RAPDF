$ErrorActionPreference = 'Stop'

function Find-TargetRoot {
    $candidates = @($PSScriptRoot, (Split-Path $PSScriptRoot -Parent))
    foreach ($candidate in $candidates) {
        if ((Test-Path (Join-Path $candidate 'EPITHETE-Agent')) -and
            (Test-Path (Join-Path $candidate 'EPITHETE-Manager'))) {
            return $candidate
        }
    }
    throw "Placez le dossier de mise a jour dans le dossier qui contient EPITHETE-Agent et EPITHETE-Manager."
}

function Stop-LocalServer([int]$Port) {
    try {
        Invoke-RestMethod "http://127.0.0.1:$Port/api/shutdown" -Method Post -ContentType 'application/json' -Body '{}' -TimeoutSec 2 | Out-Null
    } catch {
        # Le serveur est deja arrete ou inaccessible.
    }
}

$targetRoot = Find-TargetRoot
$payloadRoot = Join-Path $PSScriptRoot 'payload'
if (-not (Test-Path $payloadRoot)) { throw 'Le dossier payload de la mise a jour est introuvable.' }

Write-Host 'Arret des serveurs EPITHETE...' -ForegroundColor Cyan
Stop-LocalServer 8775
Stop-LocalServer 8776
Start-Sleep -Milliseconds 900

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backupRoot = Join-Path $targetRoot ("Sauvegarde-avant-EPITHETE-v1.2.1-$stamp")
$files = @(
    'EPITHETE-Agent\serveur.ps1',
    'EPITHETE-Agent\web\index.html',
    'EPITHETE-Agent\web\app.js',
    'EPITHETE-Manager\serveur.ps1',
    'EPITHETE-Manager\web\index.html',
    'EPITHETE-Manager\web\app.js'
)

Write-Host "Creation de la sauvegarde : $backupRoot" -ForegroundColor Cyan
foreach ($relative in $files) {
    $source = Join-Path $targetRoot $relative
    if (Test-Path $source) {
        $backup = Join-Path $backupRoot $relative
        New-Item -ItemType Directory -Path (Split-Path $backup -Parent) -Force | Out-Null
        Copy-Item -LiteralPath $source -Destination $backup -Force
    }
}

Write-Host 'Installation des fichiers corriges...' -ForegroundColor Cyan
foreach ($relative in $files) {
    $source = Join-Path $payloadRoot $relative
    $destination = Join-Path $targetRoot $relative
    if (-not (Test-Path $source)) { throw "Fichier de mise a jour manquant : $relative" }
    Copy-Item -LiteralPath $source -Destination $destination -Force
}

Write-Host ''
Write-Host 'Mise a jour v1.2.1 installee.' -ForegroundColor Green
Write-Host 'Les donnees et les traitements existants ont ete conserves.' -ForegroundColor Green
Write-Host 'Relancez ensuite Agent ou Manager avec leur fichier Lancer.bat.' -ForegroundColor Yellow
exit 0
