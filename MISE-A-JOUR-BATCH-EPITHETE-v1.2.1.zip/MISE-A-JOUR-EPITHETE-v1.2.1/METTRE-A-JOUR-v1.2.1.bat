@echo off
setlocal
title EPITHETE - Mise a jour v1.2.1
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0mise-a-jour.ps1"
set "UPDATE_EXIT=%ERRORLEVEL%"
echo.
if not "%UPDATE_EXIT%"=="0" (
  echo La mise a jour a rencontre une erreur.
  echo Consultez le message ci-dessus.
) else (
  echo Mise a jour terminee avec succes.
)
echo.
pause
exit /b %UPDATE_EXIT%
