﻿param([string]$RootPath)
$ErrorActionPreference="Stop"
$SchemaData=[IO.File]::ReadAllText((Join-Path $PSScriptRoot 'schema.json'),[Text.Encoding]::UTF8)|ConvertFrom-Json
$Schema=[ordered]@{}
foreach($entry in $SchemaData.entities){$Schema[$entry.entity]=@{Mode=$entry.mode;Branches=@($entry.branches)}}
$Statuses=@($SchemaData.statuses)
function J($o){$o|ConvertTo-Json -Depth 8 -Compress}
function Send($c,$code,$o){$b=[Text.Encoding]::UTF8.GetBytes((J $o));$c.Response.StatusCode=$code;$c.Response.ContentType="application/json; charset=utf-8";$c.Response.Headers["Cache-Control"]="no-store";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Q($r){$h=@{};if($r.Url.Query.Length-gt 1){foreach($p in $r.Url.Query.Substring(1).Split("&")){$k=$p.Split("=",2);if($k.Count-eq 2){$h[[Uri]::UnescapeDataString($k[0])] = [Uri]::UnescapeDataString(($k[1]-replace '\+',' '))}}};$h}
function Body($r){$sr=New-Object IO.StreamReader($r.InputStream,$r.ContentEncoding);$t=$sr.ReadToEnd();$sr.Close();if(!$t){return @{}};$t|ConvertFrom-Json}
function BranchPath($e,$s,$b){
 if(!$Schema.Contains($e)){throw "Entité inconnue: $e"}; if($Statuses-notcontains$s){throw "Statut invalide"}
 $cfg=$Schema[$e]
 if($b -and ($b.StartsWith('\') -or $b.Contains('/') -or $b.Contains(':') -or @($b.Replace('|','\').Split('\')|Where-Object {$_ -in @('','..','.')}).Count)){throw 'Sous-entité invalide'}
 $p=Join-Path $RootPath $e
 if($cfg.Mode-eq"CATEGORY_FIRST"){
  if(!$b){throw "Sous-entité requise"};$parts=@($b.Split('|'));if($parts.Count-gt 2){throw 'Branche invalide'}
  $p=Join-Path (Join-Path $p $parts[0]) $s;if($parts.Count-eq 2){$p=Join-Path $p $parts[1]};return $p
 }
 $p=Join-Path $p $s;if($b){$p=Join-Path $p $b};$p
}
$HistoryRoot=Join-Path $RootPath '.accessibility_history'
$DbFile=Join-Path $HistoryRoot 'registry-v3.json'
$LockFile=Join-Path $HistoryRoot 'registry-v3.lock'
$DefaultRates=@{'Bouygues telecom'=9;'CONTRATHEQUE'=9;'CMO'=9;'DIRCO'=4.5;'ACM'=9;'CMMABN'=4.5;'DIRCOM'=9;'MONABANQ'=9;'CREATIS'=9;'CIC CIB ASSET SERVICING'=4.5}
function NowIso {(Get-Date).ToUniversalTime().ToString('o')}
function LockDb {
 if(!(Test-Path -LiteralPath $RootPath -PathType Container)){throw 'Dossier partagé inaccessible'}
 [IO.Directory]::CreateDirectory($HistoryRoot)|Out-Null
 $until=(Get-Date).AddSeconds(20)
 do {try{return [IO.File]::Open($LockFile,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{if((Get-Date)-gt$until){throw 'Registre occupé, réessayez'};Start-Sleep -Milliseconds 80}}while($true)
}
function Key($e,$b,$n){([string]$e+'|'+[string]$b+'|'+[string]$n).ToLowerInvariant()}
function LoadDb {
 if([IO.File]::Exists($DbFile)){return ([IO.File]::ReadAllText($DbFile,[Text.Encoding]::UTF8)|ConvertFrom-Json)}
 $rates=@();foreach($e in $Schema.Keys){$v=$null;if($DefaultRates.ContainsKey($e)){$v=$DefaultRates[$e]};$rates+=@{entity=$e;price=$v}}
 $hist=@();$old=Join-Path $HistoryRoot 'operations.jsonl'
 if([IO.File]::Exists($old)){foreach($line in [IO.File]::ReadLines($old)){if($line.Trim()){try{$hist+=($line|ConvertFrom-Json)}catch{throw 'Historique existant illisible : migration interrompue'}}}}
 [pscustomobject]@{version=3;documents=@();history=@($hist);rates=@($rates);scannedAt=$null;scanErrors=@()}
}
function SaveDb($db){
 $tmp=$DbFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($tmp,($db|ConvertTo-Json -Depth 20 -Compress),(New-Object Text.UTF8Encoding($false)));if([IO.File]::Exists($DbFile)){[IO.File]::Replace($tmp,$DbFile,$null)}else{[IO.File]::Move($tmp,$DbFile)}}finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
}
function NewDoc($e,$b,$s,$x,$db){
 $now=NowIso;$deposit=$x.LastWriteTimeUtc.ToString('o');$k=Key $e $b $x.Name
 $events=@($db.history|Where-Object{(Key $_.entity $_.branch $_.name)-eq$k}|Sort-Object timestamp)
 $periods=@();$entered=$now;$done=$null;$agent='';$started=$null
 if($events.Count){$depositSource='Première modification observée (document déjà suivi)';foreach($ev in $events){if($ev.to-eq'EN COURS'){$started=$ev.timestamp};$agent=$ev.agent};$entered=$events[-1].timestamp;if($events[-1].to-eq'TRAITES'){$done=$entered};for($i=0;$i-lt($events.Count-1);$i++){$periods+=@{status=$events[$i].to;start=$events[$i].timestamp;end=$events[$i+1].timestamp}}}else{$depositSource='Modification au premier scan';if($s-eq'TRAITES'){$done=$deposit};if($s-eq'A TRAITER'){$entered=$deposit}}
 [pscustomobject]@{id=[guid]::NewGuid().ToString();key=$k;entity=$e;branch=$b;name=$x.Name;kind=$(if($x.PSIsContainer){'Dossier'}else{'Fichier'});status=$s;depositAt=$deposit;depositSource=$depositSource;modifiedAt=$deposit;firstSeenAt=$now;statusSince=$entered;periods=@($periods);priority=$false;priorityComment='';complex=$false;complexComment='';comment='';unitPrice=$null;billedPrice=$(if($s -eq 'TRAITES'){($db.rates|Where-Object {$_.entity -eq $e}|Select-Object -First 1).price}else{$null});agent=$agent;startedAt=$started;completedAt=$done;present=$true}
}
function ReadDb {$lk=LockDb;try{LoadDb}finally{$lk.Dispose()}}
function FindDoc($db,$id){$d=@($db.documents|Where-Object{$_.id-eq$id});if($d.Count-ne 1){throw 'Document introuvable'};return $d[0]}
function MoveDocument($body){
 $lk=LockDb
 try{
  $db=LoadDb;$d=FindDoc $db ([string]$body.id);$to=[string]$body.to
  if($Statuses-notcontains$to){throw 'Statut invalide'}
  if(!$d.present-or$d.status-ne[string]$body.from){throw 'Document déjà pris ou déplacé. Actualisez la liste.'}
  if($d.status-eq$to){throw 'Le document est déjà dans ce statut'}
  $src=Join-Path (BranchPath $d.entity $d.status $d.branch) $d.name;$target=BranchPath $d.entity $to $d.branch
  [IO.Directory]::CreateDirectory($target)|Out-Null;$dst=Join-Path $target $d.name
  if(!(Test-Path -LiteralPath $src)){throw 'Document déjà déplacé ou introuvable'}
  if(Test-Path -LiteralPath $dst){throw 'Un document existe déjà à destination'}
  $folder=[IO.Directory]::Exists($src)
  if($folder){[IO.Directory]::Move($src,$dst)}else{[IO.File]::Move($src,$dst)}
  try{
   $now=NowIso;$from=$d.status;$dmt=$null
   if($from-eq'EN COURS'-and$d.startedAt){$dmt=[Math]::Round(([datetime]$now-[datetime]$d.startedAt).TotalMinutes,2)}
   $d.periods=@($d.periods)+@(@{status=$from;start=$d.statusSince;end=$now});$d.status=$to;$d.statusSince=$now;$d.agent=[Environment]::UserName;$d.comment=[string]$body.comment
   if($to-eq'EN COURS'){$d.startedAt=$now};if($to-eq'TRAITES'){$d.completedAt=$now;$d.billedPrice=($db.rates|Where-Object {$_.entity -eq $d.entity}|Select-Object -First 1).price}else{$d.completedAt=$null}
   $db.history=@($db.history)+@(@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=$now;agent=$d.agent;entity=$d.entity;branch=$d.branch;from=$from;to=$to;name=$d.name;started=$d.startedAt;dmt_minutes=$dmt;comment=$d.comment;complex=$d.complex;complexComment=$d.complexComment})
   SaveDb $db
  }catch{if($folder){[IO.Directory]::Move($dst,$src)}else{[IO.File]::Move($dst,$src)};throw}
  $warning=$null
  try{UpdateQuickDocument $d $from $to}catch{$warning='Mouvement enregistré, compteurs non publiés : '+$_.Exception.Message}
  @{ok=$true;document=$d;from=$from;to=$to;warning=$warning}
 }finally{$lk.Dispose()}
}
function EditDocument($body,$role){
 $lk=LockDb;try{$db=LoadDb;$d=FindDoc $db ([string]$body.id)
 if($null -ne $body.PSObject.Properties['complex'] -and $body.complex -isnot [bool]){throw 'Complexité invalide'}
 if($body.complex -and !([string]$body.complexComment).Trim()){throw 'Commentaire de complexité requis'}
 if($null -ne $body.PSObject.Properties['priority'] -and $body.priority -isnot [bool]){throw 'Priorité invalide'}
 foreach($prop in @('complex','complexComment','comment')){if($null-ne$body.PSObject.Properties[$prop]){$d.$prop=$body.$prop}}
 if($role-eq'MANAGER'){
  foreach($prop in @('priority','priorityComment')){if($null-ne$body.PSObject.Properties[$prop]){$d.$prop=$body.$prop}}
  if($null-ne$body.PSObject.Properties['unitPrice']){if($null-eq$body.unitPrice){$d.unitPrice=$null}else{$price=[double]$body.unitPrice;if($price-lt 0-or[double]::IsNaN($price)-or[double]::IsInfinity($price)){throw 'Prix invalide'};$d.unitPrice=$price}}
 }
 SaveDb $db;$warning=$null;try{UpdateQuickDocument $d $d.status $d.status}catch{$warning=$_.Exception.Message};@{ok=$true;document=$d;warning=$warning}
 }finally{$lk.Dispose()}
}
function EditRate($body){$lk=LockDb;try{$db=LoadDb;$rate=@($db.rates|Where-Object{$_.entity-eq[string]$body.entity});if($rate.Count-ne 1){throw 'Entité inconnue'};$v=$null;if($null-ne$body.price){$v=[double]$body.price;if($v-lt 0-or[double]::IsNaN($v)-or[double]::IsInfinity($v)){throw 'Prix invalide'}};$rate[0].price=$v;SaveDb $db;SaveQuick (LoadQuick);@{ok=$true}}finally{$lk.Dispose()}}
function OpenDocument($body){$db=ReadDb;$d=FindDoc $db ([string]$body.id);$p=Join-Path (BranchPath $d.entity $d.status $d.branch) $d.name;if(!(Test-Path -LiteralPath $p)){throw 'Document introuvable'};Start-Process explorer.exe -ArgumentList ('"'+$p+'"');@{ok=$true}}
$QuickFile=Join-Path $HistoryRoot 'orbit-state-v4.json'
$ScanFile=Join-Path $HistoryRoot 'fullscan-v4.json'
$ScanReportFile=Join-Path $HistoryRoot 'fullscan-report-v4.json'
function DbRevision {$f=New-Object IO.FileInfo($DbFile);if($f.Exists){return ([string]$f.LastWriteTimeUtc.Ticks+':'+[string]$f.Length)};'none'}
function AtomicJson($file,$value){
 $tmp=$file+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($tmp,($value|ConvertTo-Json -Depth 20 -Compress),(New-Object Text.UTF8Encoding($false)));for($i=0;$i-lt 5;$i++){try{if([IO.File]::Exists($file)){[IO.File]::Replace($tmp,$file,$null)}else{[IO.File]::Move($tmp,$file)};return}catch{if($i-eq 4){throw};Start-Sleep -Milliseconds 40}}}finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
}
function NewQuick {
 $rows=@();foreach($e in $Schema.Keys){$bs=@($Schema[$e].Branches);if($Schema[$e].Mode-ne'CATEGORY_FIRST' -and $bs-notcontains''){$bs=@('')+$bs};foreach($b in $bs){foreach($s in $Statuses){$rows+=@{entity=$e;branch=$b;status=$s;count=$null;minimum=0;known=$false;verifiedAt=$null;updatedAt=$null}}}}
 [pscustomobject]@{version=4;revision='initial';dbRevision='none';branches=@($rows);folderKeys=@();changes=@();catalogRevision='initial';updatedAt=$null}
}
function LoadQuick {if([IO.File]::Exists($QuickFile)){return ([IO.File]::ReadAllText($QuickFile,[Text.Encoding]::UTF8)|ConvertFrom-Json)};NewQuick}
function SaveQuick($q){$q.revision=[guid]::NewGuid().ToString('N');$q.updatedAt=NowIso;$q.dbRevision=DbRevision;AtomicJson $QuickFile $q}
function QuickRow($q,$e,$b,$s){$row=@($q.branches|Where-Object{$_.entity-eq$e -and $_.branch-eq$b -and $_.status-eq$s});if($row.Count){return $row[0]};$row=[pscustomobject]@{entity=$e;branch=$b;status=$s;count=$null;minimum=0;known=$false;verifiedAt=$null;updatedAt=$null};$q.branches=@($q.branches)+@($row);return $row}
function AddBranches($q,$e,$b){foreach($s in $Statuses){$null=QuickRow $q $e $b $s}}
function MiniDoc($d){@{id=$d.id;entity=$d.entity;branch=$d.branch;name=$d.name;kind=$d.kind;status=$d.status;depositAt=$d.depositAt;statusSince=$d.statusSince;agent=$d.agent;present=$d.present;priority=$d.priority;priorityComment=$d.priorityComment;complex=$d.complex;complexComment=$d.complexComment;comment=$d.comment}}
function UpdateQuickDocument($d,$from,$to){
 $q=LoadQuick;AddBranches $q $d.entity $d.branch;if($d.kind-eq'Dossier' -and @($q.folderKeys)-notcontains$d.key){$q.folderKeys=@($q.folderKeys)+@($d.key)};$now=NowIso
 if($from-ne$to){$src=QuickRow $q $d.entity $d.branch $from;$dst=QuickRow $q $d.entity $d.branch $to;if($src.known){$src.count=[Math]::Max(0,[int]$src.count-1)}else{$src.minimum=[Math]::Max(0,[int]$src.minimum-1)};if($dst.known){$dst.count=[int]$dst.count+1}else{$dst.minimum=[int]$dst.minimum+1};$src.updatedAt=$now;$dst.updatedAt=$now}
 (QuickRow $q $d.entity $d.branch $to).updatedAt=$now
 $q.changes=@(@($q.changes|Where-Object{$_.id-ne$d.id})+@((MiniDoc $d))|Select-Object -Last 64);SaveQuick $q
}
function SeedQuick {
 $lk=LockDb;try{if([IO.File]::Exists($QuickFile)){return};$db=LoadDb;$q=NewQuick
 foreach($d in $db.documents){AddBranches $q $d.entity $d.branch;if($d.kind-eq'Dossier'){$q.folderKeys+=@($d.key)}}
 foreach($row in $q.branches){if($db.scannedAt -and (@($Schema[$row.entity].Branches)-contains$row.branch -or @($db.documents|Where-Object{$_.entity-eq$row.entity-and$_.branch-eq$row.branch}).Count)){$row.count=@($db.documents|Where-Object{$_.present -and $_.entity-eq$row.entity -and $_.branch-eq$row.branch -and $_.status-eq$row.status}).Count;$row.known=$true;$row.verifiedAt=$db.scannedAt;$row.updatedAt=$db.scannedAt}}
 SaveQuick $q
 }finally{$lk.Dispose()}
}
function ReadScanStatus {if([IO.File]::Exists($ScanFile)){return ([IO.File]::ReadAllText($ScanFile,[Text.Encoding]::UTF8)|ConvertFrom-Json)};@{running=$false;phase='idle';visited=0;added=0;errors=@();paths=@()}}
function OrbitState {
 $q=LoadQuick
 @{role='AGENT';agent=[Environment]::UserName;root=$RootPath;revision=$q.revision;catalogRevision=$q.catalogRevision;branches=@($q.branches);changes=@($q.changes);updatedAt=$q.updatedAt;stale=($q.dbRevision-ne(DbRevision))}
}
function Supported($path){[IO.Path]::GetExtension($path)-in@('.pdf','.doc','.docx')}
function BranchChild($e,$b,$name){if($Schema[$e].Mode-eq'CATEGORY_FIRST' -and !$b.Contains('|')){return ($b+'|'+$name)};if($b){return ($b+'\'+$name)};return $name}
function Structural($e,$s,$b,$name,$q){
 if(@($q.folderKeys)-contains(Key $e $b $name)){return $false}
 if($s-in@('A TRAITER','EN COURS')){return $true}
 $child=BranchChild $e $b $name
 foreach($known in @($Schema[$e].Branches)+@($q.branches|Where-Object{$_.entity-eq$e}|ForEach-Object{$_.branch})){if($known-eq$child -or $known.StartsWith($child+'\',[StringComparison]::OrdinalIgnoreCase)){return $true}}
 return $false
}
function TargetCount($e,$s,$b){
 $p=BranchPath $e $s $b;$lk=LockDb
 try{
  $q=LoadQuick;$n=0;$children=@()
  # Only this directory: names consumed internally, no per-file metadata and no recursion.
  foreach($file in [IO.Directory]::EnumerateFiles($p)){if(Supported $file){$n++}}
  foreach($dir in [IO.Directory]::EnumerateDirectories($p)){$name=[IO.Path]::GetFileName($dir);if(Structural $e $s $b $name $q){$child=BranchChild $e $b $name;AddBranches $q $e $child;$children+=@($child)}else{$n++}}
  $row=QuickRow $q $e $b $s;$row.count=$n;$row.minimum=$n;$row.known=$true;$row.verifiedAt=NowIso;$row.updatedAt=$row.verifiedAt;SaveQuick $q
  @{ok=$true;count=$n;path=$p;children=@($children);state=(OrbitState)}
 }finally{$lk.Dispose()}
}
function EnumerateBranch($e,$s,$b,$q){
 $p=BranchPath $e $s $b;$items=@();$children=@();$ignored=0
 foreach($x in (Get-ChildItem -LiteralPath $p -ErrorAction Stop)){
  if($x.PSIsContainer){if(Structural $e $s $b $x.Name $q){$child=BranchChild $e $b $x.Name;$children+=@($child)}else{$items+=@($x)}}elseif(Supported $x.Name){$items+=@($x)}else{$ignored++}
 }
 @{entity=$e;status=$s;branch=$b;path=$p;items=@($items);children=@($children);ignored=$ignored}
}
function ReconcileScope($db,$scope,$map=$null,$groups=$null){
 $e=$scope.entity;$s=$scope.status;$b=$scope.branch;$now=NowIso;$seen=@{};$added=0;$changed=0;$newDocs=New-Object 'System.Collections.Generic.List[object]';if($null-eq$map){$map=@{};foreach($d in $db.documents){$map[$d.key]=$d}};$groupKey=Key $e $b $s;if($null-ne$groups -and !$groups.ContainsKey($groupKey)){$groups[$groupKey]=New-Object 'System.Collections.Generic.List[object]'}
 foreach($x in $scope.items){$k=Key $e $b $x.Name;$seen[$k]=$true
  if(!$map.ContainsKey($k)){$d=NewDoc $e $b $s $x $db;$newDocs.Add($d);$map[$k]=$d;if($null-ne$groups){$groups[$groupKey].Add($d)};$added++}
  else{$d=$map[$k]
   if($d.status-ne$s){
    # A genuine duplicate in two statuses is never silently merged.
    $oldPath=Join-Path (BranchPath $d.entity $d.status $d.branch) $d.name
    if(Test-Path -LiteralPath $oldPath){throw ('Doublon entre statuts : '+$d.name)}
    $d.periods=@($d.periods)+@(@{status=$d.status;start=$d.statusSince;end=$now})
    $db.history=@($db.history)+@(@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=$now;entity=$e;branch=$b;name=$d.name;agent='SCAN EXTERNE';from=$d.status;to=$s;comment='Déplacement constaté';dmt_minutes=$null})
    $d.status=$s;$d.statusSince=$now;if($null-ne$groups){$groups[$groupKey].Add($d)};$changed++;if($s-eq'EN COURS'){$d.startedAt=$now};if($s-eq'TRAITES'){$d.completedAt=$now;$d.billedPrice=($db.rates|Where-Object{$_.entity-eq$e}|Select-Object -First 1).price}else{$d.completedAt=$null}
   }
   $d.present=$true;$d.modifiedAt=$x.LastWriteTimeUtc.ToString('o')
  }
 }
 $db.documents=@($db.documents)+@($newDocs.ToArray())
 $candidates=if($null-ne$groups){@($groups[$groupKey].ToArray())}else{@($db.documents)};foreach($d in $candidates){if($d.entity-eq$e -and $d.branch-eq$b -and $d.status-eq$s -and !$seen.ContainsKey($d.key)){$d.present=$false}}
 @{added=$added;changed=$changed}
}
function EngageBranch($e,$s,$b){
 $lk=LockDb;try{
  $q=LoadQuick;$db=LoadDb;$q.folderKeys=@($db.documents|Where-Object{$_.kind-eq'Dossier'}|ForEach-Object{$_.key});$scope=EnumerateBranch $e $s $b $q;$result=ReconcileScope $db $scope
  foreach($child in $scope.children){AddBranches $q $e $child}
  $row=QuickRow $q $e $b $s;$row.count=@($scope.items).Count;$row.minimum=$row.count;$row.known=$true;$row.verifiedAt=NowIso;$row.updatedAt=$row.verifiedAt
  SaveDb $db;$q.catalogRevision=[guid]::NewGuid().ToString('N');$q.folderKeys=@($db.documents|Where-Object{$_.kind-eq'Dossier'}|ForEach-Object{$_.key});SaveQuick $q
  @{ok=$true;path=$scope.path;items=@($db.documents|Where-Object{$_.present-and$_.entity-eq$e-and$_.branch-eq$b-and$_.status-eq$s});children=@($scope.children);ignored=$scope.ignored;state=(OrbitState)}
 }finally{$lk.Dispose()}
}
function CachedBranch($e,$s,$b){$null=BranchPath $e $s $b;$db=ReadDb;@{items=@($db.documents|Where-Object{$_.present-and$_.entity-eq$e-and$_.branch-eq$b-and$_.status-eq$s})}}
function PublishScan($status){
 $lk=LockDb
 try{
  if(!$status.running){AtomicJson $ScanReportFile $status}
  $thin=@{runId=$status.runId;running=$status.running;phase=$status.phase;startedAt=$status.startedAt;finishedAt=$status.finishedAt;visited=$status.visited;added=$status.added;changed=$status.changed;ignored=$status.ignored;skipped=$status.skipped;errors=@($status.errors|Select-Object -First 20);errorCount=@($status.errors).Count;lastPath=$status.lastPath;heartbeat=(NowIso);ownerHost=$status.ownerHost;ownerPid=$status.ownerPid;paths=@()}
  AtomicJson $ScanFile $thin
 }finally{$lk.Dispose()}
}
function ReadScanReport {if([IO.File]::Exists($ScanReportFile)){return ([IO.File]::ReadAllText($ScanReportFile,[Text.Encoding]::UTF8)|ConvertFrom-Json)};ReadScanStatus}

function FullScanV4($runId,[int]$ownerPid=0,[string]$ownerHost=''){
 $started=NowIso;$q=LoadQuick;
 # Verify root connectivity once before treating missing schema paths as zero.
 $rootEntries=@(Get-ChildItem -LiteralPath $RootPath -ErrorAction Stop)
 $scopes=New-Object 'System.Collections.Generic.List[object]';$paths=New-Object 'System.Collections.Generic.List[object]';$errors=New-Object 'System.Collections.Generic.List[string]';$seen=@{};$queue=New-Object Collections.Queue
 foreach($entry in $rootEntries){if($entry.PSIsContainer -and !$entry.Name.StartsWith('.') -and !$Schema.Contains($entry.Name)){$errors.Add('Entité non configurée : '+$entry.FullName+' — ajouter son mode et ses branches dans COMMON\schema.json')}}
 foreach($e in $Schema.Keys){
  $branches=@($Schema[$e].Branches)+@($q.branches|Where-Object{$_.entity-eq$e}|ForEach-Object{$_.branch})
  try{foreach($entry in (Get-ChildItem -LiteralPath (Join-Path $RootPath $e) -ErrorAction Stop)){if(!$entry.PSIsContainer -and (Supported $entry.Name)){$errors.Add('Document hors dossier de statut, non importé : '+$entry.FullName)}}}catch{$errors.Add($e+': '+$_.Exception.Message)}
  if($Schema[$e].Mode-eq'CATEGORY_FIRST'){
   try{foreach($dir in [IO.Directory]::EnumerateDirectories((Join-Path $RootPath $e))){$branches+=@([IO.Path]::GetFileName($dir))}}catch{$errors.Add($e+': '+$_.Exception.Message)}
  }elseif($branches-notcontains''){$branches=@('')+$branches}
  foreach($b in @($branches|Select-Object -Unique)){foreach($s in $Statuses){$queue.Enqueue(@{entity=$e;branch=$b;status=$s})}}
 }
 $status=[pscustomobject]@{runId=$runId;ownerPid=$ownerPid;ownerHost=$ownerHost;running=$true;phase='enumerating';startedAt=$started;finishedAt=$null;visited=0;added=0;changed=0;ignored=0;skipped=0;errors=@();paths=@();lastPath=''};PublishScan $status
 try{
  while($queue.Count){
   $task=$queue.Dequeue();$key=Key $task.entity $task.branch $task.status;if($seen.ContainsKey($key)){continue};$seen[$key]=$true;$p=BranchPath $task.entity $task.status $task.branch;$status.lastPath=$p
   try{
    $scope=EnumerateBranch $task.entity $task.status $task.branch $q;$scope.observedAt=NowIso;$scopes.Add($scope)
    foreach($child in $scope.children){AddBranches $q $task.entity $child;foreach($childStatus in $Statuses){$queue.Enqueue(@{entity=$task.entity;status=$childStatus;branch=$child})}}
    $paths.Add(@{path=$p;count=@($scope.items).Count;ignored=$scope.ignored;ok=$true});$status.ignored+=$scope.ignored
   }catch{
    if($_.Exception -is [IO.DirectoryNotFoundException] -or $_.FullyQualifiedErrorId -like '*PathNotFound*'){
     # Root connectivity was verified: a genuinely absent scope has zero documents.
     $scopes.Add(@{entity=$task.entity;status=$task.status;branch=$task.branch;path=$p;items=@();children=@();ignored=0;observedAt=(NowIso)})
     $paths.Add(@{path=$p;count=0;ok=$true;missing=$true;error='Chemin absent : 0 document'})
    }else{$paths.Add(@{path=$p;count=$null;ok=$false;error=$_.Exception.Message})}
    $errors.Add($p+': '+$_.Exception.Message)
   }
   $status.visited++;if(($status.visited%5)-eq 0){$status.errors=@($errors.ToArray());PublishScan $status}
  }
  $status.phase='merging';PublishScan $status
  # Global lock protects short reconciliation only, never the physical whole-tree enumeration.
  $lk=LockDb
  try{
   $db=LoadDb;$q=LoadQuick;$lookup=@{};$groups=@{};foreach($doc in $db.documents){$lookup[$doc.key]=$doc;$gk=Key $doc.entity $doc.branch $doc.status;if(!$groups.ContainsKey($gk)){$groups[$gk]=New-Object 'System.Collections.Generic.List[object]'};$groups[$gk].Add($doc)}
   foreach($scope in $scopes){
    $row=QuickRow $q $scope.entity $scope.branch $scope.status
    if($row.updatedAt -and [datetime]$row.updatedAt-gt[datetime]$started){$status.skipped++;continue}
    # Transactional branch validation: do not partially change a duplicate scope.
    $duplicate=$false
    foreach($x in $scope.items){$k=Key $scope.entity $scope.branch $x.Name;$old=$lookup[$k];if($old -and $old.status-ne$scope.status){$op=Join-Path (BranchPath $old.entity $old.status $old.branch) $old.name;if(Test-Path -LiteralPath $op){$errors.Add('Doublon : '+$op);$duplicate=$true;break}}}
    if($duplicate){continue}
    $result=ReconcileScope $db $scope $lookup $groups;$status.added+=$result.added;$status.changed+=$result.changed
    AddBranches $q $scope.entity $scope.branch;$row.count=@($scope.items).Count;$row.minimum=$row.count;$row.known=$true;$row.verifiedAt=$scope.observedAt;$row.updatedAt=NowIso
   }
   $db.scannedAt=NowIso;$db.scanErrors=@($errors.ToArray());$q.folderKeys=@($db.documents|Where-Object{$_.kind-eq'Dossier'}|ForEach-Object{$_.key});SaveDb $db;$q.catalogRevision=[guid]::NewGuid().ToString('N');SaveQuick $q
  }finally{$lk.Dispose()}
  $status.phase=if($errors.Count-or$status.skipped){'completed_with_warnings'}else{'completed'}
 }catch{$errors.Add($_.Exception.Message);$status.phase='failed'}
 finally{$status.running=$false;$status.finishedAt=NowIso;$status.paths=@($paths.ToArray());$status.errors=@($errors.ToArray());PublishScan $status}
 return $status
}
# Compatibility for the isolated Windows tests. Never called by Orbit.
function Scan([bool]$force=$false){FullScanV4 ([guid]::NewGuid().ToString('N'))|Out-Null;ReadDb}
