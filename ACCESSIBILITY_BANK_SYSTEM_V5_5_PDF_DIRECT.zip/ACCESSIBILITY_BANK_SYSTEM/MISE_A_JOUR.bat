@echo off
setlocal
set /p "TARGET=Chemin du dossier ACCESSIBILITY_BANK_SYSTEM existant : "
if not exist "%TARGET%\MANAGER\index.html" goto fail
for /f %%T in ('powershell -NoProfile -Command "Get-Date -Format yyyyMMdd_HHmmss_fff"') do set "BACKUPSTAMP=%%T"
if not defined BACKUPSTAMP goto fail
copy /y "%TARGET%\MANAGER\index.html" "%TARGET%\MANAGER\index.avant_pdf_%BACKUPSTAMP%.html" >nul
if errorlevel 1 goto fail
copy /y "%~dp0MANAGER\index.html" "%TARGET%\MANAGER\index.html" >nul
if errorlevel 1 goto fail
echo PDF direct et nouveau design installes. Serveurs, DATA et configuration inchanges.
echo Faites Ctrl+F5 dans le manager.
pause
exit /b 0
:fail
echo Echec. Verifiez le chemin et les droits de copie.
pause
exit /b 1
