@echo off
cd /d "%~dp0"
del /q data\STOP 2>nul
start "ACCESS SCANNER" /min powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scanner.ps1"
start "" http://localhost:8787
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
