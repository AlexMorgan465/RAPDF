param(
  [string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',
  [int]$IntervalSeconds=30
)
$ErrorActionPreference='Continue'
$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$Data=Join-Path $AppDir 'data'; New-Item -ItemType Directory -Force $Data|Out-Null
$Index=Join-Path $Data 'index.json'; $Scan=Join-Path $Data 'scan.json'; $Diag=Join-Path $Data 'diagnostic.json'; $Stop=Join-Path $Data 'STOP'
if(Test-Path $Stop){Remove-Item $Stop -Force}

function Atomic($p,$o){
  $t="$p.$([guid]::NewGuid().ToString('N')).tmp"
  try{
    $j=$o|ConvertTo-Json -Depth 12
    [IO.File]::WriteAllText($t,$j,[Text.UTF8Encoding]::new($false))
    $null=[IO.File]::ReadAllText($t)|ConvertFrom-Json
    Move-Item $t $p -Force
  } finally { Remove-Item $t -Force -EA SilentlyContinue }
}
function NS($n){
  switch -Regex ($n.Trim().ToUpperInvariant()){
    '^A\s*TRAITER$'{'A TRAITER';break}
    '^EN\s*COURS$'{'EN COURS';break}
    '^TRAITE[S]?$'{'TRAITES';break}
    '^NON\s*CONFORME$'{'NON CONFORME';break}
    '^A\s*PUBLIER$'{'A PUBLIER';break}
    default{$null}
  }
}
function Rel($b,$f){$x=$b.TrimEnd('\')+'\';if($f.StartsWith($x,[StringComparison]::OrdinalIgnoreCase)){$f.Substring($x.Length)}else{''}}

# IMPORTANT: d'apres le TREE fourni, les racines statut sont soit directement sous l'entite,
# soit un niveau plus bas (CONTRATHEQUE). On ne traverse donc PAS tout le contenu pour les trouver.
function FindStatusRootsFast($entity){
  $out=New-Object Collections.ArrayList
  $candidates=New-Object Collections.ArrayList
  try { foreach($d in @(Get-ChildItem $entity.FullName -Directory -Force -EA Stop)){ if($d.Name -ne 'OLD'){[void]$candidates.Add($d)} } } catch {}
  foreach($d in @($candidates.ToArray())){
    $s=NS $d.Name
    if($s){[void]$out.Add([pscustomobject]@{Dir=$d;Status=$s});continue}
    # Un niveau intermediaire: ex CONTRATHEQUE\CONDITIONS GENERALES\A TRAITER
    try{
      foreach($d2 in @(Get-ChildItem $d.FullName -Directory -Force -EA Stop)){
        if($d2.Name -eq 'OLD'){continue}
        $s2=NS $d2.Name
        if($s2){[void]$out.Add([pscustomobject]@{Dir=$d2;Status=$s2})}
      }
    } catch {}
  }
  @($out.ToArray())
}

function PublishScan($running,$percent,$entsTotal,$entsDone,$zonesTotal,$zonesDone,$docs,$files,$dirs,$errs,$start,$curEntity,$curStatus,$curPath,$phase){
  Atomic $Scan ([pscustomobject]@{
    running=$running; percent=[math]::Max(0,[math]::Min(100,[math]::Round($percent)))
    phase=$phase; entitiesTotal=$entsTotal; entitiesScanned=$entsDone
    statusFoldersTotal=$zonesTotal; statusFoldersScanned=$zonesDone
    documents=$docs; filesFound=$files; directoriesVisited=$dirs; errors=$errs
    currentEntity=$curEntity; currentStatus=$curStatus; currentPath=$curPath
    heartbeat=(Get-Date).ToString('o'); startedAt=$start.ToString('o')
  })
}

function ScanOnce{
  $start=Get-Date; $errs=0; $rows=New-Object Collections.ArrayList; $diag=New-Object Collections.ArrayList
  $dirs=0; $filesTotal=0; $zonesDone=0; $entitiesDone=0
  PublishScan $true 0 0 0 0 0 0 0 0 0 $start '' '' $Root 'INITIALISATION'

  try{$ents=@(Get-ChildItem $Root -Directory -Force -EA Stop|Where-Object{$_.Name -ne 'OLD'})}catch{$ents=@();$errs++}
  $allZones=New-Object Collections.ArrayList
  foreach($e in $ents){
    PublishScan $true 1 $ents.Count $entitiesDone 0 0 $rows.Count $filesTotal $dirs $errs $start $e.Name '' $e.FullName 'DETECTION STATUTS'
    foreach($z in @(FindStatusRootsFast $e)){[void]$allZones.Add([pscustomobject]@{Entity=$e;Dir=$z.Dir;Status=$z.Status})}
  }
  $zonesTotal=$allZones.Count; $totalWork=[math]::Max(1,$zonesTotal)
  PublishScan $true 2 $ents.Count 0 $zonesTotal 0 0 0 0 $errs $start '' '' $Root 'SCAN DOCUMENTS'

  foreach($e in $ents){
    $entityZones=@($allZones.ToArray()|Where-Object{$_.Entity.FullName -eq $e.FullName})
    foreach($z in $entityZones){
      $bd=$rows.Count; $bf=$filesTotal; $bdir=$dirs; $empty=0
      $stack=New-Object Collections.Stack; $stack.Push($z.Dir)
      $lastPublish=[datetime]::MinValue
      while($stack.Count){
        if(Test-Path $Stop){return}
        $d=$stack.Pop(); $dirs++
        # Heartbeat au maximum 1 fois/seconde: permet de voir EXACTEMENT ou le scan travaille.
        if(((Get-Date)-$lastPublish).TotalMilliseconds -ge 900){
          $pct=2+($zonesDone/$totalWork*96)
          PublishScan $true $pct $ents.Count $entitiesDone $zonesTotal $zonesDone $rows.Count $filesTotal $dirs $errs $start $e.Name $z.Status $d.FullName 'SCAN DOCUMENTS'
          $lastPublish=Get-Date
        }
        try{$fs=@(Get-ChildItem $d.FullName -File -Force -EA Stop)}catch{$fs=@();$errs++}
        $filesTotal+=$fs.Count
        if($d.FullName -ne $z.Dir.FullName -and $fs.Count -gt 0){
          $latest=($fs|Sort-Object LastWriteTime -Desc|Select-Object -First 1).LastWriteTime
          $businessRel=Rel $z.Dir.FullName $d.FullName; $statusRootRel=Rel $z.Entity.FullName $z.Dir.FullName
          [void]$rows.Add([pscustomobject]@{
            id=($z.Entity.Name+'|'+$statusRootRel+'|'+$businessRel); entity=$z.Entity.Name; status=$z.Status
            name=$d.Name; statusRootRelative=$statusRootRel; relativePath=$businessRel
            fileCount=$fs.Count; modified=$latest.ToString('o'); depositDate=$latest.ToString('o')
          })
          continue # le dossier contenant les fichiers = dossier metier; ne pas compter ses sous-dossiers
        }
        try{
          $subs=@(Get-ChildItem $d.FullName -Directory -Force -EA Stop|Where-Object{$_.Name -ne 'OLD'})
          if($subs.Count -eq 0 -and $d.FullName -ne $z.Dir.FullName){$empty++}
          foreach($s in $subs){$stack.Push($s)}
        }catch{$errs++}
      }
      [void]$diag.Add([pscustomobject]@{entity=$e.Name;status=$z.Status;statusRoot=(Rel $e.FullName $z.Dir.FullName);documents=($rows.Count-$bd);files=($filesTotal-$bf);directories=($dirs-$bdir);emptyBranches=$empty})
      $zonesDone++
      # Publication PROGRESSIVE: le navigateur voit les documents deja trouves sans attendre la fin du DP.
      Atomic $Index @($rows.ToArray()); Atomic $Diag @($diag.ToArray())
      $pct=2+($zonesDone/$totalWork*96)
      PublishScan $true $pct $ents.Count $entitiesDone $zonesTotal $zonesDone $rows.Count $filesTotal $dirs $errs $start $e.Name $z.Status $z.Dir.FullName 'ZONE TERMINEE'
    }
    $entitiesDone++
    PublishScan $true (2+($zonesDone/$totalWork*96)) $ents.Count $entitiesDone $zonesTotal $zonesDone $rows.Count $filesTotal $dirs $errs $start $e.Name '' $e.FullName 'ENTITE TERMINEE'
  }

  Atomic $Index @($rows.ToArray()); Atomic $Diag @($diag.ToArray())
  $end=Get-Date
  Atomic $Scan ([pscustomobject]@{
    running=$false;percent=100;phase='TERMINE';entitiesTotal=$ents.Count;entitiesScanned=$ents.Count
    statusFoldersTotal=$zonesTotal;statusFoldersScanned=$zonesDone;documents=$rows.Count;filesFound=$filesTotal
    directoriesVisited=$dirs;errors=$errs;currentEntity='';currentStatus='';currentPath='';heartbeat=$end.ToString('o')
    durationMs=[math]::Round(($end-$start).TotalMilliseconds);startedAt=$start.ToString('o');completedAt=$end.ToString('o')
  })
}

while(!(Test-Path $Stop)){
  try{ScanOnce}catch{
    $now=Get-Date
    try{Atomic $Scan ([pscustomobject]@{running=$false;percent=0;phase='ERREUR';errors=1;message=$_.Exception.Message;heartbeat=$now.ToString('o');completedAt=$now.ToString('o')})}catch{}
  }
  for($i=0;$i-lt$IntervalSeconds;$i++){if(Test-Path $Stop){break};Start-Sleep 1}
}
