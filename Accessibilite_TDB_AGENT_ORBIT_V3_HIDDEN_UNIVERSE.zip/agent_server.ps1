﻿param([string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$Port=8788)
$ErrorActionPreference='Stop'
$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$Data=Join-Path $AppDir 'data'; if(!(Test-Path $Data)){New-Item -ItemType Directory -Path $Data|Out-Null}
$Journal=Join-Path $Data 'journal.json'; $Live=Join-Path $Data 'agent_live.json'; $CountsFile=Join-Path $Data 'agent_counts.json'
$Statuses=@('A TRAITER','EN COURS','NON CONFORME')
$script:ShutdownRequested=$false
$Allowed=@{'A TRAITER'=@('EN COURS');'EN COURS'=@('A TRAITER','NON CONFORME','TRAITES');'NON CONFORME'=@('A TRAITER','EN COURS')}
function Norm([string]$s){if($null-eq$s){return ''};return $s.Trim().ToUpperInvariant()}
function Json($c,$o,[int]$code=200){$raw=$o|ConvertTo-Json -Depth 16 -Compress;$b=[Text.Encoding]::UTF8.GetBytes($raw);$c.Response.StatusCode=$code;$c.Response.ContentType='application/json;charset=utf-8';$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function File($c,$p,$type){$b=[IO.File]::ReadAllBytes($p);$c.Response.ContentType=$type;$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Body($c){$r=[IO.StreamReader]::new($c.Request.InputStream,$c.Request.ContentEncoding);try{$r.ReadToEnd()|ConvertFrom-Json}finally{$r.Dispose()}}
function ReadArr($p){if(!(Test-Path -LiteralPath $p)){return @()};try{@([IO.File]::ReadAllText($p)|ConvertFrom-Json)}catch{@()}}
function Atomic($p,$o){$t=$p+'.tmp';[IO.File]::WriteAllText($t,($o|ConvertTo-Json -Depth 16),[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $t -Destination $p -Force}
function LiveState(){if(!(Test-Path $Live)){Atomic $Live ([pscustomobject]@{version=1;last=(Get-Date).ToString('o')})};try{[IO.File]::ReadAllText($Live)|ConvertFrom-Json}catch{[pscustomobject]@{version=1;last=(Get-Date).ToString('o')}}}
function Bump(){ $s=LiveState;$s.version=[int64]$s.version+1;$s.last=(Get-Date).ToString('o');Atomic $Live $s;return $s }
function Entities(){if(!(Test-Path -LiteralPath $Root)){return @()};@(Get-ChildItem -LiteralPath $Root -Directory -ErrorAction SilentlyContinue|Where-Object{$_.Name -ne '_APPLICATION_ACCESSIBILITE'}|Sort-Object Name|ForEach-Object{$_.Name})}
function SafeEntity([string]$e){if((Entities)-notcontains$e){throw 'Entité invalide'};Join-Path $Root $e}
function StatusRoots([string]$entity,[string]$status){
 $status=Norm $status;if(@('A TRAITER','EN COURS','NON CONFORME','TRAITES')-notcontains$status){throw 'Statut invalide'};$er=SafeEntity $entity;$res=@();$q=New-Object Collections.Generic.Queue[object];$q.Enqueue([pscustomobject]@{p=$er;d=0})
 while($q.Count){$n=$q.Dequeue();if($n.d -gt 2){continue};foreach($d in @(Get-ChildItem -LiteralPath $n.p -Directory -ErrorAction SilentlyContinue)){if((Norm $d.Name)-eq'OLD'){continue};if((Norm $d.Name)-eq$status){$rel=$d.FullName.Substring($er.Length).TrimStart('\');$res+=[pscustomobject]@{label=if($rel){$rel}else{$status};relative=$rel;path=$d.FullName};continue};if($n.d-lt 2){$q.Enqueue([pscustomobject]@{p=$d.FullName;d=$n.d+1})}}};return @($res)
}
function Children([string]$path){
 if([string]::IsNullOrWhiteSpace($path)){return @()}
 try{return @(Get-ChildItem -LiteralPath $path -Force -ErrorAction Stop)}catch{return @()}
}
function CountZone([string]$start){
 if([string]::IsNullOrWhiteSpace($start)-or!(Test-Path -LiteralPath $start -PathType Container)){return [pscustomobject]@{documents=0;files=0;dirs=0}}
 $documents=0;$files=0;$dirs=0;$stack=New-Object Collections.Stack;$stack.Push($start)
 while($stack.Count -gt 0){
   $p=[string]$stack.Pop();$dirs++
   $children=@(Children $p);$fs=@($children|Where-Object{!$_.PSIsContainer});$subs=@($children|Where-Object{$_.PSIsContainer -and (Norm $_.Name)-ne'OLD'})
   $files += $fs.Count
   if($p -ne $start -and $fs.Count -gt 0){$documents++}
   foreach($d in $subs){$stack.Push($d.FullName)}
 }
 return [pscustomobject]@{documents=$documents;files=$files;dirs=$dirs}
}
function BuildCounts(){
 $out=@();$diag=@();$entities=@(Entities)
 foreach($e in $entities){
   $a=0;$ec=0;$nc=0
   foreach($status in $Statuses){
     $zoneDocs=0;$zoneFiles=0;$zoneDirs=0;$roots=@(StatusRoots $e $status)
     foreach($r in $roots){$z=CountZone ([string]$r.path);$zoneDocs += [int]$z.documents;$zoneFiles += [int]$z.files;$zoneDirs += [int]$z.dirs}
     if($status-eq'A TRAITER'){$a=$zoneDocs}elseif($status-eq'EN COURS'){$ec=$zoneDocs}else{$nc=$zoneDocs}
     $diag += [pscustomobject]@{entity=$e;status=$status;roots=$roots.Count;documents=$zoneDocs;files=$zoneFiles;directories=$zoneDirs}
   }
   $out += [pscustomobject]@{entity=$e;aTraiter=$a;enCours=$ec;nonConforme=$nc}
 }
 Atomic $CountsFile @($out);Atomic (Join-Path $Data 'agent_diagnostic.json') @($diag);return @($out)
}
function Counts(){if(Test-Path $CountsFile){try{return @([IO.File]::ReadAllText($CountsFile)|ConvertFrom-Json)}catch{}};return @(BuildCounts)}
function ResolveUnder([string]$base,[string]$rel){if([string]::IsNullOrWhiteSpace($rel)){return $base};$full=[IO.Path]::GetFullPath((Join-Path $base $rel));$b=[IO.Path]::GetFullPath($base).TrimEnd('\')+'\';if(-not $full.StartsWith($b,[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin refusé'};return $full}
function Browse($q){$entity=[uri]::UnescapeDataString([string]$q['entity']);$status=Norm ([uri]::UnescapeDataString([string]$q['status']));$rootRel=[uri]::UnescapeDataString([string]$q['root']);$rel=[uri]::UnescapeDataString([string]$q['rel']);$roots=@(StatusRoots $entity $status);$sr=$roots|Where-Object{$_.relative-eq$rootRel}|Select-Object -First 1;if(!$sr){throw 'Racine statut introuvable'};$p=ResolveUnder $sr.path $rel;if(!(Test-Path -LiteralPath $p -PathType Container)){throw 'Dossier introuvable'};$dirs=@(Get-ChildItem -LiteralPath $p -Directory -ErrorAction SilentlyContinue|Sort-Object Name|ForEach-Object{[pscustomobject]@{name=$_.Name;modified=$_.LastWriteTime.ToString('o')}});$files=@(Get-ChildItem -LiteralPath $p -File -ErrorAction SilentlyContinue|Sort-Object Name|ForEach-Object{[pscustomobject]@{name=$_.Name;modified=$_.LastWriteTime.ToString('o');size=$_.Length}});[pscustomobject]@{entity=$entity;status=$status;root=$rootRel;rel=$rel;folders=$dirs;files=$files}}
function AdjustCount([string]$entity,[string]$from,[string]$to){$rows=@(Counts);foreach($x in $rows){if($x.entity-eq$entity){if($from-eq'A TRAITER'){$x.aTraiter=[math]::Max(0,[int]$x.aTraiter-1)}elseif($from-eq'EN COURS'){$x.enCours=[math]::Max(0,[int]$x.enCours-1)}elseif($from-eq'NON CONFORME'){$x.nonConforme=[math]::Max(0,[int]$x.nonConforme-1)};if($to-eq'A TRAITER'){$x.aTraiter=[int]$x.aTraiter+1}elseif($to-eq'EN COURS'){$x.enCours=[int]$x.enCours+1}elseif($to-eq'NON CONFORME'){$x.nonConforme=[int]$x.nonConforme+1}}};Atomic $CountsFile $rows}
function MoveFolder($b){$entity=[string]$b.entity;$from=Norm([string]$b.from);$to=Norm([string]$b.to);$rootRel=[string]$b.root;$rel=[string]$b.rel;if(!$rel){throw 'Sélectionne un dossier document, pas la racine'};if($Allowed[$from]-notcontains$to){throw 'Transition interdite'};$srcRoot=@(StatusRoots $entity $from)|Where-Object{$_.relative-eq$rootRel}|Select-Object -First 1;if(!$srcRoot){throw 'Racine source introuvable'};$src=ResolveUnder $srcRoot.path $rel;if(!(Test-Path -LiteralPath $src -PathType Container)){throw 'Déjà pris ou déplacé'}
 $parent=Split-Path -Parent $srcRoot.path;$destRoot=Join-Path $parent $to;if(!(Test-Path -LiteralPath $destRoot -PathType Container)){$cand=@(StatusRoots $entity $to);if($cand.Count-eq1){$destRoot=$cand[0].path}else{throw 'Destination ambiguë/introuvable'}}
 $dst=ResolveUnder $destRoot $rel;if(Test-Path -LiteralPath $dst){throw 'Destination existe déjà'};$dp=Split-Path -Parent $dst;if(!(Test-Path -LiteralPath $dp)){New-Item -ItemType Directory -Path $dp -Force|Out-Null};Move-Item -LiteralPath $src -Destination $dst
 $j=ReadArr $Journal;$j+=[pscustomobject]@{date=(Get-Date).ToString('o');entity=$entity;document=(Split-Path -Leaf $src);from=$from;to=$to;source='AGENT';relative=$rel};Atomic $Journal $j;AdjustCount $entity $from $to;$live=Bump;[pscustomobject]@{ok=$true;version=$live.version}}
Write-Host 'Initialisation Agent Orbit autonome...' -ForegroundColor Cyan
if(!(Test-Path -LiteralPath $Root)){Write-Host "DP inaccessible: $Root" -ForegroundColor Red}else{Write-Host 'Calcul initial des compteurs AT / EC / NC...' -ForegroundColor Yellow;try{$null=BuildCounts;Write-Host 'Compteurs prêts.' -ForegroundColor Green}catch{Write-Host $_.Exception.Message -ForegroundColor Red}}
$l=[Net.HttpListener]::new();$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Write-Host "AGENT ORBIT V3 : http://localhost:$Port" -ForegroundColor Cyan
while($l.IsListening -and -not $script:ShutdownRequested){$c=$l.GetContext();try{$p=$c.Request.Url.AbsolutePath;if($p-eq'/api/bootstrap'){Json $c ([pscustomobject]@{version=(LiveState).version;counts=(Counts);entities=(Entities);statuses=$Statuses})}elseif($p-eq'/api/live'){Json $c (LiveState)}elseif($p-eq'/api/recount'-and$c.Request.HttpMethod-eq'POST'){Json $c ([pscustomobject]@{ok=$true;counts=(BuildCounts)})}elseif($p-eq'/api/diagnostic'){Json $c (ReadArr (Join-Path $Data 'agent_diagnostic.json'))}elseif($p-eq'/api/leave'-and$c.Request.HttpMethod-eq'POST'){Json $c ([pscustomobject]@{ok=$true;message='Leaving the universe'});$script:ShutdownRequested=$true;$l.Stop()}elseif($p-eq'/api/roots'){Json $c @(StatusRoots ([uri]::UnescapeDataString($c.Request.QueryString['entity'])) ([uri]::UnescapeDataString($c.Request.QueryString['status'])))}elseif($p-eq'/api/browse'){Json $c (Browse $c.Request.QueryString)}elseif($p-eq'/api/move'-and$c.Request.HttpMethod-eq'POST'){try{Json $c (MoveFolder (Body $c))}catch{Json $c @{ok=$false;error=$_.Exception.Message} 409}}elseif($p-eq'/'-or$p-eq'/agent.html'){File $c (Join-Path $AppDir 'agent.html') 'text/html;charset=utf-8'}elseif($p-eq'/agent.css'){File $c (Join-Path $AppDir 'agent.css') 'text/css;charset=utf-8'}elseif($p-eq'/agent.js'){File $c (Join-Path $AppDir 'agent.js') 'application/javascript;charset=utf-8'}else{$c.Response.StatusCode=404;$c.Response.Close()}}catch{try{Json $c @{ok=$false;error=$_.Exception.Message} 500}catch{}}}

try{$l.Close()}catch{}
