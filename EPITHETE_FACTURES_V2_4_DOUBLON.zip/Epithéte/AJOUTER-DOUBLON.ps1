﻿$ErrorActionPreference = 'Stop'
try {
    $agent = Join-Path (Join-Path $PSScriptRoot 'Traitement') 'EPITHETE-Agent'
    $utf8 = New-Object Text.UTF8Encoding($false)
    $pending = @()
    foreach ($relative in @('web\app.js','serveur.ps1')) {
        $path = Join-Path $agent $relative
        if (-not (Test-Path -LiteralPath $path)) { throw 'Placez AJOUTER-DOUBLON.bat et AJOUTER-DOUBLON.ps1 dans le dossier Epithete, au meme niveau que Traitement.' }
        $original = [IO.File]::ReadAllText($path,$utf8)
        $updated = $original
        if (-not $original.Contains("'DOUBLON'")) {
            if (-not $original.Contains("'DOUBLE_FACT'")) { throw "Liste de motifs non reconnue dans $path. Aucune modification appliquee." }
            $updated = $original.Replace("'DOUBLE_FACT'","'DOUBLE_FACT','DOUBLON'")
        }
        $pending += [pscustomobject]@{Path=$path;Original=$original;Updated=$updated;Encoding= $(if($relative -eq 'serveur.ps1'){New-Object Text.UTF8Encoding($true)}else{$utf8})}
    }
    $stamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff')
    $written = @()
    try {
        foreach ($item in $pending) {
            if ($item.Original -eq $item.Updated) { continue }
            Copy-Item -LiteralPath $item.Path -Destination ($item.Path+'.avant-doublon-'+$stamp+'.bak')
            $written += $item
            [IO.File]::WriteAllText($item.Path,$item.Updated,$item.Encoding)
        }
    } catch {
        foreach ($item in $written) { [IO.File]::WriteAllText($item.Path,$item.Original,$item.Encoding) }
        throw
    }
    Write-Host 'Motif DOUBLON ajoute. Les autres motifs et les donnees sont conserves.' -ForegroundColor Green
    Write-Host 'Deconnectez puis relancez le serveur Agent avec Lancer.bat. Actualisez avec Ctrl+F5.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
