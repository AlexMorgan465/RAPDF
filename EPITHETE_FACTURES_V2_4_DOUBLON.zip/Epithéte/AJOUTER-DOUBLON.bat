@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0AJOUTER-DOUBLON.ps1"
pause
