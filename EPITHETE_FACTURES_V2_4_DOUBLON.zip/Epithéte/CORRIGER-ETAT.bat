@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CORRIGER-ETAT.ps1"
pause
