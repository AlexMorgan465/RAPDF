﻿$ErrorActionPreference = 'Stop'
try {
    $root = Join-Path $PSScriptRoot 'Traitement'
    $utf8 = New-Object Text.UTF8Encoding($false)
    $replacements = @(
        @{Old="k.startsWith('etat du traitement')";New='/^etat (?:du |de )?traitement\b/.test(k)'},
        @{Old="key.startsWith('etat du traitement')";New='/^etat (?:du |de )?traitement\b/.test(key)'},
        @{Old="cleanLabel(c.label).startsWith('etat du traitement')";New='/^etat (?:du |de )?traitement\b/.test(cleanLabel(c.label))'}
    )
    $pending = @()
    foreach ($app in @('EPITHETE-Agent','EPITHETE-Manager')) {
        $web = Join-Path (Join-Path $root $app) 'web'
        $path = Join-Path $web 'app.js'
        if (-not (Test-Path -LiteralPath $path)) {
            throw "Placez ces deux fichiers de correction dans votre dossier Epithete existant, au meme niveau que Traitement. Fichier introuvable : $path"
        }
        $original = [IO.File]::ReadAllText($path,$utf8)
        $updated = $original
        foreach ($pair in $replacements) { $updated = $updated.Replace($pair.Old,$pair.New) }
        if (-not $updated.Contains('/^etat (?:du |de )?traitement\b/.test(')) {
            throw "Version de app.js non reconnue pour $app. Aucune modification appliquee."
        }
        $pending += [pscustomobject]@{Path=$path;Original=$original;Updated=$updated}
        $cssPath = Join-Path $web 'style.css'
        if (-not (Test-Path -LiteralPath $cssPath)) { throw "Fichier introuvable : $cssPath" }
        $originalCss = [IO.File]::ReadAllText($cssPath,$utf8)
        $selector = if ($app -eq 'EPITHETE-Agent') { '#agentHistory td:nth-child(5)' } else { '#done td:nth-child(n+5)' }
        $css = $originalCss
        if (-not $css.Contains($selector)) {
            $css += "`r`n" + $selector + '{white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;width:280px;min-width:180px;max-width:320px;vertical-align:top;overflow:visible;text-overflow:clip;height:auto;max-height:none}' + "`r`n"
        }
        $pending += [pscustomobject]@{Path=$cssPath;Original=$originalCss;Updated=$css}
    }
    $stamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss-fff')
    $written = @()
    try {
        foreach ($item in $pending) {
            if ($item.Original -eq $item.Updated) { continue }
            Copy-Item -LiteralPath $item.Path -Destination ($item.Path+'.avant-etat-'+$stamp+'.bak')
            $written += $item
            [IO.File]::WriteAllText($item.Path,$item.Updated,$utf8)
        }
    } catch {
        foreach ($item in $written) { [IO.File]::WriteAllText($item.Path,$item.Original,$utf8) }
        throw
    }
    Write-Host 'Correction appliquee. Les listes de motifs et les donnees sont conservees.' -ForegroundColor Green
    Write-Host 'Actualisez Agent et Manager avec Ctrl+F5. Aucun reimport Excel necessaire.'
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
}
