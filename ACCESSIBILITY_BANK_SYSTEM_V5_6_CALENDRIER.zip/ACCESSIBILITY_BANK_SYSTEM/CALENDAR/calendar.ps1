﻿# Reservation metadata only: all writes are in DATA, never in the document DP.
$CalendarFile=Join-Path $DataPath 'calendar.json'
$CalendarBackup=Join-Path $DataPath 'calendar.backup.json'
$CalendarLock=Join-Path $DataPath 'calendar.lock'
function ReadCalendarFile($path){
 $value=Get-Content -LiteralPath $path -Raw -Encoding UTF8|ConvertFrom-Json -ErrorAction Stop
 if($null-eq$value -or $value.PSObject.Properties.Name-notcontains'revision' -or $value.PSObject.Properties.Name-notcontains'published'){throw 'Format de calendrier invalide'}
 return $value
}
function WithCalendar($action,[bool]$save=$false){
 $lock=$null;$limit=(Get-Date).AddSeconds(15)
 while(!$lock){try{$lock=[IO.File]::Open($CalendarLock,'OpenOrCreate','ReadWrite','None')}catch{if((Get-Date)-gt$limit){throw 'Calendrier occupe, reessayez'};Start-Sleep -Milliseconds 80}}
 try{
  $value=$null
  if([IO.File]::Exists($CalendarFile)){try{$value=ReadCalendarFile $CalendarFile}catch{if(![IO.File]::Exists($CalendarBackup)){throw 'Calendrier illisible, aucune reinitialisation effectuee'};$value=ReadCalendarFile $CalendarBackup}}
  elseif([IO.File]::Exists($CalendarBackup)){$value=ReadCalendarFile $CalendarBackup}
  if(!$value){$value=[pscustomobject]@{revision=0;draft=$null;published=$null}}
  $answer=& $action $value
  if($save){
   $tmp=Join-Path $DataPath ('calendar.'+[guid]::NewGuid().ToString('N')+'.tmp')
   try{
    [IO.File]::WriteAllText($tmp,($value|ConvertTo-Json -Depth 30 -Compress),(New-Object Text.UTF8Encoding($false)))
    if([IO.File]::Exists($CalendarFile)){
     # Never replace a good backup with a corrupt primary file.
     $validPrimary=$false;try{$null=ReadCalendarFile $CalendarFile;$validPrimary=$true}catch{}
     if($validPrimary){if([IO.File]::Exists($CalendarBackup)){[IO.File]::Delete($CalendarBackup)};[IO.File]::Move($CalendarFile,$CalendarBackup)}else{[IO.File]::Delete($CalendarFile)}
    }
    try{[IO.File]::Move($tmp,$CalendarFile)}catch{if(![IO.File]::Exists($CalendarFile)-and[IO.File]::Exists($CalendarBackup)){[IO.File]::Copy($CalendarBackup,$CalendarFile,$false)};throw}
   }finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
  }
  return $answer
 }finally{$lock.Dispose()}
}
function CalendarSession($name){return ([string]$name).Trim().Split([char[]]@('\','/'))[-1].ToUpperInvariant()}
function CalendarMinute($v){
 if([string]$v-notmatch'^([0-9]{2}):([0-9]{2})$'){throw 'Horaire de calendrier invalide'}
 $h=[int]$Matches[1];$m=[int]$Matches[2];if($h-gt23-or$m-gt59){throw 'Horaire invalide'};return $h*60+$m
}
function CalendarDate($v){
 if([string]$v-notmatch'^\d{4}-\d{2}-\d{2}$'){throw 'Date de calendrier invalide'}
 return [datetime]::ParseExact([string]$v,'yyyy-MM-dd',[Globalization.CultureInfo]::InvariantCulture)
}
function CalendarNumber($v,$min,$max){
 $n=0.0;if($null-eq$v-or![double]::TryParse([string]$v,[Globalization.NumberStyles]::Float,[Globalization.CultureInfo]::InvariantCulture,[ref]$n)-or[double]::IsNaN($n)-or[double]::IsInfinity($n)-or$n-lt$min-or$n-gt$max){throw 'Valeur numerique de calendrier invalide'};return $n
}
function ValidateCalendarConfig($cfg,[bool]$publishing=$false){
 if(!$cfg){throw 'Configuration du calendrier manquante'}
 $start=CalendarDate $cfg.start;$end=CalendarDate $cfg.end
 if($end-lt$start-or($end-$start).TotalDays-gt365){throw 'Periode de calendrier invalide (366 jours maximum)'}
 $agents=@($cfg.agents);if($agents.Count-lt1-or$agents.Count-gt100){throw 'Effectif invalide (1 a 100 agents)'}
 $ids=@{};$sessions=@{}
 foreach($a in $agents){if(!$a.id-or$ids.ContainsKey([string]$a.id)-or![string]$a.name){throw 'Identifiant agent invalide'};$ids[[string]$a.id]=$true;$session=CalendarSession $a.session;if($publishing-and!$session){throw 'Renseignez la session Windows de chaque agent avant validation'};if($session){if($sessions.ContainsKey($session)){throw 'Session Windows en double'};$sessions[$session]=$true}}
 if(@($cfg.workdays).Count-lt1){throw 'Jours travailles manquants'};foreach($d in $cfg.workdays){$n=CalendarNumber $d 0 6;if($n-ne[Math]::Floor($n)){throw 'Jour travaille invalide'}}
 $s=CalendarMinute $cfg.startTime;$e=CalendarMinute $cfg.endTime;if($e-le$s){throw 'Horaires invalides'}
 $previous=$s;foreach($b in @($cfg.breaks|Sort-Object start)){ $bs=CalendarMinute $b.start;$be=CalendarMinute $b.end;if($bs-lt$previous-or$be-le$bs-or$be-gt$e){throw 'Pauses en dehors des horaires ou en chevauchement'};$previous=$be }
 if(!$cfg.rates){throw 'Durees et tarifs manquants'}
 foreach($prop in $cfg.rates.PSObject.Properties){$r=$prop.Value;$null=CalendarNumber $r.minutes 1 60000;$null=CalendarNumber $r.price 0 1000000000;$null=CalendarNumber $r.complexFactor 1 10;if($r.due){$null=CalendarDate $r.due}}
 foreach($x in @($cfg.exceptions)){$date=CalendarDate $x.date;if($date-lt$start-or$date-gt$end-or($x.agent-ne'*'-and!$ids.ContainsKey([string]$x.agent))-or(CalendarMinute $x.end)-le(CalendarMinute $x.start)){throw 'Exception de calendrier invalide'}}
 $docs=@{};foreach($x in @($cfg.overrides)){if(!$x.id-or$docs.ContainsKey([string]$x.id)){throw 'Exception document en double'};$docs[[string]$x.id]=$true;if($null-ne$x.minutes-and[string]$x.minutes-ne''){$null=CalendarNumber $x.minutes 1 60000};if($null-ne$x.price-and[string]$x.price-ne''){$null=CalendarNumber $x.price 0 1000000000};if($x.agent-and!$ids.ContainsKey([string]$x.agent)){throw 'Agent impose invalide'};if($x.due){$null=CalendarDate $x.due}}
}
function CalendarSlots($cfg,$agent,$date){
 $d=CalendarDate $date;if(@($cfg.workdays)-notcontains[int]$d.DayOfWeek){return @()}
 $slots=@([pscustomobject]@{start=(CalendarMinute $cfg.startTime);end=(CalendarMinute $cfg.endTime)})
 $blocks=@($cfg.breaks)+@($cfg.exceptions|Where-Object{$_.date-eq$date-and($_.agent-eq'*'-or$_.agent-eq$agent)})
 foreach($b in $blocks){$s=CalendarMinute $b.start;$e=CalendarMinute $b.end;$next=@();foreach($t in $slots){if($s-ge$t.end-or$e-le$t.start){$next+=$t}else{if($s-gt$t.start){$next+=[pscustomobject]@{start=$t.start;end=[Math]::Min($s,$t.end)}};if($e-lt$t.end){$next+=[pscustomobject]@{start=[Math]::Max($e,$t.start);end=$t.end}}}};$slots=$next}
 return $slots
}
function CalendarStock($db){return @($db.documents|Where-Object{$_.present-and$_.status-eq'A TRAITER'})}
function CalendarToken($docs){
 $rows=@($docs|Sort-Object id|ForEach-Object{[ordered]@{id=$_.id;name=$_.name;entity=$_.entity;branch=$_.branch;priority=$_.priority;complex=$_.complex;deposit=$_.deposit;price=$_.unitPrice}})
 $sha=[Security.Cryptography.SHA256]::Create();try{return [BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $rows -Depth 8 -Compress)))).Replace('-','')}finally{$sha.Dispose()}
}
function GetCalendar(){
 WithStore {param($db)
  WithCalendar {param($calendar)
   $published=$calendar.published
   if($published){$byId=@{};foreach($d in $db.documents){$byId[[string]$d.id]=$d};foreach($a in @($published.assignments)){$d=$byId[[string]$a.id];$status=if($d-and$d.present){$d.status}else{'Absent du stock'};$a|Add-Member -NotePropertyName currentStatus -NotePropertyValue $status -Force}}
   $result=@{revision=$calendar.revision;published=$published;agent=(Agent)}
   if($Role-eq'MANAGER'){$result.draft=$calendar.draft;$stock=@(CalendarStock $db);$result.documents=@($stock);$result.stockToken=CalendarToken $stock;$result.knownAgents=@($db.history|ForEach-Object{$_.agent}|Where-Object{$_}|Sort-Object -Unique)}
   return $result
  } $false
 } $false
}
function ValidateCalendarPlan($plan,$docs){
 $cfg=$plan.config;ValidateCalendarConfig $cfg $true
 $agents=@{};foreach($a in $cfg.agents){$agents[[string]$a.id]=$a};$stock=@{};foreach($d in $docs){$stock[[string]$d.id]=$d};$overrides=@{};foreach($x in @($cfg.overrides)){$overrides[[string]$x.id]=$x}
 $seen=@{};$occupied=@{};$total=0;$value=0.0
 foreach($a in @($plan.assignments)){
  if(!$a.id-or$seen.ContainsKey([string]$a.id)-or!$stock.ContainsKey([string]$a.id)-or!$agents.ContainsKey([string]$a.agent)){throw 'Affectation inconnue ou dupliquee'}
  $seen[[string]$a.id]=$true;$d=$stock[[string]$a.id];$rate=$cfg.rates.PSObject.Properties[[string]$d.entity];if(!$rate){throw 'Tarif ou duree de l entite manquant'};$rate=$rate.Value;$x=$overrides[[string]$a.id]
  $duration=[double]$rate.minutes;if($d.complex){$duration*=[double]$rate.complexFactor};$price=[double]$rate.price;$due=[string]$rate.due
  if($x){if($null-ne$x.minutes-and[string]$x.minutes-ne''){$duration=[double]$x.minutes};if($null-ne$x.price-and[string]$x.price-ne''){$price=[double]$x.price};if($x.due){$due=[string]$x.due};if($x.agent-and$x.agent-ne$a.agent){throw 'Agent impose non respecte'}}
  $duration=[Math]::Ceiling($duration);$sum=0;$previous='';$segments=@($a.segments);if(!$segments.Count){throw 'Document sans creneau'}
  foreach($s in $segments){$date=CalendarDate $s.date;if($date-lt(CalendarDate $cfg.start)-or$date-gt(CalendarDate $cfg.end)){throw 'Creneau hors periode'};$sm=CalendarNumber $s.start 0 1439;$em=CalendarNumber $s.end 1 1440;if($sm-ne[Math]::Floor($sm)-or$em-ne[Math]::Floor($em)-or$em-le$sm){throw 'Creneau invalide'}
   $valid=$false;foreach($slot in @(CalendarSlots $cfg $a.agent $s.date)){if($sm-ge$slot.start-and$em-le$slot.end){$valid=$true;break}};if(!$valid){throw 'Creneau pendant une pause, absence ou hors horaires'}
   $stamp=[string]$s.date+'T'+([TimeSpan]::FromMinutes($sm).ToString('hh\:mm'));if($previous-and$stamp-lt$previous){throw 'Creneaux non chronologiques'};$previous=[string]$s.date+'T'+([TimeSpan]::FromMinutes($em).ToString('hh\:mm'))
   $key=[string]$a.agent+'|'+[string]$s.date;if(!$occupied.ContainsKey($key)){$occupied[$key]=@()};foreach($other in $occupied[$key]){if($sm-lt$other.end-and$em-gt$other.start){throw 'Double reservation du meme agent'}};$occupied[$key]+=$s;$sum+=$em-$sm
  }
  if($sum-ne$duration){throw 'Duree reservee differente de la duree estimee'}
  $a.name=$d.name;$a.entity=$d.entity;$a.branch=[string]$d.branch;$a.priority=[bool]$d.priority;$a.complex=[bool]$d.complex;$a.minutes=$duration;$a.price=$price;$a.due=$due
  $a.start=[string]$segments[0].date+'T'+([TimeSpan]::FromMinutes([double]$segments[0].start).ToString('hh\:mm'));$a.end=$previous;$a.late=($due-and[string]$segments[-1].date-gt$due)
  $total+=$sum;$value+=$price
 }
 foreach($a in @($plan.unplanned)){if(!$a.id-or$seen.ContainsKey([string]$a.id)-or!$stock.ContainsKey([string]$a.id)){throw 'Document non planifie invalide'};$seen[[string]$a.id]=$true;$a.name=$stock[[string]$a.id].name;$a.entity=$stock[[string]$a.id].entity}
 if($seen.Count-ne$stock.Count){throw 'Le planning ne couvre pas tout le stock A TRAITER'}
 $plan.sourceCount=$docs.Count;$plan.plannedMinutes=$total;$plan.totalValue=$value
}
function UpdateCalendar($body){
 if($Role-ne'MANAGER'){throw 'Validation reservee au manager'}
 WithStore {param($db)
  WithCalendar {param($calendar)
   if($null-eq$body.revision-or[int]$body.revision-ne[int]$calendar.revision){throw 'Le calendrier a ete modifie par un autre manager. Rechargez le calendrier.'}
   if($body.action-eq'draft'){ValidateCalendarConfig $body.config;$calendar.draft=$body.config}
   elseif($body.action-eq'publish'){
    $stock=@(CalendarStock $db);if([string]$body.stockToken-cne(CalendarToken $stock)){throw 'Le stock A TRAITER a change. Actualisez le stock du calendrier et recalculez avant validation.'}
    ValidateCalendarPlan $body.plan $stock
    $body.plan|Add-Member -NotePropertyName publishedAt -NotePropertyValue (Get-Date).ToString('o') -Force
    $body.plan|Add-Member -NotePropertyName publishedBy -NotePropertyValue (Agent) -Force
    $calendar.published=$body.plan;$calendar.draft=$body.plan.config
   }else{throw 'Action calendrier inconnue'}
   $calendar.revision=[int]$calendar.revision+1
   return @{ok=$true;revision=$calendar.revision;published=$calendar.published}
  } $true
 } $false
}
