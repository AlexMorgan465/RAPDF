﻿V5.6 : lire CALENDRIER_V5_6.txt. Calendrier manager/agent avec validation partagee.
Fermer les deux serveurs avant MISE_A_JOUR.bat, puis relancer et Ctrl+F5.

V5.5 : lire EXPORTS_V5_5.txt. PDF telecharge directement et facture avec sous-entites.
Mise a jour interface manager uniquement.

V5.3.1 : lire CORRECTION_V5_3_1.txt. Arreter les serveurs avant MISE_A_JOUR.bat.

V5.3 : lire NOUVEAUTES_V5_3.txt. Cette mise a jour remplace interfaces et serveurs.

V5.2 — DESIGN GRIS ET BLANC + TABLEAUX DE BORD

Pour installer le design sur votre version V5.1 : extraire ce ZIP dans un
nouveau dossier, puis lancer MISE_A_JOUR.bat et indiquer votre dossier actuel.
Seules les deux pages HTML sont remplacees. Les pages precedentes sont sauvegardees
sous index.avant_design.html. Aucun serveur, CONFIG.ps1 ou DATA n'est remplace.
Rouvrir les interfaces et faire Ctrl+F5.

Navigation laterale, hierarchie visuelle, nuances de gris, blanc et degrades.
Manager : nouvel onglet Tableau de bord, stock par statut, volumes par entite,
courbes mensuelles recu/traite, production par agent et indicateurs secondaires.
Agent : nouvel onglet Tableau de bord, stock partage, mon activite et entites.
Les graphiques lisent les donnees deja disponibles ; aucun appel serveur ajoute.
Filtres manager existants appliques au tableau de bord. Donnees detaillees
consultables sous chaque graphique, focus clavier et lien d'acces au contenu.
Serveurs et logique metier conserves exactement depuis V5.1.

Validation : rendu dans Chromium, parcours manager et agent avec API simulee,
actions existantes et tableaux de bord verifies. Fichiers PowerShell et configuration
identiques a la version V5.1 (comparaison SHA-256).

CORRECTION V5.1 : lire CORRECTION_V5_1.txt pour installer sans remplacer DATA.

ACCESSIBILITY BANK SYSTEM — V5.2

INSTALLATION
1. Arrêter les anciennes interfaces/serveurs.
2. Extraire le dossier complet HORS du DP documentaire ACCESSIBILITE.
   Garder AGENT, MANAGER, common.ps1, CONFIG.ps1 et DATA ensemble.
3. Pour plusieurs postes : placer cette application dans un partage applicatif
   hors du DP, ou définir dans CONFIG.ps1 un même DataPath partagé pour tous.
   Un DATA local différent sur chaque PC ne permet PAS une consolidation partagée.
4. Lancer MANAGER/START_MANAGER.bat (localhost:8790).
5. Cliquer « Importer / actualiser le stock DP » pour initialiser le catalogue.
6. Lancer AGENT/START_AGENT.bat (localhost:8788).
   En cas de problème, utiliser START_DEBUG.bat pour lire l'erreur.

DP DOCUMENTAIRE
Aucun fichier de suivi, compteur, verrou ou dossier créé dans le DP.
Lecture des branches existantes uniquement. Les seuls déplacements de documents
sont ceux demandés par un agent ou le manager. Destination absente : action refusée,
aucune création de dossier. L'ancien historique DP est lu pour récupération,
jamais modifié. Le schéma des entités et la sélection portefeuille sont conservés.
Toutes les nouvelles données sont dans DATA/catalogue.json hors du DP.
Ne pas supprimer DATA : il conserve les dates figées et l'historique.

MANAGER
- Stock regroupé par entité puis date de dépôt ; priorités et prix par document.
- Facture : un document actuellement TRAITES = une ligne, regroupement mois/entité.
  Total = somme des prix unitaires. À tarif identique : quantité x prix.
- Tarifs de la capture : 9, sauf DIRCO, CMMABN, CIC CIB ASSET SERVICING : 4,5.
  COFIDIS FRANCE absent de la capture : 9 par défaut, modifiable à confirmer.
  Aucune devise imposée. Prix actuels modifiables, pas de clôture comptable figée.
- NC : vue globale, brouillon mail par document ou entité. Destinataire manuel.
  Pour les listes longues : export CSV à joindre au brouillon.
- Reporting : reçus selon date de dépôt ; traitements conformes selon historique
  et dates renseignées. Un retraitement constitue un nouveau traitement dans le
  reporting ; la facture compte une fois le document actuellement conforme.
- Filtres année, mois, semaine ISO, jour, entité et recherche. Exports CSV.
- Consolidation : mouvements, agents, DMT, complexité, commentaire et durée statut.

AGENT
- Sélection entité / statut / sous-entité / Afficher conservée.
- Urgence : priorités manager, PEC directe depuis A TRAITER.
- Complexité avec commentaire obligatoire, visible en facture et consolidation.
- Tous les statuts peuvent aller vers tous les autres, dossiers existants uniquement.
- Historique personnel, DMT, compteurs, déconnexion.

DATES ET SYNCHRONISATION
Date de dépôt = LastWriteTime observé au PREMIER import de ce document.
Elle ne change pas aux actualisations ni aux déplacements faits par l'application.
Elle n'est pas une preuve d'une date de dépôt antérieure au premier import.
L'identité est entité + branche + nom. Renommer un document hors application est
considéré comme un nouveau document. Chaque entrée directe de la branche reste
une unité (fichier ou dossier), comme dans la version fournie.
Documents déjà traités : récupérer la date de fin depuis l'ancien historique si
connue, sinon la renseigner dans Facture avant de les inclure au calcul.
Durée statut = temps observé depuis la première détection et les mouvements connus.
Les périodes antérieures inconnues ne sont pas inventées.
Un verrou partagé sérialise les mises à jour et les PEC. Une deuxième PEC est refusée.
Les nouvelles données visibles se rafraîchissent toutes les secondes ; aucun scan
DP global automatique. Les nouveaux dépôts externes sont découverts via Afficher
(branche sélectionnée) ou Importer / actualiser le stock DP (manager).

VALIDATION DE CETTE LIVRAISON
Scripts agent/manager exécutés dans un DOM de test avec API simulée : priorités,
prix, date de fin historique, filtres mois/semaine ISO, complexité, PEC urgence,
destinations et échappement HTML vérifiés.
Le serveur PowerShell et les déplacements Windows/partage réseau n'ont pas pu être
exécutés dans l'environnement Linux de préparation. Les lancer en START_DEBUG
sur Windows avant l'utilisation en production. Aucun DP réel n'a été utilisé.
