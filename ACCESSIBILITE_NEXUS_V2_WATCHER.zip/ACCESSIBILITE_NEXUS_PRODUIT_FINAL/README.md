# Accessibilité Nexus — V2 technique

## Démarrage

1. Arrêter l'ancien serveur avec le `STOP.bat` **de son ancien dossier**.
2. Extraire cette archive complète dans un nouveau dossier. Pour conserver le travail, copier les fichiers métier de l'ancien `data` (`tasks.json`, `events.json`, `audit.jsonl`, `entity-priorities.json`) dans le nouveau `data`. Copier `config.json` seulement si les chemins réseau ont été personnalisés. Ne pas copier d'anciens scripts.
3. Lancer `CREER_RACCOURCI.vbs` une fois, puis ouvrir le raccourci du Bureau, ou lancer directement `START.bat`.
4. PowerShell 7 (`pwsh.exe`) est requis. `START_VISIBLE.bat` affiche les erreurs ; `STOP.bat` arrête le serveur.

## Catalogue

`tasks.json` et `traites-index.json` sont chargés en mémoire au démarrage. L'interface peut afficher le cache avant la fin du premier contrôle réseau. `FileSystemWatcher` reçoit les créations, modifications, renommages et suppressions dans l'arborescence du DP. Le serveur traite les chemins concernés et met à jour le catalogue JSON. Il vérifie également `A TRAITER`, `EN COURS` et `NON CONFORME` en arrière-plan : toutes les 60 secondes si la surveillance fonctionne, toutes les 15 secondes sinon, configurables via `rescanSeconds` et `scanSeconds`.

`TRAITES` n'est pas parcouru au contrôle ordinaire. Les traitements faits dans l'application alimentent `tasks.json`, `traites-index.json` et `audit.jsonl`. Le manager peut demander une resynchronisation complète des dossiers `TRAITES` après des déplacements faits dans l'Explorateur. L'index du dernier contrôle réseau est `dp-index.json`. Une indisponibilité du DP n'efface pas les traitements mémorisés.

`/api/state` fournit les dossiers actifs et les agrégats. `/api/traitements?page=1&limit=100` et `/api/documents-traites?page=1&limit=100` paginent l'historique en mémoire. Le navigateur vérifie les changements chaque seconde et ne redessine pas sans nouvelle version.

## Comptes et fonctions

L'identité Windows transmise par le navigateur est utilisée directement. `CDM\OUBRAHMO`, `CDM\HAMDANMO` et l'alias `CDM\HMADANMO` ont accès au manager. Les autres utilisateurs Windows authentifiés ont le rôle agent. Les routes et actions manager sont contrôlées côté serveur. Les pages agent et manager, le suivi, la finalisation, le retraitement, la priorité, l'audit et l'export CSV restent présents.

Cette V2 ne crée pas d'intégration Outlook ou Excel COM nouvelle. L'export CSV existant peut être ouvert dans Excel. La surveillance d'un partage réseau peut perdre des événements en cas de rafale ou d'indisponibilité : le scan de contrôle et le bouton manager servent à réconcilier les écarts. Sauvegarder régulièrement le dossier `data`.
