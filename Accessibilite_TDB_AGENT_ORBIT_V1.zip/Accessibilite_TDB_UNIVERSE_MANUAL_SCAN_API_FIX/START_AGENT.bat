@echo off
cd /d "%~dp0"
start "ACCESSIBILITY AGENT SERVER" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0agent_server.ps1"
timeout /t 2 /nobreak >nul
start "" "http://localhost:8788/agent.html"
