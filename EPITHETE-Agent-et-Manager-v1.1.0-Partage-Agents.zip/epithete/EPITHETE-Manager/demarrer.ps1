$ErrorActionPreference='Stop'
$url='http://127.0.0.1:8776'
$errorLog=Join-Path $PSScriptRoot 'demarrage-erreur.log'
$outputLog=Join-Path $PSScriptRoot 'demarrage-sortie.log'
try {
 try {$health=Invoke-RestMethod "$url/api/health" -TimeoutSec 2} catch {$health=$null}
 if ($health) {try{Invoke-RestMethod "$url/api/shutdown" -Method Post -ContentType 'application/json' -Body '{}' -TimeoutSec 2|Out-Null}catch{};Start-Sleep -Milliseconds 900}
 $health=$null
 Remove-Item $errorLog,$outputLog -Force -ErrorAction SilentlyContinue
 $server=Join-Path $PSScriptRoot 'serveur.ps1'
 Start-Process powershell.exe -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+$server+'"')) -RedirectStandardError $errorLog -RedirectStandardOutput $outputLog
 for($i=0;$i -lt 30;$i++){Start-Sleep -Milliseconds 400;try{$health=Invoke-RestMethod "$url/api/health" -TimeoutSec 2;break}catch{}}
 if (-not $health) {
  $detail=if(Test-Path $errorLog){(Get-Content $errorLog -Raw -ErrorAction SilentlyContinue).Trim()}else{''}
  if(-not $detail){$detail='Aucun détail reçu. Vérifiez que le port 8776 est libre.'}
  $nl=[Environment]::NewLine
  throw ('Le serveur Manager ne démarre pas.'+$nl+$nl+$detail+$nl+$nl+'Journal : '+$errorLog)
 }
 Start-Process $url
} catch {
 Add-Type -AssemblyName PresentationFramework
 [System.Windows.MessageBox]::Show($_.Exception.Message,'ÉPITHÈTE Manager')|Out-Null
}
