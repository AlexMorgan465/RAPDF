(()=>{'use strict';
const $=id=>document.getElementById(id),canvas=$('photo-canvas');if(!canvas)return;const ctx=canvas.getContext('2d',{willReadFrequently:true});let source=document.createElement('canvas'),sctx=source.getContext('2d',{willReadFrequently:true}),loaded=false,tool='crop',drawing=false,start=null,selection=null,roundSelection=null,outline=[],outlineBeforeSnap=null,history=[],future=[],original=null,keepMask=document.createElement('canvas'),maskCtx=keepMask.getContext('2d'),maskHistory=[],previewMode='mask';
const controls=['photo-brightness','photo-contrast','photo-saturation','photo-grayscale','photo-sepia','photo-blur'];
function filters(){return`brightness(${$('photo-brightness').value}%) contrast(${$('photo-contrast').value}%) saturate(${$('photo-saturation').value}%) grayscale(${$('photo-grayscale').value}%) sepia(${$('photo-sepia').value}%) blur(${$('photo-blur').value}px)`}
function neutralFilters(){return $('photo-brightness').value==='100'&&$('photo-contrast').value==='100'&&$('photo-saturation').value==='100'&&$('photo-grayscale').value==='0'&&$('photo-sepia').value==='0'&&$('photo-blur').value==='0'}
function resetFilters(){for(const id of controls){const e=$(id);e.value=id.includes('grayscale')||id.includes('sepia')||id.includes('blur')?0:100;e.dispatchEvent(new Event('input'))}}
function resetMask(){keepMask.width=source.width;keepMask.height=source.height;maskCtx=keepMask.getContext('2d');maskHistory=[]}
function saveMask(){maskHistory.push(maskCtx.getImageData(0,0,keepMask.width,keepMask.height));if(maskHistory.length>10)maskHistory.shift()}
function fitCanvas(){/* Taille affichée par photo375.css, compatible CSP. */}
function render(){if(!loaded)return;canvas.width=source.width;canvas.height=source.height;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.save();ctx.filter=filters();ctx.globalCompositeOperation='source-over';ctx.drawImage(source,0,0);ctx.restore();if(previewMode==='result'&&$('photo-mask-feather')){ctx.clearRect(0,0,canvas.width,canvas.height);ctx.drawImage(previewCanvas(),0,0);$('photo-empty').hidden=true;$('photo-wrap').hidden=false;return}if(keepMask.width===source.width&&keepMask.height===source.height){ctx.save();ctx.globalAlpha=.48;ctx.drawImage(keepMask,0,0);ctx.restore()}if(selection){ctx.save();ctx.strokeStyle='#36b9ff';ctx.lineWidth=Math.max(2,canvas.width/500);ctx.setLineDash([10,7]);ctx.fillStyle='#36b9ff20';ctx.fillRect(selection.x,selection.y,selection.w,selection.h);ctx.strokeRect(selection.x,selection.y,selection.w,selection.h);ctx.restore()}if(roundSelection){ctx.save();ctx.strokeStyle='#ff9b50';ctx.lineWidth=Math.max(3,canvas.width/250);ctx.setLineDash([8,5]);ctx.beginPath();ctx.ellipse(roundSelection.cx,roundSelection.cy,roundSelection.rx||roundSelection.radius,roundSelection.ry||roundSelection.radius,0,0,Math.PI*2);ctx.stroke();ctx.restore()}if(outline.length){ctx.save();ctx.strokeStyle='#d8f6ff';ctx.shadowColor='#7fd9ff';ctx.shadowBlur=Math.max(9,canvas.width/60);ctx.lineWidth=Math.max(3,canvas.width/220);ctx.beginPath();outline.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));if(outline.length>2)ctx.closePath();ctx.stroke();ctx.restore()}$('photo-empty').hidden=true;$('photo-wrap').hidden=false;fitCanvas();$('photo-width').value=source.width;$('photo-height').value=source.height;$('photo-status').textContent=`${source.width} × ${source.height} px · ${tool==='crop'?'Sélectionnez une zone à recadrer':tool==='brush'?'Pinceau actif':tool==='eraser'?'Gomme active':'Prêt'}`}
function snapshot(){if(!loaded)return;history.push(source.toDataURL('image/png'));if(history.length>20)history.shift();future=[]}
function restore(data){const img=new Image;img.onload=()=>{source.width=img.width;source.height=img.height;sctx=source.getContext('2d',{willReadFrequently:true});sctx.drawImage(img,0,0);selection=null;resetMask();resetFilters();render()};img.src=data}
function commitFilters(){if(!loaded)return;if(neutralFilters())return;const temp=document.createElement('canvas');temp.width=source.width;temp.height=source.height;const t=temp.getContext('2d');t.filter=filters();t.drawImage(source,0,0);source=temp;sctx=source.getContext('2d',{willReadFrequently:true});resetFilters()}
function point(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
function setTool(name){tool=name;selection=null;roundSelection=null;outline=[];outlineBeforeSnap=null;document.querySelectorAll('[data-photo-tool]').forEach(b=>b.classList.toggle('active',b.dataset.photoTool===name));render()}
function transform(kind){if(!loaded)return;snapshot();commitFilters();const out=document.createElement('canvas'),o=out.getContext('2d');if(kind==='left'||kind==='right'){out.width=source.height;out.height=source.width;o.translate(out.width/2,out.height/2);o.rotate((kind==='right'?1:-1)*Math.PI/2);o.drawImage(source,-source.width/2,-source.height/2)}else{out.width=source.width;out.height=source.height;o.translate(kind==='flipH'?out.width:0,kind==='flipV'?out.height:0);o.scale(kind==='flipH'?-1:1,kind==='flipV'?-1:1);o.drawImage(source,0,0)}source=out;sctx=source.getContext('2d',{willReadFrequently:true});resetMask();render()}
async function decodeSelectedImage(file){
  if(!file)throw new Error('Aucun fichier sélectionné.');
  const bytes=await file.arrayBuffer();
  if(!bytes.byteLength)throw new Error('Le fichier sélectionné est vide.');
  const blob=new Blob([bytes],{type:file.type||'application/octet-stream'});
  if('createImageBitmap' in window){
    try{return await createImageBitmap(blob)}catch(_error){}
  }
  const dataUrl=await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(reader.result);
    reader.onerror=()=>reject(reader.error||new Error('Lecture impossible.'));
    reader.readAsDataURL(blob);
  });
  return await new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=()=>reject(new Error('Décodage impossible.'));
    img.src=dataUrl;
  });
}
$('photo-file').addEventListener('change',async e=>{
  const file=e.target.files&&e.target.files[0];if(!file)return;
  const status=$('photo-status');status.textContent='Chargement de l’image locale…';
  try{
    const img=await decodeSelectedImage(file);
    const width=img.naturalWidth||img.width,height=img.naturalHeight||img.height;
    if(!width||!height)throw new Error('Dimensions invalides.');
    source.width=width;source.height=height;
    sctx=source.getContext('2d',{willReadFrequently:true});
    sctx.clearRect(0,0,width,height);sctx.drawImage(img,0,0,width,height);
    if(typeof img.close==='function')img.close();
    loaded=true;history=[];future=[];selection=null;roundSelection=null;outline=[];resetMask();
    original=source.toDataURL('image/png');
    const before=$('photo-before-preview');if(before){before.width=width;before.height=height;before.getContext('2d').drawImage(source,0,0)}
    resetFilters();render();status.textContent='Image importée. Pour isoler le portrait, choisissez Contour manuel, tracez le sujet puis appliquez.';
  }catch(error){
    loaded=false;
    status.textContent='Impossible de charger cette image : '+(error&&error.message?error.message:'format non reconnu.');
    console.error('EBRA Photo — import local',error);
  }finally{
    e.target.value='';
  }
});
for(const id of controls){const e=$(id),out=$(id+'-value');e.oninput=()=>{out.textContent=e.value+(id==='photo-blur'?' px':'%');render()}}
document.querySelectorAll('[data-photo-tool]').forEach(b=>b.onclick=()=>setTool(b.dataset.photoTool));
document.querySelectorAll('[data-photo-transform]').forEach(b=>b.onclick=()=>transform(b.dataset.photoTransform));
canvas.onpointerdown=e=>{if(!loaded)return;const p=point(e);if(tool==='maskWand'){magicKeep(p);return}else if(tool==='maskKeep'||tool==='maskErase'){saveMask();drawing=true;start=p;maskCtx.save();maskCtx.lineCap='round';maskCtx.lineJoin='round';maskCtx.lineWidth=Number($(tool==='maskErase'?'photo-mask-erase-size':'photo-mask-size').value);maskCtx.globalCompositeOperation=tool==='maskErase'?'destination-out':'source-over';maskCtx.strokeStyle='#00ec91';maskCtx.beginPath();maskCtx.moveTo(p.x,p.y);maskCtx.lineTo(p.x+.01,p.y+.01);maskCtx.stroke();canvas.setPointerCapture(e.pointerId);render()}else if(tool==='roundManual'||tool==='ovalManual'){start=p;roundSelection={cx:p.x,cy:p.y,radius:1,rx:1,ry:1};drawing=true;canvas.setPointerCapture(e.pointerId);render()}else if(tool==='outline'){outline=[p];drawing=true;canvas.setPointerCapture(e.pointerId);render()}else if(tool==='crop'){start=p;selection={x:p.x,y:p.y,w:0,h:0};drawing=true;canvas.setPointerCapture(e.pointerId);render()}else if(tool==='brush'||tool==='eraser'){snapshot();commitFilters();drawing=true;start=p;sctx.beginPath();sctx.moveTo(p.x,p.y);canvas.setPointerCapture(e.pointerId)}};
canvas.onpointermove=e=>{if(!drawing)return;const p=point(e);if(tool==='maskKeep'||tool==='maskErase'){maskCtx.lineTo(p.x,p.y);maskCtx.stroke();render()}else if(tool==='roundManual'||tool==='ovalManual'){const rx=Math.min(Math.abs(p.x-start.x),start.x,source.width-start.x),ry=Math.min(Math.abs(p.y-start.y),start.y,source.height-start.y);roundSelection={cx:start.x,cy:start.y,radius:Math.min(Math.hypot(p.x-start.x,p.y-start.y),start.x,start.y,source.width-start.x,source.height-start.y),rx:tool==='ovalManual'?rx:undefined,ry:tool==='ovalManual'?ry:undefined};render()}else if(tool==='outline'){if(Math.hypot(p.x-outline[outline.length-1].x,p.y-outline[outline.length-1].y)>Math.max(2,source.width/350)){outline.push(p);render()}}else if(tool==='crop'){selection={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)};render()}else{sctx.lineCap='round';sctx.lineJoin='round';sctx.lineWidth=Number($('photo-brush-size').value);sctx.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';sctx.strokeStyle=$('photo-color').value;sctx.lineTo(p.x,p.y);sctx.stroke();start=p;render()}};
canvas.onpointerup=()=>{if((tool==='roundManual'||tool==='ovalManual')&&roundSelection&&roundSelection.radius>5){$('photo-status').textContent='Cadre tracé. Cliquez sur Appliquer le cadre manuel.'}if(tool==='outline'&&outline.length>2){render();$('photo-status').textContent='Contour tracé. Cliquez sur Isoler le sujet.'}if(tool==='maskKeep'||tool==='maskErase')maskCtx.restore();drawing=false;sctx.globalCompositeOperation='source-over'};
$('photo-apply-crop').onclick=()=>{if(!selection||selection.w<2||selection.h<2)return;snapshot();commitFilters();const x=Math.round(selection.x),y=Math.round(selection.y),w=Math.round(selection.w),h=Math.round(selection.h),out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,x,y,w,h,0,0,w,h);source=out;sctx=source.getContext('2d',{willReadFrequently:true});selection=null;render()};
$('photo-add-text').onclick=()=>{if(!loaded)return;const text=$('photo-text').value.trim();if(!text)return;snapshot();commitFilters();sctx.save();sctx.font=`700 ${Number($('photo-font-size').value)}px Segoe UI,Arial`;sctx.textAlign='center';sctx.textBaseline='middle';sctx.fillStyle=$('photo-color').value;sctx.fillText(text,source.width/2,source.height/2);sctx.restore();render()};
$('photo-resize').onclick=()=>{if(!loaded)return;const w=Math.max(1,Number($('photo-width').value)),h=Math.max(1,Number($('photo-height').value));snapshot();commitFilters();const out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,0,0,w,h);source=out;sctx=source.getContext('2d',{willReadFrequently:true});resetMask();render()};
$('photo-undo').onclick=()=>{if(!history.length||!loaded)return;future.push(source.toDataURL('image/png'));restore(history.pop())};$('photo-redo').onclick=()=>{if(!future.length||!loaded)return;history.push(source.toDataURL('image/png'));restore(future.pop())};$('photo-reset').onclick=()=>{if(original){snapshot();restore(original)}};
$('photo-brush-size').oninput=e=>$('photo-brush-size-value').textContent=e.target.value+' px';
function cleanCanvas(){const out=document.createElement('canvas');out.width=source.width;out.height=source.height;const o=out.getContext('2d');o.filter=filters();o.drawImage(source,0,0);return out}
function previewCanvas(){const out=cleanCanvas();if(keepMask.width!==source.width||keepMask.height!==source.height)return out;
  const alpha=maskCtx.getImageData(0,0,keepMask.width,keepMask.height).data;let hasMask=false;
  for(let i=3;i<alpha.length;i+=4)if(alpha[i]){hasMask=true;break}
  if(!hasMask)return out;const feather=Number($('photo-mask-feather').value),mask=document.createElement('canvas');mask.width=source.width;mask.height=source.height;
  const m=mask.getContext('2d');m.filter=feather?`blur(${feather}px)`:'none';m.drawImage(keepMask,0,0);
  const o=out.getContext('2d');o.globalCompositeOperation='destination-in';o.drawImage(mask,0,0);o.globalCompositeOperation='source-over';
  if($('photo-cutout-background').value==='white'){const white=document.createElement('canvas');white.width=out.width;white.height=out.height;const w=white.getContext('2d');w.fillStyle='#fff';w.fillRect(0,0,out.width,out.height);w.drawImage(out,0,0);return white}
  return out;
}
function downloadBlob(blob,name){if(!blob){$('photo-status').textContent='Création du fichier impossible.';return}const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),30000)}
$('photo-export').onclick=()=>{if(!loaded)return;const format=$('photo-format').value,mime=format==='jpg'?'image/jpeg':'image/png';let output=previewMode==='result'?previewCanvas():cleanCanvas();
  if(format==='jpg'){const white=document.createElement('canvas');white.width=output.width;white.height=output.height;const w=white.getContext('2d');w.fillStyle='#fff';w.fillRect(0,0,white.width,white.height);w.drawImage(output,0,0);output=white}
  const name='EBRA-image-'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.'+format;
  output.toBlob(blob=>downloadBlob(blob,name),mime,Number($('photo-quality').value)/100)
};
function setupBackgroundRemoval(){
  const panel=$('photo-file').closest('.photo-panel'),stage=canvas.closest('.photo-stage');
  const box=document.createElement('div');box.className='photo-cutout-box';box.innerHTML='<h3>Zoom de l’image</h3><label class="photo-control">Zoom de l’image Après<select id="photo-zoom"><option value="50">50 %</option><option value="100" selected>100 %</option><option value="150">150 %</option><option value="200">200 %</option><option value="300">300 %</option></select></label><h3>Cadre rond</h3><div class="photo-tool-grid"><button type="button" class="primary" id="photo-round-frame">◯ Automatique</button><button type="button" class="photo-tool" data-photo-tool="roundManual" id="photo-round-manual">✎ Manuel</button></div><button type="button" class="primary" id="photo-apply-round-manual">✓ Appliquer le cadre manuel</button><label class="photo-control">Flou du bord <output id="photo-round-blur-value">0 px</output><input id="photo-round-blur" type="range" min="0" max="30" value="0"></label><p class="photo-cutout-help">Automatique centre le cercle. Manuel : cliquez au centre du sujet et glissez pour régler le rayon. Le flou adoucit le bord du cercle.</p><h3>Cadre ovale</h3><div class="photo-tool-grid"><button type="button" class="primary" id="photo-oval-frame">🥚 Automatique</button><button type="button" class="photo-tool" data-photo-tool="ovalManual" id="photo-oval-manual">✎ Manuel</button></div><button type="button" class="primary" id="photo-apply-oval-manual">✓ Appliquer l’ovale manuel</button><h3>Zone à conserver</h3><button type="button" class="primary" id="photo-ai-person">✦ Détecter la personne (IA)</button><p id="photo-ai-result" class="photo-cutout-help" role="status">Cliquez pour détourer automatiquement la personne. Crée un masque modifiable : peignez pour garder, corrigez pour retirer, puis affichez le résultat.</p><label class="photo-control">Bord adouci <output id="photo-mask-feather-value">0 px</output><input id="photo-mask-feather" type="range" min="0" max="30" value="0"></label><div class="photo-tool-grid"><button type="button" class="photo-tool" data-photo-tool="maskKeep" id="photo-mask-keep">🖌 Peindre à garder</button><button type="button" class="photo-tool" data-photo-tool="maskWand" id="photo-mask-wand">✦ Baguette magique</button><button type="button" class="photo-tool" data-photo-tool="maskErase" id="photo-mask-erase">⌫ Corriger masque</button><button type="button" class="photo-tool" id="photo-mask-undo">↶ Annuler masque</button></div><label class="photo-control">Taille du pinceau <output id="photo-mask-size-value">80 px</output><input id="photo-mask-size" type="range" min="5" max="300" value="80"></label><label class="photo-control">Taille de correction <output id="photo-mask-erase-size-value">40 px</output><input id="photo-mask-erase-size" type="range" min="5" max="300" value="40"></label><label class="photo-control">Tolérance baguette <output id="photo-mask-tolerance-value">35</output><input id="photo-mask-tolerance" type="range" min="5" max="100" value="35"></label><button type="button" class="primary" id="photo-mask-apply">✓ Isoler la zone verte</button><p class="photo-cutout-help">Peignez le sujet en vert. La baguette ajoute d’un clic une zone voisine de couleur proche. Corriger masque retire le vert ; l’image reste intacte jusqu’à Isoler.</p><h3>Arrière-plan</h3><button type="button" class="photo-tool" data-photo-tool="outline" id="photo-outline-tool">✎ Contour manuel</button><button type="button" class="secondary" id="photo-snap-outline">✦ Ajuster au bord du sujet</button><button type="button" class="photo-tool" id="photo-unsnap-outline">↶ Annuler l’ajustement</button><label class="photo-control">Portée de l’ajustement <output id="photo-snap-radius-value">40 px</output><input id="photo-snap-radius" type="range" min="10" max="100" value="40"></label><label class="photo-control photo-glow-option"><input id="photo-outline-glow" type="checkbox" checked> Garder le contour lumineux</label><button type="button" class="primary" id="photo-apply-outline">✓ Isoler le sujet</button><p class="photo-cutout-help">Tracez librement autour du sujet, ajustez le tracé au bord, puis isolez. Le résultat dépend du contraste de la photo.</p><label class="photo-control">Sensibilité <output id="photo-cutout-value">38 %</output><input id="photo-cutout-sensitivity" type="range" min="15" max="75" value="38"></label><label class="photo-control">Arrière-plan<select id="photo-cutout-background"><option value="white">Fond blanc</option><option value="transparent">Transparent</option></select></label><button id="photo-cutout" type="button" class="primary">Supprimer l’arrière-plan (sans sélection)</button><p class="photo-cutout-help">Utilisez ensuite le pinceau ou la gomme pour affiner les contours.</p>';
  panel.appendChild(box);
  const currentEmpty=$('photo-empty'),currentWrap=$('photo-wrap');
  const compare=document.createElement('div');compare.className='photo-before-after';compare.innerHTML='<div class="photo-preview-pane"><span>AVANT</span><div class="photo-preview-bg"><canvas id="photo-before-preview" aria-label="Image originale"></canvas></div></div><div class="photo-preview-pane"><span>APRÈS</span><div id="photo-after-host" class="photo-preview-bg"></div></div>';
  stage.appendChild(compare);const host=compare.querySelector('#photo-after-host');host.appendChild(currentEmpty);host.appendChild(currentWrap);
  
  $('photo-mask-feather').oninput=e=>{$('photo-mask-feather-value').textContent=e.target.value+' px';if(previewMode==='result')render()};
  $('photo-ai-person').onclick=segmentPerson;
  $('photo-mask-keep').onclick=()=>{previewMode='mask';$('photo-preview-mode').value='mask';setTool('maskKeep')};
  $('photo-mask-wand').onclick=()=>setTool('maskWand');
  $('photo-mask-erase').onclick=()=>{previewMode='mask';$('photo-preview-mode').value='mask';setTool('maskErase')};
  $('photo-mask-undo').onclick=()=>{if(maskHistory.length){maskCtx.putImageData(maskHistory.pop(),0,0);render()}};
  $('photo-mask-erase-size').oninput=e=>$('photo-mask-erase-size-value').textContent=e.target.value+' px';
  $('photo-mask-size').oninput=e=>$('photo-mask-size-value').textContent=e.target.value+' px';
  $('photo-mask-tolerance').oninput=e=>$('photo-mask-tolerance-value').textContent=e.target.value;
  $('photo-mask-apply').onclick=applyKeepMask;
  $('photo-zoom').onchange=e=>{host.className='photo-preview-bg photo-zoom-'+e.target.value};
  $('photo-oval-frame').onclick=()=>ovalFrame();
  $('photo-oval-manual').onclick=()=>setTool('ovalManual');
  $('photo-apply-oval-manual').onclick=()=>{if(!roundSelection||!roundSelection.rx||roundSelection.rx<6||roundSelection.ry<6){$('photo-status').textContent='Tracez d’abord un ovale sur l’image Après.';return}ovalFrame(roundSelection)};
  $('photo-round-frame').onclick=()=>roundFrame();
  $('photo-round-manual').onclick=()=>setTool('roundManual');
  $('photo-apply-round-manual').onclick=()=>{if(!roundSelection||roundSelection.radius<6){$('photo-status').textContent='Tracez d’abord un cercle sur la photo Après.';return}roundFrame(roundSelection)};
  $('photo-round-blur').oninput=e=>$('photo-round-blur-value').textContent=e.target.value+' px';
  $('photo-outline-tool').onclick=()=>setTool('outline');
  $('photo-apply-outline').onclick=applyOutline;
  $('photo-snap-outline').onclick=snapOutline;
  $('photo-unsnap-outline').onclick=()=>{if(outlineBeforeSnap){outline=outlineBeforeSnap;outlineBeforeSnap=null;render();$('photo-status').textContent='Ajustement annulé.'}};
  $('photo-snap-radius').oninput=e=>$('photo-snap-radius-value').textContent=e.target.value+' px';
  $('photo-cutout-sensitivity').oninput=e=>$('photo-cutout-value').textContent=e.target.value+' %';
  $('photo-cutout').onclick=removeBackground;
  const bar=document.createElement('div');bar.className='photo-workbar';bar.innerHTML='<strong>Studio</strong><button type="button" id="photo-quick-keep">🖌 Garder</button><button type="button" id="photo-quick-erase">⌫ Corriger</button><button type="button" id="photo-quick-isolate">✓ Isoler</button><button type="button" id="photo-quick-undo">↶ Annuler</button><label>Aperçu<select id="photo-preview-mode"><option value="mask">Masque</option><option value="result">Résultat</option></select></label><button type="button" id="photo-quick-export">↓ Exporter</button><button type="button" id="photo-save-project">↓ Projet</button><label class="photo-project-open">↑ Ouvrir projet<input id="photo-project-file" type="file" accept="application/json,.json"></label>';
  stage.insertBefore(bar,compare);
  $('photo-quick-keep').onclick=()=>setTool('maskKeep');$('photo-quick-erase').onclick=()=>setTool('maskErase');$('photo-quick-isolate').onclick=applyKeepMask;$('photo-quick-undo').onclick=()=>$('photo-undo').click();
  $('photo-preview-mode').onchange=e=>{previewMode=e.target.value;render()};
  $('photo-quick-export').onclick=()=>$('photo-export').click();
  $('photo-save-project').onclick=saveProject;$('photo-project-file').onchange=openProject;
  const zoomLabel=$('photo-zoom').closest('label');bar.appendChild(zoomLabel);
  const group=(container,stop)=>{let current=null;for(const node of Array.from(container.children)){if(node===stop)break;if(node.tagName==='H3'){current=document.createElement('details');current.className='photo-group';current.open=node.textContent==='Zone à conserver';const summary=document.createElement('summary');summary.textContent=node.textContent;current.appendChild(summary);container.insertBefore(current,node);node.remove()}else if(current)current.appendChild(node)}};
  group(box,null);for(const d of box.querySelectorAll('details.photo-group'))if(d.children.length===1)d.remove();
  const classic=document.createElement('details');classic.className='photo-group';const summary=document.createElement('summary');summary.textContent='Recadrage et retouches';classic.appendChild(summary);
  const heading=Array.from(panel.children).find(e=>e.tagName==='H3'&&e.textContent==='Outils');
  if(heading){panel.insertBefore(classic,heading);let node=heading;while(node&&node!==$('photo-status')&&node!==box){const next=node.nextSibling;classic.appendChild(node);node=next}}
  const right=stage.nextElementSibling;if(right&&right.classList.contains('photo-panel'))right.classList.add('photo-settings-panel');
}
function saveProject(){if(!loaded)return;const values={};for(const id of [...controls,'photo-round-blur','photo-mask-feather','photo-mask-size','photo-mask-erase-size','photo-mask-tolerance','photo-cutout-background','photo-color'])values[id]=$(id).value;
  const project={type:'EBRA-PHOTOSHOP-PROJECT',version:1,source:source.toDataURL('image/png'),original,mask:keepMask.toDataURL('image/png'),values};
  downloadBlob(new Blob([JSON.stringify(project)],{type:'application/json'}),'EBRA-projet-'+new Date().toISOString().slice(0,10)+'.json')
}
async function openProject(e){const file=e.target.files&&e.target.files[0];if(!file)return;
  try{const data=JSON.parse(await file.text());if(data.type!=='EBRA-PHOTOSHOP-PROJECT'||data.version!==1||typeof data.source!=='string'||typeof data.mask!=='string')throw new Error('Projet EBRA non reconnu');
    const load=url=>new Promise((resolve,reject)=>{const img=new Image;img.onload=()=>resolve(img);img.onerror=()=>reject(new Error('Image du projet invalide'));img.src=url});
    const img=await load(data.source),mask=await load(data.mask);if(img.width<1||img.height<1||img.width>10000||img.height>10000||mask.width!==img.width||mask.height!==img.height)throw new Error('Dimensions du projet invalides');
    source.width=img.width;source.height=img.height;sctx=source.getContext('2d',{willReadFrequently:true});sctx.drawImage(img,0,0);resetMask();maskCtx.drawImage(mask,0,0);original=data.original||data.source;
    if(data.values)for(const [id,value] of Object.entries(data.values)){const input=$(id);if(input){input.value=value;input.dispatchEvent(new Event('input'))}}
    const before=$('photo-before-preview'),orig=await load(original);before.width=orig.width;before.height=orig.height;before.getContext('2d').drawImage(orig,0,0);
    loaded=true;history=[];future=[];selection=null;outline=[];previewMode='mask';$('photo-preview-mode').value='mask';render();$('photo-status').textContent='Projet ouvert.';
  }catch(error){$('photo-status').textContent='Projet non chargé : '+error.message}finally{e.target.value=''}
}
function magicKeep(p){
  const w=source.width,h=source.height,n=w*h,src=sctx.getImageData(0,0,w,h).data;
  const seedX=Math.max(0,Math.min(w-1,Math.floor(p.x))),seedY=Math.max(0,Math.min(h-1,Math.floor(p.y))),origin=(seedY*w+seedX)*4;
  const tolerance=Number($('photo-mask-tolerance').value)*1.7,seen=new Uint8Array(n),queue=new Int32Array(n),selected=[];
  let head=0,tail=0;queue[tail++]=seedY*w+seedX;seen[seedY*w+seedX]=1;
  const visit=q=>{if(q<0||q>=n||seen[q])return;seen[q]=1;const i=q*4;
    const d=Math.hypot((src[i]-src[origin])*.55,(src[i+1]-src[origin+1])*.7,(src[i+2]-src[origin+2])*.45);
    if(d<=tolerance)queue[tail++]=q;
  };
  while(head<tail){const q=queue[head++],x=q%w;selected.push(q);
    if(x>0)visit(q-1);if(x<w-1)visit(q+1);if(q>=w)visit(q-w);if(q<n-w)visit(q+w);
  }
  if(selected.length>n*.85){$('photo-status').textContent='Zone trop grande : baissez la tolérance et réessayez.';return}
  saveMask();const data=maskCtx.getImageData(0,0,w,h),m=data.data;
  for(const q of selected){const i=q*4;m[i]=0;m[i+1]=236;m[i+2]=145;m[i+3]=255}
  maskCtx.putImageData(data,0,0);render();$('photo-status').textContent='Zone verte ajoutée : '+selected.length+' pixels. Ajoutez d’autres zones si nécessaire.';
}
function applyKeepMask(){
  if(!loaded)return;const w=source.width,h=source.height,m=maskCtx.getImageData(0,0,w,h).data;
  let count=0;for(let i=3;i<m.length;i+=4)if(m[i])count++;
  if(count<20){$('photo-status').textContent='Peignez d’abord la zone à garder en vert.';return}
  snapshot();commitFilters();const out=document.createElement('canvas');out.width=w;out.height=h;const o=out.getContext('2d');o.drawImage(source,0,0);
  const feather=Number($('photo-mask-feather').value),soft=document.createElement('canvas');soft.width=w;soft.height=h;const sm=soft.getContext('2d');sm.filter=feather?`blur(${feather}px)`:'none';sm.drawImage(keepMask,0,0);o.globalCompositeOperation='destination-in';o.drawImage(soft,0,0);o.globalCompositeOperation='source-over';
  if($('photo-cutout-background').value==='white'){
    const white=document.createElement('canvas');white.width=w;white.height=h;const c=white.getContext('2d');c.fillStyle='#fff';c.fillRect(0,0,w,h);c.drawImage(out,0,0);source=white;
  }else source=out;
  sctx=source.getContext('2d',{willReadFrequently:true});resetMask();render();$('photo-status').textContent='Zone verte isolée. Annuler pour retrouver la photo.';
}
function roundFrame(bounds){
  if(!loaded){$('photo-status').textContent='Importez d’abord une image.';return}
  const center=bounds||{cx:source.width/2,cy:source.height/2,radius:Math.min(source.width,source.height)/2};
  const radius=Math.max(6,Math.floor(center.radius)),size=Math.min(Math.floor(radius*2),source.width,source.height);
  const sx=Math.max(0,Math.min(source.width-size,Math.round(center.cx-size/2)));
  const sy=Math.max(0,Math.min(source.height-size,Math.round(center.cy-size/2)));
  snapshot();commitFilters();const out=document.createElement('canvas');out.width=size;out.height=size;
  const o=out.getContext('2d');o.drawImage(source,sx,sy,size,size,0,0,size,size);
  const blur=Number($('photo-round-blur').value),mask=document.createElement('canvas');mask.width=size;mask.height=size;
  const m=mask.getContext('2d');m.fillStyle='#fff';m.filter=blur?`blur(${blur}px)`:'none';
  const inset=Math.max(1,blur*2+1);m.beginPath();m.arc(size/2,size/2,Math.max(1,size/2-inset),0,Math.PI*2);m.fill();
  o.globalCompositeOperation='destination-in';o.drawImage(mask,0,0);o.globalCompositeOperation='source-over';
  if(!blur){const border=Math.max(3,Math.round(size*.018));o.beginPath();o.arc(size/2,size/2,size/2-border/2,0,Math.PI*2);o.strokeStyle=$('photo-color').value;o.lineWidth=border;o.stroke()}
  source=out;sctx=source.getContext('2d',{willReadFrequently:true});selection=null;roundSelection=null;outline=[];resetMask();render();
  $('photo-status').textContent='Cadre rond créé · exportez en PNG pour garder la transparence. Annuler pour revenir.';
}
function ovalFrame(bounds){
  if(!loaded){$('photo-status').textContent='Importez d’abord une image.';return}
  const w=source.width,h=source.height,center=bounds||{cx:w/2,cy:h/2,rx:w/2,ry:h/2};
  const rx=Math.max(6,Math.floor(center.rx)),ry=Math.max(6,Math.floor(center.ry));
  const ow=Math.min(w,rx*2),oh=Math.min(h,ry*2),sx=Math.max(0,Math.min(w-ow,Math.round(center.cx-ow/2))),sy=Math.max(0,Math.min(h-oh,Math.round(center.cy-oh/2)));
  snapshot();commitFilters();const out=document.createElement('canvas');out.width=ow;out.height=oh;const o=out.getContext('2d');o.drawImage(source,sx,sy,ow,oh,0,0,ow,oh);
  const blur=Number($('photo-round-blur').value),mask=document.createElement('canvas');mask.width=ow;mask.height=oh;
  const m=mask.getContext('2d'),inset=Math.max(1,blur*2+1);m.fillStyle='#fff';m.filter=blur?`blur(${blur}px)`:'none';m.beginPath();m.ellipse(ow/2,oh/2,Math.max(1,ow/2-inset),Math.max(1,oh/2-inset),0,0,Math.PI*2);m.fill();
  o.globalCompositeOperation='destination-in';o.drawImage(mask,0,0);o.globalCompositeOperation='source-over';
  if(!blur){const border=Math.max(3,Math.round(Math.min(ow,oh)*.018));o.beginPath();o.ellipse(ow/2,oh/2,ow/2-border/2,oh/2-border/2,0,0,Math.PI*2);o.strokeStyle=$('photo-color').value;o.lineWidth=border;o.stroke()}
  source=out;sctx=source.getContext('2d',{willReadFrequently:true});selection=null;roundSelection=null;outline=[];resetMask();render();$('photo-status').textContent='Cadre ovale créé · exportez en PNG pour garder la transparence.';
}
function snapOutline(){
  if(!loaded||outline.length<3){$('photo-status').textContent='Tracez d’abord un contour autour du sujet.';return}
  const w=source.width,h=source.height,px=sctx.getImageData(0,0,w,h).data;
  const spacing=Math.max(3,Math.round(Math.max(w,h)/360)),radius=Number($('photo-snap-radius').value);
  const points=[];
  for(let i=0;i<outline.length;i++){
    const a=outline[i],b=outline[(i+1)%outline.length],length=Math.hypot(b.x-a.x,b.y-a.y);
    for(let j=0;j<Math.max(1,Math.ceil(length/spacing));j++){
      const t=j/Math.max(1,Math.ceil(length/spacing));points.push({x:a.x+(b.x-a.x)*t,y:a.y+(b.y-a.y)*t});
    }
  }
  if(points.length>1800){$('photo-status').textContent='Tracé trop long : recommencez avec un contour plus simple.';return}
  const color=(x,y)=>{x=Math.max(0,Math.min(w-1,Math.round(x)));y=Math.max(0,Math.min(h-1,Math.round(y)));const i=(y*w+x)*4;return [px[i],px[i+1],px[i+2]]};
  const edge=(x,y,nx,ny)=>{const a=color(x-nx*3,y-ny*3),b=color(x+nx*3,y+ny*3);return Math.hypot((a[0]-b[0])*.55,(a[1]-b[1])*.7,(a[2]-b[2])*.45)};
  let refined=points.map((p,i)=>{
    const prev=points[(i+points.length-2)%points.length],next=points[(i+2)%points.length],len=Math.hypot(next.x-prev.x,next.y-prev.y)||1;
    const nx=-(next.y-prev.y)/len,ny=(next.x-prev.x)/len;
    let best=p,score=24;
    for(let d=-radius;d<=radius;d+=2){const x=p.x+nx*d,y=p.y+ny*d;if(x<4||y<4||x>w-5||y>h-5)continue;
      const value=edge(x,y,nx,ny)-Math.abs(d)*.35;
      if(value>score){score=value;best={x,y}}
    }
    return best;
  });
  for(let pass=0;pass<2;pass++)refined=refined.map((p,i)=>{
    const before=refined[(i+refined.length-1)%refined.length],after=refined[(i+1)%refined.length];
    return {x:(before.x+p.x*3+after.x)/5,y:(before.y+p.y*3+after.y)/5};
  });
  outlineBeforeSnap=outline.map(p=>({...p}));outline=refined;render();$('photo-status').textContent='Contour ajusté aux contrastes proches. Vérifiez le tracé avant Isoler ; retracez si nécessaire.';
}
function applyOutline(){
  if(!loaded||outline.length<3){$('photo-status').textContent='Tracez d’abord le contour du sujet sur l’image Après.';return}
  snapshot();commitFilters();const mask=document.createElement('canvas');mask.width=source.width;mask.height=source.height;
  const m=mask.getContext('2d');m.fillStyle='#fff';m.beginPath();outline.forEach((p,i)=>i?m.lineTo(p.x,p.y):m.moveTo(p.x,p.y));m.closePath();m.fill();
  sctx.save();sctx.globalCompositeOperation='destination-in';sctx.drawImage(mask,0,0);sctx.restore();
  if($('photo-cutout-background').value==='white'){
    const out=document.createElement('canvas');out.width=source.width;out.height=source.height;const o=out.getContext('2d');o.fillStyle='#fff';o.fillRect(0,0,out.width,out.height);o.drawImage(source,0,0);source=out;sctx=source.getContext('2d',{willReadFrequently:true});
  }
  if($('photo-outline-glow').checked){sctx.save();sctx.beginPath();outline.forEach((p,i)=>i?sctx.lineTo(p.x,p.y):sctx.moveTo(p.x,p.y));sctx.closePath();sctx.strokeStyle='#d9f6ff';sctx.shadowColor='#7bd8ff';sctx.shadowBlur=Math.max(8,source.width/50);sctx.lineWidth=Math.max(3,source.width/180);sctx.stroke();sctx.restore()}outline=[];selection=null;render();$('photo-status').textContent='Sujet isolé. Vous pouvez annuler ou exporter le résultat.';
}
let personSegmenterPromise;
async function segmentPerson(){
  if(!loaded){$('photo-status').textContent='Importez d’abord une image.';return}
  const button=$('photo-ai-person');button.disabled=true;button.textContent='Détection en cours…';$('photo-ai-result').textContent='Chargement du modèle et analyse de la photo…';$('photo-status').textContent='Chargement du modèle IA et détection…';
  try{
    if(!personSegmenterPromise)personSegmenterPromise=(async()=>{
      const {ImageSegmenter,FilesetResolver}=await import('/ai/vision_bundle.mjs');
      const files=await FilesetResolver.forVisionTasks('/ai');
      return ImageSegmenter.createFromOptions(files,{baseOptions:{modelAssetPath:'/ai/selfie_segmenter.tflite',delegate:'CPU'},runningMode:'IMAGE',outputCategoryMask:true,outputConfidenceMasks:true});
    })();
    const segmenter=await personSegmenterPromise;
    // Le modèle travaille sur les pixels originaux ; aucun filtre ni recadrage supplémentaire.
    segmenter.segment(source,result=>{
      try{
        const confidence=result.confidenceMasks;
        // Certains modèles Selfie exposent un seul canal, d'autres un canal par classe.
        // Le masque catégoriel (classe 1 = personne) sert de repli vérifiable.
        const foreground=confidence?.length>=2?confidence[1]:confidence?.[0];
        const category=result.categoryMask;
        if(!foreground&&!category)throw Error('Le modèle ne renvoie aucun masque exploitable.');
        const mask=foreground||category,w=mask.width,h=mask.height;
        const values=foreground?.getAsFloat32Array(),classes=category?.getAsUint8Array();
        const small=document.createElement('canvas');small.width=w;small.height=h;
        const smallCtx=small.getContext('2d'),pixels=smallCtx.createImageData(w,h);
        let kept=0;
        for(let i=0;i<w*h;i++){
          let alpha=values?Math.max(0,Math.min(1,(values[i]-.18)/.64)):(classes[i]===1?1:0);
          const a=Math.round(alpha*255);if(a>128)kept++;
          pixels.data[i*4]=38;pixels.data[i*4+1]=220;pixels.data[i*4+2]=130;pixels.data[i*4+3]=a;
        }
        if(kept<Math.max(10,w*h*.005))throw Error('Masque IA presque vide (pixels conservés : '+kept+'/'+(w*h)+', canaux : '+(confidence?.length||0)+').');
        smallCtx.putImageData(pixels,0,0);
        saveMask();maskCtx.clearRect(0,0,keepMask.width,keepMask.height);
        maskCtx.imageSmoothingEnabled=true;maskCtx.drawImage(small,0,0,keepMask.width,keepMask.height);
        previewMode='result';$('photo-preview-mode').value='result';render();
        $('photo-ai-result').textContent='✓ Personne détectée. Le fond est supprimé dans Après. Pour retoucher : Peindre à garder ou Corriger masque.';
        $('photo-status').textContent='Détourage IA terminé. Corrigez si nécessaire, puis exportez le résultat.';
      }finally{result.close?.()}
    });
  }catch(error){personSegmenterPromise=null;$('photo-ai-result').textContent='Échec du détourage IA : '+error.message;$('photo-status').textContent='Échec du détourage IA : '+error.message;console.error('EBRA segmentation',error)}
  finally{button.disabled=false;button.textContent='✦ Détecter la personne (IA)'}
}
function removeBackground(){
  if(!loaded){$('photo-status').textContent='Importez d’abord une image.';return}
  snapshot();commitFilters();$('photo-status').textContent='Détourage en cours…';
  setTimeout(()=>{
    const w=source.width,h=source.height,data=sctx.getImageData(0,0,w,h),px=data.data,n=w*h;
    const sensitivity=Number($('photo-cutout-sensitivity').value),localLimit=22+sensitivity*.72,paletteLimit=36+sensitivity*1.45;
    const palette=[],step=Math.max(1,Math.floor(Math.min(w,h)/90));
    const add=(x,y)=>{const i=(y*w+x)*4;palette.push([px[i],px[i+1],px[i+2]])};
    for(let x=0;x<w;x+=step){add(x,0);if(h>2)add(x,Math.min(h-1,Math.floor(h*.035)))}
    for(let y=0;y<h;y+=step){add(0,y);add(w-1,y)}
    const bg=new Uint8Array(n),queue=new Int32Array(n);let head=0,tail=0;
    const seed=(x,y)=>{const p=y*w+x;if(!bg[p]){bg[p]=1;queue[tail++]=p}};
    for(let x=0;x<w;x+=Math.max(1,step>>1))seed(x,0);
    for(let y=0;y<h;y+=Math.max(1,step>>1)){seed(0,y);seed(w-1,y)}
    const colorDistance=(i,c)=>{const dr=px[i]-c[0],dg=px[i+1]-c[1],db=px[i+2]-c[2];return Math.sqrt(dr*dr*.3+dg*dg*.59+db*db*.11)};
    const nearPalette=i=>{for(let k=0;k<palette.length;k++)if(colorDistance(i,palette[k])<paletteLimit)return true;return false};
    const visit=(from,to)=>{if(to<0||to>=n||bg[to])return;const a=from*4,b=to*4,dr=px[a]-px[b],dg=px[a+1]-px[b+1],db=px[a+2]-px[b+2],d=Math.sqrt(dr*dr*.3+dg*dg*.59+db*db*.11);if(d<=localLimit&&nearPalette(b)){bg[to]=1;queue[tail++]=to}};
    while(head<tail){const p=queue[head++],x=p%w;visit(p,p-w);visit(p,p+w);if(x)visit(p,p-1);if(x<w-1)visit(p,p+1)}
    if(tail>n*.70){history.pop();$('photo-status').textContent='Détourage interrompu : trop de pixels seraient effacés. Essayez une sensibilité plus faible.';return}
    const white=$('photo-cutout-background').value==='white';
    for(let p=0;p<n;p++){if(!bg[p])continue;const i=p*4;if(white){px[i]=255;px[i+1]=255;px[i+2]=255;px[i+3]=255}else px[i+3]=0}
    sctx.putImageData(data,0,0);selection=null;render();$('photo-status').textContent='Détourage terminé · utilisez Annuler si vous souhaitez modifier la sensibilité.';
  },30)
}
setupBackgroundRemoval();
setTool('crop');
window.addEventListener('resize',()=>{if(loaded)fitCanvas()});
})();
