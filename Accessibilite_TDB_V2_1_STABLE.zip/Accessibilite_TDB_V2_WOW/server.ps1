﻿param([string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$Port=8787)
$ErrorActionPreference='Stop';$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path;$Data=Join-Path $AppDir 'data';New-Item -ItemType Directory -Force $Data|Out-Null
$Index=Join-Path $Data 'index.json';$Scan=Join-Path $Data 'scan.json';$Journal=Join-Path $Data 'journal.json';foreach($f in @($Index,$Journal)){if(!(Test-Path $f)){'[]'|Set-Content -Encoding UTF8 $f}}
$Allowed=@{'A TRAITER'=@('EN COURS');'EN COURS'=@('A TRAITER','TRAITES','NON CONFORME');'TRAITES'=@('A TRAITER');'NON CONFORME'=@('A TRAITER');'A PUBLIER'=@()}
function ReadJsonSafe($p,$fallback){
 for($i=0;$i -lt 5;$i++){
  try{if(!(Test-Path -LiteralPath $p)){return $fallback};$raw=[IO.File]::ReadAllText($p,[Text.Encoding]::UTF8);if([string]::IsNullOrWhiteSpace($raw)){return $fallback};return ($raw|ConvertFrom-Json)}catch{Start-Sleep -Milliseconds (40+($i*40))}
 }
 return $fallback
}
function ReadJ($p){$x=ReadJsonSafe $p @();if($null-eq$x){@()}else{@($x)}}
function Atomic($p,$o){
 $t=Join-Path (Split-Path -Parent $p) ((Split-Path -Leaf $p)+'.'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{[IO.File]::WriteAllText($t,($o|ConvertTo-Json -Depth 8),[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $t -Destination $p -Force}finally{if(Test-Path -LiteralPath $t){Remove-Item -LiteralPath $t -Force -ErrorAction SilentlyContinue}}
}
function NS($n){switch -Regex ($n.Trim().ToUpperInvariant()){'^A\s*TRAITER$'{'A TRAITER';break};'^EN\s*COURS$'{'EN COURS';break};'^TRAITE[S]?$'{'TRAITES';break};'^NON\s*CONFORME$'{'NON CONFORME';break};'^A\s*PUBLIER$'{'A PUBLIER';break};default{$null}}}
function Json($c,$o,$code=200){$b=[Text.Encoding]::UTF8.GetBytes(($o|ConvertTo-Json -Depth 8));$c.Response.StatusCode=$code;$c.Response.ContentType='application/json;charset=utf-8';$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function File($c,$p,$t){if(!(Test-Path $p)){$c.Response.StatusCode=404;$c.Response.Close();return};$b=[IO.File]::ReadAllBytes($p);$c.Response.ContentType=$t;$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Body($c){$r=New-Object IO.StreamReader($c.Request.InputStream,$c.Request.ContentEncoding);try{$r.ReadToEnd()|ConvertFrom-Json}finally{$r.Dispose()}}
function StatusDir($entity,$status){Get-ChildItem -LiteralPath (Join-Path $Root $entity) -Directory -ErrorAction Stop|Where-Object{(NS $_.Name)-eq$status}|Select-Object -First 1}
function MoveDoc($b){$e=[string]$b.entity;$from=[string]$b.from;$to=[string]$b.to;$rel=[string]$b.relativePath;if(!$Allowed.ContainsKey($from)-or $Allowed[$from]-notcontains$to){throw 'Transition interdite'};if($rel -match '(^|[\\/])\.\.([\\/]|$)'){throw 'Chemin invalide'}
 $fd=StatusDir $e $from;$td=StatusDir $e $to;if(!$fd-or!$td){throw 'Statut source/destination introuvable'};$src=Join-Path $fd.FullName $rel;$dst=Join-Path $td.FullName $rel;if(!(Test-Path -LiteralPath $src)){throw 'Dossier déjà déplacé ou introuvable'};if(Test-Path -LiteralPath $dst){throw 'La destination existe déjà'}
 $parent=Split-Path -Parent $dst;if(!(Test-Path -LiteralPath $parent)){New-Item -ItemType Directory -Force -Path $parent|Out-Null};Move-Item -LiteralPath $src -Destination $dst
 $j=ReadJ $Journal;$j=@($j)+@([pscustomobject]@{date=(Get-Date).ToString('o');entity=$e;document=(Split-Path -Leaf $rel);relativePath=$rel;from=$from;to=$to;source='INTERFACE'});if($j.Count-gt5000){$j=$j[($j.Count-5000)..($j.Count-1)]};Atomic $Journal $j;[pscustomobject]@{ok=$true;message='Mouvement effectué. Le scan va se synchroniser.'}}
$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Write-Host "TDB V2 : http://localhost:$Port" -ForegroundColor Green;Write-Host 'Serveur léger: le scan tourne dans un processus séparé.' -ForegroundColor Cyan
while($l.IsListening){$c=$l.GetContext();try{$p=$c.Request.Url.AbsolutePath;if($p-eq'/api/items'){Json $c ([pscustomobject]@{root=$Root;scan=(ReadJsonSafe $Scan $null);items=(ReadJ $Index)})}elseif($p-eq'/api/journal'){Json $c (ReadJ $Journal)}elseif($p-eq'/api/move'-and$c.Request.HttpMethod-eq'POST'){
 try{Json $c (MoveDoc (Body $c)) 200}catch{$m=$_.Exception.Message;$code=if($m -match 'déjà|destination existe|introuvable'){409}elseif($m -match 'interdite|invalide|source/destination'){400}else{500};Json $c ([pscustomobject]@{ok=$false;error=$m}) $code}
}elseif($p-eq'/'-or$p-eq'/index.html'){File $c (Join-Path $AppDir 'index.html') 'text/html;charset=utf-8'}elseif($p-eq'/style.css'){File $c (Join-Path $AppDir 'style.css') 'text/css;charset=utf-8'}elseif($p-eq'/app.js'){File $c (Join-Path $AppDir 'app.js') 'application/javascript;charset=utf-8'}else{$c.Response.StatusCode=404;$c.Response.Close()}}catch{try{Json $c ([pscustomobject]@{ok=$false;error=$_.Exception.Message}) 500}catch{try{$c.Response.Abort()}catch{}}}}
