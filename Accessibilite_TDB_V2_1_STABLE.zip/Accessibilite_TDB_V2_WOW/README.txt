ACCESSIBILITE TDB V2 WOW
========================
1. Extraire le ZIP dans un dossier local.
2. Double-cliquer START.bat.
3. Le scanner tourne dans une seconde fenêtre minimisée et écrit uniquement dans le dossier data LOCAL.
4. Le serveur web reste léger et disponible pendant les scans du DP.
5. Racine par défaut : \\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE

COMPTAGE
- Scan récursif jusqu'à 5 niveaux sous chaque dossier statut.
- Dès qu'un dossier contient au moins un fichier, ce dossier parent = 1 document métier.
- Ses fichiers sont comptés séparément uniquement dans la métrique FICHIERS.
- Une fois un dossier métier détecté, ses sous-dossiers ne sont pas rescannés pour éviter les doublons.

PERFORMANCE
- scanner.ps1 est séparé de server.ps1 : un scan réseau lent ne bloque plus l'interface.
- Le navigateur ne rescane jamais le DP : il lit un index JSON local.
- Scan par défaut toutes les 20 secondes, interface actualisée toutes les 3 secondes.

DP
- Les scans sont en lecture seule.
- Le DP n'est modifié que lorsqu'un déplacement est explicitement demandé dans l'interface.


V2.1: lecture JSON avec retries, publication atomique validée, HTTP 409 réservé aux vrais conflits de mouvement, erreurs serveur=500, reconnexion front silencieuse.
