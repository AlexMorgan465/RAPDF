﻿param([string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$IntervalSeconds=20,[int]$MaxDepth=5)
$ErrorActionPreference='Continue'; $AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path; $Data=Join-Path $AppDir 'data'; New-Item -ItemType Directory -Force $Data|Out-Null
$Index=Join-Path $Data 'index.json'; $Scan=Join-Path $Data 'scan.json'; $Stop=Join-Path $Data 'STOP'; if(Test-Path $Stop){Remove-Item $Stop -Force}
function Atomic($p,$o){
 $dir=Split-Path -Parent $p;$t=Join-Path $dir ((Split-Path -Leaf $p)+'.'+[guid]::NewGuid().ToString('N')+'.tmp')
 try{
  $json=$o|ConvertTo-Json -Depth 8
  [IO.File]::WriteAllText($t,$json,[Text.UTF8Encoding]::new($false))
  # Validate before publication: readers only ever see a complete JSON document.
  $null=[IO.File]::ReadAllText($t,[Text.Encoding]::UTF8)|ConvertFrom-Json
  Move-Item -LiteralPath $t -Destination $p -Force
 }finally{if(Test-Path -LiteralPath $t){Remove-Item -LiteralPath $t -Force -ErrorAction SilentlyContinue}}
}
function NS($n){switch -Regex ($n.Trim().ToUpperInvariant()){'^A\s*TRAITER$'{'A TRAITER';break};'^EN\s*COURS$'{'EN COURS';break};'^TRAITE[S]?$'{'TRAITES';break};'^NON\s*CONFORME$'{'NON CONFORME';break};'^A\s*PUBLIER$'{'A PUBLIER';break};default{$null}}}
function Rel($b,$f){$x=$b.TrimEnd('\')+'\';if($f.StartsWith($x,[StringComparison]::OrdinalIgnoreCase)){$f.Substring($x.Length)}else{Split-Path -Leaf $f}}
function ScanOnce{
 $start=Get-Date;$errs=0;$rows=New-Object Collections.ArrayList
 try{$ents=@(Get-ChildItem -LiteralPath $Root -Directory -ErrorAction Stop)}catch{$ents=@();$errs++}
 $status=@();foreach($e in $ents){try{foreach($d in @(Get-ChildItem -LiteralPath $e.FullName -Directory -ErrorAction Stop)){if(NS $d.Name){$status+=,[pscustomobject]@{E=$e;D=$d;S=(NS $d.Name)}}}}catch{$errs++}}
 $total=[math]::Max(1,$status.Count);$done=0;Atomic $Scan ([pscustomobject]@{running=$true;percent=0;entitiesTotal=$ents.Count;entitiesScanned=0;statusFoldersTotal=$status.Count;statusFoldersScanned=0;documents=0;filesFound=0;directoriesVisited=0;errors=$errs;startedAt=$start.ToString('o');completedAt=$null})
 $entDone=@{}
 foreach($st in $status){
  $stack=New-Object Collections.Stack;$stack.Push([pscustomobject]@{D=$st.D;Depth=0})
  while($stack.Count){$n=$stack.Pop();$dir=$n.D;$depth=[int]$n.Depth
   try{$files=@(Get-ChildItem -LiteralPath $dir.FullName -File -Force -ErrorAction Stop)}catch{$files=@();$errs++}
   if($depth -gt 0 -and $files.Count -gt 0){
    $latest=($files|Sort-Object LastWriteTime -Descending|Select-Object -First 1).LastWriteTime;$rel=Rel $st.D.FullName $dir.FullName
    [void]$rows.Add([pscustomobject]@{id=[guid]::NewGuid().ToString();entity=$st.E.Name;status=$st.S;name=$dir.Name;relativePath=$rel;fileCount=$files.Count;depth=$depth;modified=$latest.ToString('o');depositDate=$latest.ToString('o')});continue
   }
   if($depth -lt $MaxDepth){try{$subs=@(Get-ChildItem -LiteralPath $dir.FullName -Directory -Force -ErrorAction Stop);foreach($sub in $subs){$stack.Push([pscustomobject]@{D=$sub;Depth=$depth+1})}}catch{$errs++}}
  }
  $done++;$entDone[$st.E.Name]=$true;$pct=[math]::Round($done/$total*100);Atomic $Scan ([pscustomobject]@{running=$true;percent=$pct;entitiesTotal=$ents.Count;entitiesScanned=$entDone.Count;statusFoldersTotal=$status.Count;statusFoldersScanned=$done;documents=$rows.Count;filesFound=(@($rows|Measure-Object fileCount -Sum).Sum);directoriesVisited=$null;errors=$errs;startedAt=$start.ToString('o');completedAt=$null})
 }
 Atomic $Index @($rows.ToArray());$end=Get-Date;Atomic $Scan ([pscustomobject]@{running=$false;percent=100;entitiesTotal=$ents.Count;entitiesScanned=$ents.Count;statusFoldersTotal=$status.Count;statusFoldersScanned=$status.Count;documents=$rows.Count;filesFound=(@($rows|Measure-Object fileCount -Sum).Sum);errors=$errs;durationMs=[math]::Round(($end-$start).TotalMilliseconds);startedAt=$start.ToString('o');completedAt=$end.ToString('o')})
}
while(!(Test-Path $Stop)){ScanOnce;for($i=0;$i -lt $IntervalSeconds;$i++){if(Test-Path $Stop){break};Start-Sleep 1}}
