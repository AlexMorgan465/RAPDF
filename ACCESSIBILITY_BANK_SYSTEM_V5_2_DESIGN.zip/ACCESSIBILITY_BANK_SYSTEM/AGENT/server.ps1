﻿param([int]$Port=8788,[string]$RootPath="\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE",[string]$DataPath=(Join-Path (Split-Path $PSScriptRoot -Parent) 'DATA'))
$ErrorActionPreference='Stop'
$ConfigFile=Join-Path (Split-Path $PSScriptRoot -Parent) 'CONFIG.ps1'
if(Test-Path -LiteralPath $ConfigFile){. $ConfigFile}
$Role='AGENT'
. (Join-Path (Split-Path $PSScriptRoot -Parent) 'common.ps1')

$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Start-Process "http://localhost:$Port/"
try{$run=$true;while($run){$c=$l.GetContext();try{$r=$c.Request;$p=$r.Url.AbsolutePath
 if($p-eq'/'){$f=Join-Path $PSScriptRoot 'index.html';$bytes=[IO.File]::ReadAllBytes($f);$c.Response.ContentType='text/html; charset=utf-8';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue}
 if($p-eq'/api/ping'){Send $c 200 @{ok=$true;exists=[IO.Directory]::Exists($RootPath);agent=(Agent)};continue}
 if($p-eq'/api/schema'){$x=@();foreach($e in $Schema.Keys){$x+=@{entity=$e;mode=$Schema[$e].Mode;branches=@($Schema[$e].Branches)}};Send $c 200 @{entities=$x};continue}
 if($p-eq'/api/counts'){Send $c 200 (Counts);continue}
 if($p-eq'/api/documents'){Send $c 200 (Documents);continue}
 if($p-eq'/api/history'){Send $c 200 @{agent=(Agent);history=@(ReadHistory)};continue}
 if($p-eq'/api/fullscan' -and $r.HttpMethod-eq'POST'){Send $c 200 (FullScan);continue}
 if($p-eq'/api/items'){$q=Q $r;Send $c 200 (Items $q.entity $q.status $q.branch);continue}
 if($p-eq'/api/document' -and $r.HttpMethod-eq'POST'){Send $c 200 (UpdateDoc (Body $r));continue}
 if($p-eq'/api/move' -and $r.HttpMethod-eq'POST'){Send $c 200 (MoveOne (Body $r));continue}
 if($p-eq'/api/leave' -and $r.HttpMethod-eq'POST'){Send $c 200 @{ok=$true};$run=$false;continue}
 Send $c 404 @{error='Route inconnue'}
 }catch{try{Send $c 500 @{error=$_.Exception.Message}}catch{}}}}finally{$l.Stop();$l.Close()}
