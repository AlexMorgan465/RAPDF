@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0SELF_TEST.ps1"
pause
