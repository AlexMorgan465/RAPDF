@echo off
setlocal
set /p "TARGET=Chemin du dossier ACCESSIBILITY_BANK_SYSTEM existant : "
if not exist "%TARGET%\AGENT\index.html" goto invalid
if not exist "%TARGET%\MANAGER\index.html" goto invalid
echo Cette mise a jour remplace uniquement les deux interfaces HTML.
echo Fermez les pages ouvertes avant de continuer.
pause
copy /y "%TARGET%\AGENT\index.html" "%TARGET%\AGENT\index.avant_design.html" >nul
if errorlevel 1 goto fail
copy /y "%TARGET%\MANAGER\index.html" "%TARGET%\MANAGER\index.avant_design.html" >nul
if errorlevel 1 goto fail
copy /y "%~dp0AGENT\index.html" "%TARGET%\AGENT\index.html" >nul
if errorlevel 1 goto fail
copy /y "%~dp0MANAGER\index.html" "%TARGET%\MANAGER\index.html" >nul
if errorlevel 1 goto fail
echo Design installe. Serveurs, CONFIG.ps1 et DATA inchanges.
echo Rouvrez les interfaces puis faites Ctrl+F5.
pause
exit /b 0
:invalid
echo Dossier invalide. Indiquez le dossier qui contient AGENT et MANAGER.
pause
exit /b 1
:fail
echo Echec de copie. Les pages precedentes sont sauvegardees en index.avant_design.html.
pause
exit /b 1
