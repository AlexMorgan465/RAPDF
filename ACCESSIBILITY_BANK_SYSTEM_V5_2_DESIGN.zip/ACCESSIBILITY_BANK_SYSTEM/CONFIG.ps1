﻿# Facultatif : même chemin DATA pour tous les agents et le manager.
# Le dossier DATA doit être HORS du DP documentaire ACCESSIBILITE.
# Exemple à adapter, puis décommenter :
# $DataPath="\\serveur\partage-applications\ACCESSIBILITY_BANK_SYSTEM\DATA"
# Le chemin documentaire RootPath et la sélection portefeuille sont conservés.
