param([Parameter(Mandatory)][string]$EntityEncoded)
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $base 'store.ps1')
$entity=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($EntityEncoded))
Safe-Part $entity | Out-Null
$indexDir=Join-Path $script:sharedData 'entities';[void][IO.Directory]::CreateDirectory($indexDir)
$key=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($entity)))
$index=Join-Path $indexDir ($key+'.json');$mutex=Join-Path $indexDir ($key+'.lock')
try{$lease=[IO.FileStream]::new($mutex,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch [IO.IOException]{exit 0}
# Every entity has its own process. Exclusive handles coordinate the number
# of directory enumerations across the Accessibilite Windows sessions.
function Acquire-ScanSlot {
 $limit=[math]::Min(11,[math]::Max(1,[int]$script:cfg.maxParallelScans))
 while($true){
  foreach($slotNumber in 1..$limit){
   $slotPath=Join-Path $indexDir ("scan-slot-$slotNumber.lock")
   try { return [IO.FileStream]::new($slotPath,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None) }
   catch [IO.IOException] { }
  }
  Start-Sleep -Milliseconds 400
 }
}
try{
 while($true){
  $scanSignal=if(Test-Path -LiteralPath $script:refreshFile){[IO.File]::ReadAllText($script:refreshFile)}else{''}
  try{
   $scanSlot=$null
   $scanSlot=Acquire-ScanSlot
   try {
    # The timestamp is taken after waiting: a take/finish while queued must
    # still be protected from an older snapshot in Merge-Scan.
    $scanStarted=(Get-Date).ToString('o')
    $items=@(& (Join-Path $base 'scan-entity.ps1') -Root ([string]$script:cfg.sharedRoot) -Entity $entity -IncludeTreated $false)
   }finally{if($scanSlot){$scanSlot.Dispose()}}
   $snapshot=@{entity=$entity;scanStarted=$scanStarted;updated=(Get-Date).ToString('o');items=$items}
   $tmp=$index+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
   [IO.File]::WriteAllText($tmp,(ConvertTo-Json -InputObject $snapshot -Depth 10 -Compress),[Text.UTF8Encoding]::new($false))
   [IO.File]::Move($tmp,$index,$true)
   & (Join-Path $base 'merge-index.ps1') -EntityEncoded $EntityEncoded
  }catch{
   $errorPath=Join-Path $indexDir ($key+'.error.txt')
   [IO.File]::WriteAllText($errorPath,((Get-Date).ToString('o')+' '+$_.Exception.Message),[Text.UTF8Encoding]::new($false))
  }
  $signal=if(Test-Path -LiteralPath $script:refreshFile){[IO.File]::ReadAllText($script:refreshFile)}else{''}
  if($signal -ne $scanSignal){continue}
  $until=(Get-Date).AddSeconds([math]::Max(15,[int]$script:cfg.reconcileSeconds))
  while((Get-Date) -lt $until){
   Start-Sleep -Seconds 2
   $next=if(Test-Path -LiteralPath $script:refreshFile){[IO.File]::ReadAllText($script:refreshFile)}else{''}
   if($next -ne $signal){break}
  }
 }
}finally{$lease.Dispose()}
