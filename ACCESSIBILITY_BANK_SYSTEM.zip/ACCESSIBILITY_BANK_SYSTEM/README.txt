ACCESSIBILITY BANK SYSTEM
AGENT: serveur indépendant http://localhost:8788
MANAGER: serveur indépendant http://localhost:8790

Historique partagé:
\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE\.accessibility_history\operations.jsonl

DMT:
Départ = prise en charge A TRAITER -> EN COURS.
Fin = EN COURS -> TRAITES ou NON CONFORME.
Le manager consolide les DMT par agent.

Les deux interfaces utilisent le même design bancaire, sans thème orbital.
