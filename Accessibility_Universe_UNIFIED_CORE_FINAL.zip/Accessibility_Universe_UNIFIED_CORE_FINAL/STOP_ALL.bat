@echo off
powershell -NoProfile -ExecutionPolicy Bypass -Command "$ports=8787,8788; foreach($p in $ports){Get-NetTCPConnection -LocalPort $p -State Listen -ErrorAction SilentlyContinue|ForEach-Object{Stop-Process -Id $_.OwningProcess -Force -ErrorAction SilentlyContinue}}"
exit
