@echo off
cd /d "%~dp0"
if not exist data mkdir data
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -WindowStyle Hidden -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%~dp0command_server.ps1""'"
powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process powershell.exe -WindowStyle Hidden -ArgumentList '-NoProfile -ExecutionPolicy Bypass -File ""%~dp0agent_server.ps1""'"
timeout /t 2 /nobreak >nul
start "" http://localhost:8787/
start "" http://localhost:8788/agent.html
exit
