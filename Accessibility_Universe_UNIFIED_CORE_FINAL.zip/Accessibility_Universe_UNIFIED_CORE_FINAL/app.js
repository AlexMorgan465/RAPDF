const REF={'A TRAITER':96,'EN COURS':2,'TRAITES':609,'NON CONFORME':16,'A PUBLIER':91}, COLORS={'A TRAITER':'#55e7ff','EN COURS':'#ffc766','TRAITES':'#55f5b2','NON CONFORME':'#ff6b89','A PUBLIER':'#9b7cff'};let items=[],diag=[],journal=[],scan=null;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)], esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
async function get(u){let r=await fetch(u,{cache:'no-store'});if(!r.ok)throw Error(u+' HTTP '+r.status);return r.json()}
async function safeGet(u,fallback){try{return await get(u)}catch(e){console.warn('API secondaire indisponible',u,e);return fallback}}
async function load(){
  try{
    // Les documents sont la source principale: l'UI s'affiche même si diagnostic/journal est absent.
    const a=await get('/api/items');
    items=Array.isArray(a.items)?a.items:[]; scan=a.scan||null;
    const extras=await Promise.all([safeGet('/api/diagnostic',[]),safeGet('/api/journal',[])]);
    diag=Array.isArray(extras[0])?extras[0]:[]; journal=Array.isArray(extras[1])?extras[1]:[];
    $('#live').textContent='● LIVE'; render(); renderUniverse();
  }catch(e){
    console.error(e); $('#live').textContent='● API OFFLINE';
    const m=$('#scanMeta'); if(m)m.textContent='Serveur joignable mais /api/items est indisponible : '+e.message;
    setTimeout(load,1800)
  }
}
function counts(list=items){let o={};Object.keys(REF).forEach(k=>o[k]=0);list.forEach(x=>o[x.status]=(o[x.status]||0)+1);return o} function fmt(d){if(!d)return'—';return new Date(d).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})}
function render(){let c=counts();$('#total').textContent=items.length.toLocaleString('fr-FR');let p=scan?.percent||0;$('#fetchBar').style.width=p+'%';$('#fetchText').textContent=`${p}% • ${scan?.entitiesScanned||0}/${scan?.entitiesTotal||0} entités • ${scan?.statusFoldersScanned||0}/${scan?.statusFoldersTotal||0} zones statut`;$('#health').textContent=(scan?.errors||0)?'ALERTE':'ONLINE';$('#scanMeta').textContent=`${scan?.filesFound||0} fichiers • ${scan?.directoriesVisited||0} dossiers • ${scan?.errors||0} erreur(s) • ${scan?.phase||'EN ATTENTE'}${scan?.currentEntity?' • '+scan.currentEntity:''}${scan?.currentStatus?' / '+scan.currentStatus:''}${scan?.currentPath?' • '+scan.currentPath:''}`;
 $('#kpis').innerHTML=Object.keys(REF).map(s=>`<div class="kpi" style="--c:${COLORS[s]}" onclick="openStatus('${s}')"><b>${c[s]||0}</b><span>${s}</span></div>`).join(''); fillSelects();drawEntity();drawDonut(c);recent();docs();concordance(c);diagnostics();journals()}
function fillSelects(){let es=[...new Set(items.map(x=>x.entity))].sort(),ss=Object.keys(REF);[['#entityFilter',es],['#statusFilter',ss],['#chartStatus',ss]].forEach(([id,a])=>{let el=$(id),v=el.value,first=id=='#entityFilter'?'Toutes entités':id=='#chartStatus'?'Tous statuts':'Tous statuts',fv='ALL';el.innerHTML=`<option value="${fv}">${first}</option>`+a.map(x=>`<option>${esc(x)}</option>`).join('');el.value=a.includes(v)?v:'ALL'})}
function canvas(id){let el=$(id),d=devicePixelRatio||1,w=el.clientWidth,h=el.clientHeight;el.width=w*d;el.height=h*d;let x=el.getContext('2d');x.scale(d,d);return{x,w,h}}
function drawEntity(){let{x,w,h}=canvas('#entityChart'),st=$('#chartStatus').value||'ALL',map={};items.filter(i=>st==='ALL'||i.status===st).forEach(i=>map[i.entity]=(map[i.entity]||0)+1);let a=Object.entries(map).sort((a,b)=>b[1]-a[1]),max=Math.max(1,...a.map(x=>x[1])),pad=35,bw=(w-pad*2)/Math.max(1,a.length);x.font='10px Segoe UI';a.forEach(([n,v],i)=>{let bh=(h-70)*v/max,xx=pad+i*bw+8,yy=h-35-bh;x.fillStyle='rgba(85,231,255,.18)';x.fillRect(xx,yy,Math.max(10,bw-16),bh);x.fillStyle='#55e7ff';x.fillRect(xx,yy,Math.max(10,bw-16),2);x.fillStyle=getComputedStyle(document.body).getPropertyValue('--muted');x.save();x.translate(xx+bw/2-8,h-25);x.rotate(-.55);x.fillText(n.slice(0,15),0,0);x.restore();x.fillText(v,xx,yy-7)})}
function drawDonut(c){let{x,w,h}=canvas('#donut'),vals=Object.entries(c).filter(x=>x[1]>0),sum=vals.reduce((s,x)=>s+x[1],0)||1,cx=w/2,cy=h/2,r=Math.min(w,h)*.31,a=-Math.PI/2;vals.forEach(([s,v])=>{let z=Math.PI*2*v/sum;x.beginPath();x.strokeStyle=COLORS[s];x.lineWidth=24;x.arc(cx,cy,r,a,a+z);x.stroke();a+=z});x.fillStyle=getComputedStyle(document.body).getPropertyValue('--text');x.font='bold 28px Segoe UI';x.textAlign='center';x.fillText(sum,cx,cy+7);$('#legend').innerHTML=vals.map(([s,v])=>`<span><i style="background:${COLORS[s]}"></i>${s} ${v}</span>`).join('')}
function rows(list,limit){return `<table><thead><tr><th>ENTITÉ</th><th>DOCUMENT</th><th>STATUT</th><th>DÉPÔT / MODIF.</th><th>FICHIERS</th><th>ACTION</th></tr></thead><tbody>${list.slice(0,limit||99999).map(i=>`<tr><td>${esc(i.entity)}</td><td><b>${esc(i.name)}</b><br><small>${esc(i.relativePath)}</small></td><td><span class="badge">${esc(i.status)}</span></td><td>${fmt(i.depositDate)}</td><td>${i.fileCount}</td><td>${actions(i)}</td></tr>`).join('')}</tbody></table>`}
function actions(i){let a={'A TRAITER':['EN COURS'],'EN COURS':['A TRAITER','TRAITES','NON CONFORME'],'TRAITES':['A TRAITER'],'NON CONFORME':['A TRAITER'],'A PUBLIER':['A TRAITER']}[i.status]||[];return a.map(t=>`<button class="action" onclick='move(${JSON.stringify(i.id)},${JSON.stringify(t)})'>→ ${t}</button>`).join(' ')}
function recent(){$('#recent').innerHTML=rows([...items].sort((a,b)=>new Date(b.modified)-new Date(a.modified)),8)} function docs(){let q=($('#search')?.value||'').toLowerCase(),e=$('#entityFilter')?.value||'ALL',s=$('#statusFilter')?.value||'ALL',a=items.filter(i=>(e==='ALL'||i.entity===e)&&(s==='ALL'||i.status===s)&&(!q||(i.name+' '+i.relativePath+' '+i.entity).toLowerCase().includes(q)));$('#docTable').innerHTML=rows(a)}
function concordance(c){let total=Object.values(REF).reduce((a,b)=>a+b,0);$('#concordance').innerHTML=Object.keys(REF).map(s=>{let d=(c[s]||0)-REF[s];return`<div class="kpi" style="--c:${COLORS[s]}"><b>${c[s]||0} / ${REF[s]}</b><span>${s}</span><small class="delta ${d===0?'ok':'bad'}">Δ ${d>0?'+':''}${d}</small></div>`}).join('')+`<div class="kpi"><b>${items.length} / ${total}</b><span>TOTAL</span><small class="delta ${items.length===total?'ok':'bad'}">Δ ${items.length-total}</small></div>`}
function diagnostics(){$('#diagTable').innerHTML=`<table><thead><tr><th>ENTITÉ</th><th>ZONE STATUT</th><th>RACINE</th><th>DOCS</th><th>FICHIERS</th><th>DOSSIERS SCANNÉS</th><th>BRANCHES VIDES</th></tr></thead><tbody>${diag.map(d=>`<tr><td>${esc(d.entity)}</td><td>${esc(d.status)}</td><td>${esc(d.statusRoot)}</td><td><b>${d.documents}</b></td><td>${d.files}</td><td>${d.directories}</td><td>${d.emptyBranches}</td></tr>`).join('')}</tbody></table>`} function journals(){$('#journalTable').innerHTML=`<table><thead><tr><th>DATE</th><th>ENTITÉ</th><th>DOCUMENT</th><th>DE</th><th>VERS</th><th>SOURCE</th></tr></thead><tbody>${[...journal].reverse().map(j=>`<tr><td>${fmt(j.date)}</td><td>${esc(j.entity)}</td><td>${esc(j.document)}</td><td>${esc(j.from)}</td><td>${esc(j.to)}</td><td>${esc(j.source)}</td></tr>`).join('')}</tbody></table>`}
function renderUniverse(){
 const root=$('#universe'); if(!root)return; root.innerHTML='';
 const entities=[...new Set(items.map(x=>x.entity))].sort();
 const W=root.clientWidth||1000,H=root.clientHeight||500,cx=W/2,cy=H/2;
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg'); svg.setAttribute('viewBox',`0 0 ${W} ${H}`); svg.classList.add('space-svg'); root.appendChild(svg);
 const defs=document.createElementNS(svg.namespaceURI,'defs'); defs.innerHTML='<filter id="glow"><feGaussianBlur stdDeviation="3" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>';svg.appendChild(defs);
 const g=document.createElementNS(svg.namespaceURI,'g');svg.appendChild(g);
 const core=document.createElementNS(svg.namespaceURI,'circle');core.setAttribute('cx',cx);core.setAttribute('cy',cy);core.setAttribute('r',42);core.setAttribute('class','sun');g.appendChild(core);
 const label=document.createElementNS(svg.namespaceURI,'text');label.setAttribute('x',cx);label.setAttribute('y',cy+5);label.setAttribute('class','sun-label');label.textContent='ACCESS';g.appendChild(label);
 entities.forEach((name,i)=>{const ang=-Math.PI/2+i*Math.PI*2/Math.max(1,entities.length),r=Math.min(W,H)*(.28+(i%2)*.08),x=cx+Math.cos(ang)*r,y=cy+Math.sin(ang)*r,n=items.filter(v=>v.entity===name).length;
   const orbit=document.createElementNS(svg.namespaceURI,'line');orbit.setAttribute('x1',cx);orbit.setAttribute('y1',cy);orbit.setAttribute('x2',x);orbit.setAttribute('y2',y);orbit.setAttribute('class','orbit-line');g.appendChild(orbit);
   const node=document.createElementNS(svg.namespaceURI,'g');node.setAttribute('class','planet');node.style.cursor='pointer';node.onclick=()=>{show('documents');$('#entityFilter').value=name;docs()};
   const c=document.createElementNS(svg.namespaceURI,'circle');c.setAttribute('cx',x);c.setAttribute('cy',y);c.setAttribute('r',Math.max(12,Math.min(27,12+Math.sqrt(n)*1.5)));node.appendChild(c);
   const t=document.createElementNS(svg.namespaceURI,'text');t.setAttribute('x',x);t.setAttribute('y',y+4);t.setAttribute('class','planet-count');t.textContent=n;node.appendChild(t);
   const nm=document.createElementNS(svg.namespaceURI,'text');nm.setAttribute('x',x);nm.setAttribute('y',y+38);nm.setAttribute('class','planet-name');nm.textContent=name;node.appendChild(nm);g.appendChild(node);
 });
} 
async function move(id,to){if(!confirm(`Déplacer vers ${to} ?`))return;let r=await fetch('/api/move',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id,to})}),j=await r.json();toast(j.ok?'Mouvement effectué':j.error);setTimeout(load,800)} function toast(t){let e=$('#toast');e.textContent=t;e.style.display='block';setTimeout(()=>e.style.display='none',3500)} function openStatus(s){show('documents');$('#statusFilter').value=s;docs()} function show(v){$$('.view').forEach(x=>x.classList.toggle('active',x.id===v));$$('nav button').forEach(x=>x.classList.toggle('active',x.dataset.view===v));if(v==='overview')setTimeout(()=>{drawEntity();drawDonut(counts());renderUniverse()},20)}
$$('nav button').forEach(b=>b.onclick=()=>show(b.dataset.view));$$('[data-goto]').forEach(b=>b.onclick=()=>show(b.dataset.goto));['search','entityFilter','statusFilter'].forEach(id=>$('#'+id).addEventListener(id==='search'?'input':'change',docs));$('#chartStatus').onchange=drawEntity;$('#theme').onclick=()=>{document.body.classList.toggle('light');setTimeout(()=>{drawEntity();drawDonut(counts());renderUniverse()},20)};window.addEventListener('resize',()=>{if($('#overview').classList.contains('active')){drawEntity();drawDonut(counts());renderUniverse()}});load();setInterval(load,5000);

// --- MANUAL SCAN CONTROL ---
let pendingTimer=null;
async function postJson(url){let r=await fetch(url,{method:'POST'});let j=await r.json();if(!r.ok)throw Error(j.error||url+' HTTP '+r.status);return j}
async function refreshPending(){
  try{
    const p=await get('/api/scan/pending'), s=p.scan||{}, box=document.querySelector('#manualScanState'), apply=document.querySelector('#applyScanBtn');
    if(!box)return;
    const oldCount=items.length, newCount=Array.isArray(p.items)?p.items.length:0;
    box.innerHTML=`<b>${s.running?'SCAN EN COURS':'SCAN MANUEL'}</b> • ${s.percent||0}% • ${s.currentEntity||''} ${s.currentStatus?'/ '+s.currentStatus:''}<br><small>${s.currentPath||''}</small><br>${s.documents||newCount} détectés • ${s.filesFound||0} fichiers • ${s.directoriesVisited||0} dossiers parcourus${!s.running&&newCount?`<br><b>Index actuel ${oldCount} → Nouveau ${newCount} (${newCount-oldCount>=0?'+':''}${newCount-oldCount})</b>`:''}`;
    if(apply)apply.style.display=(!s.running&&newCount>0)?'inline-flex':'none';
    if(s.running){clearTimeout(pendingTimer);pendingTimer=setTimeout(refreshPending,1000)}
  }catch(e){console.warn(e)}
}
document.addEventListener('DOMContentLoaded',()=>{
  const b=document.querySelector('#manualScanBtn'), a=document.querySelector('#applyScanBtn');
  if(b)b.addEventListener('click',async()=>{try{let j=await postJson('/api/scan/start');toast(j.message||'Scan lancé');refreshPending()}catch(e){toast(e.message)}});
  if(a)a.addEventListener('click',async()=>{if(!confirm('Appliquer le nouvel index ?'))return;try{let j=await postJson('/api/scan/apply');toast(`Nouvel index appliqué : ${j.documents} documents`);a.style.display='none';await load()}catch(e){toast(e.message)}});
  refreshPending();
});
