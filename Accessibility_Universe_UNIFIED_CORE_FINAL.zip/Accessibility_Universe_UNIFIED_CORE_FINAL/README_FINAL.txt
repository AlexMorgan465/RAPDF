ACCESSIBILITY UNIVERSE — UNIFIED CORE FINAL

1. Lance START_UNIVERSE.bat
2. Command Center : http://localhost:8787
3. Agent Orbit    : http://localhost:8788/agent.html

SOURCE UNIQUE : data/index.json
- Command Center et Agent Orbit lisent le MEME index.
- Agent Orbit ne fait plus son propre scan global.
- Le scan global est MANUEL uniquement depuis le Command Center.
- Pendant un nouveau scan, l'ancien index reste actif.
- Apres validation du scan, les deux interfaces lisent les nouveaux nombres.
- Les operations Agent mettent a jour le DP + index central + journal.
- Reconstruction de chemin Agent charge uniquement la branche demandee.

REGLE DE COMPTAGE : un dossier contenant au moins un fichier = un document metier. Le scan continue dans les sous-dossiers pour ne pas rater les niveaux imbriques.
OLD et _APPLICATION_ACCESSIBILITE sont exclus.
