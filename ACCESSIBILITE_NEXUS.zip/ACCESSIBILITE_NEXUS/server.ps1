﻿$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg=[IO.File]::ReadAllText((Join-Path $base 'config.json'),[Text.Encoding]::UTF8) | ConvertFrom-Json
$share=[string]$cfg.sharedRoot; $history=[string]$cfg.historyRoot
$db=Join-Path $base 'data\tasks.json'; $events=Join-Path $base 'data\events.json'
$staging=Join-Path $base 'data\staging'; New-Item -ItemType Directory -Force -Path $staging | Out-Null
if(!(Test-Path -LiteralPath $db)){[IO.File]::WriteAllText($db,'[]',[Text.UTF8Encoding]::new($false))}
if(!(Test-Path -LiteralPath $events)){[IO.File]::WriteAllText($events,'[]',[Text.UTF8Encoding]::new($false))}
$script:tasks=@(Get-Content -LiteralPath $db -Raw | ConvertFrom-Json)
$script:eventList=@(Get-Content -LiteralPath $events -Raw | ConvertFrom-Json)
$script:uploads=@{}; $script:lastScan=[datetime]::MinValue
function SaveJson($path,$value){$json=ConvertTo-Json -InputObject @($value) -Depth 12 -Compress;$tmp=$path+'.tmp';[IO.File]::WriteAllText($tmp,$json,[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $tmp -Destination $path -Force}
function SaveState{SaveJson $db $script:tasks;SaveJson $events $script:eventList}
function Event($task,$kind,$agent,$detail){$script:eventList+= [pscustomobject]@{id=[guid]::NewGuid().ToString();taskId=$task.id;at=(Get-Date).ToString('o');kind=$kind;agent=$agent;detail=$detail}}
function Status($name){switch -Regex ($name.Trim().ToUpperInvariant()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function Stem($name){[IO.Path]::GetFileNameWithoutExtension($name)}
function TaskKey($entity,$prefix,$branch,$stem){($entity+'|'+$prefix+'|'+$branch+'|'+$stem).ToUpperInvariant()}
function FindTask($id){@($script:tasks | Where-Object id -eq $id | Select-Object -First 1)[0]}
function SafeName($name){if([string]::IsNullOrWhiteSpace($name)-or $name -in @('.','..') -or $name.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $name.Contains('/') -or $name.Contains('\')){throw 'Nom de fichier ou dossier invalide.'};return $name}
function EnsureUnder($root,$relative){
  $full=[IO.Path]::GetFullPath((Join-Path $root $relative));$parent=[IO.Path]::GetFullPath($root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
  if(!$full.StartsWith($parent,[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin hors du dossier autorisé.'};return $full
}
function GroupPaths($x){
  $p=Join-Path $share $x.entity
  if($x.prefix){$p=Join-Path $p $x.prefix}
  return $p
}
function Destination($x,$status){
  $p=Join-Path (GroupPaths $x) $status
  if($x.branch){$p=Join-Path $p $x.branch}
  New-Item -ItemType Directory -Force -Path $p | Out-Null
  return $p
}
function Register($entity,$prefix,$status,$statusDir,$path,$isFolder){
  $rel=[IO.Path]::GetDirectoryName($path.Substring($statusDir.Length).TrimStart('\','/'))
  if($null -eq $rel -or $rel -eq '.'){ $rel='' }
  $name=[IO.Path]::GetFileName($path);$stem=if($isFolder){$name}else{Stem $name}
  $key=TaskKey $entity $prefix $rel $stem
  $old=@($script:tasks | Where-Object key -eq $key | Select-Object -Last 1)[0]
  if($old){return}
  $now=(Get-Date).ToString('o')
  $task=[pscustomobject]@{id=[guid]::NewGuid().ToString();key=$key;entity=$entity;prefix=$prefix;branch=$rel;name=$name;stem=$stem;status=$status;agent='';sourcePath=$path;currentPath=$path;resultPath='';historyPath='';createdAt=$now;startedAt=$null;finishedAt=$null;reworkedAt=$null;comment='';solution='';cleanupWarning=''}
  $script:tasks += $task
  Event $task 'DECOUVERTE' '' $path
}
function Scan{
  if(!(Test-Path -LiteralPath $share -PathType Container)){throw "Racine DP introuvable : $share"}
  foreach($entityDir in @(Get-ChildItem -LiteralPath $share -Directory -ErrorAction Stop)){
    $todo=New-Object System.Collections.Queue;$todo.Enqueue($entityDir)
    while($todo.Count){$d=$todo.Dequeue()
      foreach($child in @(Get-ChildItem -LiteralPath $d.FullName -Directory -ErrorAction Stop)){
        if($child.Name.Trim().ToUpperInvariant() -eq 'A PUBLIER'){continue}
        $status=Status $child.Name
        if(!$status){$todo.Enqueue($child);continue}
        $prefix=$d.FullName.Substring($entityDir.FullName.Length).TrimStart('\','/')
        if($status -in @('A_TRAITER','EN_COURS')){
          foreach($file in @(Get-ChildItem -LiteralPath $child.FullName -File -Recurse -ErrorAction Stop | Where-Object {$_.Extension -in @('.pdf','.doc','.docx')})){
            Register $entityDir.Name $prefix $status $child.FullName $file.FullName $false
          }
        }else{
          $dirs=@(Get-ChildItem -LiteralPath $child.FullName -Directory -Recurse -ErrorAction Stop)
          foreach($folder in $dirs){
            # Les dossiers de résultat contiennent des fichiers; les branches n'en contiennent pas directement.
            if(@(Get-ChildItem -LiteralPath $folder.FullName -File -ErrorAction Stop).Count){Register $entityDir.Name $prefix $status $child.FullName $folder.FullName $true}
          }
        }
      }
    }
  }
  $script:lastScan=Get-Date;SaveState
}
function Json($response,$value,$code=200){$bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $value -Depth 12 -Compress));$response.StatusCode=$code;$response.ContentType='application/json; charset=utf-8';$response.ContentLength64=$bytes.Length;$response.OutputStream.Write($bytes,0,$bytes.Length);$response.Close()}
function Body($request){if($request.ContentLength64 -gt 42000000){throw 'Fichier trop volumineux (25 Mo maximum par fichier).'};$reader=[IO.StreamReader]::new($request.InputStream,[Text.Encoding]::UTF8);try{$raw=$reader.ReadToEnd();return ($raw|ConvertFrom-Json)}finally{$reader.Dispose()}}
function CopyTree($src,$dest){
  if(!(Test-Path -LiteralPath $src -PathType Container)){throw 'Dossier de travail introuvable.'}
  if(Test-Path -LiteralPath $dest){throw "Destination déjà présente : $dest"}
  Copy-Item -LiteralPath $src -Destination $dest -Recurse -ErrorAction Stop
  $a=@(Get-ChildItem -LiteralPath $src -File -Recurse);$b=@(Get-ChildItem -LiteralPath $dest -File -Recurse)
  if(!$a.Count -or $a.Count -ne $b.Count -or (($a|Measure-Object Length -Sum).Sum -ne ($b|Measure-Object Length -Sum).Sum)){Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw 'Copie non vérifiée : dossier final annulé.'}
}
function UploadFolder($b,$x){
  $upload=$script:uploads[[string]$b.uploadId]
  if(!$upload -or $upload.agent -ne [string]$b.agent -or !$upload.files){throw 'Sélectionnez un dossier du Bureau et attendez la fin de son transfert.'}
  if($upload.root -ine $x.stem -and $upload.root -ine $x.name){throw "Le dossier choisi doit s’appeler $($x.stem) (ou $($x.name))."}
  return $upload
}
function SendFile($r,$path,$type){$bytes=[IO.File]::ReadAllBytes($path);$r.ContentType=$type;$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close()}
function ExistsFile($path){if([string]::IsNullOrWhiteSpace($path)){return $false};return (Test-Path -LiteralPath $path -PathType Leaf)}
function Csv($v){'"'+([string]$v).Replace('"','""')+'"'}
try{Scan}catch{Write-Host "SCAN INITIAL : $($_.Exception.Message)" -ForegroundColor Yellow}
$listener=[Net.HttpListener]::new();$listener.Prefixes.Add([string]$cfg.listenUrl);$listener.Start()
Write-Host "ACCESSIBILITÉ démarré : $($cfg.listenUrl)" -ForegroundColor Cyan
while($listener.IsListening){
  $c=$listener.GetContext();$q=$c.Request;$r=$c.Response;$path=$q.Url.AbsolutePath
  try{
    if($path -eq '/api/state'){
      if((Get-Date)-$script:lastScan -gt [timespan]::FromSeconds([math]::Max(5,[int]$cfg.scanSeconds))){Scan}
      Json $r @{tasks=@($script:tasks);events=@($script:eventList);lastScan=$script:lastScan.ToString('o')};continue
    }
    if($path -eq '/api/document' -and $q.HttpMethod -eq 'GET'){
      $x=FindTask ([string]$q.QueryString['id'])
      if(!$x -or (!(ExistsFile $x.currentPath) -and !(ExistsFile $x.historyPath))){throw 'Document introuvable.'}
      $source=if(ExistsFile $x.currentPath){$x.currentPath}else{$x.historyPath}
      $r.AddHeader('Content-Disposition',('attachment; filename="'+[uri]::EscapeDataString($x.name)+'"'))
      SendFile $r $source 'application/octet-stream';continue
    }
    if($path -eq '/api/take' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=([string]$b.agent).Trim()
      if(!$x -or $x.status -ne 'A_TRAITER' -or !$agent){throw 'Document ou agent invalide. Actualisez la liste.'}
      if(!(Test-Path -LiteralPath $x.currentPath -PathType Leaf)){throw 'Document absent du DP. Actualisez.'}
      $dest=Join-Path (Destination $x 'EN COURS') $x.name
      if(Test-Path -LiteralPath $dest){throw 'Un fichier existe déjà dans En cours.'}
      Move-Item -LiteralPath $x.currentPath -Destination $dest -ErrorAction Stop
      $old=$x.currentPath
      try{$x.currentPath=$dest;$x.status='EN_COURS';$x.agent=$agent;$x.startedAt=(Get-Date).ToString('o');Event $x 'PRISE_EN_CHARGE' $agent $dest;SaveState}
      catch{Move-Item -LiteralPath $dest -Destination $old -ErrorAction SilentlyContinue;throw}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/upload/start' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$rootName=SafeName ([string]$b.root);$agent=([string]$b.agent).Trim();if(!$agent){throw 'Agent requis.'}
      $id=[guid]::NewGuid().ToString();$folder=Join-Path $staging $id;New-Item -ItemType Directory -Path $folder | Out-Null
      $script:uploads[$id]=@{root=$rootName;agent=$agent;folder=$folder;files=0;bytes=0}
      Json $r @{ok=$true;uploadId=$id};continue
    }
    if($path -eq '/api/upload/file' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$upload=$script:uploads[[string]$b.uploadId]
      if(!$upload -or $upload.agent -ne [string]$b.agent){throw 'Transfert introuvable.'}
      $segments=@(([string]$b.relative).Replace('\','/') -split '/')
      if(!$segments.Count -or $segments.Count -gt 15){throw 'Chemin relatif invalide.'}
      foreach($seg in $segments){[void](SafeName $seg)}
      $relative=($segments -join [IO.Path]::DirectorySeparatorChar)
      $dest=EnsureUnder $upload.folder $relative
      $bytes=[Convert]::FromBase64String([string]$b.data)
      if($bytes.Length -gt 25000000 -or $upload.bytes+$bytes.Length -gt 250000000){throw 'Dossier trop volumineux (25 Mo par fichier, 250 Mo au total).'}
      if(Test-Path -LiteralPath $dest){throw 'Nom en double dans le dossier choisi.'}
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest)|Out-Null
      [IO.File]::WriteAllBytes($dest,$bytes);$upload.files++;$upload.bytes+=$bytes.Length
      Json $r @{ok=$true;count=$upload.files};continue
    }
    if($path -eq '/api/finish' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=([string]$b.agent).Trim()
      if(!$x -or $x.status -ne 'EN_COURS' -or $x.agent -ne $agent){throw 'Traitement introuvable ou attribué à un autre agent.'}
      if($b.status -notin @('TRAITES','NON_CONFORME')){throw 'Statut final invalide.'}
      if($b.status -eq 'NON_CONFORME' -and ([string]::IsNullOrWhiteSpace($b.comment) -or [string]::IsNullOrWhiteSpace($b.solution))){throw 'Décrivez le problème et une proposition de solution.'}
      $u=UploadFolder $b $x
      $finalStatus=if($b.status -eq 'TRAITES'){'TRAITES'}else{'NON CONFORME'}
      $dest=Join-Path (Destination $x $finalStatus) $u.root
      $archive=Join-Path $history $x.entity;if($x.prefix){$archive=Join-Path $archive $x.prefix};if($x.branch){$archive=Join-Path $archive $x.branch}
      New-Item -ItemType Directory -Force -Path $archive|Out-Null
      $archived=Join-Path $archive $x.name
      if(Test-Path -LiteralPath $archived){$archived=Join-Path $archive (('{0}_{1}{2}' -f $x.stem,(Get-Date -Format yyyyMMddHHmmss),[IO.Path]::GetExtension($x.name)))}
      Copy-Item -LiteralPath $x.currentPath -Destination $archived -ErrorAction Stop
      if((Get-Item -LiteralPath $archived).Length -ne (Get-Item -LiteralPath $x.currentPath).Length){Remove-Item -LiteralPath $archived -Force;throw 'Archive non vérifiée.'}
      try{CopyTree $u.folder $dest}catch{Remove-Item -LiteralPath $archived -Force -ErrorAction SilentlyContinue;throw}
      $oldPath=$x.currentPath
      $x.historyPath=$archived;$x.resultPath=$dest;$x.currentPath=$dest;$x.status=[string]$b.status;$x.finishedAt=(Get-Date).ToString('o');$x.comment=[string]$b.comment;$x.solution=[string]$b.solution
      Event $x 'FIN_TRAITEMENT' $agent $finalStatus;SaveState
      try{Remove-Item -LiteralPath $oldPath -Force -ErrorAction Stop;Remove-Item -LiteralPath $u.folder -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.uploadId)}catch{$x.cleanupWarning=$_.Exception.Message;SaveState}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/rework' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=([string]$b.agent).Trim()
      if(!$x -or $x.status -ne 'NON_CONFORME' -or !$agent){throw 'Dossier non conforme introuvable.'}
      $u=UploadFolder $b $x
      $dest=Join-Path (Destination $x 'TRAITES') $u.root
      CopyTree $u.folder $dest
      $old=$x.resultPath;$x.resultPath=$dest;$x.currentPath=$dest;$x.status='TRAITES';$x.reworkedAt=(Get-Date).ToString('o')
      Event $x 'RETRAITEMENT' $agent ('NON_CONFORME vers TRAITES : '+[string]$b.comment);SaveState
      try{if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction Stop};Remove-Item -LiteralPath $u.folder -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.uploadId)}catch{$x.cleanupWarning=$_.Exception.Message;SaveState}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/export'){
      $rows=@('NomFichier;Domaine;SousDomaine;Statut;Statut_2;Date_A_TRAITER;Date_FIN;Date_de_Retraitement;Agent;DMT_minutes;DMT2_minutes;Commentaire;Solution')
      foreach($x in $script:tasks){$dmt='';$dmt2='';if($x.startedAt -and $x.finishedAt){$dmt=[math]::Round(([datetime]$x.finishedAt-[datetime]$x.startedAt).TotalMinutes,2)};if($x.finishedAt -and $x.reworkedAt){$dmt2=[math]::Round(([datetime]$x.reworkedAt-[datetime]$x.finishedAt).TotalMinutes,2)}
        $rows+=(@((Csv $x.name),(Csv $x.entity),(Csv $x.branch),(Csv $x.status),(Csv $(if($x.reworkedAt){'NON_CONFORME -> TRAITES'}else{''})),(Csv $x.createdAt),(Csv $x.finishedAt),(Csv $x.reworkedAt),(Csv $x.agent),(Csv $dmt),(Csv $dmt2),(Csv $x.comment),(Csv $x.solution)) -join ';')}
      $bytes=[Text.Encoding]::UTF8.GetBytes([char]0xFEFF+($rows -join "`r`n"));$r.ContentType='text/csv; charset=utf-8';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();continue
    }
    if($path -eq '/' -or $path -in @('/agent','/manager','/app.js','/style.css')){
      $file=switch($path){'/'{'index.html'}'/agent'{'agent.html'}'/manager'{'manager.html'}'/app.js'{'app.js'}'/style.css'{'style.css'}}
      $type=if($file.EndsWith('.css')){'text/css; charset=utf-8'}elseif($file.EndsWith('.js')){'application/javascript; charset=utf-8'}else{'text/html; charset=utf-8'}
      SendFile $r (Join-Path (Join-Path $base 'web') $file) $type;continue
    }
    Json $r @{error='Route inconnue.'} 404
  }catch{Write-Host $_.Exception.Message -ForegroundColor Red;try{Json $r @{error=$_.Exception.Message} 400}catch{}}
}
