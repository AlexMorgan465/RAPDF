ACCESSIBILITE TDB V1.2 - FETCH MONITOR + DARK MODE

1. La racine par défaut est : \\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE
2. Lancer START.bat.
3. Ouvrir http://localhost:8787

NOUVEAUTES V1.2
- Carte FETCH DU DP : pourcentage de couverture du dernier scan.
- Nombre d'entités détectées/scannées.
- Nombre de dossiers de statut reconnus/scannés.
- Nombre d'éléments récupérés, durée et erreurs.
- Interface entièrement revue.
- Mode sombre/clair mémorisé dans le navigateur.
- Le serveur détecte automatiquement les entités et les dossiers de statut.

SECURITE
Le scan est en lecture. Le contenu des documents n'est jamais modifié. Les seules modifications du DP sont les déplacements explicitement demandés depuis l'interface.
