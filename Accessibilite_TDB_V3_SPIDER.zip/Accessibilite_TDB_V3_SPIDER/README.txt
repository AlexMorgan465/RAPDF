ACCESSIBILITE TDB V3 — SPIDER WEB

1. Extraire le ZIP dans un nouveau dossier.
2. Lancer START.bat.
3. Ouvrir http://localhost:8787

Nouveautés :
- Navigation centrale en toile / réseau, sans panneau latéral.
- Diagnostic du scan par entité et statut.
- Compteurs de dossiers lus, fichiers vus, documents retenus et branches rejetées.
- Comparaison visuelle avec les volumes de contrôle communiqués : A TRAITER 96, EN COURS 2, TRAITES 609, NON CONFORME 16, A PUBLIER 91.
- Le diagnostic sert à identifier précisément les branches sous-comptées avant de modifier la règle métier.
- Scan et serveur restent séparés pour préserver la fluidité.
