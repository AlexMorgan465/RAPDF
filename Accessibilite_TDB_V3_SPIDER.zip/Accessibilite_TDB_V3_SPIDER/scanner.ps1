param([string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$IntervalSeconds=20,[int]$MaxDepth=5)
$ErrorActionPreference='Continue';$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path;$Data=Join-Path $AppDir 'data';New-Item -ItemType Directory -Force $Data|Out-Null
$Index=Join-Path $Data 'index.json';$Scan=Join-Path $Data 'scan.json';$Diag=Join-Path $Data 'diagnostic.json';$Stop=Join-Path $Data 'STOP';if(Test-Path $Stop){Remove-Item $Stop -Force}
function Atomic($p,$o){$t=Join-Path (Split-Path -Parent $p) ((Split-Path -Leaf $p)+'.'+[guid]::NewGuid().ToString('N')+'.tmp');try{$json=$o|ConvertTo-Json -Depth 10;[IO.File]::WriteAllText($t,$json,[Text.UTF8Encoding]::new($false));$null=[IO.File]::ReadAllText($t)|ConvertFrom-Json;Move-Item -LiteralPath $t -Destination $p -Force}finally{if(Test-Path $t){Remove-Item $t -Force -ErrorAction SilentlyContinue}}}
function NS($n){switch -Regex ($n.Trim().ToUpperInvariant()){'^A\s*TRAITER$'{'A TRAITER';break};'^EN\s*COURS$'{'EN COURS';break};'^TRAITE[S]?$'{'TRAITES';break};'^NON\s*CONFORME$'{'NON CONFORME';break};'^A\s*PUBLIER$'{'A PUBLIER';break};default{$null}}}
function Rel($b,$f){$x=$b.TrimEnd('\')+'\';if($f.StartsWith($x,[StringComparison]::OrdinalIgnoreCase)){$f.Substring($x.Length)}else{Split-Path -Leaf $f}}
function ScanOnce{
 $start=Get-Date;$errs=0;$rows=New-Object Collections.ArrayList;$diagRows=New-Object Collections.ArrayList;$dirsVisited=0;$allFiles=0
 try{$ents=@(Get-ChildItem -LiteralPath $Root -Directory -Force -ErrorAction Stop)}catch{$ents=@();$errs++}
 $statuses=New-Object Collections.ArrayList
 foreach($e in $ents){try{foreach($d in @(Get-ChildItem -LiteralPath $e.FullName -Directory -Force -ErrorAction Stop)){$s=NS $d.Name;if($s){[void]$statuses.Add([pscustomobject]@{E=$e;D=$d;S=$s})}}}catch{$errs++}}
 $total=[math]::Max(1,$statuses.Count);$done=0;$entDone=@{}
 Atomic $Scan ([pscustomobject]@{running=$true;percent=0;entitiesTotal=$ents.Count;entitiesScanned=0;statusFoldersTotal=$statuses.Count;statusFoldersScanned=0;documents=0;filesFound=0;directoriesVisited=0;errors=$errs;startedAt=$start.ToString('o')})
 foreach($st in $statuses){
   $beforeDocs=$rows.Count;$beforeFiles=$allFiles;$beforeDirs=$dirsVisited;$depthCounts=@{};$rejected=0
   $stack=New-Object Collections.Stack;$stack.Push([pscustomobject]@{D=$st.D;Depth=0})
   while($stack.Count){$n=$stack.Pop();$dir=$n.D;$depth=[int]$n.Depth;$dirsVisited++;if(!$depthCounts.ContainsKey("$depth")){$depthCounts["$depth"]=0};$depthCounts["$depth"]++
     try{$files=@(Get-ChildItem -LiteralPath $dir.FullName -File -Force -ErrorAction Stop)}catch{$files=@();$errs++}
     $allFiles += $files.Count
     if($depth -gt 0 -and $files.Count -gt 0){
       $latest=($files|Sort-Object LastWriteTime -Descending|Select-Object -First 1).LastWriteTime;$rel=Rel $st.D.FullName $dir.FullName
       [void]$rows.Add([pscustomobject]@{id=($st.E.Name+'|'+$st.S+'|'+$rel);entity=$st.E.Name;status=$st.S;name=$dir.Name;relativePath=$rel;fileCount=$files.Count;depth=$depth;modified=$latest.ToString('o');depositDate=$latest.ToString('o')})
       # A business folder is terminal: files inside it define the document. Do not count its children again.
       continue
     }
     if($depth -lt $MaxDepth){try{$subs=@(Get-ChildItem -LiteralPath $dir.FullName -Directory -Force -ErrorAction Stop);if($subs.Count-eq0 -and $depth-gt0){$rejected++};foreach($sub in $subs){$stack.Push([pscustomobject]@{D=$sub;Depth=$depth+1})}}catch{$errs++}}
     elseif($depth -ge $MaxDepth){$rejected++}
   }
   [void]$diagRows.Add([pscustomobject]@{entity=$st.E.Name;status=$st.S;documents=($rows.Count-$beforeDocs);files=($allFiles-$beforeFiles);directories=($dirsVisited-$beforeDirs);rejected=$rejected;depths=$depthCounts})
   $done++;$entDone[$st.E.Name]=$true;$pct=[math]::Round($done/$total*100)
   Atomic $Scan ([pscustomobject]@{running=$true;percent=$pct;entitiesTotal=$ents.Count;entitiesScanned=$entDone.Count;statusFoldersTotal=$statuses.Count;statusFoldersScanned=$done;documents=$rows.Count;filesFound=$allFiles;directoriesVisited=$dirsVisited;errors=$errs;startedAt=$start.ToString('o')})
 }
 Atomic $Index @($rows.ToArray());Atomic $Diag @($diagRows.ToArray());$end=Get-Date
 Atomic $Scan ([pscustomobject]@{running=$false;percent=100;entitiesTotal=$ents.Count;entitiesScanned=$ents.Count;statusFoldersTotal=$statuses.Count;statusFoldersScanned=$statuses.Count;documents=$rows.Count;filesFound=$allFiles;directoriesVisited=$dirsVisited;errors=$errs;durationMs=[math]::Round(($end-$start).TotalMilliseconds);startedAt=$start.ToString('o');completedAt=$end.ToString('o')})
}
while(!(Test-Path $Stop)){ScanOnce;for($i=0;$i-lt$IntervalSeconds;$i++){if(Test-Path $Stop){break};Start-Sleep 1}}
