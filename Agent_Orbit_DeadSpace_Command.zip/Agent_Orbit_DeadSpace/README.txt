AGENT ORBIT — DEAD SPACE COMMAND UI
Même backend validé et même logique DP directe que la version précédente.
Seule l'interface a été reconstruite : centre de commande spatial, radar orbital,
télémétrie, journal live, animations, cargo bay, sélection des secteurs et départ animé.
Lancer START_AGENT_ORBIT.bat.
