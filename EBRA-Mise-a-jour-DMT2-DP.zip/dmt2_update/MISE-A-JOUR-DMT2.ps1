$ErrorActionPreference = 'Stop'
$dpRoot = '\\Uf11-a03\EIDS_PRESSE\EBRA SERVICE'
$agentRoot = Join-Path $dpRoot 'work\EBRA-Press-Service'
$managerRoot = Join-Path $dpRoot 'manager_src\EBRA-Manager'
$payload = Join-Path $PSScriptRoot 'Payload'
$stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
$backup = Join-Path $dpRoot ('Sauvegarde-avant-DMT2-' + $stamp)

function Stop-EbraServer([string]$url) {
    try { Invoke-RestMethod ($url + '/api/shutdown') -Method Post -Headers @{'X-Ebra-Request'='1';'Origin'=$url} -ContentType 'application/json' -Body '{}' -TimeoutSec 3 | Out-Null } catch { }
}

try {
    if (-not (Test-Path -LiteralPath $agentRoot)) { throw "Dossier Agent introuvable : $agentRoot" }
    if (-not (Test-Path -LiteralPath $managerRoot)) { throw "Dossier Manager introuvable : $managerRoot" }
    Stop-EbraServer 'http://127.0.0.1:8765'
    Stop-EbraServer 'http://127.0.0.1:8766'
    Start-Sleep -Seconds 2

    $files = @(
        @{ Source='Agent\serverr.ps1'; Target=(Join-Path $agentRoot 'serverr.ps1') },
        @{ Source='Agent\demarrer.ps1'; Target=(Join-Path $agentRoot 'demarrer.ps1') },
        @{ Source='Agent\web\app.js'; Target=(Join-Path $agentRoot 'web\app.js') },
        @{ Source='Manager\serveur.ps1'; Target=(Join-Path $managerRoot 'serveur.ps1') },
        @{ Source='Manager\demarrer.ps1'; Target=(Join-Path $managerRoot 'demarrer.ps1') },
        @{ Source='Manager\web\app.js'; Target=(Join-Path $managerRoot 'web\app.js') }
    )

    New-Item -ItemType Directory -Path $backup -Force | Out-Null
    foreach ($file in $files) {
        if (-not (Test-Path -LiteralPath $file.Target)) { throw "Fichier cible introuvable : $($file.Target)" }
        $relative = $file.Target.Substring($dpRoot.Length).TrimStart('\')
        $backupFile = Join-Path $backup $relative
        New-Item -ItemType Directory -Path ([IO.Path]::GetDirectoryName($backupFile)) -Force | Out-Null
        Copy-Item -LiteralPath $file.Target -Destination $backupFile -Force
    }
    foreach ($file in $files) {
        $source = Join-Path $payload $file.Source
        if (-not (Test-Path -LiteralPath $source)) { throw "Fichier de mise a jour absent : $source" }
        Copy-Item -LiteralPath $source -Destination $file.Target -Force
    }
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show("Mise a jour DMT 2 terminee.`n`nLes donnees JSON n ont pas ete modifiees.`nSauvegarde : $backup`n`nRelancez Agent et Manager.",'EBRA SERVICE - DMT 2') | Out-Null
} catch {
    Add-Type -AssemblyName PresentationFramework
    [System.Windows.MessageBox]::Show($_.Exception.Message,'Echec mise a jour DMT 2') | Out-Null
    exit 1
}
