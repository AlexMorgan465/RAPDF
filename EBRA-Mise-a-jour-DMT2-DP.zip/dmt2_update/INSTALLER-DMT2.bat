@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File ".\MISE-A-JOUR-DMT2.ps1"
