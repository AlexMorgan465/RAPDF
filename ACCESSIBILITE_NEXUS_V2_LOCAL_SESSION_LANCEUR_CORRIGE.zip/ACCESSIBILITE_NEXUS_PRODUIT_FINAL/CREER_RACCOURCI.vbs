Option Explicit
Dim shell, fso, root, shortcut
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
Set shortcut = shell.CreateShortcut(shell.SpecialFolders("Desktop") & "\Accessibilite Nexus.lnk")
shortcut.TargetPath = root & "\START.bat"
shortcut.WorkingDirectory = root
shortcut.Description = "Ouvrir Accessibilite Nexus"
shortcut.IconLocation = "%SystemRoot%\System32\shell32.dll,220"
shortcut.Save
MsgBox "Raccourci cree sur votre Bureau.", vbInformation, "Accessibilite Nexus"
