﻿$ErrorActionPreference='Stop'
if($PSVersionTable.PSVersion.Major -lt 7){throw 'PowerShell 7 est requis pour cette version. Lancez avec pwsh.exe.'}
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$configPath=Join-Path $base 'config.json'
if(!(Test-Path -LiteralPath $configPath -PathType Leaf)){throw "Installation incomplète : config.json est absent de $base. Extrayez l'archive complète avant de lancer START.bat."}
$cfg=[IO.File]::ReadAllText($configPath,[Text.Encoding]::UTF8) | ConvertFrom-Json
if([string]::IsNullOrWhiteSpace($cfg.sharedRoot) -or [string]::IsNullOrWhiteSpace($cfg.historyRoot) -or [string]::IsNullOrWhiteSpace($cfg.listenUrl)){throw 'config.json incomplet : sharedRoot, historyRoot et listenUrl sont obligatoires.'}
$share=[string]$cfg.sharedRoot; $history=[string]$cfg.historyRoot
$db=Join-Path $base 'data\tasks.json'; $events=Join-Path $base 'data\events.json'
$auditLines=Join-Path $base 'data\audit.jsonl'
$entityPrioritiesFile=Join-Path $base 'data\entity-priorities.json'
$usersFile=Join-Path $base 'data\users.json';$logFile=Join-Path $base 'data\server.log'
$indexFile=Join-Path $base 'data\dp-index.json'
$treatedFile=Join-Path $base 'data\traites-index.json'
$staging=Join-Path $base 'data\staging'; New-Item -ItemType Directory -Force -Path $staging | Out-Null
if(!(Test-Path -LiteralPath $db)){[IO.File]::WriteAllText($db,'[]',[Text.UTF8Encoding]::new($false))}
if(!(Test-Path -LiteralPath $events)){[IO.File]::WriteAllText($events,'[]',[Text.UTF8Encoding]::new($false))}
$script:tasks=[Collections.ArrayList]::new()
foreach($item in @([IO.File]::ReadAllText($db,[Text.Encoding]::UTF8) | ConvertFrom-Json)){if($null -ne $item){[void]$script:tasks.Add($item)}}
$script:eventList=[Collections.ArrayList]::new()
foreach($item in @([IO.File]::ReadAllText($events,[Text.Encoding]::UTF8) | ConvertFrom-Json)){if($null -ne $item){[void]$script:eventList.Add($item)}}
if(Test-Path -LiteralPath $auditLines){
  foreach($line in [IO.File]::ReadLines($auditLines,[Text.Encoding]::UTF8)){
    if($line){try{[void]$script:eventList.Add(($line | ConvertFrom-Json))}catch{}}
  }
}
if(!(Test-Path -LiteralPath $entityPrioritiesFile)){[IO.File]::WriteAllText($entityPrioritiesFile,'{}',[Text.UTF8Encoding]::new($false))}
$script:entityPriorities=@{}
$loadedPriorities=[IO.File]::ReadAllText($entityPrioritiesFile,[Text.Encoding]::UTF8) | ConvertFrom-Json
if($loadedPriorities){foreach($prop in $loadedPriorities.PSObject.Properties){$script:entityPriorities[$prop.Name]=[string]$prop.Value}}
$script:taskByKey=@{};$script:taskById=@{};$script:taskByPath=@{}
foreach($item in $script:tasks){
  if($item.PSObject.Properties.Match('priority').Count -eq 0){$item | Add-Member -NotePropertyName priority -NotePropertyValue 'Normale' -Force}
  if($item.PSObject.Properties.Match('priorityOverride').Count -eq 0){$item | Add-Member -NotePropertyName priorityOverride -NotePropertyValue ($item.priority -ne 'Normale') -Force}
  if(!$item.priorityOverride -and $script:entityPriorities.ContainsKey([string]$item.entity)){$item.priority=$script:entityPriorities[[string]$item.entity]}
  $script:taskByKey[[string]$item.key]=$item;$script:taskById[[string]$item.id]=$item
  if($item.currentPath){$script:taskByPath[[string]$item.currentPath]=$item}
}
if(!(Test-Path -LiteralPath $usersFile)){
  $owner=[Security.Principal.WindowsIdentity]::GetCurrent().Name
  $seed=@([pscustomobject]@{account=$owner;role='manager';enabled=$true})
  [IO.File]::WriteAllText($usersFile,(ConvertTo-Json -InputObject $seed -Compress),[Text.UTF8Encoding]::new($false))
}
$script:users=[Collections.ArrayList]::new()
foreach($item in @([IO.File]::ReadAllText($usersFile,[Text.Encoding]::UTF8) | ConvertFrom-Json)){if($null -ne $item){[void]$script:users.Add($item)}}
$script:sessions=@{}
$script:uploads=@{}; $script:lastScan=[datetime]::MinValue;$script:scanHandle=$null;$script:scanPowerShell=$null;$script:scanError='';$script:lastHistoryScan=[datetime]::MinValue;$script:scanQueue=$null;$script:scanDirty=$false
$script:watchQueue=[System.Collections.Concurrent.ConcurrentQueue[object]]::new();$script:watcher=$null;$script:watching=$false
$script:indexEntries=@{}
if(Test-Path -LiteralPath $indexFile){try{$indexData=[IO.File]::ReadAllText($indexFile,[Text.Encoding]::UTF8)|ConvertFrom-Json;foreach($entry in @($indexData.entries)){if($entry -and $entry.path){$script:indexEntries[[string]$entry.path]=$entry}}}catch{Write-Warning 'Index DP illisible ; une nouvelle analyse va le recréer.'}}
$script:stateVersion=0
function InvalidateState{$script:stateBytes=$null;$script:stateVersion++}
function SaveJson($path,$value){$json=ConvertTo-Json -InputObject $value.ToArray() -Depth 12 -Compress;$tmp=$path+'.tmp';[IO.File]::WriteAllText($tmp,$json,[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $tmp -Destination $path -Force}
function SaveUsers{SaveJson $usersFile $script:users}
function SaveEntityPriorities{[IO.File]::WriteAllText($entityPrioritiesFile,(ConvertTo-Json -InputObject $script:entityPriorities -Compress -Depth 4),[Text.UTF8Encoding]::new($false))}
function SaveState{SaveJson $db $script:tasks;InvalidateState}
function SaveIndex{
  $json=ConvertTo-Json -InputObject @{updatedAt=(Get-Date).ToString('o');entries=@($script:indexEntries.Values)} -Depth 6 -Compress
  $tmp=$indexFile+'.tmp';[IO.File]::WriteAllText($tmp,$json,[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $tmp -Destination $indexFile -Force
}
function SaveTreatedIndex{
  $rows=@($script:tasks | Where-Object {$_.status -eq 'TRAITES'} | ForEach-Object {
    [pscustomobject]@{id=$_.id;key=$_.key;entity=$_.entity;name=$_.name;resultPath=$_.resultPath;agent=$_.agent;finishedAt=$_.finishedAt;reworkedAt=$_.reworkedAt}
  })
  $json=ConvertTo-Json -InputObject @{updatedAt=(Get-Date).ToString('o');folders=$rows} -Depth 5 -Compress
  $tmp=$treatedFile+'.tmp';[IO.File]::WriteAllText($tmp,$json,[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $tmp -Destination $treatedFile -Force
}
if(!(Test-Path -LiteralPath $treatedFile)){SaveTreatedIndex}
function Event($task,$kind,$agent,$detail){
  $taskId=if($task){$task.id}else{''}
  $entry=[pscustomobject]@{id=[guid]::NewGuid().ToString();taskId=$taskId;at=(Get-Date).ToString('o');kind=$kind;agent=$agent;detail=$detail}
  [IO.File]::AppendAllText($auditLines,((ConvertTo-Json -InputObject $entry -Compress -Depth 4)+"`n"),[Text.Encoding]::UTF8)
  [void]$script:eventList.Add($entry);InvalidateState
}
function Account($name){return @($script:users | Where-Object {$_.account -ieq $name -and $_.enabled} | Select-Object -First 1)[0]}
function ActiveSession($context){
  $windowsName=[Security.Principal.WindowsIdentity]::GetCurrent().Name
  if([string]::IsNullOrWhiteSpace($windowsName)){return $null}
  $managerNames=@('CDM\OUBRAHMO','CDM\HAMDANMO','CDM\HMADANMO')
  $role=if($managerNames -icontains $windowsName){'manager'}else{'agent'}
  return [pscustomobject]@{account=$windowsName;role=$role}
}
function ManagerOnly($user){if(!$user -or $user.role -ne 'manager'){throw 'Accès réservé au manager.'}}
function Audit($kind,$agent,$detail){Event $null $kind $agent $detail}
function Status($name){switch -Regex ($name.Trim().ToUpperInvariant()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function Stem($name){[IO.Path]::GetFileNameWithoutExtension($name)}
function TaskKey($entity,$prefix,$branch,$stem){($entity+'|'+$prefix+'|'+$branch+'|'+$stem).ToUpperInvariant()}
function FindTask($id){return $script:taskById[$id]}
function TrackPath($task,$newPath){if($task.currentPath){[void]$script:taskByPath.Remove([string]$task.currentPath)};$task.currentPath=$newPath;$script:taskByPath[[string]$newPath]=$task}
function SafeName($name){if([string]::IsNullOrWhiteSpace($name)-or $name -in @('.','..') -or $name.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $name.Contains('/') -or $name.Contains('\')){throw 'Nom de fichier ou dossier invalide.'};return $name}
function EnsureUnder($root,$relative){
  $full=[IO.Path]::GetFullPath((Join-Path $root $relative));$parent=[IO.Path]::GetFullPath($root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
  if(!$full.StartsWith($parent,[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin hors du dossier autorisé.'};return $full
}
function GroupPaths($x){
  $p=Join-Path $share $x.entity
  if($x.prefix){$p=Join-Path $p $x.prefix}
  return $p
}
function Destination($x,$status){
  $p=Join-Path (GroupPaths $x) $status
  if($x.branch){$p=Join-Path $p $x.branch}
  New-Item -ItemType Directory -Force -Path $p | Out-Null
  return $p
}
function Register($entity,$prefix,$status,$statusDir,$path,$isFolder,$modified){
  $rel=[IO.Path]::GetDirectoryName($path.Substring($statusDir.Length).TrimStart('\','/'))
  if($null -eq $rel -or $rel -eq '.'){ $rel='' }
  $name=[IO.Path]::GetFileName($path);$stem=if($isFolder -and [IO.Path]::GetExtension($name) -notin @('.pdf','.doc','.docx')){$name}else{Stem $name}
  $key=TaskKey $entity $prefix $rel $stem
  if($script:taskByKey.ContainsKey($key)){
    $existing=$script:taskByKey[$key]
    if(($existing.status -ne $status -or $existing.currentPath -ine $path) -and ($existing.status -eq 'ABSENT' -or [string]::IsNullOrWhiteSpace($existing.currentPath) -or !(Test-Path -LiteralPath $existing.currentPath))){
      $existing.status=$status;TrackPath $existing $path
      if($isFolder){$existing.resultPath=$path}else{$existing.sourcePath=$path}
      $existing | Add-Member -NotePropertyName modifiedAt -NotePropertyValue $modified -Force
      Event $existing 'SYNCHRONISATION' '' ('Déplacement détecté : '+$path)
      return $true
    }
    if($existing.currentPath -ieq $path -and $existing.PSObject.Properties.Match('modifiedAt').Count -gt 0 -and $existing.modifiedAt -and $existing.modifiedAt -ne $modified){
      $existing.modifiedAt=$modified;Event $existing 'MODIFICATION_DP' '' ('Modifié dans le DP : '+$path);return $true
    }
    if($existing.PSObject.Properties.Match('modifiedAt').Count -eq 0){$existing | Add-Member -NotePropertyName modifiedAt -NotePropertyValue $modified -Force;return $true}
    return $false
  }
  $now=if($modified){[string]$modified}else{(Get-Date).ToString('o')}
  $task=[pscustomobject]@{id=[guid]::NewGuid().ToString();key=$key;entity=$entity;prefix=$prefix;branch=$rel;name=$name;stem=$stem;status=$status;priority=$(if($script:entityPriorities.ContainsKey($entity)){$script:entityPriorities[$entity]}else{'Normale'});priorityOverride=$false;agent='';sourcePath=$(if($isFolder){''}else{$path});currentPath=$path;resultPath=$(if($isFolder){$path}else{''});historyPath='';createdAt=$now;modifiedAt=$modified;startedAt=$null;finishedAt=$null;reworkedAt=$null;comment='';solution='';cleanupWarning=''}
  [void]$script:tasks.Add($task);$script:taskByKey[$key]=$task;$script:taskById[$task.id]=$task
  $script:taskByPath[[string]$path]=$task
  return $true
}
# L'analyse du partage s'effectue dans un runspace indépendant du serveur HTTP.
# Elle renvoie les documents et les dossiers finaux, sans explorer les fichiers internes des résultats.
$scanner=@'
param([string]$root,$queue,[bool]$includeTreated)
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath $root -PathType Container)){throw "Racine DP introuvable : $root"}
foreach($entity in (Get-ChildItem -LiteralPath $root -Directory)){
  $directoryQueue=[Collections.Queue]::new();$directoryQueue.Enqueue($entity)
  while($directoryQueue.Count){
    $parent=$directoryQueue.Dequeue()
    foreach($child in (Get-ChildItem -LiteralPath $parent.FullName -Directory)){
      $name=$child.Name.Trim().ToUpperInvariant()
      if($name -eq 'A PUBLIER'){continue}
      $status=switch -Regex ($name){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}
      if(!$status){$directoryQueue.Enqueue($child);continue}
$prefix=$parent.FullName.Substring($entity.FullName.Length).TrimStart('\','/')
      if($status -in @('A_TRAITER','EN_COURS')){
        foreach($file in (Get-ChildItem -LiteralPath $child.FullName -File -Recurse)){
          if($file.Extension -in @('.pdf','.doc','.docx')){
            $queue.Enqueue([pscustomobject]@{entity=$entity.Name;prefix=$prefix;status=$status;statusDir=$child.FullName;path=$file.FullName;isFolder=$false;modified=$file.LastWriteTime.ToString('o')})
          }
        }
      }elseif($status -eq 'NON_CONFORME' -or $includeTreated){
        $folders=[Collections.Queue]::new();$folders.Enqueue($child.FullName)
        while($folders.Count){
          $folderPath=[string]$folders.Dequeue()
          foreach($folder in (Get-ChildItem -LiteralPath $folderPath -Directory)){
            $firstFile=Get-ChildItem -LiteralPath $folder.FullName -File | Select-Object -First 1
            if($firstFile){
              $queue.Enqueue([pscustomobject]@{entity=$entity.Name;prefix=$prefix;status=$status;statusDir=$child.FullName;path=$folder.FullName;isFolder=$true;modified=$folder.LastWriteTime.ToString('o')})
            }else{$folders.Enqueue($folder.FullName)}
          }
        }
      }
    }
  }
}
'@
function StartScan{
  if($script:scanHandle){return}
  $script:scanHadWatchEvents=$false
  $script:scanErrorBefore=$script:scanError
  $script:scanDirty=$false
  $script:scanQueue=[System.Collections.Concurrent.ConcurrentQueue[object]]::new()
  $script:scanSnapshot=@{};$script:scanSeen=@{}
  $script:includeTreated=[bool]$script:forceTreatedScan
  $script:forceTreatedScan=$false
  $script:scanPowerShell=[PowerShell]::Create()
  [void]$script:scanPowerShell.AddScript($scanner).AddArgument($share).AddArgument($script:scanQueue).AddArgument($script:includeTreated)
  $script:scanHandle=$script:scanPowerShell.BeginInvoke()
}
function CompleteScan{
  if(!$script:scanHandle){return}
  $changed=$false
  $budget=[Diagnostics.Stopwatch]::StartNew()
  for($i=0;$i -lt 100 -and $budget.ElapsedMilliseconds -lt 35;$i++){
    [object]$f=$null
    if(!$script:scanQueue.TryDequeue([ref]$f)){break}
    $script:scanSnapshot[[string]$f.path]=$f
    $relative=[IO.Path]::GetDirectoryName($f.path.Substring($f.statusDir.Length).TrimStart('\','/'))
    if(!$relative -or $relative -eq '.'){$relative=''}
    $entryName=[IO.Path]::GetFileName($f.path)
    $entryStem=if($f.isFolder -and [IO.Path]::GetExtension($entryName) -notin @('.pdf','.doc','.docx')){$entryName}else{Stem $entryName}
    $script:scanSeen[(TaskKey $f.entity $f.prefix $relative $entryStem)]=$true
    if((Register $f.entity $f.prefix $f.status $f.statusDir $f.path $f.isFolder $f.modified)){$changed=$true}
  }
  if($changed){$script:scanDirty=$true;InvalidateState}
  if(!$script:scanHandle.IsCompleted -or !$script:scanQueue.IsEmpty){return}
  try{
    [void]$script:scanPowerShell.EndInvoke($script:scanHandle)
    if($script:scanPowerShell.HadErrors){throw ([string]$script:scanPowerShell.Streams.Error[0])}
    if(!$script:scanHadWatchEvents){
      foreach($task in $script:tasks){
        if(($task.status -in @('A_TRAITER','EN_COURS','NON_CONFORME') -or ($script:includeTreated -and $task.status -eq 'TRAITES')) -and !$script:scanSeen.ContainsKey([string]$task.key)){
          $task.status='ABSENT';$script:scanDirty=$true
          Event $task 'RETRAIT_DP' '' ('Introuvable dans le DP : '+[string]$task.currentPath)
        }
      }
    }
    $nextIndex=@{}
    if(!$script:includeTreated){foreach($entry in $script:indexEntries.Values){if($entry.status -eq 'TRAITES'){$nextIndex[[string]$entry.path]=$entry}}}
    foreach($entry in $script:scanSnapshot.Values){$nextIndex[[string]$entry.path]=$entry}
    $indexChanged=$nextIndex.Count -ne $script:indexEntries.Count
    if(!$indexChanged){foreach($key in $nextIndex.Keys){$old=$script:indexEntries[$key];$new=$nextIndex[$key];if(!$old -or $old.status -ne $new.status -or $old.modified -ne $new.modified){$indexChanged=$true;break}}}
    $script:indexEntries=$nextIndex
    if($indexChanged){SaveIndex}
    if($script:includeTreated){SaveTreatedIndex;$script:lastHistoryScan=Get-Date}
    $script:scanError=''
  }catch{$script:scanError=$_.Exception.Message;Write-Host "SCAN : $script:scanError" -ForegroundColor Yellow}
  finally{
    $script:lastScan=if($script:scanHadWatchEvents){[datetime]::MinValue}else{Get-Date};$script:scanPowerShell.Dispose();$script:scanPowerShell=$null;$script:scanHandle=$null;$script:scanQueue=$null
    if($script:scanDirty -or $script:stateScanShown -or $script:scanError -ne $script:scanErrorBefore){InvalidateState}
    if($script:scanDirty){SaveState;$script:scanDirty=$false}
  }
}
function StartWatcher{
  try{
    $script:watcher=[IO.FileSystemWatcher]::new($share)
    $script:watcher.IncludeSubdirectories=$true
    $script:watcher.NotifyFilter=[IO.NotifyFilters]::FileName -bor [IO.NotifyFilters]::DirectoryName -bor [IO.NotifyFilters]::LastWrite
    $script:watcher.InternalBufferSize=32768
    foreach($kind in @('Created','Changed','Deleted','Renamed','Error')){
      Register-ObjectEvent -InputObject $script:watcher -EventName $kind -SourceIdentifier ('AccessibiliteDP-'+$PID+'-'+$kind) -MessageData $script:watchQueue -Action {
        $a=$Event.SourceEventArgs
        $newPath=if($a.PSObject.Properties['FullPath']){[string]$a.FullPath}else{''}
        $oldPath=if($a.PSObject.Properties['OldFullPath']){[string]$a.OldFullPath}else{''}
        [void]$Event.MessageData.Enqueue([pscustomobject]@{path=$newPath;oldPath=$oldPath;kind=[string]$Event.SourceIdentifier})
      } | Out-Null
    }
    $script:watcher.EnableRaisingEvents=$true;$script:watching=$true
  }catch{
    $script:watching=$false;$script:watcher=$null
    [IO.File]::AppendAllText($logFile,((Get-Date).ToString('o')+' FileSystemWatcher indisponible : '+$_.Exception.Message+"`r`n"),[Text.Encoding]::UTF8)
  }
}
function WatchPath($path){
  if(!$path -or !$path.StartsWith($share.TrimEnd('\','/')+'\',[StringComparison]::OrdinalIgnoreCase)){return $false}
  $pieces=@($path.Substring($share.TrimEnd('\','/').Length).TrimStart('\','/') -split '[\\/]')
  if($pieces.Count -lt 3){return $false}
  $entity=$pieces[0];$position=-1;$status=$null
  for($j=1;$j -lt $pieces.Count;$j++){$status=Status $pieces[$j];if($status){$position=$j;break}}
  if($position -lt 0){return $false}
  if($position -eq $pieces.Count-1){$script:lastScan=[datetime]::MinValue;return $false}
  $prefix=if($position -gt 1){$pieces[1..($position-1)] -join '\'}else{''}
  $statusDir=Join-Path (Join-Path $share $entity) ($pieces[1..$position] -join '\')
  if(!(Test-Path -LiteralPath $path)){
    $task=$script:taskByPath[[string]$path]
    if($task -and $task.status -eq $status){$task.status='ABSENT';Event $task 'RETRAIT_DP' '' ('Retiré : '+$path);return $true}
  }
  if($status -in @('A_TRAITER','EN_COURS')){
    if(Test-Path -LiteralPath $path -PathType Leaf){
      $file=Get-Item -LiteralPath $path
      if($file.Extension -in @('.pdf','.doc','.docx')){return (Register $entity $prefix $status $statusDir $path $false $file.LastWriteTime.ToString('o'))}
    }else{
      return $false
    }
  }else{
    $candidate=if(Test-Path -LiteralPath $path -PathType Container){$path}else{Split-Path -Parent $path}
    if($candidate -and $candidate -ine $statusDir -and (Test-Path -LiteralPath $candidate -PathType Container)){
      $first=Get-ChildItem -LiteralPath $candidate -File | Select-Object -First 1
      if($first){return (Register $entity $prefix $status $statusDir $candidate $true (Get-Item -LiteralPath $candidate).LastWriteTime.ToString('o'))}
    }
  }
  return $false
}
function DrainWatcher{
  $changed=$false;$treatedChanged=$false;$seen=@{};$budget=[Diagnostics.Stopwatch]::StartNew()
  for($i=0;$i -lt 80 -and $budget.ElapsedMilliseconds -lt 40;$i++){
    [object]$eventItem=$null;if(!$script:watchQueue.TryDequeue([ref]$eventItem)){break}
    if($script:scanHandle){$script:scanHadWatchEvents=$true}
    if($eventItem.kind -like '*-Error'){$script:lastScan=[datetime]::MinValue;continue}
    foreach($path in @($eventItem.oldPath,$eventItem.path)){
      if(!$path -or $seen.ContainsKey($path)){continue};$seen[$path]=$true
      try{if(WatchPath $path){$changed=$true;if($path -match '(?i)[\\/]TRAIT(ES|ÉS)[\\/]'){$treatedChanged=$true}}}
      catch{$script:lastScan=[datetime]::MinValue}
    }
  }
  if($changed){SaveState;if($treatedChanged){SaveTreatedIndex}}
}
function Json($response,$value,$code=200){$bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $value -Depth 12 -Compress));$response.StatusCode=$code;$response.ContentType='application/json; charset=utf-8';$response.ContentLength64=$bytes.Length;$response.OutputStream.Write($bytes,0,$bytes.Length);$response.Close()}
function SendState($response){
  $etag='"'+[string]$script:stateVersion+'"'
  if(!$script:stateBytes){
    $n=[math]::Min(300,$script:eventList.Count)
    $recent=@()
    if($n){$recent=@($script:eventList.GetRange($script:eventList.Count-$n,$n).ToArray())}
    $script:stateScanShown=[bool]$script:scanHandle
    $counts=@{A_TRAITER=0;EN_COURS=0;NON_CONFORME=0;TRAITES=0;ABSENT=0}
    $byEntity=@{};$byAgent=@{};$byDay=@{};$agentStats=@{}
    $visible=[Collections.Generic.List[object]]::new()
    foreach($task in $script:tasks){
      $status=[string]$task.status
      if($counts.ContainsKey($status)){$counts[$status]++}
      if($status -ne 'TRAITES'){[void]$visible.Add($task)}
      $entity=[string]$task.entity;if($entity){if(!$byEntity.ContainsKey($entity)){$byEntity[$entity]=0};$byEntity[$entity]++}
      if($status -in @('TRAITES','NON_CONFORME') -or $task.finishedAt){
        $agent=[string]$task.agent;if(!$agent){$agent='Non attribué'}
        if(!$byAgent.ContainsKey($agent)){$byAgent[$agent]=0};$byAgent[$agent]++}
        if(!$agentStats.ContainsKey($agent)){$agentStats[$agent]=@{total=0;treated=0;entities=@{};days=@{}}}
        $agentStats[$agent].total++;if($status -eq 'TRAITES'){$agentStats[$agent].treated++}
        if($entity){if(!$agentStats[$agent].entities.ContainsKey($entity)){$agentStats[$agent].entities[$entity]=0};$agentStats[$agent].entities[$entity]++}
        if($task.finishedAt){try{$day=([datetime]$task.finishedAt).ToString('dd/MM/yyyy');if(!$byDay.ContainsKey($day)){$byDay[$day]=0};$byDay[$day]++;if(!$agentStats[$agent].days.ContainsKey($day)){$agentStats[$agent].days[$day]=0};$agentStats[$agent].days[$day]++}catch{}}
      }
    }
    $data=@{tasks=$visible.ToArray();counts=$counts;byEntity=$byEntity;byAgent=$byAgent;byDay=$byDay;agentStats=$agentStats;events=$recent;entityPriorities=$script:entityPriorities;lastScan=$script:lastScan.ToString('o');scanning=$script:stateScanShown;watching=$script:watching;scanError=$script:scanError}
    $script:stateBytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $data -Depth 12 -Compress))
  }
  $response.AddHeader('ETag',$etag)
  $response.ContentType='application/json; charset=utf-8';$response.ContentLength64=$script:stateBytes.Length
  $response.OutputStream.Write($script:stateBytes,0,$script:stateBytes.Length);$response.Close()
}
function Body($request){if($request.ContentLength64 -gt 42000000){throw 'Fichier trop volumineux (25 Mo maximum par fichier).'};$reader=[IO.StreamReader]::new($request.InputStream,[Text.Encoding]::UTF8);try{$raw=$reader.ReadToEnd();return ($raw|ConvertFrom-Json)}finally{$reader.Dispose()}}
function CopyTree($src,$dest){
  if(!(Test-Path -LiteralPath $src -PathType Container)){throw 'Dossier de travail introuvable.'}
  if(Test-Path -LiteralPath $dest){throw "Destination déjà présente : $dest"}
  Copy-Item -LiteralPath $src -Destination $dest -Recurse -ErrorAction Stop
  $a=@(Get-ChildItem -LiteralPath $src -File -Recurse);$b=@(Get-ChildItem -LiteralPath $dest -File -Recurse)
  if(!$a.Count -or $a.Count -ne $b.Count -or (($a|Measure-Object Length -Sum).Sum -ne ($b|Measure-Object Length -Sum).Sum)){Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw 'Copie non vérifiée : dossier final annulé.'}
}
function UploadFolder($b,$x){
  $upload=$script:uploads[[string]$b.uploadId]
  if(!$upload -or $upload.agent -ne [string]$b.agent -or !$upload.files){throw 'Sélectionnez un dossier du Bureau et attendez la fin de son transfert.'}
  if($upload.root -ine $x.stem -and $upload.root -ine $x.name){throw "Le dossier choisi doit s’appeler $($x.stem) (ou $($x.name))."}
  return $upload
}
function SendFile($r,$path,$type){$bytes=[IO.File]::ReadAllBytes($path);$r.ContentType=$type;$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close()}
function ExistsFile($path){if([string]::IsNullOrWhiteSpace($path)){return $false};return (Test-Path -LiteralPath $path -PathType Leaf)}
function Csv($v){'"'+([string]$v).Replace('"','""')+'"'}
# Serveur TCP local : aucune inscription HTTP.sys (PID 4).
class LocalResponse {
  [Net.Sockets.TcpClient]$Client
  [IO.MemoryStream]$OutputStream
  [hashtable]$ExtraHeaders
  [int]$StatusCode = 200
  [string]$ContentType = 'text/plain; charset=utf-8'
  [long]$ContentLength64 = 0
  [bool]$Closed = $false
  LocalResponse([Net.Sockets.TcpClient]$client){$this.Client=$client;$this.OutputStream=[IO.MemoryStream]::new();$this.ExtraHeaders=@{}}
  [void]AddHeader([string]$name,[string]$value){$this.ExtraHeaders[$name]=$value}
  [void]Close(){
    if($this.Closed){return};$this.Closed=$true
    try{
      $reasons=@{200='OK';304='Not Modified';400='Bad Request';401='Unauthorized';403='Forbidden';404='Not Found';413='Payload Too Large'}
      $reason=if($reasons.ContainsKey($this.StatusCode)){$reasons[$this.StatusCode]}else{'Error'}
      $body=$this.OutputStream.ToArray();if($this.StatusCode -eq 304){$body=[byte[]]@()}
      $header="HTTP/1.1 $($this.StatusCode) $reason`r`nContent-Type: $($this.ContentType)`r`nContent-Length: $($body.Length)`r`nConnection: close`r`nCache-Control: no-store`r`n"
      foreach($key in $this.ExtraHeaders.Keys){$safe=([string]$this.ExtraHeaders[$key]) -replace "[`r`n]",'';$header+="${key}: $safe`r`n"}
      $header+="`r`n";$stream=$this.Client.GetStream();$bytes=[Text.Encoding]::ASCII.GetBytes($header);$stream.Write($bytes,0,$bytes.Length)
      if($body.Length){$stream.Write($body,0,$body.Length)};$stream.Flush()
    }finally{$this.OutputStream.Dispose();$this.Client.Close()}
  }
}
function ReadLocalRequest($client){
  $client.ReceiveTimeout=10000;$client.SendTimeout=10000;$stream=$client.GetStream()
  $header=[Collections.Generic.List[byte]]::new();$complete=$false
  while($header.Count -lt 16384){
    $one=$stream.ReadByte();if($one -lt 0){throw 'Connexion interrompue.'};$header.Add([byte]$one)
    $n=$header.Count
    if($n -ge 4 -and $header[$n-4] -eq 13 -and $header[$n-3] -eq 10 -and $header[$n-2] -eq 13 -and $header[$n-1] -eq 10){$complete=$true;break}
  }
  if(!$complete){throw 'En-tête HTTP trop long.'}
  $lines=([Text.Encoding]::ASCII.GetString($header.ToArray()) -split "`r`n")
  $parts=$lines[0] -split ' ';if($parts.Count -lt 3 -or $parts[0] -notin @('GET','POST')){throw 'Requête invalide.'}
  $headers=@{};foreach($line in $lines[1..($lines.Count-1)]){if($line -match '^([^:]+):\s*(.*)$'){$headers[$Matches[1]]=$Matches[2]}}
  if($headers['Transfer-Encoding']){throw 'Transfert fragmenté non pris en charge.'}
  $length=0L;if($headers['Content-Length']){if(![long]::TryParse($headers['Content-Length'],[ref]$length)){throw 'Taille de requête invalide.'}}
  if($length -lt 0 -or $length -gt 42000000){throw 'Requête trop volumineuse.'}
  $body=[byte[]]::new([int]$length);$offset=0
  while($offset -lt $length){$got=$stream.Read($body,$offset,[int]($length-$offset));if($got -le 0){throw 'Corps de requête incomplet.'};$offset+=$got}
  if($headers['Host'] -notin @(('localhost:'+$script:localPort),('127.0.0.1:'+$script:localPort))){throw 'Hôte HTTP non autorisé.'}
  if($parts[0] -eq 'POST' -and $headers['Origin'] -and $headers['Origin'] -notin @(('http://localhost:'+$script:localPort),('http://127.0.0.1:'+$script:localPort))){throw 'Origine HTTP non autorisée.'}
  $url=[uri]('http://localhost'+$parts[1]);$query=[System.Web.HttpUtility]::ParseQueryString($url.Query)
  return [pscustomobject]@{Request=[pscustomobject]@{Url=$url;HttpMethod=$parts[0];Headers=$headers;QueryString=$query;ContentLength64=$length;InputStream=[IO.MemoryStream]::new($body)};Response=[LocalResponse]::new($client)}
}
$uri=[uri][string]$cfg.listenUrl
if($uri.Scheme -ne 'http' -or $uri.Host -notin @('localhost','127.0.0.1') -or $uri.AbsolutePath -ne '/'){throw 'listenUrl doit être http://localhost:PORT/ : le serveur est réservé au poste local.'}
$script:localPort=$uri.Port
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$uri.Port)
$listener.Start()
[IO.File]::WriteAllText((Join-Path $base 'data\server.pid'),[string]$PID,[Text.Encoding]::ASCII)
[IO.File]::AppendAllText($logFile,((Get-Date).ToString('o')+" DÉMARRAGE $($cfg.listenUrl)`r`n"),[Text.Encoding]::UTF8)
if($args -contains '-Visible'){try{Start-Process ([string]$cfg.listenUrl)}catch{Write-Host $_.Exception.Message}}
Write-Host "ACCESSIBILITÉ démarré : $($cfg.listenUrl)" -ForegroundColor Cyan
StartScan
StartWatcher
$script:running=$true
while($script:running){
  DrainWatcher
  CompleteScan
  $checkInterval=if($script:watching){[math]::Max(30,[int]$cfg.rescanSeconds)}else{[math]::Max(10,[int]$cfg.scanSeconds)}
  if(!$script:scanHandle -and ($script:forceTreatedScan -or (Get-Date)-$script:lastScan -ge [timespan]::FromSeconds($checkInterval))){StartScan}
  if(!$listener.Pending()){Start-Sleep -Milliseconds 250;continue}
  $client=$listener.AcceptTcpClient()
  try{$c=ReadLocalRequest $client}catch{$client.Close();continue}
  $q=$c.Request;$r=$c.Response;$path=$q.Url.AbsolutePath
  try{
    $user=ActiveSession $c
    if(!$user){Json $r @{error='Session Windows introuvable.'} 401;continue}
    if($path -eq '/api/version'){Json $r @{transport='tcp-v2';session=($user.account -split '\\')[-1]};continue}
    if($path -eq '/api/me'){Json $r @{account=$user.account;session=($user.account -split '\\')[-1];role=$user.role};continue}
    if(($path -eq '/manager' -or $path -in @('/api/users','/api/priority','/api/entity-priority','/api/assign','/api/audit','/api/audit/export','/api/export','/api/resync-traites')) -and $user.role -ne 'manager'){Json $r @{error='Accès réservé au manager.'} 403;continue}
    if($path -eq '/api/disconnect' -and $q.HttpMethod -eq 'POST'){
      Audit 'DECONNEXION' $user.account 'Arrêt de tous les serveurs locaux Accessibilité Nexus'
      Json $r @{ok=$true}
      Start-Process -FilePath 'pwsh.exe' -WindowStyle Hidden -ArgumentList @('-NoProfile','-ExecutionPolicy','Bypass','-File',('"'+(Join-Path $base 'stop.ps1')+'"')) -ErrorAction SilentlyContinue
      $script:running=$false;continue
    }
    if($path -eq '/api/users' -and $q.HttpMethod -eq 'GET'){
      Json $r @{users=$script:users.ToArray()};continue
    }
    if($path -eq '/api/resync-traites' -and $q.HttpMethod -eq 'POST'){
      $script:forceTreatedScan=$true
      if(!$script:scanHandle){StartScan}
      Audit 'RESYNCHRONISATION_TRAITES' $user.account 'Analyse manuelle demandée'
      Json $r @{ok=$true;scheduled=[bool]$script:scanHandle};continue
    }
    if($path -eq '/api/priority' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$priority=[string]$b.priority
      if(!$x -or $priority -notin @('Basse','Normale','Haute','Urgente','HERITEE')){throw 'Document ou priorité invalide.'}
      $x.priority=if($priority -eq 'HERITEE'){$script:entityPriorities[$x.entity]}else{$priority};if(!$x.priority){$x.priority='Normale'};$x.priorityOverride=($priority -ne 'HERITEE');Event $x 'PRIORITE' $user.account $priority;SaveState
      Json $r @{ok=$true};continue
    }
    if($path -eq '/api/entity-priority' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$entity=([string]$b.entity).Trim();$priority=[string]$b.priority
      if($priority -notin @('Basse','Normale','Haute','Urgente') -or !$entity -or !@($script:tasks|Where-Object {$_.entity -ieq $entity}).Count){throw 'Entité ou priorité invalide.'}
      $script:entityPriorities[$entity]=$priority
      foreach($item in $script:tasks){if($item.entity -ieq $entity -and !$item.priorityOverride -and $item.status -in @('A_TRAITER','EN_COURS')){$item.priority=$priority}}
      SaveEntityPriorities;Audit 'PRIORITE_ENTITE' $user.account "$entity : $priority"
      Json $r @{ok=$true;entity=$entity;priority=$priority};continue
    }
    if($path -eq '/api/assign' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$assigned=Account ([string]$b.account)
      if(!$x -or $x.status -notin @('TRAITES','NON_CONFORME') -or !$assigned){throw 'Choisissez un dossier finalisé et un compte actif.'}
      $x.agent=$assigned.account;Event $x 'ATTRIBUTION_HISTORIQUE' $user.account $assigned.account;SaveState
      if($x.status -eq 'TRAITES'){SaveTreatedIndex}
      Json $r @{ok=$true};continue
    }
    if($path -eq '/api/audit'){
      $offset=[math]::Max(0,[int]$q.QueryString['offset']);$limit=[math]::Min(100,[math]::Max(1,[int]$q.QueryString['limit']))
      $count=$script:eventList.Count;$n=[math]::Min($limit,[math]::Max(0,$count-$offset))
      $items=for($i=0;$i -lt $n;$i++){$script:eventList[$count-1-$offset-$i]}
      Json $r @{total=$count;items=@($items)};continue
    }
    if($path -eq '/api/audit/export'){
      $rows=[Collections.Generic.List[string]]::new()
      [void]$rows.Add('Horodatage;Action;Compte_Windows;Document;Details')
      foreach($e in $script:eventList){
        $doc='';if($e.taskId -and $script:taskById.ContainsKey([string]$e.taskId)){$doc=$script:taskById[[string]$e.taskId].name}
        [void]$rows.Add((@((Csv $e.at),(Csv $e.kind),(Csv $e.agent),(Csv $doc),(Csv $e.detail)) -join ';'))
      }
      $bytes=[Text.Encoding]::UTF8.GetBytes([char]0xFEFF+($rows -join "`r`n"));$r.ContentType='text/csv; charset=utf-8';$r.AddHeader('Content-Disposition','attachment; filename=journal_audit_accessibilite.csv');$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();continue
    }
    if($path -eq '/api/state'){
      if($q.Headers['If-None-Match'] -eq ('"'+[string]$script:stateVersion+'"')){$r.StatusCode=304;$r.Close();continue}
      SendState $r;continue
    }
    if($path -in @('/api/traitements','/api/documents-traites')){
      $page=[math]::Max(1,[int]$q.QueryString['page']);$limit=[math]::Min(150,[math]::Max(1,[int]$q.QueryString['limit']))
      $status=if($path -eq '/api/documents-traites'){'TRAITES'}else{[string]$q.QueryString['status']}
      $entity=[string]$q.QueryString['entity'];$search=[string]$q.QueryString['q'];$mine=[string]$q.QueryString['mine'] -eq '1';$history=[string]$q.QueryString['history'] -eq '1'
      if($script:orderedVersion -ne $script:stateVersion){
        $script:orderedTasks=@($script:tasks | Sort-Object -Property @{Expression={switch($_.priority){'Urgente'{0};'Haute'{1};'Basse'{3};default{2}}}},@{Expression={[string]$_.createdAt};Descending=$true})
        $script:orderedVersion=$script:stateVersion
      }
      $offset=($page-1)*$limit;$total=0;$items=[Collections.Generic.List[object]]::new()
      foreach($task in $script:orderedTasks){
        if($status -and $status -ne [string]$task.status){continue}
        if($history -and $task.status -notin @('TRAITES','NON_CONFORME') -and !$task.finishedAt){continue}
        if($entity -and $entity -ine [string]$task.entity){continue}
        if($mine -and [string]$task.agent -ine [string]$user.account){continue}
        if($search -and (([string]$task.name+' '+[string]$task.entity+' '+[string]$task.branch+' '+[string]$task.agent).IndexOf($search,[StringComparison]::OrdinalIgnoreCase) -lt 0)){continue}
        if($total -ge $offset -and $items.Count -lt $limit){[void]$items.Add($task)}
        $total++
      }
      Json $r @{items=$items.ToArray();total=$total;page=$page;limit=$limit};continue
    }
    if($path -eq '/api/document' -and $q.HttpMethod -eq 'GET'){
      $x=FindTask ([string]$q.QueryString['id'])
      if(!$x -or (!(ExistsFile $x.currentPath) -and !(ExistsFile $x.historyPath))){throw 'Document introuvable.'}
      $source=if(ExistsFile $x.currentPath){$x.currentPath}else{$x.historyPath}
      $r.AddHeader('Content-Disposition',('attachment; filename="'+[uri]::EscapeDataString($x.name)+'"'))
      SendFile $r $source 'application/octet-stream';continue
    }
    if($path -eq '/api/take' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=[string]$user.account
      if(!$x -or $x.status -ne 'A_TRAITER' -or !$agent){throw 'Document ou agent invalide. Actualisez la liste.'}
      if(!(Test-Path -LiteralPath $x.currentPath -PathType Leaf)){throw 'Document absent du DP. Actualisez.'}
      $dest=Join-Path (Destination $x 'EN COURS') $x.name
      if(Test-Path -LiteralPath $dest){throw 'Un fichier existe déjà dans En cours.'}
      Move-Item -LiteralPath $x.currentPath -Destination $dest -ErrorAction Stop
      $old=$x.currentPath
      try{TrackPath $x $dest;$x.status='EN_COURS';$x.agent=$agent;$x.startedAt=(Get-Date).ToString('o');Event $x 'PRISE_EN_CHARGE' $agent $dest;SaveState}
      catch{Move-Item -LiteralPath $dest -Destination $old -ErrorAction SilentlyContinue;throw}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/upload/start' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$rootName=SafeName ([string]$b.root);$agent=[string]$user.account;if(!$agent){throw 'Agent requis.'}
      $id=[guid]::NewGuid().ToString();$folder=Join-Path $staging $id;New-Item -ItemType Directory -Path $folder | Out-Null
      $script:uploads[$id]=@{root=$rootName;agent=$agent;folder=$folder;files=0;bytes=0}
      Json $r @{ok=$true;uploadId=$id};continue
    }
    if($path -eq '/api/upload/file' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$upload=$script:uploads[[string]$b.uploadId]
      if(!$upload -or $upload.agent -ne $user.account){throw 'Transfert introuvable.'}
      $segments=@(([string]$b.relative).Replace('\','/') -split '/')
      if(!$segments.Count -or $segments.Count -gt 15){throw 'Chemin relatif invalide.'}
      foreach($seg in $segments){[void](SafeName $seg)}
      $relative=($segments -join [IO.Path]::DirectorySeparatorChar)
      $dest=EnsureUnder $upload.folder $relative
      $bytes=[Convert]::FromBase64String([string]$b.data)
      if($bytes.Length -gt 25000000 -or $upload.bytes+$bytes.Length -gt 250000000){throw 'Dossier trop volumineux (25 Mo par fichier, 250 Mo au total).'}
      if(Test-Path -LiteralPath $dest){throw 'Nom en double dans le dossier choisi.'}
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest)|Out-Null
      [IO.File]::WriteAllBytes($dest,$bytes);$upload.files++;$upload.bytes+=$bytes.Length
      Json $r @{ok=$true;count=$upload.files};continue
    }
    if($path -eq '/api/finish' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=[string]$user.account
      if(!$x -or $x.status -ne 'EN_COURS' -or ($x.agent -ine $agent -and $x.agent -ine ($agent -split '\\')[-1])){throw 'Traitement introuvable ou attribué à un autre agent.'}
      if($b.status -notin @('TRAITES','NON_CONFORME')){throw 'Statut final invalide.'}
      if($b.status -eq 'NON_CONFORME' -and ([string]::IsNullOrWhiteSpace($b.comment) -or [string]::IsNullOrWhiteSpace($b.solution))){throw 'Décrivez le problème et une proposition de solution.'}
      $b | Add-Member -NotePropertyName agent -NotePropertyValue $agent -Force
      $u=UploadFolder $b $x
      $finalStatus=if($b.status -eq 'TRAITES'){'TRAITES'}else{'NON CONFORME'}
      $dest=Join-Path (Destination $x $finalStatus) $u.root
      $archive=Join-Path $history $x.entity;if($x.prefix){$archive=Join-Path $archive $x.prefix};if($x.branch){$archive=Join-Path $archive $x.branch}
      New-Item -ItemType Directory -Force -Path $archive|Out-Null
      $archived=Join-Path $archive $x.name
      if(Test-Path -LiteralPath $archived){$archived=Join-Path $archive (('{0}_{1}{2}' -f $x.stem,(Get-Date -Format yyyyMMddHHmmss),[IO.Path]::GetExtension($x.name)))}
      Copy-Item -LiteralPath $x.currentPath -Destination $archived -ErrorAction Stop
      if((Get-Item -LiteralPath $archived).Length -ne (Get-Item -LiteralPath $x.currentPath).Length){Remove-Item -LiteralPath $archived -Force;throw 'Archive non vérifiée.'}
      try{CopyTree $u.folder $dest}catch{Remove-Item -LiteralPath $archived -Force -ErrorAction SilentlyContinue;throw}
      $oldPath=$x.currentPath
      $x.agent=$agent;$x.historyPath=$archived;$x.resultPath=$dest;TrackPath $x $dest;$x.status=[string]$b.status;$x.finishedAt=(Get-Date).ToString('o');$x.comment=[string]$b.comment;$x.solution=[string]$b.solution
      Event $x 'FIN_TRAITEMENT' $agent $finalStatus;SaveState
      if($x.status -eq 'TRAITES'){SaveTreatedIndex}
      try{Remove-Item -LiteralPath $oldPath -Force -ErrorAction Stop;Remove-Item -LiteralPath $u.folder -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.uploadId)}catch{$x.cleanupWarning=$_.Exception.Message;SaveState}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/rework' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=[string]$user.account
      if(!$x -or $x.status -ne 'NON_CONFORME' -or !$agent){throw 'Dossier non conforme introuvable.'}
      $b | Add-Member -NotePropertyName agent -NotePropertyValue $agent -Force
      $u=UploadFolder $b $x
      $dest=Join-Path (Destination $x 'TRAITES') $u.root
      CopyTree $u.folder $dest
      $old=$x.resultPath;$x.resultPath=$dest;TrackPath $x $dest;$x.status='TRAITES';$x.reworkedAt=(Get-Date).ToString('o')
      Event $x 'RETRAITEMENT' $agent ('NON_CONFORME vers TRAITES : '+[string]$b.comment);SaveState;SaveTreatedIndex
      try{if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction Stop};Remove-Item -LiteralPath $u.folder -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.uploadId)}catch{$x.cleanupWarning=$_.Exception.Message;SaveState}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/export'){
      $rows=@('NomFichier;Domaine;SousDomaine;Statut;Statut_2;Date_A_TRAITER;Date_FIN;Date_de_Retraitement;Agent;DMT_minutes;DMT2_minutes;Commentaire;Solution')
      foreach($x in $script:tasks){$dmt='';$dmt2='';if($x.startedAt -and $x.finishedAt){$dmt=[math]::Round(([datetime]$x.finishedAt-[datetime]$x.startedAt).TotalMinutes,2)};if($x.finishedAt -and $x.reworkedAt){$dmt2=[math]::Round(([datetime]$x.reworkedAt-[datetime]$x.finishedAt).TotalMinutes,2)}
        $rows+=(@((Csv $x.name),(Csv $x.entity),(Csv $x.branch),(Csv $x.status),(Csv $(if($x.reworkedAt){'NON_CONFORME -> TRAITES'}else{''})),(Csv $x.createdAt),(Csv $x.finishedAt),(Csv $x.reworkedAt),(Csv $x.agent),(Csv $dmt),(Csv $dmt2),(Csv $x.comment),(Csv $x.solution)) -join ';')}
      $bytes=[Text.Encoding]::UTF8.GetBytes([char]0xFEFF+($rows -join "`r`n"));$r.ContentType='text/csv; charset=utf-8';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();continue
    }
    if($path -eq '/' -or $path -in @('/agent','/manager','/app.js','/style.css')){
      $file=switch($path){'/'{'index.html'}'/agent'{'agent.html'}'/manager'{'manager.html'}'/app.js'{'app.js'}'/style.css'{'style.css'}}
      $type=if($file.EndsWith('.css')){'text/css; charset=utf-8'}elseif($file.EndsWith('.js')){'application/javascript; charset=utf-8'}else{'text/html; charset=utf-8'}
      SendFile $r (Join-Path (Join-Path $base 'web') $file) $type;continue
    }
    Json $r @{error='Route inconnue.'} 404
  }catch{Write-Host $_.Exception.Message -ForegroundColor Red;[IO.File]::AppendAllText($logFile,((Get-Date).ToString('o')+' '+$_.Exception.Message+"`r`n"),[Text.Encoding]::UTF8);try{Json $r @{error=$_.Exception.Message} 400}catch{}}
}

$listener.Stop()
Remove-Item -LiteralPath (Join-Path $base 'data\server.pid') -Force -ErrorAction SilentlyContinue
