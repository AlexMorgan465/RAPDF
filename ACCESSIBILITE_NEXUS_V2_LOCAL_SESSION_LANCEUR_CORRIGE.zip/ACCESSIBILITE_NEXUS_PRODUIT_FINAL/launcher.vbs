Option Explicit
Dim shell, fso, root, command, url, i, config, pattern, matches
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
url = "http://localhost:8090/"
If fso.FileExists(root & "\config.json") Then
  config = fso.OpenTextFile(root & "\config.json", 1, False).ReadAll
  Set pattern = New RegExp
  pattern.Pattern = """listenUrl""\s*:\s*""([^""]+)"""
  If pattern.Test(config) Then
    Set matches = pattern.Execute(config)
    url = matches(0).SubMatches(0)
  End If
End If
If shell.Run("cmd /c where pwsh.exe >nul 2>nul", 0, True) <> 0 Then
  MsgBox "PowerShell 7 (pwsh.exe) est introuvable. Lancez START_VISIBLE.bat pour le diagnostic.", vbExclamation, "Accessibilité Nexus"
  WScript.Quit
End If
If Not Ready(url) Then
  ' Arrête les anciennes instances Nexus de cette session avant la migration TCP.
  command = "pwsh.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & root & "\stop.ps1" & Chr(34)
  shell.Run command, 0, True
  command = "pwsh.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & root & "\server.ps1" & Chr(34)
  shell.Run command, 0, False
  For i = 1 To 48
    WScript.Sleep 250
    If Ready(url) Then Exit For
  Next
End If
If Ready(url) Then
  shell.Run url & "agent", 1, False
Else
  MsgBox "Le serveur n'a pas démarré. Lancez START_VISIBLE.bat et consultez data\server.log.", vbExclamation, "Accessibilité Nexus"
End If
Function Ready(address)
  On Error Resume Next
  Dim request
  Set request = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  request.setTimeouts 300, 300, 300, 300
  request.Open "GET", address & "api/version", False
  request.Send
  Ready = False
  If Err.Number = 0 Then Ready = (request.Status = 200 And InStr(request.responseText, "tcp-v2") > 0)
  Err.Clear
End Function
