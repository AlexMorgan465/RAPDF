$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$current=[Security.Principal.WindowsIdentity]::GetCurrent().Name
$stopped=0
# Arrête uniquement les instances Accessibilité Nexus de l'utilisateur courant.
foreach($item in @(Get-CimInstance Win32_Process -Filter "Name='pwsh.exe' OR Name='powershell.exe'")){
  if(!$item.CommandLine -or $item.ProcessId -eq $PID){continue}
  if($item.CommandLine -notmatch '(?i)[\\/]ACCESSIBILITE_NEXUS(?:_PRODUIT_FINAL)?[\\/]server\.ps1(?:["\s]|$)'){continue}
  try{
    $owner=$item | Invoke-CimMethod -MethodName GetOwner
    if($owner.ReturnValue -ne 0 -or ($owner.Domain+'\'+$owner.User) -ine $current){continue}
    Stop-Process -Id $item.ProcessId -ErrorAction Stop
    $stopped++
  }catch{Write-Warning $_.Exception.Message}
}
$pidFile=Join-Path $base 'data\server.pid'
if(Test-Path -LiteralPath $pidFile){
  try{$serverPid=[int]([IO.File]::ReadAllText($pidFile).Trim());if(!(Get-Process -Id $serverPid -ErrorAction SilentlyContinue)){Remove-Item -LiteralPath $pidFile -Force}}catch{}
}
Write-Host "$stopped serveur(s) Accessibilité Nexus de cette session arrêté(s)."
