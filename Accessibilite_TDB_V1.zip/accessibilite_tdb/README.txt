TDB ACCESSIBILITE
=================
1. Vérifier la variable -Root dans server.ps1. Par défaut :
   \\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE
2. Double-cliquer START.bat.
3. Ouvrir http://localhost:8787
4. Pour les autres PC du LAN : http://IP_DU_SERVEUR:8787 (pare-feu/URLACL selon politique IT).

Sécurité fonctionnelle :
- Le scan est en lecture seule.
- Le serveur n'édite, ne renomme et ne supprime aucun document.
- Une écriture sur le DP n'arrive que lorsqu'un utilisateur confirme un déplacement de statut.
- Les transitions sont limitées aux règles prévues.
- Chaque mouvement est journalisé dans data/journal.json.
- Les mouvements manuels détectés au scan sont aussi journalisés comme EXTERNE.
- DMT = temps cumulé passé dans EN COURS; compteur live tant que le document y reste.

IMPORTANT DATE DEPOT :
La date de dernière modification n'est pas une vraie date de dépôt. La V1 l'utilise comme estimation initiale, puis le journal fournit des horodatages fiables pour les mouvements effectués/détectés après démarrage.
