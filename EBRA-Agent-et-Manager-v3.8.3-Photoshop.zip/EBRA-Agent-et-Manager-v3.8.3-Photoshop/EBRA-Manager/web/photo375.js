(()=>{'use strict';
const $=id=>document.getElementById(id),canvas=$('photo-canvas');if(!canvas)return;const ctx=canvas.getContext('2d',{willReadFrequently:true});let source=document.createElement('canvas'),sctx=source.getContext('2d',{willReadFrequently:true}),loaded=false,tool='crop',drawing=false,start=null,selection=null,outline=[],history=[],future=[],original=null;
const controls=['photo-brightness','photo-contrast','photo-saturation','photo-grayscale','photo-sepia','photo-blur'];
function filters(){return`brightness(${$('photo-brightness').value}%) contrast(${$('photo-contrast').value}%) saturate(${$('photo-saturation').value}%) grayscale(${$('photo-grayscale').value}%) sepia(${$('photo-sepia').value}%) blur(${$('photo-blur').value}px)`}
function neutralFilters(){return $('photo-brightness').value==='100'&&$('photo-contrast').value==='100'&&$('photo-saturation').value==='100'&&$('photo-grayscale').value==='0'&&$('photo-sepia').value==='0'&&$('photo-blur').value==='0'}
function resetFilters(){for(const id of controls){const e=$(id);e.value=id.includes('grayscale')||id.includes('sepia')||id.includes('blur')?0:100;e.dispatchEvent(new Event('input'))}}
function fitCanvas(){/* Taille affichée par photo375.css, compatible CSP. */}
function render(){if(!loaded)return;canvas.width=source.width;canvas.height=source.height;ctx.clearRect(0,0,canvas.width,canvas.height);ctx.save();ctx.filter=filters();ctx.globalCompositeOperation='source-over';ctx.drawImage(source,0,0);ctx.restore();if(selection){ctx.save();ctx.strokeStyle='#36b9ff';ctx.lineWidth=Math.max(2,canvas.width/500);ctx.setLineDash([10,7]);ctx.fillStyle='#36b9ff20';ctx.fillRect(selection.x,selection.y,selection.w,selection.h);ctx.strokeRect(selection.x,selection.y,selection.w,selection.h);ctx.restore()}if(outline.length){ctx.save();ctx.strokeStyle='#ff5c35';ctx.lineWidth=Math.max(3,canvas.width/250);ctx.setLineDash([8,5]);ctx.beginPath();outline.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));ctx.stroke();ctx.restore()}$('photo-empty').hidden=true;$('photo-wrap').hidden=false;fitCanvas();$('photo-width').value=source.width;$('photo-height').value=source.height;$('photo-status').textContent=`${source.width} × ${source.height} px · ${tool==='crop'?'Sélectionnez une zone à recadrer':tool==='brush'?'Pinceau actif':tool==='eraser'?'Gomme active':'Prêt'}`}
function snapshot(){if(!loaded)return;history.push(source.toDataURL('image/png'));if(history.length>20)history.shift();future=[]}
function restore(data){const img=new Image;img.onload=()=>{source.width=img.width;source.height=img.height;sctx=source.getContext('2d',{willReadFrequently:true});sctx.drawImage(img,0,0);selection=null;resetFilters();render()};img.src=data}
function commitFilters(){if(!loaded)return;if(neutralFilters())return;const temp=document.createElement('canvas');temp.width=source.width;temp.height=source.height;const t=temp.getContext('2d');t.filter=filters();t.drawImage(source,0,0);source=temp;sctx=source.getContext('2d',{willReadFrequently:true});resetFilters()}
function point(e){const r=canvas.getBoundingClientRect();return{x:(e.clientX-r.left)*canvas.width/r.width,y:(e.clientY-r.top)*canvas.height/r.height}}
function setTool(name){tool=name;selection=null;outline=[];document.querySelectorAll('[data-photo-tool]').forEach(b=>b.classList.toggle('active',b.dataset.photoTool===name));render()}
function transform(kind){if(!loaded)return;snapshot();commitFilters();const out=document.createElement('canvas'),o=out.getContext('2d');if(kind==='left'||kind==='right'){out.width=source.height;out.height=source.width;o.translate(out.width/2,out.height/2);o.rotate((kind==='right'?1:-1)*Math.PI/2);o.drawImage(source,-source.width/2,-source.height/2)}else{out.width=source.width;out.height=source.height;o.translate(kind==='flipH'?out.width:0,kind==='flipV'?out.height:0);o.scale(kind==='flipH'?-1:1,kind==='flipV'?-1:1);o.drawImage(source,0,0)}source=out;sctx=source.getContext('2d',{willReadFrequently:true});render()}
async function decodeSelectedImage(file){
  if(!file)throw new Error('Aucun fichier sélectionné.');
  const bytes=await file.arrayBuffer();
  if(!bytes.byteLength)throw new Error('Le fichier sélectionné est vide.');
  const blob=new Blob([bytes],{type:file.type||'application/octet-stream'});
  if('createImageBitmap' in window){
    try{return await createImageBitmap(blob)}catch(_error){}
  }
  const dataUrl=await new Promise((resolve,reject)=>{
    const reader=new FileReader();
    reader.onload=()=>resolve(reader.result);
    reader.onerror=()=>reject(reader.error||new Error('Lecture impossible.'));
    reader.readAsDataURL(blob);
  });
  return await new Promise((resolve,reject)=>{
    const img=new Image();
    img.onload=()=>resolve(img);
    img.onerror=()=>reject(new Error('Décodage impossible.'));
    img.src=dataUrl;
  });
}
$('photo-file').addEventListener('change',async e=>{
  const file=e.target.files&&e.target.files[0];if(!file)return;
  const status=$('photo-status');status.textContent='Chargement de l’image locale…';
  try{
    const img=await decodeSelectedImage(file);
    const width=img.naturalWidth||img.width,height=img.naturalHeight||img.height;
    if(!width||!height)throw new Error('Dimensions invalides.');
    source.width=width;source.height=height;
    sctx=source.getContext('2d',{willReadFrequently:true});
    sctx.clearRect(0,0,width,height);sctx.drawImage(img,0,0,width,height);
    if(typeof img.close==='function')img.close();
    loaded=true;history=[];future=[];selection=null;outline=[];
    original=source.toDataURL('image/png');
    const before=$('photo-before-preview');if(before){before.width=width;before.height=height;before.getContext('2d').drawImage(source,0,0)}
    resetFilters();render();status.textContent='Image importée. Pour isoler le portrait, choisissez Contour manuel, tracez le sujet puis appliquez.';
  }catch(error){
    loaded=false;
    status.textContent='Impossible de charger cette image : '+(error&&error.message?error.message:'format non reconnu.');
    console.error('EBRA Photo — import local',error);
  }finally{
    e.target.value='';
  }
});
for(const id of controls){const e=$(id),out=$(id+'-value');e.oninput=()=>{out.textContent=e.value+(id==='photo-blur'?' px':'%');render()}}
document.querySelectorAll('[data-photo-tool]').forEach(b=>b.onclick=()=>setTool(b.dataset.photoTool));
document.querySelectorAll('[data-photo-transform]').forEach(b=>b.onclick=()=>transform(b.dataset.photoTransform));
canvas.onpointerdown=e=>{if(!loaded)return;const p=point(e);if(tool==='outline'){outline=[p];drawing=true;canvas.setPointerCapture(e.pointerId);render()}else if(tool==='crop'){start=p;selection={x:p.x,y:p.y,w:0,h:0};drawing=true;canvas.setPointerCapture(e.pointerId);render()}else if(tool==='brush'||tool==='eraser'){snapshot();commitFilters();drawing=true;start=p;sctx.beginPath();sctx.moveTo(p.x,p.y);canvas.setPointerCapture(e.pointerId)}};
canvas.onpointermove=e=>{if(!drawing)return;const p=point(e);if(tool==='outline'){if(Math.hypot(p.x-outline[outline.length-1].x,p.y-outline[outline.length-1].y)>Math.max(2,source.width/350)){outline.push(p);render()}}else if(tool==='crop'){selection={x:Math.min(start.x,p.x),y:Math.min(start.y,p.y),w:Math.abs(p.x-start.x),h:Math.abs(p.y-start.y)};render()}else{sctx.lineCap='round';sctx.lineJoin='round';sctx.lineWidth=Number($('photo-brush-size').value);sctx.globalCompositeOperation=tool==='eraser'?'destination-out':'source-over';sctx.strokeStyle=$('photo-color').value;sctx.lineTo(p.x,p.y);sctx.stroke();start=p;render()}};
canvas.onpointerup=()=>{if(tool==='outline'&&outline.length>2){render();$('photo-status').textContent='Contour tracé. Cliquez sur Isoler le sujet.'}drawing=false;sctx.globalCompositeOperation='source-over'};
$('photo-apply-crop').onclick=()=>{if(!selection||selection.w<2||selection.h<2)return;snapshot();commitFilters();const x=Math.round(selection.x),y=Math.round(selection.y),w=Math.round(selection.w),h=Math.round(selection.h),out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,x,y,w,h,0,0,w,h);source=out;sctx=source.getContext('2d',{willReadFrequently:true});selection=null;render()};
$('photo-add-text').onclick=()=>{if(!loaded)return;const text=$('photo-text').value.trim();if(!text)return;snapshot();commitFilters();sctx.save();sctx.font=`700 ${Number($('photo-font-size').value)}px Segoe UI,Arial`;sctx.textAlign='center';sctx.textBaseline='middle';sctx.fillStyle=$('photo-color').value;sctx.fillText(text,source.width/2,source.height/2);sctx.restore();render()};
$('photo-resize').onclick=()=>{if(!loaded)return;const w=Math.max(1,Number($('photo-width').value)),h=Math.max(1,Number($('photo-height').value));snapshot();commitFilters();const out=document.createElement('canvas');out.width=w;out.height=h;out.getContext('2d').drawImage(source,0,0,w,h);source=out;sctx=source.getContext('2d',{willReadFrequently:true});render()};
$('photo-undo').onclick=()=>{if(!history.length||!loaded)return;future.push(source.toDataURL('image/png'));restore(history.pop())};$('photo-redo').onclick=()=>{if(!future.length||!loaded)return;history.push(source.toDataURL('image/png'));restore(future.pop())};$('photo-reset').onclick=()=>{if(original){snapshot();restore(original)}};
$('photo-brush-size').oninput=e=>$('photo-brush-size-value').textContent=e.target.value+' px';
$('photo-export').onclick=()=>{if(!loaded)return;const savedSelection=selection;selection=null;render();const format=$('photo-format').value,mime=format==='jpg'?'image/jpeg':'image/png',name='EBRA-image-'+new Date().toISOString().slice(0,19).replace(/[:T]/g,'-')+'.'+format;canvas.toBlob(blob=>{const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);selection=savedSelection;render()},mime,Number($('photo-quality').value)/100)};
function setupBackgroundRemoval(){
  const panel=$('photo-file').closest('.photo-panel'),stage=canvas.closest('.photo-stage');
  const box=document.createElement('div');box.className='photo-cutout-box';box.innerHTML='<h3>Détourage du portrait</h3><button type="button" class="photo-tool" data-photo-tool="outline" id="photo-outline-tool">✎ Contour manuel</button><button type="button" class="primary" id="photo-apply-outline">✓ Isoler le sujet</button><p class="photo-cutout-help">Tracez le bord du portrait en maintenant le clic, puis cliquez sur Isoler le sujet. Utilisez Annuler pour recommencer.</p><label class="photo-control">Sensibilité <output id="photo-cutout-value">38 %</output><input id="photo-cutout-sensitivity" type="range" min="15" max="75" value="38"></label><label class="photo-control">Arrière-plan<select id="photo-cutout-background"><option value="white">Fond blanc</option><option value="transparent">Transparent</option></select></label><button id="photo-cutout" type="button" class="primary">Essai automatique (fond uni)</button><p class="photo-cutout-help">Utilisez ensuite le pinceau ou la gomme pour affiner les contours.</p>';
  panel.appendChild(box);
  const currentEmpty=$('photo-empty'),currentWrap=$('photo-wrap');
  const compare=document.createElement('div');compare.className='photo-before-after';compare.innerHTML='<div class="photo-preview-pane"><span>AVANT</span><div class="photo-preview-bg"><canvas id="photo-before-preview" aria-label="Image originale"></canvas></div></div><div class="photo-preview-pane"><span>APRÈS</span><div id="photo-after-host" class="photo-preview-bg"></div></div>';
  stage.appendChild(compare);const host=compare.querySelector('#photo-after-host');host.appendChild(currentEmpty);host.appendChild(currentWrap);
  
  $('photo-outline-tool').onclick=()=>setTool('outline');
  $('photo-apply-outline').onclick=applyOutline;
  $('photo-cutout-sensitivity').oninput=e=>$('photo-cutout-value').textContent=e.target.value+' %';
  $('photo-cutout').onclick=removeBackground;
}
function applyOutline(){
  if(!loaded||outline.length<3){$('photo-status').textContent='Tracez d’abord le contour du sujet sur l’image Après.';return}
  snapshot();commitFilters();const mask=document.createElement('canvas');mask.width=source.width;mask.height=source.height;
  const m=mask.getContext('2d');m.fillStyle='#fff';m.beginPath();outline.forEach((p,i)=>i?m.lineTo(p.x,p.y):m.moveTo(p.x,p.y));m.closePath();m.fill();
  sctx.save();sctx.globalCompositeOperation='destination-in';sctx.drawImage(mask,0,0);sctx.restore();
  if($('photo-cutout-background').value==='white'){
    const out=document.createElement('canvas');out.width=source.width;out.height=source.height;const o=out.getContext('2d');o.fillStyle='#fff';o.fillRect(0,0,out.width,out.height);o.drawImage(source,0,0);source=out;sctx=source.getContext('2d',{willReadFrequently:true});
  }
  outline=[];selection=null;render();$('photo-status').textContent='Sujet isolé. Vous pouvez annuler ou exporter le résultat.';
}
function removeBackground(){
  if(!loaded){$('photo-status').textContent='Importez d’abord une image.';return}
  snapshot();commitFilters();$('photo-status').textContent='Détourage en cours…';
  setTimeout(()=>{
    const w=source.width,h=source.height,data=sctx.getImageData(0,0,w,h),px=data.data,n=w*h;
    const sensitivity=Number($('photo-cutout-sensitivity').value),localLimit=22+sensitivity*.72,paletteLimit=36+sensitivity*1.45;
    const palette=[],step=Math.max(1,Math.floor(Math.min(w,h)/90));
    const add=(x,y)=>{const i=(y*w+x)*4;palette.push([px[i],px[i+1],px[i+2]])};
    for(let x=0;x<w;x+=step){add(x,0);if(h>2)add(x,Math.min(h-1,Math.floor(h*.035)))}
    for(let y=0;y<h;y+=step){add(0,y);add(w-1,y)}
    const bg=new Uint8Array(n),queue=new Int32Array(n);let head=0,tail=0;
    const seed=(x,y)=>{const p=y*w+x;if(!bg[p]){bg[p]=1;queue[tail++]=p}};
    for(let x=0;x<w;x+=Math.max(1,step>>1))seed(x,0);
    for(let y=0;y<h;y+=Math.max(1,step>>1)){seed(0,y);seed(w-1,y)}
    const colorDistance=(i,c)=>{const dr=px[i]-c[0],dg=px[i+1]-c[1],db=px[i+2]-c[2];return Math.sqrt(dr*dr*.3+dg*dg*.59+db*db*.11)};
    const nearPalette=i=>{for(let k=0;k<palette.length;k++)if(colorDistance(i,palette[k])<paletteLimit)return true;return false};
    const visit=(from,to)=>{if(to<0||to>=n||bg[to])return;const a=from*4,b=to*4,dr=px[a]-px[b],dg=px[a+1]-px[b+1],db=px[a+2]-px[b+2],d=Math.sqrt(dr*dr*.3+dg*dg*.59+db*db*.11);if(d<=localLimit&&nearPalette(b)){bg[to]=1;queue[tail++]=to}};
    while(head<tail){const p=queue[head++],x=p%w;visit(p,p-w);visit(p,p+w);if(x)visit(p,p-1);if(x<w-1)visit(p,p+1)}
    if(tail>n*.82){history.pop();$('photo-status').textContent='Détourage interrompu : trop de pixels seraient effacés. Essayez une sensibilité plus faible.';return}
    const white=$('photo-cutout-background').value==='white';
    for(let p=0;p<n;p++){if(!bg[p])continue;const i=p*4;if(white){px[i]=255;px[i+1]=255;px[i+2]=255;px[i+3]=255}else px[i+3]=0}
    sctx.putImageData(data,0,0);selection=null;render();$('photo-status').textContent='Détourage terminé · utilisez Annuler si vous souhaitez modifier la sensibilité.';
  },30)
}
setupBackgroundRemoval();
setTool('crop');
window.addEventListener('resize',()=>{if(loaded)fitCanvas()});
})();
