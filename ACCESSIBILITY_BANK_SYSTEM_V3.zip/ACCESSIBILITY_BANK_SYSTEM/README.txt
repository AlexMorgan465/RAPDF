ACCESSIBILITE BANK SYSTEM — V3

INSTALLATION
1. Fermer les anciennes sessions Agent et Manager (Déconnexion).
2. Extraire le ZIP et remplacer le dossier applicatif complet. Garder AGENT,
   MANAGER et COMMON ensemble. Aucun fichier du DP ne doit être supprimé.
3. Vérifier COMMON\settings.ps1 : même chemin partagé sur chaque poste.
4. Lancer MANAGER\START_MANAGER.bat ou AGENT\START_AGENT.bat.
   Manager : http://localhost:8790 — Agent : http://localhost:8788.
   En cas d'erreur au lancement : utiliser START_DEBUG.bat.

FONCTIONS
- Documents structurés par entité, sous-entité et dépôt initial.
- Dépôt = LastWriteTimeUtc au premier scan. Conservé dans le registre partagé,
  sans changement aux actualisations ni aux déplacements de cette application.
- Pour les documents déjà traités avant installation, le dépôt réel antérieur
  n'est pas récupérable : la première modification observée est utilisée.
  La date de fin historique est récupérée du journal existant si disponible ;
  sinon la modification initiale sert d'estimation pour les documents traités.
- Manager : priorités, facturation, non-conformités, reporting, consolidation.
- Agent : urgences, PEC, document complexe et commentaire libre.
- Les deux rôles peuvent déplacer entre tous les quatre statuts, y compris
  les retours EN COURS -> A TRAITER et NON CONFORME -> tous les statuts.
- Chaque mouvement physique est protégé par un verrou commun à tous les
  serveurs. La seconde PEC reçoit « déjà pris ou déplacé ».
- Durée cumulée par statut dans la fiche document ; DMT des passages EN COURS
  dans l'historique. Durées antérieures inconnues non inventées.
- Mails préparés par document ou par entité avec motif. Brouillon modifiable,
  copier ou ouvrir dans la messagerie ; aucun envoi automatique.
- Interfaces sombre/clair, recherche, filtres, export CSV compatible Excel.

FACTURATION
- Une ligne = un document / dossier actuellement TRAITES. Pas de facturation
  des passages successifs du même document. Mois = dernière fin de traitement.
- Quantité x prix unitaire. Tarif entité mémorisé à la fin du traitement.
  Prix individuel modifiable dans « Gérer » ; vide = tarif mémorisé / entité.
- Tarifs de la capture : 9 pour Bouygues telecom, CONTRATHEQUE, CMO, ACM,
  DIRCOM, MONABANQ, CREATIS ; 4,5 pour DIRCO, CMMABN,
  CIC CIB ASSET SERVICING. Les doublons CMMABN de la capture sont fusionnés.
- COFIDIS FRANCE : tarif non présent sur la capture, à renseigner.
- Devise non précisée : montants affichés en unités. Prix manquants signalés,
  total partiel tant qu'ils ne sont pas renseignés. Prix zéro accepté.
- Les changements du tarif entité s'appliquent aux nouvelles fins de traitement,
  pas aux tarifs déjà mémorisés. Pour corriger une ancienne ligne : prix document.

SCANS ET PARTAGE
- Chaque interface vérifie les changements une fois par seconde avec une
  requête légère. Le registre est chargé uniquement lorsqu'il a changé.
- Scan automatique toutes les 30 secondes tant qu'un serveur est lancé ;
  les autres serveurs évitent les scans rapprochés (25 secondes minimum).
- Les mouvements faits dans l'interface sont publiés immédiatement dans le
  registre ; visibles au prochain rafraîchissement d'une seconde.
- « Actualiser le scan » force un scan. Un déplacement fait avec Explorer est
  détecté au prochain scan, avec une date de constat et l'agent SCAN EXTERNE.
- PDF, DOC, DOCX et dossiers de premier niveau sont les unités suivies,
  comme dans le projet d'origine. Le contenu interne d'un dossier n'est pas
  compté une seconde fois. A PUBLIER n'est pas un des quatre statuts de ce ZIP.
- Un même nom dans une même entité/sous-entité présent dans plusieurs statuts
  est signalé comme doublon : pas de fusion silencieuse. Renommages externes :
  considérés comme nouveaux documents ; utiliser les déplacements du logiciel
  pour conserver la date et l'identité.
- Les opérations.jsonl existantes sont importées lors de la création du registre
  V3. Elles restent intactes. Toutes les nouvelles écritures utilisent
  <DP>\.accessibility_history\registry-v3.json.
- Ne pas mélanger ancienne et nouvelle version : les anciens serveurs ne
  participent pas au verrou commun et continueraient à écrire l'ancien journal.
- Les agents doivent pouvoir lire/écrire dans le dossier partagé et déplacer
  les documents. Aucun appel Internet, aucune dépendance externe.

VALIDATION
Logique JS vérifiée : filtres ISO/date, prix individuel et tarif mémorisé,
prix manquant, durées cumulées. Parcours des vues Agent/Manager vérifiés avec
une API simulée : navigation, détails, urgences, facturation et PEC.
Le serveur PowerShell et les accès au partage Windows ne peuvent pas être
exécutés dans l'environnement Linux de préparation. Avant utilisation en
production, lancer TESTS\TEST_LOCAL.bat sous Windows : il vérifie dépôt figé,
mouvements physiques, double PEC, historique, complexité et tarifs dans un
répertoire temporaire isolé (sans toucher au DP). Ensuite tester avec le DP
habituel et deux postes. START_DEBUG.bat affiche les erreurs de lancement.
