﻿param([int]$Port=8788,[string]$RootPath='')
. (Join-Path $PSScriptRoot '..\COMMON\settings.ps1')
if(!$RootPath){$RootPath=$SharedRoot}
& (Join-Path $PSScriptRoot '..\COMMON\server.ps1') -Port $Port -RootPath $RootPath -Role 'AGENT' -AppPath $PSScriptRoot
