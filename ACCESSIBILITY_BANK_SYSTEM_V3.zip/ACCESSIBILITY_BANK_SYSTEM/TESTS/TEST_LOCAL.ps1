﻿$ErrorActionPreference='Stop'
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('AccessibilityTest-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($testRoot)|Out-Null
try{
 . (Join-Path $PSScriptRoot '..\COMMON\core.ps1') -RootPath $testRoot
 function Assert($condition,$message){if(!$condition){throw ('ECHEC : '+$message)};Write-Host ('OK : '+$message) -ForegroundColor Green}
 $p=BranchPath 'DIRCO' 'A TRAITER' 'CM';[IO.Directory]::CreateDirectory($p)|Out-Null
 $f=Join-Path $p 'test.pdf';[IO.File]::WriteAllText($f,'Fixture');[IO.File]::SetLastWriteTimeUtc($f,[datetime]'2026-09-01T10:00:00Z')
 $db=Scan $true;$d=@($db.documents)[0];$id=$d.id;$deposit=$d.depositAt
 Assert ($deposit -eq '2026-09-01T10:00:00.0000000Z') 'Depot = modification au premier scan'
 EditDocument ([pscustomobject]@{id=$id;complex=$true;complexComment='Tableau difficile';priority=$true;priorityComment='Urgent';unitPrice=0}) 'MANAGER'|Out-Null
 MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='EN COURS';comment='PEC'})|Out-Null
 $conflict=$false;try{MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='EN COURS'})|Out-Null}catch{$conflict=$true}
 Assert $conflict 'Double PEC refusee'
 Assert (Test-Path -LiteralPath (Join-Path (BranchPath 'DIRCO' 'EN COURS' 'CM') 'test.pdf')) 'Fichier deplace physiquement'
 MoveDocument ([pscustomobject]@{id=$id;from='EN COURS';to='NON CONFORME';comment='Contraste'})|Out-Null
 MoveDocument ([pscustomobject]@{id=$id;from='NON CONFORME';to='A TRAITER';comment='Retour'})|Out-Null
 MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='TRAITES';comment='Conforme'})|Out-Null
 $f=Join-Path (BranchPath 'DIRCO' 'TRAITES' 'CM') 'test.pdf';[IO.File]::SetLastWriteTimeUtc($f,[datetime]'2026-10-07T10:00:00Z')
 $db=Scan $true;$d=FindDoc $db $id
 Assert ($d.depositAt -eq $deposit) 'Depot conserve apres mouvements et scans'
 Assert ($d.complex -and $d.priority -and $d.complexComment -eq 'Tableau difficile') 'Complexite et priorite conservees'
 Assert ($d.unitPrice -eq 0) 'Prix individuel nul conserve'
 Assert ($d.billedPrice -eq 4.5) 'Tarif DIRCO memorise a la fin'
 Assert (@($d.periods).Count -eq 4) 'Durees de chaque passage historisees'
 Assert (@($db.history).Count -eq 4) 'Historique sans doublon de PEC'
 EditRate ([pscustomobject]@{entity='DIRCO';price=9})|Out-Null
 $d=FindDoc (ReadDb) $id;Assert ($d.billedPrice -eq 4.5) 'Modification du tarif ne change pas le tarif memorise'
 # Corruption: aucun remplacement silencieux du registre
 [IO.File]::WriteAllText($DbFile,'{INVALID');$rejected=$false;try{ReadDb|Out-Null}catch{$rejected=$true}
 Assert $rejected 'Registre invalide refuse sans ecrasement'
 Write-Host 'Tous les tests locaux ont reussi.' -ForegroundColor Green
}finally{Remove-Item -LiteralPath $testRoot -Recurse -Force}
