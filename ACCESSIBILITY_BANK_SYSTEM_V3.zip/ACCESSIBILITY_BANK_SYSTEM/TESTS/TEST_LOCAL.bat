@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0TEST_LOCAL.ps1"
pause
