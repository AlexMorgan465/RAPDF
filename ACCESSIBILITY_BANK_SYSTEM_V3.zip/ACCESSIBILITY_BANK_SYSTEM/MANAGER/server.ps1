﻿param([int]$Port=8790,[string]$RootPath='')
. (Join-Path $PSScriptRoot '..\COMMON\settings.ps1')
if(!$RootPath){$RootPath=$SharedRoot}
& (Join-Path $PSScriptRoot '..\COMMON\server.ps1') -Port $Port -RootPath $RootPath -Role 'MANAGER' -AppPath $PSScriptRoot
