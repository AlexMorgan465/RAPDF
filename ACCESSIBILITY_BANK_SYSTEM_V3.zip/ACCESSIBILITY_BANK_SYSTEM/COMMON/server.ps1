﻿param([int]$Port,[string]$RootPath,[string]$Role,[string]$AppPath)
. (Join-Path $PSScriptRoot 'core.ps1') -RootPath $RootPath
$scanJob=Start-Job -ArgumentList (Join-Path $PSScriptRoot 'core.ps1'),$RootPath -ScriptBlock {param($core,$root);. $core -RootPath $root;while($true){try{Scan|Out-Null}catch{};Start-Sleep -Seconds 30}}
$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Start-Process "http://localhost:$Port/"
try{$run=$true;while($run){$c=$l.GetContext();try{
 $r=$c.Request;$p=$r.Url.AbsolutePath
 if($r.HttpMethod-eq'POST'-and$r.Headers['X-Workflow']-ne'bank-v3'){Send $c 403 @{error='Requête non autorisée'};continue}
 if($p-in@('/','/app.js','/style.css')){$name=if($p-eq'/'){'index.html'}else{$p.TrimStart('/')};$file=Join-Path $AppPath $name;$bytes=[IO.File]::ReadAllBytes($file);$c.Response.ContentType=@{'index.html'='text/html; charset=utf-8';'app.js'='application/javascript; charset=utf-8';'style.css'='text/css; charset=utf-8'}[$name];$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue}
 if($p-eq'/api/revision'){$info=New-Object IO.FileInfo($DbFile);$revision=if($info.Exists){[string]$info.LastWriteTimeUtc.Ticks+':'+[string]$info.Length}else{'initializing'};Send $c 200 @{revision=$revision};continue}
 if($p-eq'/api/state'){$db=ReadDb;Send $c 200 @{role=$Role;agent=[Environment]::UserName;root=$RootPath;exists=[IO.Directory]::Exists($RootPath);documents=@($db.documents);history=@($db.history);rates=@($db.rates);scannedAt=$db.scannedAt;scanErrors=@($db.scanErrors)};continue}
 if($p-eq'/api/schema'){$a=@();foreach($e in $Schema.Keys){$a+=@{entity=$e;branches=@($Schema[$e].Branches)}};Send $c 200 @{entities=$a};continue}
 if($r.HttpMethod-ne'POST'){Send $c 405 @{error='Méthode invalide'};continue}
 $body=Body $r
 switch($p){
 '/api/fullscan' {Send $c 200 @{ok=$true;scannedAt=(Scan $true).scannedAt}}
 '/api/move' {Send $c 200 (MoveDocument $body)}
 '/api/edit' {Send $c 200 (EditDocument $body $Role)}
 '/api/rate' {if($Role-ne'MANAGER'){throw 'Réservé au manager'};Send $c 200 (EditRate $body)}
 '/api/open' {Send $c 200 (OpenDocument $body)}
 '/api/leave' {Send $c 200 @{ok=$true};$run=$false}
 default {Send $c 404 @{error='Route inconnue'}}
 }
 }catch{try{Send $c 409 @{error=$_.Exception.Message}}catch{}}}}finally{Stop-Job $scanJob;Remove-Job $scanJob -Force;$l.Stop();$l.Close()}
