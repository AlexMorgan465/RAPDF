﻿# Chemin commun à tous les postes. Modifier uniquement cette ligne si nécessaire.
$SharedRoot='\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE'
