﻿param([string]$RootPath)
$ErrorActionPreference="Stop"
$Schema=[ordered]@{
"ACM"=@{Mode="STATUS_FIRST";Branches=@("ASS-BIENS","ASS-COMPTA-CONTENTIEUX","ASS-EMPRUNTEURS","ASS-INDEMN-BIENS-PERS","ASS-PERS-COLL","ASS-PERS-IND","ASS-PROTECTION-JUR","ASS-VIE-EPARGNE-RET\MONABANQ - VIE","ASS-VIE-EPARGNE-RET\RETRAITE COLLECTIVE")}
"Bouygues telecom"=@{Mode="SIMPLE";Branches=@("")}
"CIC CIB ASSET SERVICING"=@{Mode="STATUS_FIRST";Branches=@("Agence Clientèle Déposée")}
"CMMABN"=@{Mode="SIMPLE";Branches=@("")}
"CMO"=@{Mode="STATUS_FIRST";Branches=@("BAD","Cartes bancaires","Compte courant","Epargne bancaire","Epargne financière","Packages","Tarif")}
"COFIDIS FRANCE"=@{Mode="STATUS_FIRST";Branches=@("COFIDIS FRANCE-DMA\DMA – Agence WEB","COFIDIS FRANCE-DMA\DMA – Marque et Stratégie","COFIDIS FRANCE-DMA\DMA – Performance Digitale","COFIDIS FRANCE-DPA\DPA – Domaine Marketing","COFIDIS FRANCE-DPA\DPA – Service Marketing","COFIDIS FRANCE-DPA\DPA – Service Relation")}
"CONTRATHEQUE"=@{Mode="CATEGORY_FIRST";Branches=@("CONDITIONS GENERALES","DOCUMENT D'INFORMATION TARIFAIRE","GARANTIES","POLITIQUE DE PROTECTION")}
"CREATIS"=@{Mode="SIMPLE";Branches=@("")}
"DIRCO"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"DIRCOM"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"MONABANQ"=@{Mode="SIMPLE";Branches=@("")}
}
$Statuses=@("A TRAITER","EN COURS","NON CONFORME","TRAITES")
function J($o){$o|ConvertTo-Json -Depth 8 -Compress}
function Send($c,$code,$o){$b=[Text.Encoding]::UTF8.GetBytes((J $o));$c.Response.StatusCode=$code;$c.Response.ContentType="application/json; charset=utf-8";$c.Response.Headers["Cache-Control"]="no-store";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Q($r){$h=@{};if($r.Url.Query.Length-gt 1){foreach($p in $r.Url.Query.Substring(1).Split("&")){$k=$p.Split("=",2);if($k.Count-eq 2){$h[[Uri]::UnescapeDataString($k[0])] = [Uri]::UnescapeDataString(($k[1]-replace '\+',' '))}}};$h}
function Body($r){$sr=New-Object IO.StreamReader($r.InputStream,$r.ContentEncoding);$t=$sr.ReadToEnd();$sr.Close();if(!$t){return @{}};$t|ConvertFrom-Json}
function BranchPath($e,$s,$b){
 if(!$Schema.Contains($e)){throw "Entité inconnue: $e"}; if($Statuses-notcontains$s){throw "Statut invalide"}
 $cfg=$Schema[$e];if(@($cfg.Branches) -notcontains [string]$b){throw "Sous-entité invalide"};$p=Join-Path $RootPath $e
 if($cfg.Mode-eq"CATEGORY_FIRST"){if(!$b){throw "Sous-entité requise"};return Join-Path (Join-Path $p $b) $s}
 $p=Join-Path $p $s;if($b){$p=Join-Path $p $b};$p
}
$HistoryRoot=Join-Path $RootPath '.accessibility_history'
$DbFile=Join-Path $HistoryRoot 'registry-v3.json'
$LockFile=Join-Path $HistoryRoot 'registry-v3.lock'
$DefaultRates=@{'Bouygues telecom'=9;'CONTRATHEQUE'=9;'CMO'=9;'DIRCO'=4.5;'ACM'=9;'CMMABN'=4.5;'DIRCOM'=9;'MONABANQ'=9;'CREATIS'=9;'CIC CIB ASSET SERVICING'=4.5}
function NowIso {(Get-Date).ToUniversalTime().ToString('o')}
function LockDb {
 if(!(Test-Path -LiteralPath $RootPath -PathType Container)){throw 'Dossier partagé inaccessible'}
 [IO.Directory]::CreateDirectory($HistoryRoot)|Out-Null
 $until=(Get-Date).AddSeconds(20)
 do {try{return [IO.File]::Open($LockFile,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}catch{if((Get-Date)-gt$until){throw 'Registre occupé, réessayez'};Start-Sleep -Milliseconds 80}}while($true)
}
function Key($e,$b,$n){([string]$e+'|'+[string]$b+'|'+[string]$n).ToLowerInvariant()}
function LoadDb {
 if([IO.File]::Exists($DbFile)){return ([IO.File]::ReadAllText($DbFile,[Text.Encoding]::UTF8)|ConvertFrom-Json)}
 $rates=@();foreach($e in $Schema.Keys){$v=$null;if($DefaultRates.ContainsKey($e)){$v=$DefaultRates[$e]};$rates+=@{entity=$e;price=$v}}
 $hist=@();$old=Join-Path $HistoryRoot 'operations.jsonl'
 if([IO.File]::Exists($old)){foreach($line in [IO.File]::ReadLines($old)){if($line.Trim()){try{$hist+=($line|ConvertFrom-Json)}catch{throw 'Historique existant illisible : migration interrompue'}}}}
 [pscustomobject]@{version=3;documents=@();history=@($hist);rates=@($rates);scannedAt=$null;scanErrors=@()}
}
function SaveDb($db){
 $tmp=$DbFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 try{[IO.File]::WriteAllText($tmp,($db|ConvertTo-Json -Depth 20 -Compress),(New-Object Text.UTF8Encoding($false)));if([IO.File]::Exists($DbFile)){[IO.File]::Replace($tmp,$DbFile,$null)}else{[IO.File]::Move($tmp,$DbFile)}}finally{if([IO.File]::Exists($tmp)){[IO.File]::Delete($tmp)}}
}
function NewDoc($e,$b,$s,$x,$db){
 $now=NowIso;$deposit=$x.LastWriteTimeUtc.ToString('o');$k=Key $e $b $x.Name
 $events=@($db.history|Where-Object{(Key $_.entity $_.branch $_.name)-eq$k}|Sort-Object timestamp)
 $periods=@();$entered=$now;$done=$null;$agent='';$started=$null
 if($events.Count){$depositSource='Première modification observée (document déjà suivi)';foreach($ev in $events){if($ev.to-eq'EN COURS'){$started=$ev.timestamp};$agent=$ev.agent};$entered=$events[-1].timestamp;if($events[-1].to-eq'TRAITES'){$done=$entered};for($i=0;$i-lt($events.Count-1);$i++){$periods+=@{status=$events[$i].to;start=$events[$i].timestamp;end=$events[$i+1].timestamp}}}else{$depositSource='Modification au premier scan';if($s-eq'TRAITES'){$done=$deposit};if($s-eq'A TRAITER'){$entered=$deposit}}
 [pscustomobject]@{id=[guid]::NewGuid().ToString();key=$k;entity=$e;branch=$b;name=$x.Name;kind=$(if($x.PSIsContainer){'Dossier'}else{'Fichier'});status=$s;depositAt=$deposit;depositSource=$depositSource;modifiedAt=$deposit;firstSeenAt=$now;statusSince=$entered;periods=@($periods);priority=$false;priorityComment='';complex=$false;complexComment='';comment='';unitPrice=$null;billedPrice=$(if($s -eq 'TRAITES'){($db.rates|Where-Object {$_.entity -eq $e}|Select-Object -First 1).price}else{$null});agent=$agent;startedAt=$started;completedAt=$done;present=$true}
}
function Scan([bool]$force=$false) {
 $lk=LockDb
 try {
  $db=LoadDb
  if(!$force -and $db.scannedAt -and ((Get-Date).ToUniversalTime()-[datetime]$db.scannedAt).TotalSeconds -lt 25){return $db}
  $map=@{};foreach($d in $db.documents){$map[$d.key]=$d}
  $observed=@{};$locations=@{};$errors=@();$now=NowIso
  foreach($e in $Schema.Keys){foreach($b in $Schema[$e].Branches){foreach($s in $Statuses){
   $p=BranchPath $e $s $b;$loc=Key $e $b $s
   try {
    if([IO.Directory]::Exists($p)){$xs=@(Get-ChildItem -LiteralPath $p -ErrorAction Stop | Where-Object {$_.PSIsContainer -or $_.Extension -in @('.pdf','.doc','.docx')})}
    else {if(@($db.documents | Where-Object {$_.present -and $_.entity -eq $e -and $_.branch -eq $b -and $_.status -eq $s}).Count){throw 'Dossier précédemment suivi inaccessible'};$xs=@()}
    foreach($x in $xs){$k=Key $e $b $x.Name;if(!$observed.ContainsKey($k)){$observed[$k]=@()};$observed[$k]+= @(@{entity=$e;branch=$b;status=$s;item=$x})}
    $locations[$loc]=$true
   } catch {$errors+=($p+': '+$_.Exception.Message)}
  }}}
  foreach($k in $observed.Keys){
   $entries=@($observed[$k]);if($entries.Count -ne 1){$errors+=('Doublon entre statuts : '+$k+' — aucune mise à jour de ce document');continue}
   $entry=$entries[0];$x=$entry.item;$s=$entry.status
   if(!$map.ContainsKey($k)){$d=NewDoc $entry.entity $entry.branch $s $x $db;$db.documents=@($db.documents)+@($d);$map[$k]=$d}
   else {
    $d=$map[$k]
    if($d.status -ne $s){
     $d.periods=@($d.periods)+@(@{status=$d.status;start=$d.statusSince;end=$now})
     $db.history=@($db.history)+@(@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=$now;entity=$d.entity;branch=$d.branch;name=$d.name;agent='SCAN EXTERNE';from=$d.status;to=$s;comment='Déplacement constaté au scan';dmt_minutes=$null})
     $d.status=$s;$d.statusSince=$now
     if($s -eq 'TRAITES'){$d.completedAt=$now;$d.billedPrice=($db.rates|Where-Object {$_.entity -eq $d.entity}|Select-Object -First 1).price}else{$d.completedAt=$null}
     if($s -eq 'EN COURS'){$d.startedAt=$now}
    }
    $d.present=$true;$d.modifiedAt=$x.LastWriteTimeUtc.ToString('o')
   }
  }
  foreach($d in $db.documents){if(!$observed.ContainsKey($d.key) -and $locations.ContainsKey((Key $d.entity $d.branch $d.status))){$d.present=$false}}
  $db.scannedAt=$now;$db.scanErrors=@($errors);SaveDb $db;return $db
 } finally {$lk.Dispose()}
}
function ReadDb {$lk=LockDb;try{LoadDb}finally{$lk.Dispose()}}
function FindDoc($db,$id){$d=@($db.documents|Where-Object{$_.id-eq$id});if($d.Count-ne 1){throw 'Document introuvable'};return $d[0]}
function MoveDocument($body){
 $lk=LockDb
 try{
  $db=LoadDb;$d=FindDoc $db ([string]$body.id);$to=[string]$body.to
  if($Statuses-notcontains$to){throw 'Statut invalide'}
  if(!$d.present-or$d.status-ne[string]$body.from){throw 'Document déjà pris ou déplacé. Actualisez la liste.'}
  if($d.status-eq$to){throw 'Le document est déjà dans ce statut'}
  $src=Join-Path (BranchPath $d.entity $d.status $d.branch) $d.name;$target=BranchPath $d.entity $to $d.branch
  [IO.Directory]::CreateDirectory($target)|Out-Null;$dst=Join-Path $target $d.name
  if(!(Test-Path -LiteralPath $src)){throw 'Document déjà déplacé ou introuvable'}
  if(Test-Path -LiteralPath $dst){throw 'Un document existe déjà à destination'}
  $folder=[IO.Directory]::Exists($src)
  if($folder){[IO.Directory]::Move($src,$dst)}else{[IO.File]::Move($src,$dst)}
  try{
   $now=NowIso;$from=$d.status;$dmt=$null
   if($from-eq'EN COURS'-and$d.startedAt){$dmt=[Math]::Round(([datetime]$now-[datetime]$d.startedAt).TotalMinutes,2)}
   $d.periods=@($d.periods)+@(@{status=$from;start=$d.statusSince;end=$now});$d.status=$to;$d.statusSince=$now;$d.agent=[Environment]::UserName;$d.comment=[string]$body.comment
   if($to-eq'EN COURS'){$d.startedAt=$now};if($to-eq'TRAITES'){$d.completedAt=$now;$d.billedPrice=($db.rates|Where-Object {$_.entity -eq $d.entity}|Select-Object -First 1).price}else{$d.completedAt=$null}
   $db.history=@($db.history)+@(@{id=[guid]::NewGuid().ToString();documentId=$d.id;timestamp=$now;agent=$d.agent;entity=$d.entity;branch=$d.branch;from=$from;to=$to;name=$d.name;started=$d.startedAt;dmt_minutes=$dmt;comment=$d.comment;complex=$d.complex;complexComment=$d.complexComment})
   SaveDb $db
  }catch{if($folder){[IO.Directory]::Move($dst,$src)}else{[IO.File]::Move($dst,$src)};throw}
  @{ok=$true}
 }finally{$lk.Dispose()}
}
function EditDocument($body,$role){
 $lk=LockDb;try{$db=LoadDb;$d=FindDoc $db ([string]$body.id)
 if($null -ne $body.PSObject.Properties['complex'] -and $body.complex -isnot [bool]){throw 'Complexité invalide'}
 if($body.complex -and !([string]$body.complexComment).Trim()){throw 'Commentaire de complexité requis'}
 if($null -ne $body.PSObject.Properties['priority'] -and $body.priority -isnot [bool]){throw 'Priorité invalide'}
 foreach($prop in @('complex','complexComment','comment')){if($null-ne$body.PSObject.Properties[$prop]){$d.$prop=$body.$prop}}
 if($role-eq'MANAGER'){
  foreach($prop in @('priority','priorityComment')){if($null-ne$body.PSObject.Properties[$prop]){$d.$prop=$body.$prop}}
  if($null-ne$body.PSObject.Properties['unitPrice']){if($null-eq$body.unitPrice){$d.unitPrice=$null}else{$price=[double]$body.unitPrice;if($price-lt 0-or[double]::IsNaN($price)-or[double]::IsInfinity($price)){throw 'Prix invalide'};$d.unitPrice=$price}}
 }
 SaveDb $db;@{ok=$true}
 }finally{$lk.Dispose()}
}
function EditRate($body){$lk=LockDb;try{$db=LoadDb;$rate=@($db.rates|Where-Object{$_.entity-eq[string]$body.entity});if($rate.Count-ne 1){throw 'Entité inconnue'};$v=$null;if($null-ne$body.price){$v=[double]$body.price;if($v-lt 0-or[double]::IsNaN($v)-or[double]::IsInfinity($v)){throw 'Prix invalide'}};$rate[0].price=$v;SaveDb $db;@{ok=$true}}finally{$lk.Dispose()}}
function OpenDocument($body){$db=ReadDb;$d=FindDoc $db ([string]$body.id);$p=Join-Path (BranchPath $d.entity $d.status $d.branch) $d.name;if(!(Test-Path -LiteralPath $p)){throw 'Document introuvable'};Start-Process explorer.exe -ArgumentList ('"'+$p+'"');@{ok=$true}}
