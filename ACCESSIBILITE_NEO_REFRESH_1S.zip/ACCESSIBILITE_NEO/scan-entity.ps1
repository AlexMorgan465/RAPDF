param([Parameter(Mandatory)][string]$Root,[Parameter(Mandatory)][string]$Entity,[bool]$IncludeTreated=$false)
$ErrorActionPreference='Stop'
$statuses=@{'A TRAITER'='A_TRAITER';'EN COURS'='EN_COURS';'NON CONFORME'='NON_CONFORME';'TRAITES'='TRAITES';'TRAITÉS'='TRAITES'}
$entityPath=Join-Path $Root $Entity
if(![IO.Directory]::Exists($entityPath)){throw "Entité inaccessible : $Entity"}
# Directory.Enumerate* yields paths as they are found, without materialising
# every child as a PowerShell object. This matters on high-latency UNC shares.
$queue=[Collections.Queue]::new();$queue.Enqueue($entityPath)
while($queue.Count){
 $folder=[string]$queue.Dequeue()
 foreach($childPath in [IO.Directory]::EnumerateDirectories($folder)){
   $child=[IO.DirectoryInfo]::new($childPath)
   if(($child.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){continue}
   $state=$statuses[$child.Name.ToUpperInvariant()]
   if(!$state){$queue.Enqueue($childPath);continue}
   if($state -eq 'TRAITES' -and !$IncludeTreated){continue}
   $parts=[Collections.Queue]::new();$parts.Enqueue($childPath)
   while($parts.Count){
     $container=[string]$parts.Dequeue()
     if($state -in @('A_TRAITER','EN_COURS')){
       foreach($filePath in [IO.Directory]::EnumerateFiles($container)){
         $item=[IO.FileInfo]::new($filePath)
         if($item.Extension.ToLowerInvariant() -notin @('.pdf','.doc','.docx')){continue}
         [pscustomobject]@{entity=$Entity;status=$state;path=$filePath;statusRoot=$childPath;isFolder=$false;modified=$item.LastWriteTimeUtc.ToString('o');received=$item.CreationTime.ToString('o');size=$item.Length}
       }
       foreach($subPath in [IO.Directory]::EnumerateDirectories($container)){
         $sub=[IO.DirectoryInfo]::new($subPath)
         if(($sub.Attributes -band [IO.FileAttributes]::ReparsePoint) -eq 0){$parts.Enqueue($subPath)}
       }
     }else{
       foreach($subPath in [IO.Directory]::EnumerateDirectories($container)){
         $sub=[IO.DirectoryInfo]::new($subPath)
         if(($sub.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){continue}
         $hasFile=$false
         foreach($unused in [IO.Directory]::EnumerateFiles($subPath)){$hasFile=$true;break}
         if($hasFile){
           [pscustomobject]@{entity=$Entity;status=$state;path=$subPath;statusRoot=$childPath;isFolder=$true;modified=$sub.LastWriteTimeUtc.ToString('o');received=$sub.CreationTime.ToString('o');size=0}
         }else{$parts.Enqueue($subPath)}
       }
     }
   }
 }
}
