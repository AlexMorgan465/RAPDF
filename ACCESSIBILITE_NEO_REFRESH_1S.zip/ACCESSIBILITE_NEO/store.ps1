$script:base=Split-Path -Parent $MyInvocation.MyCommand.Path
$script:cfg=[IO.File]::ReadAllText((Join-Path $script:base 'config.json'),[Text.Encoding]::UTF8)|ConvertFrom-Json
$script:data=Join-Path $script:base 'data';[void][IO.Directory]::CreateDirectory($script:data)
$script:sharedData=if($script:cfg.dataRoot){[string]$script:cfg.dataRoot}else{Join-Path ([string]$script:cfg.sharedRoot) '_APPLICATION_ACCESSIBILITE'}
try{[void][IO.Directory]::CreateDirectory($script:sharedData)}catch{throw "Dossier de données partagé inaccessible : $script:sharedData. $($_.Exception.Message)"}
$script:catalogFile=Join-Path $script:sharedData 'catalog.json'
$script:versionFile=Join-Path $script:sharedData 'catalog.version'
$script:cacheCatalog=$null;$script:cacheVersion=''
$script:auditFile=Join-Path $script:sharedData 'audit.jsonl'
$script:lockFile=Join-Path $script:sharedData 'catalog.lock'
$script:refreshFile=Join-Path $script:sharedData 'refresh.json'
$script:tempRoot=Join-Path $script:data 'uploads';[void][IO.Directory]::CreateDirectory($script:tempRoot)
$script:uploads=@{}
function With-Store([scriptblock]$action){
 $lock=$null;$until=(Get-Date).AddSeconds(15)
 while(!$lock -and (Get-Date) -lt $until){
   try{$lock=[IO.FileStream]::new($script:lockFile,[IO.FileMode]::OpenOrCreate,[IO.FileAccess]::ReadWrite,[IO.FileShare]::None)}
   catch [IO.IOException]{Start-Sleep -Milliseconds 80}
   catch [UnauthorizedAccessException]{throw "Écriture refusée dans le dossier de données partagé : $script:sharedData"}
 }
 if(!$lock){throw 'Catalogue partagé momentanément occupé'}
 try{& $action}finally{$lock.Dispose()}
}
if(!(Test-Path -LiteralPath $script:catalogFile)){
With-Store {
 if(!(Test-Path -LiteralPath $script:catalogFile)){
   $localCatalog=Join-Path $script:data 'catalog.json'
   if(Test-Path -LiteralPath $localCatalog){Copy-Item -LiteralPath $localCatalog -Destination $script:catalogFile -ErrorAction Stop}
   else{[IO.File]::WriteAllText($script:catalogFile,'{"version":0,"documents":[]}',[Text.UTF8Encoding]::new($false))}
   $localAudit=Join-Path $script:data 'audit.jsonl'
   if((Test-Path -LiteralPath $localAudit) -and !(Test-Path -LiteralPath $script:auditFile)){Copy-Item -LiteralPath $localAudit -Destination $script:auditFile -ErrorAction Stop}
 }
}
}
function Refresh-Token{try{if(Test-Path -LiteralPath $script:refreshFile){return [IO.File]::ReadAllText($script:refreshFile,[Text.Encoding]::UTF8)}}catch{};return ''}
function Catalog-Version{
 try{if(Test-Path -LiteralPath $script:versionFile){return [IO.File]::ReadAllText($script:versionFile,[Text.Encoding]::ASCII)}}catch{}
 return [string]([IO.File]::GetLastWriteTimeUtc($script:catalogFile).Ticks)
}
function Load-Catalog{
 $stamp=Catalog-Version
 if($script:cacheCatalog -and $script:cacheVersion -eq $stamp){return $script:cacheCatalog}
 for($attempt=0;$attempt -lt 4;$attempt++){
   try{
     $o=[IO.File]::ReadAllText($script:catalogFile,[Text.Encoding]::UTF8)|ConvertFrom-Json -ErrorAction Stop
     if(!$o -or $o.PSObject.Properties.Match('documents').Count -eq 0){throw 'Catalogue invalide'}
     $script:cacheCatalog=$o;$script:cacheVersion=$stamp
     return $o
   }catch{if($attempt -eq 3){throw};Start-Sleep -Milliseconds 50}
 }
}
function Save-Catalog($o){
 $o.version=[long]$o.version+1
 $tmp=$script:catalogFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
 [IO.File]::WriteAllText($tmp,(ConvertTo-Json -InputObject $o -Depth 12 -Compress),[Text.UTF8Encoding]::new($false))
 try{[IO.File]::Move($tmp,$script:catalogFile,$true)}
 catch [UnauthorizedAccessException]{
  Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
  throw "Impossible de remplacer le catalogue partagé ($script:catalogFile). Vérifiez les droits de remplacement/suppression dans dataRoot avec VERIFIER.bat."
 }
 $script:cacheCatalog=$o
 $stamp=[guid]::NewGuid().ToString('N')
 $versionTmp=$script:versionFile+'.'+$stamp+'.tmp'
 [IO.File]::WriteAllText($versionTmp,$stamp,[Text.Encoding]::ASCII)
 try{[IO.File]::Move($versionTmp,$script:versionFile,$true)}
 catch [UnauthorizedAccessException]{
  Remove-Item -LiteralPath $versionTmp -Force -ErrorAction SilentlyContinue
  throw "Catalogue enregistré mais marqueur de version non actualisé ($script:versionFile). Vérifiez les droits dans dataRoot avec VERIFIER.bat."
 }
 $script:cacheVersion=$stamp
}
function Audit($action,$task,$actor,$detail){
 $event=[pscustomobject]@{at=(Get-Date).ToString('o');action=$action;id=$task.id;name=$task.name;entity=$task.entity;agent=$actor;status=$task.status;detail=$detail}
 [IO.File]::AppendAllText($script:auditFile,((ConvertTo-Json -InputObject $event -Compress -Depth 5)+"`n"),[Text.UTF8Encoding]::new($false))
}
function Session-Name{[Security.Principal.WindowsIdentity]::GetCurrent().Name}
function Safe-Part($name){if(!$name -or $name -in @('.','..') -or $name.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $name.Contains('/') -or $name.Contains('\')){throw 'Nom de dossier invalide'};return $name}
function Under($root,$relative){
 $p=[IO.Path]::GetFullPath((Join-Path $root $relative));$prefix=[IO.Path]::GetFullPath($root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
 if(!$p.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin hors du dossier autorisé'};return $p
}
function Source-Allowed($path){
 $prefix=[IO.Path]::GetFullPath([string]$script:cfg.sharedRoot).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
 if(!$path -or !([IO.Path]::GetFullPath($path)).StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){throw 'Document hors du DP'}
}
function Current-Task($catalog,$id){$t=@($catalog.documents|Where-Object {$_.id -eq $id}|Select-Object -First 1);if(!$t.Count){throw 'Document introuvable : actualisez la page'};return $t[0]}
function Merge-Scan($entity,$items,$scanStarted=''){
 # Le scan a déjà énuméré les fichiers : ne pas refaire un aller-retour UNC par document.
 $valid=@($items|Where-Object {$_.path})
 With-Store {
   $catalog=Load-Catalog;$changed=$false;$seen=@{};$events=[Collections.Generic.List[string]]::new()
   $documents=[Collections.Generic.List[object]]::new()
   foreach($record in @($catalog.documents)){$documents.Add($record)}
   $catalog.documents=$documents
   $byPath=@{};$byStem=@{}
   foreach($record in @($catalog.documents)){
     if($record.currentPath){$byPath[[string]$record.currentPath]=$record}
     if($record.entity -ine $entity){continue}
     $stemKey=([string]$record.branch+'|'+[string]$record.stem).ToUpperInvariant()
     if(!$byStem.ContainsKey($stemKey)){$byStem[$stemKey]=[Collections.Generic.List[object]]::new()}
     $byStem[$stemKey].Add($record)
   }
   foreach($item in $valid){$seen[[string]$item.path]=$true}
   foreach($item in $valid){
     $path=[string]$item.path
     $relative=[IO.Path]::GetRelativePath([string]$item.statusRoot,$path)
     $branch=[IO.Path]::GetDirectoryName($relative);if($branch -eq '.'){$branch=''}
     $name=[IO.Path]::GetFileName($path)
     $stem=if($item.isFolder){$name}else{[IO.Path]::GetFileNameWithoutExtension($name)}
     $t=$byPath[$path]
     if($t){
       if($t.modified -ne $item.modified){$t.modified=[string]$item.modified;$changed=$true}
       continue
     }
     $stemKey=($branch+'|'+$stem).ToUpperInvariant();$moved=$null
     if($byStem.ContainsKey($stemKey) -and $item.status -eq 'A_TRAITER' -and @($byStem[$stemKey]|Where-Object {$_.status -eq 'EN_COURS' -and $_.agent}).Count){continue}
     if($byStem.ContainsKey($stemKey)){
       foreach($candidate in $byStem[$stemKey]){
         if($candidate.status -in @('A_TRAITER','EN_COURS','NON_CONFORME','ABSENT') -and !$seen.ContainsKey([string]$candidate.currentPath) -and [string]$candidate.currentPath -ne $path){$moved=$candidate;break}
       }
     }
     if($moved){
       $moved.currentPath=$path;$moved.status=[string]$item.status;$moved.statusRoot=[string]$item.statusRoot;$moved.modified=[string]$item.modified
       if($item.isFolder){$moved.resultPath=$path}else{$moved.originalPath=$path}
       $byPath[$path]=$moved;$changed=$true
       $events.Add((ConvertTo-Json -InputObject @{at=(Get-Date).ToString('o');action='DEPLACEMENT_DP';id=$moved.id;name=$moved.name;entity=$entity;agent='';status=$moved.status;detail=$path} -Compress))
       continue
     }
     $key=($entity+'|'+$item.statusRoot+'|'+$branch+'|'+$stem).ToUpperInvariant()
     $task=[pscustomobject]@{id=[guid]::NewGuid().ToString();key=$key;entity=$entity;name=$name;stem=$stem;branch=$branch;status=[string]$item.status;statusRoot=[string]$item.statusRoot;currentPath=$path;originalPath=$(if($item.isFolder){''}else{$path});historyPath='';resultPath=$(if($item.isFolder){$path}else{''});agent='';created=(Get-Date).ToString('o');started='';finished='';reworked='';comment='';solution='';modified=[string]$item.modified;received=$(if($item.received){[string]$item.received}else{[string]$item.modified});published=''}
     $catalog.documents.Add($task);$byPath[$path]=$task;$changed=$true
     $events.Add((ConvertTo-Json -InputObject @{at=$task.created;action='NOUVEAU_DOCUMENT';id=$task.id;name=$name;entity=$entity;agent='';status=$task.status;detail=$path} -Compress))
     if(!$byStem.ContainsKey($stemKey)){$byStem[$stemKey]=[Collections.Generic.List[object]]::new()};$byStem[$stemKey].Add($task)
   }
   foreach($t in @($catalog.documents|Where-Object {$_.entity -ieq $entity -and $_.status -in @('A_TRAITER','EN_COURS','NON_CONFORME')})){
     if($seen.ContainsKey([string]$t.currentPath)){continue}
     # Ne pas effacer une prise en charge plus récente que ce scan.
     if($scanStarted -and (($t.started -and $t.started -ge $scanStarted) -or ($t.created -and $t.created -ge $scanStarted))){continue}
     $t.status='ABSENT';$changed=$true
     $events.Add((ConvertTo-Json -InputObject @{at=(Get-Date).ToString('o');action='RETRAIT_DP';id=$t.id;name=$t.name;entity=$entity;agent='';status='ABSENT';detail=$t.currentPath} -Compress))
   }
   if($changed){Save-Catalog $catalog}
   if($events.Count){try{[IO.File]::AppendAllText($script:auditFile,($events -join "`n")+"`n",[Text.UTF8Encoding]::new($false))}catch{}}
 }
}
function Entity-List{
 if(!(Test-Path -LiteralPath $script:cfg.sharedRoot -PathType Container)){throw 'DP inaccessible : '+$script:cfg.sharedRoot}
 return @(Get-ChildItem -LiteralPath $script:cfg.sharedRoot -Directory|Select-Object -ExpandProperty Name)
}
function Get-Destination($task,$folder){
 $entityRoot=Join-Path ([string]$script:cfg.sharedRoot) $task.entity
 $relative=[IO.Path]::GetRelativePath($entityRoot,$task.statusRoot)
 $parts=$relative -split '[\\/]';$parts[-1]=$folder
 $root=Join-Path $entityRoot ($parts -join [IO.Path]::DirectorySeparatorChar)
 if($task.branch){$root=Join-Path $root $task.branch}
 Source-Allowed $root
 [void][IO.Directory]::CreateDirectory($root)
 return $root
}
function Upload-Start($name,$actor){
 Safe-Part $name|Out-Null
 $id=[guid]::NewGuid().ToString();$p=Join-Path $script:tempRoot $id;[void][IO.Directory]::CreateDirectory($p)
 $script:uploads[$id]=@{path=$p;root=$name;actor=$actor;count=0;bytes=0}
 return $id
}
function Upload-File($id,$actor,$relative,$data){
 $u=$script:uploads[[string]$id];if(!$u -or $u.actor -ne $actor){throw 'Transfert introuvable'}
 $segments=@($relative.Replace('\','/') -split '/');if(!$segments.Count -or $segments.Count -gt 15){throw 'Chemin invalide'}
 foreach($part in $segments){Safe-Part $part|Out-Null}
 $bytes=[Convert]::FromBase64String($data)
 if($bytes.Length -gt 25000000 -or $u.bytes+$bytes.Length -gt 250000000){throw 'Dossier trop volumineux'}
 $p=Under $u.path ($segments -join [IO.Path]::DirectorySeparatorChar)
 if(Test-Path -LiteralPath $p){throw 'Nom de fichier en double'}
 [void][IO.Directory]::CreateDirectory((Split-Path -Parent $p));[IO.File]::WriteAllBytes($p,$bytes)
 $u.count++;$u.bytes+=$bytes.Length
}
function Upload-Ready($id,$actor,$stem,$name){
 $u=$script:uploads[[string]$id]
 if(!$u -or $u.actor -ne $actor -or !$u.count){throw 'Choisissez un dossier de résultat contenant des fichiers'}
 if($u.root -ine $stem -and $u.root -ine $name){throw "Le dossier doit s'appeler $stem"}
 return $u
}
