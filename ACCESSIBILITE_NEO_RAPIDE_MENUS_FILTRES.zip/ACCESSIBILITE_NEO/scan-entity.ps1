param([Parameter(Mandatory)][string]$Root,[Parameter(Mandatory)][string]$Entity,[bool]$IncludeTreated=$false)
$ErrorActionPreference='Stop'
$statuses=@{'A TRAITER'='A_TRAITER';'EN COURS'='EN_COURS';'NON CONFORME'='NON_CONFORME';'TRAITES'='TRAITES';'TRAITÉS'='TRAITES'}
$entityPath=Join-Path $Root $Entity
if(!(Test-Path -LiteralPath $entityPath -PathType Container)){throw "Entité inaccessible : $Entity"}
$queue=[Collections.Queue]::new();$queue.Enqueue($entityPath)
while($queue.Count){
 $folder=[string]$queue.Dequeue()
 foreach($child in @(Get-ChildItem -LiteralPath $folder -Directory -ErrorAction Stop)){
   $state=$statuses[$child.Name.ToUpperInvariant()]
   if(!$state){$queue.Enqueue($child.FullName);continue}
   if($state -eq 'TRAITES' -and !$IncludeTreated){continue}
   $parts=[Collections.Queue]::new();$parts.Enqueue($child.FullName)
   while($parts.Count){
     $container=[string]$parts.Dequeue()
     foreach($item in @(Get-ChildItem -LiteralPath $container -ErrorAction Stop)){
       if($state -in @('A_TRAITER','EN_COURS')){
         if($item.PSIsContainer){$parts.Enqueue($item.FullName)}
         elseif($item.Extension.ToLowerInvariant() -in @('.pdf','.doc','.docx')){
           [pscustomobject]@{entity=$Entity;status=$state;path=$item.FullName;statusRoot=$child.FullName;isFolder=$false;modified=$item.LastWriteTimeUtc.ToString('o');received=$item.CreationTime.ToString('o');size=$item.Length}
         }
       }elseif($item.PSIsContainer){
         $files=@(Get-ChildItem -LiteralPath $item.FullName -File -ErrorAction Stop)
         if($files.Count){
           [pscustomobject]@{entity=$Entity;status=$state;path=$item.FullName;statusRoot=$child.FullName;isFolder=$true;modified=$item.LastWriteTimeUtc.ToString('o');received=$item.CreationTime.ToString('o');size=0}
         }else{$parts.Enqueue($item.FullName)}
       }
     }
   }
 }
}
