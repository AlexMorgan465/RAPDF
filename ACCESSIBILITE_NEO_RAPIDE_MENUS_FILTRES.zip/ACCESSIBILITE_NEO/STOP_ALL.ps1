$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$current=[Security.Principal.WindowsIdentity]::GetCurrent().Name
$scripts=@('server-agent.ps1','server-manager.ps1','server-entity.ps1')
foreach($p in @(Get-CimInstance Win32_Process -Filter "Name='pwsh.exe'" -ErrorAction SilentlyContinue)){
 if(!$p.CommandLine){continue}
 $match=$false
 foreach($scriptName in $scripts){
  if($p.CommandLine.IndexOf($scriptName,[StringComparison]::OrdinalIgnoreCase) -ge 0 -and $p.CommandLine.IndexOf('ACCESSIBILITE',[StringComparison]::OrdinalIgnoreCase) -ge 0){$match=$true;break}
 }
 if(!$match){continue}
 try{
  $owner=$p|Invoke-CimMethod -MethodName GetOwner
  if($owner.ReturnValue -eq 0 -and ($owner.Domain+'\'+$owner.User) -ieq $current){
   Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop
   Write-Host "Processus Accessibilité arrêté : $($p.ProcessId)"
  }
 }catch{Write-Warning $_.Exception.Message}
}
foreach($mode in @('agent','manager')){
 foreach($suffix in @('pid','endpoint.json')){
  Remove-Item -LiteralPath (Join-Path $base ("data\$mode.$suffix")) -Force -ErrorAction SilentlyContinue
 }
}
