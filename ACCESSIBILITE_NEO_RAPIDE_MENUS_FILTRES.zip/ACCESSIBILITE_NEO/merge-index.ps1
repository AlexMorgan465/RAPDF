param([Parameter(Mandatory)][string]$EntityEncoded)
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $base 'store.ps1')
$entity=[Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($EntityEncoded))
$key=[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($entity)))
$path=Join-Path (Join-Path $script:sharedData 'entities') ($key+'.json')
if(!(Test-Path -LiteralPath $path)){throw "Index absent pour $entity"}
$snapshot=[IO.File]::ReadAllText($path,[Text.Encoding]::UTF8)|ConvertFrom-Json -ErrorAction Stop
if($snapshot.entity -cne $entity -or $snapshot.PSObject.Properties.Match('items').Count -eq 0){throw 'Index entité invalide'}
Merge-Scan $entity @($snapshot.items) ([string]$snapshot.scanStarted)
