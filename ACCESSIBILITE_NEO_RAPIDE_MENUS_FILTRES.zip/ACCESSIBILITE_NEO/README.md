# Accessibilité — Nouveau projet

## Installer et démarrer

1. Extraire **toute** l’archive dans un dossier où la session Windows peut écrire dans `data`. Conserver ce même dossier pour les deux interfaces.
2. Vérifier `config.json` : `sharedRoot` est le DP Accessibilité, `historyRoot` le chemin distinct d’historique, et `dataRoot` un dossier partagé où tous les agents et le manager peuvent lire et écrire. Par défaut, `dataRoot` vaut `ACCESSIBILITE\_APPLICATION_ACCESSIBILITE`. Les deux ports sont `0` : Windows attribue à chaque serveur un port local libre. Le port et le PID réels sont écrits dans `data/agent.endpoint.json` et `data/manager.endpoint.json`. Adapter `managerAccounts` à vos sessions autorisées.
3. Lancer `VERIFIER.bat` pour contrôler les scripts, l’accès aux chemins et l’ouverture d’un port local libre. Double-cliquer sur `START_AGENT.bat` pour l’agent, et `START_MANAGER.bat` pour le manager. Chaque bouton **Déconnecter** ferme son propre serveur. Pour voir une erreur de démarrage, lancer `START_VISIBLE_AGENT.bat` ou `START_VISIBLE_MANAGER.bat` et consulter `data/agent-error.log` ou `data/manager-error.log`.
4. Les deux serveurs utilisent `TcpListener` sur `127.0.0.1`, sans inscription dans HTTP.sys (PID 4). Les processus sont deux `pwsh.exe` distincts et les ports peuvent être observés avec `netstat -ano`. Un ancien serveur occupant 8091 ou 8092 ne bloque plus leur démarrage. Le lanceur vérifie le PID et l’identifiant de l’instance avant d’ouvrir la page.

## Fonctionnement

- L’application détecte les entités directement sous le DP. Sous chaque entité, elle cherche récursivement les dossiers `A TRAITER`, `EN COURS` et `NON CONFORME`, quelle que soit leur profondeur. Le cinquième dossier `A PUBLIER` d’ACM est conservé. Les PDF, DOC et DOCX sont détectés dans `A TRAITER` et `EN COURS`. Les résultats dans `NON CONFORME` et `TRAITES` sont des dossiers.
- Chaque entité est extraite par un processus `pwsh.exe` distinct qui exécute `server-entity.ps1` et ne parcourt que son dossier. Il écrit un JSON indépendant dans `dataRoot/entities/<SHA256 du nom>.json`. Un verrou partagé par entité empêche deux postes de scanner la même entité simultanément. Les scans périodiques ne parcourent pas les dossiers TRAITES ; les dossiers déjà consignés restent dans le catalogue partagé. `merge-index.ps1` combine chaque instantané dans le catalogue commun `dataRoot/catalog.json` sous verrou ; les traitements et l’historique restent dans ce catalogue. Les interfaces ne parcourent jamais le DP lorsqu’elles affichent une page. Le contrôle périodique de chaque entité est réglé par `reconcileSeconds` (minimum 15 secondes). Les fichiers `.error.txt` de `dataRoot/entities` signalent les problèmes de scan.
- Depuis **Manager → Ajouter une entité**, saisir le nom exact d’un dossier qui existe déjà directement sous le DP. Le processus correspondant démarre immédiatement et les autres interfaces voient ensuite les documents. Les nouveaux dossiers sont également découverts automatiquement. Ce bouton ne crée aucun dossier métier ni les statuts `A TRAITER`, `EN COURS`, etc. : leur arborescence reste sous votre contrôle.
- **Prise en charge** : déplace le document de `A TRAITER` à `EN COURS` en conservant la branche. **Terminer** : exige un dossier local portant le nom du document sans extension (ou son nom complet), copie le résultat dans `TRAITES` ou `NON CONFORME`, archive l’original sous `historyRoot`, puis le retire de `EN COURS`. Le statut non conforme exige un problème et une solution. **Retraitement** : copie un nouveau dossier dans `TRAITES` puis supprime l’ancien dossier de `NON CONFORME`.
- Les mouvements, dates, agents et commentaires sont conservés dans `dataRoot/catalog.json` et `dataRoot/audit.jsonl`, partagés par tous les postes. Le manager dispose de tous les statuts, graphiques, historique et export CSV lisible dans Excel. Une session autre que celles définies dans `managerAccounts` ne peut pas démarrer le serveur manager. Aucune page d’identification : le nom de la session Windows est affiché. Au premier démarrage uniquement, un ancien `data/catalog.json` local peut être copié vers `dataRoot` si ce dernier ne contient encore aucun catalogue.

## Limites d’exploitation

Les ports ne sont accessibles que depuis **le poste qui lance le serveur**. Le nom de session provient du processus PowerShell, donc chaque utilisateur doit lancer sa propre instance dans sa session Windows. Cette variante locale ne doit pas être exposée sur le réseau ou derrière un proxy : elle n’identifie pas séparément les navigateurs distants. Tous les postes doivent pointer vers le même `dataRoot`. Sauvegardez régulièrement ce dossier partagé.

La durée des scans périodiques sur un partage UNC dépend du serveur de fichiers. Si le DP est indisponible, le dernier catalogue reste consultable et les actions échouent explicitement.

## Pilotage et actualisation

- **Manager → Actualiser tous** émet un signal partagé sans verrouiller le catalogue : les interfaces agent et manager relisent la dernière vue au prochain cycle (environ 1,5 seconde). Les extracteurs d’entité détectent le signal partagé au plus tard lors de leur vérification de deux secondes, puis rescannent leur entité. La durée effective dépend de la vitesse du DP et du nombre de dossiers.
- **Manager → Tableau de bord & reporting** filtre par entité et mois de réception, compte les dossiers traités et publiés, les non-conformités, le délai moyen, et exporte le récapitulatif CSV. Le mois repose sur `CreationTime` du fichier au moment de sa première indexation ; les copies peuvent conserver ou réinitialiser cette date selon la source. Les mouvements sont conservés dans l’audit.
- **Manager → Tous les traitements** affiche l’action **A publier** uniquement sur un dossier ACM au statut `TRAITES`. L’action déplace physiquement ce dossier dans le dossier frère `A PUBLIER`, marque `PUBLIE`, puis journalise l’opération.
- **Agent → Mes traitements** et **Mon historique** affichent les indicateurs et les dossiers de la session Windows. Une prise en charge est protégée par le verrou partagé ; le déplacement est confirmé dans `catalog.json` avant la réponse, avec retour au chemin initial si la sauvegarde échoue. La vue `En cours` est relue immédiatement après le succès.

Pour vérifier la syntaxe des scripts sur le poste Windows, lancer `VERIFIER.bat`. Cette archive a été contrôlée statiquement pour JavaScript et JSON ici, mais le partage UNC et PowerShell 7 ne sont pas disponibles dans cet environnement ; valider les déplacements sur une copie du DP avant usage métier.

## Révision rapidité et vues

- La lecture de page vérifie un petit marqueur de version ; si rien n’a changé, le serveur renvoie 304 sans décoder le gros catalogue JSON. La mémoire de chaque processus conserve le catalogue jusqu’au prochain marqueur.
- Les extracteurs ne refont plus un `Test-Path` réseau par document et ne parcourent pas `TRAITES` pendant les actualisations. Les traités connus proviennent du catalogue et des actions effectuées dans l’application. Une importation historique de dossiers `TRAITES` jamais enregistrés auparavant doit être réalisée séparément ; leur total n’est pas inventé.
- **Actualiser tous** écrit directement un signal partagé sans attendre le verrou du catalogue ; les pages relisent ensuite les données et chaque extracteur rescannera son entité. Le scan complet du DP reste dépendant du réseau et ne peut pas être garanti instantané.
- Le menu de page sépare les vues. Les documents traités de tous les agents ne sont visibles que côté manager ; l’agent retrouve ses propres dossiers dans **Mon historique** et ses propres chiffres dans le tableau de bord. Le filtre par sous-entité affiche ses effectifs et un total filtré.

### Mise à jour depuis la version précédente

1. Extraire la nouvelle archive dans un dossier local, puis fermer les pages et exécuter son **STOP_ALL.bat**. Il arrête les serveurs Accessibilité des anciennes versions et leurs extracteurs sous votre session Windows.
2. Reprendre vos chemins réels dans le nouveau `config.json`. Conserver le même `dataRoot` partagé pour préserver le catalogue et l’audit.
3. Exécuter `VERIFIER.bat`, puis lancer les interfaces. Un ancien extracteur encore actif sur un autre poste pourra conserver son verrou : sa session doit aussi arrêter l’ancienne version.
