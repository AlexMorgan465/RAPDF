param([ValidateSet('agent','manager')][string]$Mode)
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $base 'http.ps1')
. (Join-Path $base 'store.ps1')
$actor=Session-Name
if($Mode -eq 'manager' -and $script:cfg.managerAccounts -inotcontains $actor){throw "Accès manager refusé pour la session $actor"}
$port=if($Mode -eq 'manager'){[int]$script:cfg.managerPort}else{[int]$script:cfg.agentPort}
if($port -lt 0 -or $port -gt 65535 -or ($port -gt 0 -and $port -lt 1024)){throw 'Port invalide'}
$pidPath=Join-Path $script:data ("$Mode.pid")
$endpointPath=Join-Path $script:data ("$Mode.endpoint.json")
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$port)
try{$listener.Start()}catch [Net.Sockets.SocketException]{
  # Un ancien serveur peut occuper le port configuré. Laisser Windows choisir un port libre.
  $listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,0)
  $listener.Start()
}
$port=([Net.IPEndPoint]$listener.LocalEndpoint).Port
$instance=[guid]::NewGuid().ToString('N')
[IO.File]::WriteAllText($pidPath,[string]$PID,[Text.Encoding]::ASCII)
[IO.File]::WriteAllText($endpointPath,(ConvertTo-Json -InputObject @{port=$port;pid=$PID;instance=$instance;mode=$Mode} -Compress),[Text.UTF8Encoding]::new($false))
Write-Host "$Mode prêt sur http://localhost:$port/ — $actor"
$script:run=$true
$script:lastError='';$script:lastDiscovery=[datetime]::MinValue
$script:discovery=$null;$script:discoveryHandle=$null;$script:entities=@{};$script:children=@{};$script:attempts=@{}
function Entity-Key($name){[Convert]::ToHexString([Security.Cryptography.SHA256]::HashData([Text.Encoding]::UTF8.GetBytes($name)))}
function Discover{
 if($script:discovery){return}
 $script:discovery=[PowerShell]::Create()
 [void]$script:discovery.AddScript('param($root) @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction Stop | Where-Object { $_.Name -ne "_APPLICATION_ACCESSIBILITE" } | Select-Object -ExpandProperty Name)').AddArgument([string]$script:cfg.sharedRoot)
 $script:discoveryHandle=$script:discovery.BeginInvoke();$script:lastDiscovery=Get-Date
}
function Pump{
 if($script:discovery -and $script:discoveryHandle.IsCompleted){
  try{
   $names=@($script:discovery.EndInvoke($script:discoveryHandle))
   foreach($name in $names){$script:entities[[string]$name]=$true}
   $script:lastError=''
  }catch{$script:lastError=$_.Exception.Message}
  finally{$script:discovery.Dispose();$script:discovery=$null;$script:discoveryHandle=$null}
 }
 foreach($name in @($script:entities.Keys)){
  $old=$script:children[$name]
  if($old -and !$old.HasExited){continue}
  if($script:attempts[$name] -and (Get-Date)-$script:attempts[$name] -lt [timespan]::FromSeconds(30)){continue}
  $script:attempts[$name]=Get-Date
  $encoded=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($name))
  try{
   $exe=(Get-Command pwsh -ErrorAction Stop).Source
   $child=Start-Process -FilePath $exe -ArgumentList @('-NoProfile','-File',('"'+(Join-Path $base 'server-entity.ps1')+'"'),'-EntityEncoded',$encoded) -WindowStyle Hidden -PassThru
   $script:children[$name]=$child
  }catch{$script:lastError="${name}: $($_.Exception.Message)"}
 }
 if(!$script:discovery -and (Get-Date)-$script:lastDiscovery -gt [timespan]::FromSeconds([math]::Max(30,[int]$script:cfg.reconcileSeconds))){Discover}
}
function Serve($client,$req){
 $path=$req.path;$method=$req.verb
 if($path -eq '/api/health'){Reply-Json $client @{ok=$true;mode=$Mode;session=$actor;pid=$PID;instance=$instance;scanning=0;entityWorkers=@($script:children.Values|Where-Object { !$_.HasExited }).Count;error=$lastError};return}
 if($path -eq '/api/entities'){Reply-Json $client @{items=@($script:entities.Keys|Sort-Object)};return}
 if($path -eq '/api/entities/add' -and $method -eq 'POST'){
  if($Mode -ne 'manager'){Reply-Json $client @{error='Réservé au manager'} 403;return}
  $b=Body-Json $req;$name=[string]$b.name
  Safe-Part $name|Out-Null
  $folder=Join-Path ([string]$script:cfg.sharedRoot) $name
  if(!(Test-Path -LiteralPath $folder -PathType Container)){throw "Créez d'abord le dossier $name sous le DP, puis ajoutez-le ici"}
  $script:entities[$name]=$true
  Pump
  try{Audit 'AJOUT_ENTITE' ([pscustomobject]@{id='';name=$name;entity=$name;status=''}) $actor $folder}catch{$script:lastError=$_.Exception.Message}
  Reply-Json $client @{ok=$true;name=$name};return
 }
 if($path -eq '/api/refresh-all' -and $method -eq 'POST'){
  if($Mode -ne 'manager'){Reply-Json $client @{error='Réservé au manager'} 403;return}
  $token=[guid]::NewGuid().ToString('N')
  $signalTmp=$script:refreshFile+'.'+[guid]::NewGuid().ToString('N')+'.tmp'
  [IO.File]::WriteAllText($signalTmp,$token,[Text.UTF8Encoding]::new($false))
  [IO.File]::Move($signalTmp,$script:refreshFile,$true)
  try{Audit 'ACTUALISATION_GLOBALE' ([pscustomobject]@{id='';name='Toutes les entités';entity='';status=''}) $actor $token}catch{$script:lastError=$_.Exception.Message}
  Discover
  Reply-Json $client @{ok=$true;token=$token};return
 }
 if($path -eq '/api/report'){
  $catalog=Load-Catalog;$entity=[string]$req.query['entity'];$month=[string]$req.query['month'];$mine=$Mode -eq 'agent' -or [string]$req.query['mine'] -eq '1';$branch=[string]$req.query['branch']
  $baseRows=@($catalog.documents|Where-Object {(!$entity -or $_.entity -eq $entity) -and (!$mine -or $_.agent -ieq $actor) -and (!$month -or ([string]$(if($_.received){$_.received}else{$_.created})).StartsWith($month))})
  $branchFacets=@{};foreach($t in $baseRows){$key=if($t.branch){[string]$t.branch}else{'(Racine)'};if(!$branchFacets.ContainsKey($key)){$branchFacets[$key]=0};$branchFacets[$key]++}
  $rows=@($baseRows|Where-Object {(!$branch -or $(if($_.branch){[string]$_.branch}else{'(Racine)'}) -eq $branch)})
  $byEntity=@{};$byBranch=@{};$byMonth=@{};$receivedByMonth=@{};$byAgent=@{};$durations=[Collections.Generic.List[double]]::new()
  foreach($t in $rows){
   $name=[string]$t.entity
   if(!$byEntity.ContainsKey($name)){$byEntity[$name]=@{A_TRAITER=0;EN_COURS=0;NON_CONFORME=0;TRAITES=0;PUBLIE=0;ABSENT=0;total=0}}
   $byEntity[$name].total++
   $branchName=if($t.branch){[string]$t.branch}else{'(Racine)'};if(!$byBranch.ContainsKey($branchName)){$byBranch[$branchName]=0};$byBranch[$branchName]++
   if($byEntity[$name].ContainsKey([string]$t.status)){$byEntity[$name][[string]$t.status]++}
   $arrival=[string]$(if($t.received){$t.received}else{$t.created})
   if($arrival.Length -ge 7){$m=$arrival.Substring(0,7);if(!$byMonth.ContainsKey($m)){$byMonth[$m]=0};if(!$receivedByMonth.ContainsKey($m)){$receivedByMonth[$m]=0};$receivedByMonth[$m]++;if($t.status -in @('TRAITES','PUBLIE')){$byMonth[$m]++}}
   if($t.agent){$agentName=[string]$t.agent;if(!$byAgent.ContainsKey($agentName)){$byAgent[$agentName]=@{total=0;TRAITES=0;NON_CONFORME=0;EN_COURS=0;PUBLIE=0}};$byAgent[$agentName].total++;if($byAgent[$agentName].ContainsKey([string]$t.status)){$byAgent[$agentName][[string]$t.status]++}}
   if($t.started -and $t.finished){try{$durations.Add(([datetime]::Parse([string]$t.finished)-[datetime]::Parse([string]$t.started)).TotalHours)}catch{}}
  }
  $finished=@($rows|Where-Object {$_.status -in @('TRAITES','PUBLIE')}).Count
  $nonconform=@($rows|Where-Object {$_.status -eq 'NON_CONFORME'}).Count
  $mean=if($durations.Count){[math]::Round(($durations|Measure-Object -Average).Average,1)}else{0}
  Reply-Json $client @{total=$rows.Count;treated=$finished;nonconform=$nonconform;rate=$(if($rows.Count){[math]::Round(100*$finished/$rows.Count,1)}else{0});meanHours=$mean;byEntity=$byEntity;byBranch=$byBranch;branchFacets=$branchFacets;byMonth=$byMonth;receivedByMonth=$receivedByMonth;byAgent=$byAgent};return
 }
 if($path -eq '/api/publish' -and $method -eq 'POST'){
  if($Mode -ne 'manager'){Reply-Json $client @{error='Réservé au manager'} 403;return}
  $b=Body-Json $req
  $result=With-Store {
   $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
   if($t.entity -ine 'ACM' -or $t.status -ne 'TRAITES'){throw 'Publication autorisée uniquement pour un dossier ACM traité'}
   if(!$t.resultPath -or !(Test-Path -LiteralPath $t.resultPath -PathType Container)){throw 'Dossier traité introuvable'}
   $target=Join-Path (Get-Destination $t 'A PUBLIER') (Split-Path -Leaf $t.resultPath)
   if(Test-Path -LiteralPath $target){throw 'Ce dossier existe déjà dans A PUBLIER'}
   $source=[string]$t.resultPath
   Move-Item -LiteralPath $source -Destination $target -ErrorAction Stop
   try{
    $t.resultPath=$target;$t.currentPath=$target;$t.status='PUBLIE';$publishedAt=(Get-Date).ToString('o');$t | Add-Member -NotePropertyName published -NotePropertyValue $publishedAt -Force
    Save-Catalog $catalog
   }catch{Move-Item -LiteralPath $target -Destination $source -ErrorAction SilentlyContinue;throw}
   try{Audit 'PUBLICATION_ACM' $t $actor $target}catch{$script:lastError=$_.Exception.Message}
   return $t
  }
  Reply-Json $client @{ok=$true;document=$result};return
 }
 if($path -eq '/api/state'){
   $refresh=Refresh-Token
   $stamp=Catalog-Version
   $etag='"'+$stamp+'-'+$script:entities.Count+'-'+$refresh+'"'
   if($req.headers['If-None-Match'] -eq $etag){Reply $client 304 'application/json' ([byte[]]@()) @{ETag=$etag};return}
   $catalog=Load-Catalog
   $rows=@($catalog.documents|Where-Object {$_.status -in @('A_TRAITER','EN_COURS','NON_CONFORME')})
   $counts=@{A_TRAITER=0;EN_COURS=0;NON_CONFORME=0;TRAITES=0;PUBLIE=0;ABSENT=0}
   $byEntity=@{};$byAgent=@{}
   foreach($t in @($catalog.documents)){
     if($counts.ContainsKey([string]$t.status)){$counts[[string]$t.status]++}
     if(!$byEntity.ContainsKey([string]$t.entity)){$byEntity[[string]$t.entity]=0};$byEntity[[string]$t.entity]++
     if($t.agent -and $t.status -in @('TRAITES','PUBLIE')){if(!$byAgent.ContainsKey([string]$t.agent)){$byAgent[[string]$t.agent]=0};$byAgent[[string]$t.agent]++}
   }
   $response=@{version=$catalog.version;refreshToken=$refresh;documents=$rows;counts=$counts;byEntity=$byEntity;byAgent=$byAgent;scanning=0;entityWorkers=@($script:children.Values|Where-Object { !$_.HasExited }).Count;error=$lastError;entities=@($script:entities.Keys);session=($actor -split '\\')[-1]}
   $bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $response -Depth 12 -Compress))
   Reply $client 200 'application/json; charset=utf-8' $bytes @{ETag=$etag};return
 }
 if($path -eq '/api/list'){
   $catalog=Load-Catalog;$page=[math]::Max(1,[int]$req.query['page']);$limit=[math]::Min(100,[math]::Max(1,[int]$req.query['limit']))
   $status=[string]$req.query['status'];$entity=[string]$req.query['entity'];$branch=[string]$req.query['branch'];$search=[string]$req.query['q'];$mine=[string]$req.query['mine'] -eq '1'
   if($Mode -eq 'agent' -and $status -in @('TRAITES','PUBLIE')){$mine=$true}
   $baseRows=@($catalog.documents|Where-Object {(!$status -or $_.status -eq $status) -and (!$entity -or $_.entity -eq $entity) -and (!$mine -or $_.agent -ieq $actor) -and (!$search -or ($_.name+' '+$_.entity+' '+$_.agent+' '+$_.branch).IndexOf($search,[StringComparison]::OrdinalIgnoreCase) -ge 0)})
   $facets=@{};foreach($t in $baseRows){$key=if($t.branch){[string]$t.branch}else{'(Racine)'};if(!$facets.ContainsKey($key)){$facets[$key]=0};$facets[$key]++}
   $rows=@($baseRows|Where-Object {(!$branch -or $(if($_.branch){[string]$_.branch}else{'(Racine)'}) -eq $branch)}|Sort-Object -Property @{Expression={if($_.reworked){$_.reworked}elseif($_.published){$_.published}elseif($_.finished){$_.finished}elseif($_.started){$_.started}else{$_.created}};Descending=$true})
   Reply-Json $client @{items=@($rows|Select-Object -Skip (($page-1)*$limit) -First $limit);total=$rows.Count;facets=$facets;page=$page;limit=$limit};return
 }
 if($path -eq '/api/audit'){
   $page=[math]::Max(1,[int]$req.query['page']);$limit=100
   $all=if(Test-Path -LiteralPath $script:auditFile){@([IO.File]::ReadAllLines($script:auditFile)|Where-Object {$_}|ForEach-Object {try{$_|ConvertFrom-Json}catch{}})}else{@()}
   $sorted=@($all|Select-Object -Last ($page*$limit)|Select-Object -Last $limit)
   [array]::Reverse($sorted)
   Reply-Json $client @{items=$sorted;total=$all.Count;page=$page};return
 }
 if($path -eq '/api/file'){
   $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$req.query['id']);$file=if($t.currentPath -and (Test-Path -LiteralPath $t.currentPath -PathType Leaf)){$t.currentPath}else{$t.historyPath}
   Source-Allowed $t.currentPath
   if(!$file -or !(Test-Path -LiteralPath $file -PathType Leaf)){throw 'Original absent'}
   $bytes=[IO.File]::ReadAllBytes($file)
   Reply $client 200 'application/octet-stream' $bytes @{'Content-Disposition'=('attachment; filename="'+[uri]::EscapeDataString($t.name)+'"')};return
 }
 if($path -eq '/api/stop' -and $method -eq 'POST'){Reply-Json $client @{ok=$true};$script:run=$false;return}
 if($Mode -eq 'agent' -and $method -eq 'POST'){
   $b=Body-Json $req
   if($path -eq '/api/take'){
     $result=With-Store {
       $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
       if($t.status -ne 'A_TRAITER' -or !(Test-Path -LiteralPath $t.currentPath -PathType Leaf)){throw 'Document déjà pris ou absent'}
       $folder=Get-Destination $t 'EN COURS';$dest=Join-Path $folder $t.name
       if(Test-Path -LiteralPath $dest){throw 'Destination déjà présente'}
       $source=[string]$t.currentPath
       Move-Item -LiteralPath $source -Destination $dest -ErrorAction Stop
       try{
        $t.currentPath=$dest;$t.status='EN_COURS';$t.agent=$actor;$t.started=(Get-Date).ToString('o')
        Save-Catalog $catalog
       }catch{Move-Item -LiteralPath $dest -Destination $source -ErrorAction SilentlyContinue;throw}
       try{Audit 'PRISE_EN_CHARGE' $t $actor $dest}catch{$script:lastError=$_.Exception.Message}
       return $t
     }
     Reply-Json $client @{ok=$true;document=$result};return
   }
   if($path -eq '/api/upload/start'){Reply-Json $client @{id=(Upload-Start ([string]$b.name) $actor)};return}
   if($path -eq '/api/upload/file'){Upload-File ([string]$b.id) $actor ([string]$b.relative) ([string]$b.data);Reply-Json $client @{ok=$true};return}
   if($path -eq '/api/finish'){
     $result=With-Store {
       $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
       if($t.status -ne 'EN_COURS' -or $t.agent -ine $actor){throw 'Traitement attribué à un autre agent'}
       if($b.status -notin @('TRAITES','NON_CONFORME')){throw 'Statut invalide'}
       if($b.status -eq 'NON_CONFORME' -and (!$b.comment -or !$b.solution)){throw 'Problème et solution obligatoires'}
       if(!(Test-Path -LiteralPath $t.currentPath -PathType Leaf)){throw 'Original absent'}
       $u=Upload-Ready ([string]$b.upload) $actor $t.stem $t.name
       $folder=if($b.status -eq 'TRAITES'){'TRAITES'}else{'NON CONFORME'}
       $dest=Join-Path (Get-Destination $t $folder) $u.root
       if(Test-Path -LiteralPath $dest){throw 'Un résultat existe déjà'}
       $archive=Join-Path ([string]$script:cfg.historyRoot) $t.entity
       $entityRoot=Join-Path ([string]$script:cfg.sharedRoot) $t.entity
       $relative=[IO.Path]::GetRelativePath($entityRoot,$t.statusRoot)
       $parts=$relative -split '[\\/]';$parts[-1]='EN COURS'
       $archive=Join-Path $archive ($parts -join [IO.Path]::DirectorySeparatorChar)
       if($t.branch){$archive=Join-Path $archive $t.branch}
       [void][IO.Directory]::CreateDirectory($archive)
       $archived=Join-Path $archive $t.name
       if(Test-Path -LiteralPath $archived){$archived=Join-Path $archive ((Get-Date -Format yyyyMMddHHmmss)+'_'+$t.name)}
       try{Copy-Item -LiteralPath $u.path -Destination $dest -Recurse -ErrorAction Stop}
       catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw}
       try{
         Copy-Item -LiteralPath $t.currentPath -Destination $archived -ErrorAction Stop
         if((Get-Item -LiteralPath $archived).Length -ne (Get-Item -LiteralPath $t.currentPath).Length){throw 'Copie de l original incomplète'}
         Remove-Item -LiteralPath $t.currentPath -Force -ErrorAction Stop
       }catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;Remove-Item -LiteralPath $archived -Force -ErrorAction SilentlyContinue;throw}
       $t.currentPath=$dest;$t.resultPath=$dest;$t.historyPath=$archived;$t.status=[string]$b.status;$t.finished=(Get-Date).ToString('o');$t.comment=[string]$b.comment;$t.solution=[string]$b.solution
       Save-Catalog $catalog
       try{Audit 'FIN_TRAITEMENT' $t $actor $folder}catch{$script:lastError=$_.Exception.Message}
       Remove-Item -LiteralPath $u.path -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.upload)
       return $t
     }
     Reply-Json $client @{ok=$true;document=$result};return
   }
   if($path -eq '/api/rework'){
     $result=With-Store {
       $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
       if($t.status -ne 'NON_CONFORME'){throw 'Dossier non conforme absent'}
       $u=Upload-Ready ([string]$b.upload) $actor $t.stem $t.name
       $dest=Join-Path (Get-Destination $t 'TRAITES') $u.root
       if(Test-Path -LiteralPath $dest){throw 'Résultat déjà présent'}
       try{Copy-Item -LiteralPath $u.path -Destination $dest -Recurse -ErrorAction Stop}
       catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw}
       try{Remove-Item -LiteralPath $t.resultPath -Recurse -Force -ErrorAction Stop}catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw}
       $t.status='TRAITES';$t.resultPath=$dest;$t.currentPath=$dest;$t.reworked=(Get-Date).ToString('o')
       Save-Catalog $catalog
       try{Audit 'RETRAITEMENT' $t $actor ([string]$b.note)}catch{$script:lastError=$_.Exception.Message}
       Remove-Item -LiteralPath $u.path -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.upload)
       return $t
     }
     Reply-Json $client @{ok=$true;document=$result};return
   }
 }
 if($path -in @('/','/app.js','/style.css')){
   $file=switch($path){'/'{"$Mode.html"}'/app.js'{'app.js'}'/style.css'{'style.css'}}
   $content=Join-Path (Join-Path $base 'web') $file
   $type=if($file.EndsWith('.js')){'application/javascript; charset=utf-8'}elseif($file.EndsWith('.css')){'text/css; charset=utf-8'}else{'text/html; charset=utf-8'}
   Reply $client 200 $type ([IO.File]::ReadAllBytes($content));return
 }
 Reply-Json $client @{error='Route inconnue'} 404
}
try{
 Discover
 while($script:run){
   Pump
   if(!$listener.Pending()){Start-Sleep -Milliseconds 250;continue}
   $client=$listener.AcceptTcpClient()
   try{$request=Read-Request $client $port;Serve $client $request}
   catch{
     $errorText=$_.Exception.Message
     try{Reply-Json $client @{error=$errorText} 400}catch{try{$client.Close()}catch{}}
     $lastError=$errorText
   }
 }
}finally{
 foreach($name in @($script:children.Keys)){
  try{$child=$script:children[$name];if(!$child.HasExited){Stop-Process -Id $child.Id -Force -ErrorAction SilentlyContinue}}catch{}
 }
 $listener.Stop()
 if(Test-Path -LiteralPath $endpointPath){
   try{if(([IO.File]::ReadAllText($endpointPath)|ConvertFrom-Json).instance -eq $instance){Remove-Item -LiteralPath $endpointPath -Force;Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue}}catch{}
 }
}
