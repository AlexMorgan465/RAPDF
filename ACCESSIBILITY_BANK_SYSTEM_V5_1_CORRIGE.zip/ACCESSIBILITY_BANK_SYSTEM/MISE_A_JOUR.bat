@echo off
setlocal
chcp 65001 >nul
set /p "TARGET=Chemin du dossier ACCESSIBILITY_BANK_SYSTEM existant : "
if not exist "%TARGET%\AGENT\server.ps1" (echo Dossier invalide.& pause& exit /b 1)
echo Arretez les deux serveurs avant la mise a jour.
pause
copy /y "%~dp0common.ps1" "%TARGET%\common.ps1" >nul
if errorlevel 1 goto fail
copy /y "%~dp0AGENT\server.ps1" "%TARGET%\AGENT\server.ps1" >nul
if errorlevel 1 goto fail
copy /y "%~dp0MANAGER\server.ps1" "%TARGET%\MANAGER\server.ps1" >nul
if errorlevel 1 goto fail
echo Correction installee. DATA et CONFIG.ps1 conserves. Relancez les serveurs.
pause
exit /b 0
:fail
echo Echec de copie. Verifiez les droits et le chemin.
pause
exit /b 1
