AGENT ORBIT FINAL — VBA LOGIC

Double-clique START_AGENT_ORBIT.bat.

Architecture:
- indépendant du Command Center
- aucun JSON central
- aucun scan global récursif
- compte directement les branches métier du DP
- ne charge la liste d'un dossier qu'après sélection
- actualisation toutes les 3 secondes
- déplacement atomique directement sur le partage
- bouton Leave the universe pour arrêter le serveur local

Racine configurée:
\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE

Les structures ACM, CMO, COFIDIS FRANCE, CONTRATHEQUE, DIRCO, DIRCOM,
CIC CIB ASSET SERVICING et les entités simples sont codées dans server.ps1.
