﻿param([int]$Port=8790,[string]$RootPath="\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE")
$ErrorActionPreference="Stop"
$Schema=[ordered]@{
"ACM"=@{Mode="STATUS_FIRST";Branches=@("ASS-BIENS","ASS-COMPTA-CONTENTIEUX","ASS-EMPRUNTEURS","ASS-INDEMN-BIENS-PERS","ASS-PERS-COLL","ASS-PERS-IND","ASS-PROTECTION-JUR","ASS-VIE-EPARGNE-RET\MONABANQ - VIE","ASS-VIE-EPARGNE-RET\RETRAITE COLLECTIVE")}
"Bouygues telecom"=@{Mode="SIMPLE";Branches=@("")}
"CIC CIB ASSET SERVICING"=@{Mode="STATUS_FIRST";Branches=@("Agence Clientèle Déposée")}
"CMMABN"=@{Mode="SIMPLE";Branches=@("")}
"CMO"=@{Mode="STATUS_FIRST";Branches=@("BAD","Cartes bancaires","Compte courant","Epargne bancaire","Epargne financière","Packages","Tarif")}
"COFIDIS FRANCE"=@{Mode="STATUS_FIRST";Branches=@("COFIDIS FRANCE-DMA\DMA – Agence WEB","COFIDIS FRANCE-DMA\DMA – Marque et Stratégie","COFIDIS FRANCE-DMA\DMA – Performance Digitale","COFIDIS FRANCE-DPA\DPA – Domaine Marketing","COFIDIS FRANCE-DPA\DPA – Service Marketing","COFIDIS FRANCE-DPA\DPA – Service Relation")}
"CONTRATHEQUE"=@{Mode="CATEGORY_FIRST";Branches=@("CONDITIONS GENERALES","DOCUMENT D'INFORMATION TARIFAIRE","GARANTIES","POLITIQUE DE PROTECTION")}
"CREATIS"=@{Mode="SIMPLE";Branches=@("")}
"DIRCO"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"DIRCOM"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"MONABANQ"=@{Mode="SIMPLE";Branches=@("")}
}
$Statuses=@("A TRAITER","EN COURS","NON CONFORME","TRAITES")
function J($o){$o|ConvertTo-Json -Depth 8 -Compress}
function Send($c,$code,$o){$b=[Text.Encoding]::UTF8.GetBytes((J $o));$c.Response.StatusCode=$code;$c.Response.ContentType="application/json; charset=utf-8";$c.Response.Headers["Cache-Control"]="no-store";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Q($r){$h=@{};if($r.Url.Query.Length-gt 1){foreach($p in $r.Url.Query.Substring(1).Split("&")){$k=$p.Split("=",2);if($k.Count-eq 2){$h[[Uri]::UnescapeDataString($k[0])] = [Uri]::UnescapeDataString(($k[1]-replace '\+',' '))}}};$h}
function Body($r){$sr=New-Object IO.StreamReader($r.InputStream,$r.ContentEncoding);$t=$sr.ReadToEnd();$sr.Close();if(!$t){return @{}};$t|ConvertFrom-Json}
function BranchPath($e,$s,$b){
 if(!$Schema.Contains($e)){throw "Entité inconnue: $e"}; if($Statuses-notcontains$s){throw "Statut invalide"}
 $cfg=$Schema[$e];$p=Join-Path $RootPath $e
 if($cfg.Mode-eq"CATEGORY_FIRST"){if(!$b){throw "Sous-entité requise"};return Join-Path (Join-Path $p $b) $s}
 $p=Join-Path $p $s;if($b){$p=Join-Path $p $b};$p
}
$StateFile=Join-Path $RootPath ".agent_orbit_counts.json"
function CountBranch($e,$s,$b){$p=BranchPath $e $s $b;if(![IO.Directory]::Exists($p)){return 0};$n=0;try{foreach($x in [IO.Directory]::EnumerateFileSystemEntries($p)){$n++}}catch{};return $n}
function NewState(){$a=@();foreach($e in $Schema.Keys){$a+=@{entity=$e;counts=[ordered]@{"A TRAITER"=0;"EN COURS"=0;"NON CONFORME"=0};total=0}};return @{entities=$a;initialized=$false;at="JAMAIS"}}
function ReadState(){try{if([IO.File]::Exists($StateFile)){return (Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8|ConvertFrom-Json)}}catch{};return (NewState)}
function WriteState($st){$tmp=$StateFile+"."+[Guid]::NewGuid().ToString("N")+".tmp";[IO.File]::WriteAllText($tmp,(J $st),(New-Object Text.UTF8Encoding($false)));if([IO.File]::Exists($StateFile)){try{[IO.File]::Replace($tmp,$StateFile,$null)}catch{Move-Item -LiteralPath $tmp -Destination $StateFile -Force}}else{Move-Item -LiteralPath $tmp -Destination $StateFile -Force}}
function Counts(){return (ReadState)}
function FullScan(){$a=@();foreach($e in $Schema.Keys){$c=[ordered]@{};foreach($s in @("A TRAITER","EN COURS","NON CONFORME")){$n=0;foreach($b in $Schema[$e].Branches){$n+=CountBranch $e $s $b};$c[$s]=$n};$a+=@{entity=$e;counts=$c;total=([int]$c["A TRAITER"]+[int]$c["EN COURS"]+[int]$c["NON CONFORME"])}};$st=@{entities=$a;initialized=$true;at=(Get-Date).ToString("dd/MM/yyyy HH:mm:ss")};WriteState $st;return $st}
function AdjustState($entity,$from,$to){$st=ReadState;if(-not $st.initialized){return};foreach($x in $st.entities){if($x.entity -eq $entity){if($from -ne "TRAITES"){$p=$x.counts.PSObject.Properties[$from];if($null -ne $p){$p.Value=[Math]::Max(0,[int]$p.Value-1)}};if($to -ne "TRAITES"){$p=$x.counts.PSObject.Properties[$to];if($null -ne $p){$p.Value=[int]$p.Value+1}};$x.total=[int]$x.counts.'A TRAITER'+[int]$x.counts.'EN COURS'+[int]$x.counts.'NON CONFORME'}};$st.at=(Get-Date).ToString("dd/MM/yyyy HH:mm:ss");WriteState $st}
function Items($p){if(![IO.Directory]::Exists($p)){return @()};@(Get-ChildItem -LiteralPath $p -Force|%{@{name=$_.Name;kind=$(if($_.PSIsContainer){"Dossier"}else{"Fichier"});modified=$_.LastWriteTime.ToString("dd/MM/yyyy HH:mm")}})}
function Safe($n){if(!$n-or$n.Contains("..")-or$n.Contains("\")-or$n.Contains("/")){throw "Nom invalide"};$n}
function MoveOne($b){
 $n=Safe ([string]$b.name);$srcD=BranchPath ([string]$b.entity) ([string]$b.from) ([string]$b.branch);$dstD=BranchPath ([string]$b.entity) ([string]$b.to) ([string]$b.branch)
 if(![IO.Directory]::Exists($dstD)){[IO.Directory]::CreateDirectory($dstD)|Out-Null};$src=Join-Path $srcD $n;$dst=Join-Path $dstD $n
 if(!([IO.Directory]::Exists($src)-or[IO.File]::Exists($src))){throw "Déjà déplacé ou introuvable"}
 if([IO.Directory]::Exists($dst)-or[IO.File]::Exists($dst)){throw "Existe déjà à destination"}
 if([IO.Directory]::Exists($src)){[IO.Directory]::Move($src,$dst)}else{[IO.File]::Move($src,$dst)}
 AdjustState ([string]$b.entity) ([string]$b.from) ([string]$b.to)
 @{ok=$true}
}

$HistoryRoot=Join-Path $RootPath ".accessibility_history"
$HistoryFile=Join-Path $HistoryRoot "operations.jsonl"
function ReadHistory(){
 $a=@();try{if([IO.File]::Exists($HistoryFile)){foreach($ln in [IO.File]::ReadLines($HistoryFile)){if($ln.Trim()){try{$a+=($ln|ConvertFrom-Json)}catch{}}}}}catch{}
 @($a|Sort-Object timestamp -Descending)
}
function Dashboard(){
 $h=@(ReadHistory);$agents=@()
 foreach($g in ($h|Group-Object agent)){
  $final=@($g.Group|?{$_.to-eq"TRAITES"-or$_.to-eq"NON CONFORME"})
  $dm=@($final|?{$null-ne$_.dmt_minutes}|%{[double]$_.dmt_minutes})
  $avg=if($dm.Count){[Math]::Round((($dm|Measure-Object -Average).Average),2)}else{$null}
  $agents+=@{agent=$g.Name;operations=$g.Count;pec=@($g.Group|?{$_.to-eq"EN COURS"}).Count;traites=@($g.Group|?{$_.to-eq"TRAITES"}).Count;nc=@($g.Group|?{$_.to-eq"NON CONFORME"}).Count;dmt=$avg}
 }
 $today=@($h|?{([datetime]$_.timestamp).Date-eq(Get-Date).Date})
 $byEntity=@();foreach($g in ($h|Group-Object entity)){$byEntity+=@{name=$g.Name;value=$g.Count}}
 $byDay=@();foreach($g in ($h|Group-Object {([datetime]$_.timestamp).ToString("yyyy-MM-dd")})){$byDay+=@{name=$g.Name;value=$g.Count}}
 @{agents=$agents;history=$h;today=$today.Count;byEntity=$byEntity;byDay=$byDay}
}


$MetaRoot=Join-Path $RootPath ".accessibility_system";$MetaFile=Join-Path $MetaRoot "documents.json";$PriceFile=Join-Path $MetaRoot "prices.json";$MailFile=Join-Path $MetaRoot "mail_recipients.json"
function EnsureMeta(){if(![IO.Directory]::Exists($MetaRoot)){[IO.Directory]::CreateDirectory($MetaRoot)|Out-Null}}
function RJson($p,$f){try{if([IO.File]::Exists($p)){return(Get-Content -LiteralPath $p -Raw -Encoding UTF8|ConvertFrom-Json)}}catch{};return $f}
function WJson($p,$o){EnsureMeta;[IO.File]::WriteAllText($p,(J $o),(New-Object Text.UTF8Encoding($false)))}
function DKey($e,$b,$n){($e+"|"+$b+"|"+$n).ToLowerInvariant()}
function Metas(){@(RJson $MetaFile @())};function SaveMetas($a){WJson $MetaFile @($a)}
function EnsureDM($e,$b,$s,$n,$fp){$a=@(Metas);$k=DKey $e $b $n;$m=$a|?{$_.key-eq$k}|select -First 1;if($null-eq$m){$dep=(Get-Date).ToString("o");try{$dep=(Get-Item -LiteralPath $fp).LastWriteTime.ToString("o")}catch{};$m=[pscustomobject]@{key=$k;entity=$e;branch=$b;name=$n;deposit_date=$dep;priority=$false;priority_note="";complex=$false;complex_comment="";current_status=$s;status_since=(Get-Date).ToString("o")};$a+=$m;SaveMetas $a};return $m}
function MoveMeta($e,$b,$n,$to){$a=@(Metas);$m=$a|?{$_.key-eq(DKey $e $b $n)}|select -First 1;if($m){$m.current_status=$to;$m.status_since=(Get-Date).ToString("o");SaveMetas $a}}
function FlagMeta($e,$b,$n,$f,$v,$c){$a=@(Metas);$m=$a|?{$_.key-eq(DKey $e $b $n)}|select -First 1;if(!$m){throw "Document non indexé"};if($f-eq"priority"){$m.priority=[bool]$v;$m.priority_note=$c}else{$m.complex=[bool]$v;$m.complex_comment=$c};SaveMetas $a;$m}
function AgeMin($m){try{[Math]::Round(((Get-Date)-[datetime]$m.status_since).TotalMinutes,1)}catch{0}}
function DefPrices(){@(@{entity="Bouygues telecom";unit=9},@{entity="CONTRATHEQUE";unit=9},@{entity="CMO";unit=9},@{entity="DIRCO";unit=4.5},@{entity="ACM";unit=9},@{entity="CMMABN";unit=4.5},@{entity="DIRCOM";unit=9},@{entity="MONABANQ";unit=9},@{entity="CREATIS";unit=9},@{entity="CIC CIB ASSET SERVICING";unit=4.5},@{entity="COFIDIS FRANCE";unit=0})}
function Prices(){$p=RJson $PriceFile $null;if($null-eq$p){$p=DefPrices;WJson $PriceFile $p};@($p)}
function SetPrice($e,$u){$p=@(Prices);$x=$p|?{$_.entity-eq$e}|select -First 1;if($x){$x.unit=[double]$u}else{$p+=@{entity=$e;unit=[double]$u}};WJson $PriceFile $p;@($p)}
function Recips(){@(RJson $MailFile @())};function SetRecip($e,$mail){$a=@(Recips);$x=$a|?{$_.entity-eq$e}|select -First 1;if($x){$x.email=$mail}else{$a+=@{entity=$e;email=$mail}};WJson $MailFile $a;@($a)}

$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Start-Process "http://localhost:$Port/"
try{$run=$true;while($run){$c=$l.GetContext();try{$r=$c.Request;$p=$r.Url.AbsolutePath
 if($p-eq"/"){ $f=Join-Path $PSScriptRoot "index.html";$b=[IO.File]::ReadAllBytes($f);$c.Response.ContentType="text/html; charset=utf-8";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close();continue}
 if($p-eq"/api/ping"){Send $c 200 @{ok=$true;root=$RootPath;exists=[IO.Directory]::Exists($RootPath)};continue}
 if($p-eq"/api/schema"){$x=@();foreach($e in $Schema.Keys){$x+=@{entity=$e;mode=$Schema[$e].Mode;branches=@($Schema[$e].Branches)}};Send $c 200 @{entities=$x};continue}
 if($p-eq"/api/counts"){Send $c 200 (Counts);continue}
 if($p-eq"/api/dashboard"){Send $c 200 (Dashboard);continue}
 if($p-eq"/api/meta"){Send $c 200 @{items=@(Metas)};continue}
 if($p-eq"/api/indexdocs"-and$r.HttpMethod-eq"POST"){
  $n=0;foreach($e in $Schema.Keys){foreach($st in @("A TRAITER","EN COURS","NON CONFORME","TRAITES")){foreach($br in $Schema[$e].Branches){$bp=BranchPath $e $st $br;if([IO.Directory]::Exists($bp)){try{foreach($fp in [IO.Directory]::EnumerateFileSystemEntries($bp)){EnsureDM $e $br $st ([IO.Path]::GetFileName($fp)) $fp|Out-Null;$n++}}catch{}}}}};Send $c 200 @{ok=$true;indexed=$n};continue}
 if($p-eq"/api/flag"-and$r.HttpMethod-eq"POST"){$b=Body $r;Send $c 200 (FlagMeta $b.entity $b.branch $b.name $b.field $b.value $b.comment);continue}
 if($p-eq"/api/prices"){Send $c 200 @{prices=@(Prices)};continue}
 if($p-eq"/api/price"-and$r.HttpMethod-eq"POST"){$b=Body $r;Send $c 200 @{prices=@(SetPrice $b.entity ([double]$b.unit))};continue}
 if($p-eq"/api/recipients"){Send $c 200 @{recipients=@(Recips)};continue}
 if($p-eq"/api/recipient"-and$r.HttpMethod-eq"POST"){$b=Body $r;Send $c 200 @{recipients=@(SetRecip $b.entity $b.email)};continue}
 if($p-eq"/api/ncmail"-and$r.HttpMethod-eq"POST"){$b=Body $r;try{$ol=New-Object -ComObject Outlook.Application;$m=$ol.CreateItem(0);$m.To=$b.email;$m.Subject="Accessibilité - Non conformité - "+$b.entity;$m.Body=$b.body;$m.Display();Send $c 200 @{ok=$true}}catch{Send $c 500 @{error=$_.Exception.Message}};continue}

 if($p-eq"/api/fullscan"-and$r.HttpMethod-eq"POST"){Send $c 200 (FullScan);continue}
 if($p-eq"/api/items"){$q=Q $r;$bp=BranchPath $q.entity $q.status $q.branch;Send $c 200 @{items=@(Items $bp);path=$bp};continue}
 if($p-eq"/api/move"-and$r.HttpMethod-eq"POST"){Send $c 200 (MoveOne (Body $r));continue}
 if($p-eq"/api/leave"-and$r.HttpMethod-eq"POST"){Send $c 200 @{ok=$true};$run=$false;continue}
 Send $c 404 @{error="Route inconnue"}
}catch{try{Send $c 500 @{error=$_.Exception.Message}}catch{}}}}finally{$l.Stop();$l.Close()}