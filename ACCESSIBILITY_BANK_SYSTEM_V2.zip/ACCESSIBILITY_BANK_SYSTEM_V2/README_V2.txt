ACCESSIBILITY BANK SYSTEM V2

AGENT (port 8788)
- Urgences provenant des priorités Manager.
- Flag COMPLEXE + commentaire libre.
- Workflow libre entre A TRAITER / EN COURS / NON CONFORME / TRAITES.
- DMT + durée dans le statut + historique.

MANAGER (port 8790)
- TDB détaillé agents / DMT / stock.
- Bouton INDEXER LE DP : au premier indexage, LastWriteTime devient DATE DE DEPOT et est ensuite figée définitivement dans documents.json.
- Priorités visibles dans l'onglet Urgences Agent.
- Facturation mensuelle = nombre de documents traités x prix unitaire.
- Prix unitaires modifiables. Valeurs initiales reprises de la photo.
- Les documents COMPLEXES sont identifiés dans la consolidation/facturation.
- Non conformes : destinataire mémorisé par entité + création de brouillon Outlook.
- Durée de présence dans le statut courant.
- Reporting reçus / traités : Année, Mois, Semaine ISO, Jour + filtres date et entité.
- Historique consolidé.

Fichiers partagés créés dans le DP:
.accessibility_system/documents.json
.accessibility_system/prices.json
.accessibility_system/mail_recipients.json
.accessibility_history/operations.jsonl
