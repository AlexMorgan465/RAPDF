# Accessibilité — Nouveau projet

## Installer et démarrer

1. Extraire **toute** l’archive dans un dossier où la session Windows peut écrire dans `data`. Conserver ce même dossier pour les deux interfaces.
2. Vérifier `config.json` : `sharedRoot` est le DP Accessibilité et `historyRoot` le chemin distinct d’historique. Les ports locaux par défaut sont 8091 (agent) et 8092 (manager). Adapter `managerAccounts` à vos sessions autorisées.
3. Double-cliquer sur `START_AGENT.bat` pour l’agent, et `START_MANAGER.bat` pour le manager. Chaque bouton **Déconnecter** ferme son propre serveur. Pour voir une erreur de démarrage, lancer `START_VISIBLE_AGENT.bat` ou `START_VISIBLE_MANAGER.bat` et consulter `data/agent-error.log` ou `data/manager-error.log`.
4. Les deux serveurs utilisent `TcpListener` sur `127.0.0.1`, sans inscription dans HTTP.sys (PID 4). Les processus sont deux `pwsh.exe` distincts et les ports peuvent être observés avec `netstat -ano`.

## Fonctionnement

- L’application détecte les entités directement sous le DP. Sous chaque entité, elle cherche récursivement les dossiers `A TRAITER`, `EN COURS` et `NON CONFORME`, quelle que soit leur profondeur. Le cinquième dossier `A PUBLIER` d’ACM est conservé. Les PDF, DOC et DOCX sont détectés dans `A TRAITER` et `EN COURS`. Les résultats dans `NON CONFORME` et `TRAITES` sont des dossiers.
- L’extraction tourne en parallèle avec `maxEntityWorkers` (4 par serveur par défaut), et `FileSystemWatcher` signale les entités à réconcilier. Un contrôle périodique récupère les événements réseau manqués. Le catalogue `data/catalog.json` charge immédiatement la dernière vue avant le scan. Lors du premier démarrage avec catalogue vide, `TRAITES` est importé une fois en arrière-plan, par entité ; les contrôles ordinaires suivants ne rescannent pas cet arbre.
- **Prise en charge** : déplace le document de `A TRAITER` à `EN COURS` en conservant la branche. **Terminer** : exige un dossier local portant le nom du document sans extension (ou son nom complet), copie le résultat dans `TRAITES` ou `NON CONFORME`, archive l’original sous `historyRoot`, puis le retire de `EN COURS`. Le statut non conforme exige un problème et une solution. **Retraitement** : copie un nouveau dossier dans `TRAITES` puis supprime l’ancien dossier de `NON CONFORME`.
- Les mouvements, dates, agents et commentaires sont conservés dans `catalog.json` et `audit.jsonl`. Le manager dispose de tous les statuts, graphiques, historique et export CSV lisible dans Excel. Une session autre que celles définies dans `managerAccounts` ne peut pas démarrer le serveur manager. Aucune page d’identification : le nom de la session Windows est affiché.

## Limites d’exploitation

Les ports ne sont accessibles que depuis **le poste qui lance le serveur**. Le nom de session provient du processus PowerShell, donc chaque utilisateur doit lancer sa propre instance dans sa session Windows. Cette variante locale ne doit pas être exposée sur le réseau ou derrière un proxy : elle n’identifie pas séparément les navigateurs distants. Les deux serveurs doivent utiliser le même dossier applicatif pour partager l’index et le journal. Sauvegardez régulièrement `data`.

La qualité et le débit de `FileSystemWatcher` sur un partage UNC dépendent du serveur de fichiers ; la réconciliation périodique est nécessaire. Si le DP est indisponible, le dernier catalogue reste consultable et les actions échouent explicitement.
