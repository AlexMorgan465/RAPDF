Option Explicit
Dim shell, fso, root, mode, port, url, command, i, req, ok
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
mode = "agent"
If WScript.Arguments.Count > 0 Then mode = LCase(WScript.Arguments(0))
If mode <> "agent" And mode <> "manager" Then WScript.Quit
port = 8091
If mode = "manager" Then port = 8092
url = "http://localhost:" & port & "/"
If shell.Run("cmd /c where pwsh.exe >nul 2>nul", 0, True) <> 0 Then
  MsgBox "PowerShell 7 est requis. Vérifiez avec START_VISIBLE_" & UCase(mode) & ".bat", vbExclamation, "Accessibilité"
  WScript.Quit
End If
If Not Ready(url, mode) Then
  command = "pwsh.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File " & Chr(34) & root & "\server-" & mode & ".ps1" & Chr(34)
  shell.Run command, 0, False
  For i = 1 To 60
    WScript.Sleep 250
    If Ready(url, mode) Then Exit For
  Next
End If
If Ready(url, mode) Then
  shell.Run url, 1, False
Else
  MsgBox "Démarrage impossible. Ouvrez START_VISIBLE_" & UCase(mode) & ".bat puis consultez data\" & mode & "-error.log", vbExclamation, "Accessibilité"
End If
Function Ready(address, role)
  On Error Resume Next
  Set req = CreateObject("MSXML2.ServerXMLHTTP.6.0")
  req.setTimeouts 300, 300, 300, 300
  req.Open "GET", address & "api/health", False
  req.Send
  Ready = False
  If Err.Number = 0 Then Ready = (req.Status = 200 And InStr(req.responseText, Chr(34) & role & Chr(34)) > 0)
  Err.Clear
End Function
