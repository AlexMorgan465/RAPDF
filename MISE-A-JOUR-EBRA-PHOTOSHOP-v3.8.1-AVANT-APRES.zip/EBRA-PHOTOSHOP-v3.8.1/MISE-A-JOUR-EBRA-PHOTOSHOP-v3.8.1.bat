@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Mise a jour EBRA Photoshop v3.8.1 - Avant Apres

set "UPDATE=%~dp0"
set "ROOT=%~dp0"
if not exist "%ROOT%EBRA-Manager\web\index.html" if exist "%ROOT%..\EBRA-Manager\web\index.html" set "ROOT=%~dp0..\"

if not exist "%ROOT%EBRA-Manager\web\index.html" goto :notfound
if not exist "%ROOT%EBRA-Press-Service\web\index.html" goto :notfound
if not exist "%UPDATE%patch\photo375.js" goto :missingpatch

echo.
echo ================================================
echo   EBRA PHOTOSHOP v3.8.1 - MODE AVANT / APRES
echo ================================================
echo.
echo Fermez Agent et Manager avant de continuer.
echo Installation dans : %ROOT%
echo.

if exist "%ROOT%EBRA-Manager\web\photo375.js" copy /Y "%ROOT%EBRA-Manager\web\photo375.js" "%ROOT%EBRA-Manager\web\photo375.js.backup-v3.8.1" >nul
if exist "%ROOT%EBRA-Press-Service\web\photo375.js" copy /Y "%ROOT%EBRA-Press-Service\web\photo375.js" "%ROOT%EBRA-Press-Service\web\photo375.js.backup-v3.8.1" >nul

copy /Y "%UPDATE%patch\photo375.js" "%ROOT%EBRA-Manager\web\photo375.js" >nul || goto :failed
copy /Y "%UPDATE%patch\photo375.js" "%ROOT%EBRA-Press-Service\web\photo375.js" >nul || goto :failed

for %%F in ("%ROOT%EBRA-Manager\web\photo375.js" "%ROOT%EBRA-Press-Service\web\photo375.js") do if %%~zF LSS 1000 goto :failed

echo.
echo SUCCES : le mode Avant / Apres est installe.
echo Nouvelles fonctions :
echo   - photo originale a gauche
echo   - resultat detoure a droite
echo   - fond blanc ou transparent
echo   - sensibilite reglable
echo   - correction avec pinceau et gomme
echo.
echo Fermez tous les onglets EBRA dans Edge puis relancez les applications.
echo.
pause
exit /b 0

:notfound
echo.
echo ERREUR : EBRA-Manager ou EBRA-Press-Service est introuvable.
echo Extrayez le dossier de mise a jour a cote des deux dossiers EBRA.
echo.
pause
exit /b 1

:missingpatch
echo.
echo ERREUR : patch\photo375.js est absent.
echo Extrayez completement le ZIP avant de lancer le BAT.
echo.
pause
exit /b 1

:failed
echo.
echo ERREUR pendant l'installation.
echo Fermez EBRA et recommencez. Les sauvegardes portent l'extension backup-v3.8.1.
echo.
pause
exit /b 1
