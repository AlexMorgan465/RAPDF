@echo off
setlocal EnableExtensions
chcp 65001 >nul
title Mise a jour EBRA Photoshop v3.7.3

set "ROOT=%~dp0"
set "MANAGER="
set "AGENT="

if exist "%ROOT%manager_src\EBRA-Manager\web\index.html" set "MANAGER=%ROOT%manager_src\EBRA-Manager\web"
if exist "%ROOT%EBRA-Manager\web\index.html" set "MANAGER=%ROOT%EBRA-Manager\web"
if exist "%ROOT%work\EBRA-Press-Service\web\index.html" set "AGENT=%ROOT%work\EBRA-Press-Service\web"
if exist "%ROOT%EBRA-Press-Service\web\index.html" set "AGENT=%ROOT%EBRA-Press-Service\web"

if not defined MANAGER goto :notfound
if not defined AGENT goto :notfound

copy /Y "%ROOT%patch\photo.css" "%MANAGER%\photo.css" >nul || goto :failed
copy /Y "%ROOT%patch\photo.js" "%MANAGER%\photo.js" >nul || goto :failed
copy /Y "%ROOT%patch\manager-index.html" "%MANAGER%\index.html" >nul || goto :failed
copy /Y "%ROOT%patch\photo.css" "%AGENT%\photo.css" >nul || goto :failed
copy /Y "%ROOT%patch\photo.js" "%AGENT%\photo.js" >nul || goto :failed
copy /Y "%ROOT%patch\agent-index.html" "%AGENT%\index.html" >nul || goto :failed

echo.
echo Mise a jour v3.7.3 terminee avec succes.
echo Fermez puis relancez EBRA Manager et EBRA Agent.
echo La nouvelle version contourne automatiquement le cache Edge.
echo.
pause
exit /b 0

:notfound
echo.
echo ERREUR : dossiers EBRA introuvables.
echo Extrayez ce ZIP directement dans le dossier racine EBRA SERVICE,
echo celui qui contient manager_src et work.
echo.
pause
exit /b 1

:failed
echo.
echo ERREUR : impossible de copier les fichiers de mise a jour.
echo Fermez EBRA puis recommencez.
echo.
pause
exit /b 1
