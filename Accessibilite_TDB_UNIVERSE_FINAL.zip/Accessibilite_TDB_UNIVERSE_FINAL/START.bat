@echo off
cd /d "%~dp0"
if not exist data mkdir data
del /q data\STOP 2>nul
start "ACCESS SCANNER V4.2 - NE PAS FERMER" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scanner.ps1"
timeout /t 1 /nobreak >nul
start "" http://localhost:8787
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
