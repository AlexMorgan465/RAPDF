$ErrorActionPreference = 'Stop'
$version = '0.10.35'
$base = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@$version"
$assets = @{
  'vision_bundle.mjs' = "$base/vision_bundle.mjs"
  'vision_wasm_internal.js' = "$base/wasm/vision_wasm_internal.js"
  'vision_wasm_internal.wasm' = "$base/wasm/vision_wasm_internal.wasm"
  'vision_wasm_nosimd_internal.js' = "$base/wasm/vision_wasm_nosimd_internal.js"
  'vision_wasm_nosimd_internal.wasm' = "$base/wasm/vision_wasm_nosimd_internal.wasm"
  'selfie_segmenter.tflite' = 'https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter/float16/latest/selfie_segmenter.tflite'
}
$destination = Join-Path $PSScriptRoot 'EBRA-Manager\web\ai'
New-Item -ItemType Directory -Force -Path $destination | Out-Null
foreach ($name in $assets.Keys) {
  $path = Join-Path $destination $name
  Write-Host "Telechargement : $name"
  try { Invoke-WebRequest -Uri $assets[$name] -OutFile $path -UseBasicParsing } catch { Remove-Item $path -ErrorAction SilentlyContinue; throw "Echec du telechargement de $name : $($_.Exception.Message)" }
  if ((Get-Item $path).Length -lt 1024) { throw "Fichier incomplet : $name" }
}
$second = Join-Path $PSScriptRoot 'EBRA-Press-Service\web\ai'
New-Item -ItemType Directory -Force -Path $second | Out-Null
foreach ($name in $assets.Keys) { Copy-Item (Join-Path $destination $name) (Join-Path $second $name) -Force }
Write-Host 'Modele installe pour Manager et Press Service. Redemarrez les serveurs.'
