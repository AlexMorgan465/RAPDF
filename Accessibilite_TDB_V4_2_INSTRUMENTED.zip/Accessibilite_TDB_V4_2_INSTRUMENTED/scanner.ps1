param(
  [string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',
  [int]$IntervalSeconds=60
)
$ErrorActionPreference='Continue'
$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path
$Data=Join-Path $AppDir 'data'; New-Item -ItemType Directory -Force -Path $Data | Out-Null
$Index=Join-Path $Data 'index.json'; $Scan=Join-Path $Data 'scan.json'; $Diag=Join-Path $Data 'diagnostic.json'; $Log=Join-Path $Data 'scanner.log'; $Stop=Join-Path $Data 'STOP'
if(Test-Path $Stop){Remove-Item $Stop -Force -EA SilentlyContinue}

function Log([string]$m,[string]$kind='INFO'){
  $line='[{0}] [{1}] {2}' -f (Get-Date -Format 'HH:mm:ss'),$kind,$m
  Write-Host $line -ForegroundColor $(if($kind-eq'ERR'){'Red'}elseif($kind-eq'OK'){'Green'}elseif($kind-eq'SCAN'){'Cyan'}else{'Gray'})
  try{Add-Content -LiteralPath $Log -Value $line -Encoding UTF8}catch{}
}
function Atomic($p,$o){
  $t="$p.$([guid]::NewGuid().ToString('N')).tmp"
  try{
    $j=$o|ConvertTo-Json -Depth 14
    [IO.File]::WriteAllText($t,$j,(New-Object Text.UTF8Encoding($false)))
    $null=([IO.File]::ReadAllText($t)|ConvertFrom-Json)
    if(Test-Path $p){Remove-Item -LiteralPath $p -Force -EA SilentlyContinue}
    [IO.File]::Move($t,$p)
  } finally {if(Test-Path $t){Remove-Item $t -Force -EA SilentlyContinue}}
}
function NS([string]$n){
  $u=$n.Trim().ToUpperInvariant()
  if($u -match '^A\s*TRAITER$'){return 'A TRAITER'}
  if($u -match '^EN\s*COURS$'){return 'EN COURS'}
  if($u -match '^TRAITE[S]?$'){return 'TRAITES'}
  if($u -match '^NON\s*CONFORME$'){return 'NON CONFORME'}
  if($u -match '^A\s*PUBLIER$'){return 'A PUBLIER'}
  return $null
}
function Rel($b,$f){$x=$b.TrimEnd('\')+'\';if($f.StartsWith($x,[StringComparison]::OrdinalIgnoreCase)){return $f.Substring($x.Length)};return ''}
function State($phase,$entity,$status,$path,$running,$docs,$files,$dirs,$errors,$zonesDone,$zonesTotal,$entsDone,$entsTotal,$started){
  $pct=if($zonesTotal -gt 0){[math]::Round(($zonesDone/[double]$zonesTotal)*100)}else{0}
  Atomic $Scan ([pscustomobject]@{running=$running;phase=$phase;percent=$pct;currentEntity=$entity;currentStatus=$status;currentPath=$path;documents=$docs;filesFound=$files;directoriesVisited=$dirs;errors=$errors;statusFoldersScanned=$zonesDone;statusFoldersTotal=$zonesTotal;entitiesScanned=$entsDone;entitiesTotal=$entsTotal;heartbeat=(Get-Date).ToString('o');startedAt=$started.ToString('o')})
}
function Children($path){
  # Une seule enumeration par dossier. Aucun -Recurse.
  try{return @(Get-ChildItem -LiteralPath $path -Force -EA Stop)}catch{Log "Impossible de lire: $path :: $($_.Exception.Message)" 'ERR';return @()}
}
function FindZones($entity){
  $zones=New-Object Collections.ArrayList
  foreach($d in @(Children $entity.FullName | Where-Object{$_.PSIsContainer -and $_.Name -ne 'OLD'})){
    $s=NS $d.Name
    if($s){[void]$zones.Add([pscustomobject]@{Entity=$entity;Dir=$d;Status=$s});continue}
    # Cas CONTRATHEQUE : un niveau intermédiaire avant le statut.
    foreach($d2 in @(Children $d.FullName | Where-Object{$_.PSIsContainer -and $_.Name -ne 'OLD'})){
      $s2=NS $d2.Name
      if($s2){[void]$zones.Add([pscustomobject]@{Entity=$entity;Dir=$d2;Status=$s2})}
    }
  }
  return @($zones.ToArray())
}
function ScanOnce{
  $started=Get-Date; $rows=New-Object Collections.ArrayList; $diag=New-Object Collections.ArrayList
  $files=0;$dirs=0;$errors=0;$zonesDone=0;$entsDone=0
  Log '===== NOUVEAU SCAN =====' 'SCAN'
  Log "Racine: $Root"
  State 'TEST DP' '' '' $Root $true 0 0 0 0 0 0 0 0 $started
  if(!(Test-Path -LiteralPath $Root)){Log 'DP inaccessible. Vérifie le chemin ou la connexion réseau.' 'ERR';State 'DP INACCESSIBLE' '' '' $Root $false 0 0 0 1 0 0 0 0 $started;return}
  Log 'DP accessible' 'OK'
  Log 'Lecture des entités...'
  $entities=@(Children $Root | Where-Object{$_.PSIsContainer -and $_.Name -ne 'OLD'})
  Log ("Entités trouvées: {0}" -f $entities.Count) 'OK'
  State 'DETECTION STATUTS' '' '' $Root $true 0 0 0 0 0 0 0 $entities.Count $started
  $zones=New-Object Collections.ArrayList
  foreach($e in $entities){
    Log ("> Entité: {0}" -f $e.Name) 'SCAN'
    State 'DETECTION STATUTS' $e.Name '' $e.FullName $true $rows.Count $files $dirs $errors 0 0 $entsDone $entities.Count $started
    foreach($z in @(FindZones $e)){[void]$zones.Add($z);Log ("  Statut: {0} -> {1}" -f $z.Status,$z.Dir.FullName)}
  }
  $zonesTotal=$zones.Count; Log ("Zones statut détectées: {0}" -f $zonesTotal) 'OK'
  Atomic $Index @(); Atomic $Diag @()
  foreach($e in $entities){
    $ez=@($zones.ToArray()|Where-Object{$_.Entity.FullName -eq $e.FullName})
    foreach($z in $ez){
      Log ("SCAN {0} / {1}" -f $e.Name,$z.Status) 'SCAN'
      $beforeDocs=$rows.Count;$beforeFiles=$files;$beforeDirs=$dirs;$empty=0
      $stack=New-Object Collections.Stack;$stack.Push($z.Dir.FullName)
      while($stack.Count -gt 0){
        if(Test-Path $Stop){Log 'STOP demandé';return}
        $path=[string]$stack.Pop();$dirs++
        Log ("  -> {0}" -f $path)
        State 'SCAN DOCUMENTS' $e.Name $z.Status $path $true $rows.Count $files $dirs $errors $zonesDone $zonesTotal $entsDone $entities.Count $started
        $children=@(Children $path)
        $fs=@($children|Where-Object{!$_.PSIsContainer})
        $subs=@($children|Where-Object{$_.PSIsContainer -and $_.Name -ne 'OLD'})
        $files += $fs.Count
        if($path -ne $z.Dir.FullName -and $fs.Count -gt 0){
          $latest=($fs|Sort-Object LastWriteTime -Descending|Select-Object -First 1).LastWriteTime
          $businessRel=Rel $z.Dir.FullName $path;$statusRootRel=Rel $e.FullName $z.Dir.FullName
          $dobj=Get-Item -LiteralPath $path -Force -EA SilentlyContinue
          [void]$rows.Add([pscustomobject]@{id=($e.Name+'|'+$statusRootRel+'|'+$businessRel);entity=$e.Name;status=$z.Status;name=(Split-Path $path -Leaf);statusRootRelative=$statusRootRel;relativePath=$businessRel;fileCount=$fs.Count;modified=$latest.ToString('o');depositDate=if($dobj){$dobj.LastWriteTime.ToString('o')}else{$latest.ToString('o')}})
          # Le dossier contenant des fichiers est l'unité métier: on ne descend plus dessous.
          continue
        }
        if($subs.Count -eq 0 -and $path -ne $z.Dir.FullName){$empty++}
        foreach($s in $subs){$stack.Push($s.FullName)}
      }
      $zonesDone++
      [void]$diag.Add([pscustomobject]@{entity=$e.Name;status=$z.Status;statusRoot=(Rel $e.FullName $z.Dir.FullName);documents=($rows.Count-$beforeDocs);files=($files-$beforeFiles);directories=($dirs-$beforeDirs);emptyBranches=$empty})
      Atomic $Index @($rows.ToArray());Atomic $Diag @($diag.ToArray())
      State 'ZONE TERMINEE' $e.Name $z.Status $z.Dir.FullName $true $rows.Count $files $dirs $errors $zonesDone $zonesTotal $entsDone $entities.Count $started
      Log ("  OK: +{0} dossiers métier, +{1} fichiers" -f ($rows.Count-$beforeDocs),($files-$beforeFiles)) 'OK'
    }
    $entsDone++
  }
  $ended=Get-Date
  Atomic $Index @($rows.ToArray());Atomic $Diag @($diag.ToArray())
  Atomic $Scan ([pscustomobject]@{running=$false;phase='TERMINE';percent=100;documents=$rows.Count;filesFound=$files;directoriesVisited=$dirs;errors=$errors;statusFoldersScanned=$zonesDone;statusFoldersTotal=$zonesTotal;entitiesScanned=$entities.Count;entitiesTotal=$entities.Count;currentEntity='';currentStatus='';currentPath='';heartbeat=$ended.ToString('o');startedAt=$started.ToString('o');completedAt=$ended.ToString('o');durationMs=[math]::Round(($ended-$started).TotalMilliseconds)})
  Log ("TERMINÉ: {0} dossiers métier / {1} fichiers / {2} dossiers parcourus" -f $rows.Count,$files,$dirs) 'OK'
}

Log 'Scanner V4.2 démarré' 'OK'
while(!(Test-Path $Stop)){
  try{ScanOnce}catch{Log $_.Exception.Message 'ERR';try{State 'ERREUR' '' '' '' $false 0 0 0 1 0 0 0 0 (Get-Date)}catch{}}
  Log ("Prochain scan dans {0}s" -f $IntervalSeconds)
  for($i=0;$i-lt$IntervalSeconds;$i++){if(Test-Path $Stop){break};Start-Sleep -Seconds 1}
}
