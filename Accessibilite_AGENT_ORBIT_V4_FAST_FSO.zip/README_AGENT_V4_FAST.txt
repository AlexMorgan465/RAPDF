AGENT ORBIT V4 FAST FSO

- 100% autonome du Command Center.
- Aucun index Manager lu.
- Comptage direct du DP avec Scripting.FileSystemObject, comme le VBA.
- A TRAITER / EN COURS / NON CONFORME uniquement.
- Racine statut: chaque fichier direct = 1 document.
- Sous-dossier: s’il contient au moins un fichier direct = 1 document; la descente continue.
- CONTRATHEQUE: statuts trouvés sous les catégories.
- DIRCO\OLD ignoré.
- Reconstruction de chemin à la demande uniquement.
- Mouvements + journal + synchro Orbit 1 s.
- PowerShell caché; LEAVE THE UNIVERSE arrête uniquement le serveur Agent.

Lancer START_AGENT.bat.
