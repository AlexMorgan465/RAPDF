AGENT ORBIT V3
- Serveur PowerShell masqué en arrière-plan.
- Comptage COUNT ONLY basé sur la même traversée que scanner.ps1.
- Diagnostic RADAR DP visible dans l’interface.
- Reconstruction ciblée des chemins.
- Synchronisation live 1 seconde.
- Bouton LEAVE THE UNIVERSE : animation fusée + arrêt du serveur Agent.

Lancer START_AGENT.bat uniquement.
