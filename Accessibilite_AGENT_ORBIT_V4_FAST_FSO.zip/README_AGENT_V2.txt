AGENT ORBIT V2 STANDALONE
- Ne dépend plus de index.json ni du dashboard Manager.
- Au lancement, calcule directement les compteurs A TRAITER / EN COURS / NON CONFORME depuis le DP.
- Les noms de documents ne sont chargés que lors de la reconstruction d'un chemin précis.
- Après un mouvement, les compteurs sont ajustés immédiatement et la version LIVE est incrémentée.
- Les autres agents détectent la version toutes les secondes et se synchronisent.
- Lancer uniquement START_AGENT.bat.
