VERSION MANUAL SCAN
- Aucun scan automatique au démarrage.
- Aucun scan périodique.
- Le bouton SCAN DP lance scanner.ps1 dans index_pending.json.
- index.json actuel reste intact et visible pendant tout le scan.
- A la fin, l'interface affiche Ancien -> Nouveau et attend le clic APPLIQUER LE NOUVEL INDEX.
- Si le scan échoue, l'ancien index n'est jamais supprimé.
- Le scanner continue dans les sous-dossiers même lorsqu'un dossier parent contient déjà des fichiers, afin de ne pas rater les dossiers métier imbriqués (cas ACM et autres).
