@echo off
cd /d "%~dp0"
if not exist data mkdir data
start "" http://localhost:8787
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0server.ps1"
pause
