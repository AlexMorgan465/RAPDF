ACCESSIBILITY AGENT ORBIT
=========================
1. Le Manager reste sur le port 8787.
2. L'interface Agent utilise le port 8788 : lancer START_AGENT.bat.
3. Au chargement, le navigateur reçoit seulement les compteurs agrégés (A TRAITER / EN COURS / NON CONFORME), jamais la liste complète des documents.
4. Pour voir un document : Entité -> Statut -> racine/sous-entité -> navigation ciblée dossier par dossier.
5. Synchronisation live : version légère interrogée chaque seconde. Si un autre agent déplace un dossier, seule la vue utile est rechargée.
6. Les déplacements sont revérifiés côté serveur. Si un autre agent a déjà pris le dossier, l'action est refusée.
7. Tous les mouvements Agent sont ajoutés à data/journal.json.
