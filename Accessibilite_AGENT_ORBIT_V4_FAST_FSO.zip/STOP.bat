@echo off
cd /d "%~dp0"
type nul > data\STOP
