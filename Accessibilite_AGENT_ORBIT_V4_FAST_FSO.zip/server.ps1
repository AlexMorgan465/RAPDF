﻿param([string]$Root='\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE',[int]$Port=8787)
$ErrorActionPreference='Stop';$AppDir=Split-Path -Parent $MyInvocation.MyCommand.Path;$Data=Join-Path $AppDir 'data';$Index=Join-Path $Data 'index.json';$Scan=Join-Path $Data 'scan.json';$Diag=Join-Path $Data 'diagnostic.json';$Journal=Join-Path $Data 'journal.json';foreach($f in @($Index,$Journal,$Diag)){if(!(Test-Path -LiteralPath $f)){[IO.File]::WriteAllText($f,'[]',(New-Object Text.UTF8Encoding($false)))}};if(!(Test-Path -LiteralPath $Scan)){[IO.File]::WriteAllText($Scan,'{}',(New-Object Text.UTF8Encoding($false)))}
$PendingIndex=Join-Path $Data 'index_pending.json';$PendingScan=Join-Path $Data 'scan_pending.json';$PendingDiag=Join-Path $Data 'diagnostic_pending.json';$Scanner=Join-Path $AppDir 'scanner.ps1';
$Allowed=@{'A TRAITER'=@('EN COURS');'EN COURS'=@('A TRAITER','TRAITES','NON CONFORME');'TRAITES'=@('A TRAITER');'NON CONFORME'=@('A TRAITER');'A PUBLIER'=@('A TRAITER')}
function R($p,$fb){try{$x=[IO.File]::ReadAllText($p);if(!$x){return $fb};$x|ConvertFrom-Json}catch{$fb}};function RJ($p){@((R $p @()))};function A($p,$o){$t="$p.tmp";[IO.File]::WriteAllText($t,($o|ConvertTo-Json -Depth 10),[Text.UTF8Encoding]::new($false));Move-Item $t $p -Force}
function J($c,$o,$code=200){$b=[Text.Encoding]::UTF8.GetBytes(($o|ConvertTo-Json -Depth 10));$c.Response.StatusCode=$code;$c.Response.ContentType='application/json;charset=utf-8';$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()};function F($c,$p,$t){$b=[IO.File]::ReadAllBytes($p);$c.Response.ContentType=$t;$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()};function B($c){$r=New-Object IO.StreamReader($c.Request.InputStream,$c.Request.ContentEncoding);try{$r.ReadToEnd()|ConvertFrom-Json}finally{$r.Dispose()}}
function RawJsonText($Path,$Fallback){
  try {
    if(!(Test-Path -LiteralPath $Path)){ return $Fallback }
    $txt=[IO.File]::ReadAllText($Path,[Text.Encoding]::UTF8)
    if([string]::IsNullOrWhiteSpace($txt)){ return $Fallback }
    $null=$txt | ConvertFrom-Json -ErrorAction Stop
    return $txt
  } catch { return $Fallback }
}
function RawResponse($c,[string]$json,[int]$code=200){
  $b=[Text.Encoding]::UTF8.GetBytes($json)
  $c.Response.StatusCode=$code
  $c.Response.ContentType='application/json;charset=utf-8'
  $c.Response.ContentLength64=$b.Length
  $c.Response.OutputStream.Write($b,0,$b.Length)
  $c.Response.Close()
}
function ItemsResponse($c){
  $itemsRaw=RawJsonText $Index '[]'
  $scanRaw=RawJsonText $Scan '{}'
  $rootJson=$Root | ConvertTo-Json -Compress
  $payload='{"root":'+$rootJson+',"scan":'+$scanRaw+',"items":'+$itemsRaw+'}'
  RawResponse $c $payload 200
}

function MoveDoc($b){$items=RJ $Index;$it=$items|Where-Object{$_.id-eq$b.id}|Select-Object -First 1;if(!$it){throw 'Document introuvable dans index'};$to=[string]$b.to;if($Allowed[$it.status]-notcontains$to){throw 'Transition interdite'};$srcRoot=Join-Path (Join-Path $Root $it.entity) $it.statusRootRelative;$src=Join-Path $srcRoot $it.relativePath
 $parentRel=Split-Path -Parent $it.statusRootRelative;$entityRoot=Join-Path $Root $it.entity;$searchBase=if($parentRel){Join-Path $entityRoot $parentRel}else{$entityRoot};$destRoot=Get-ChildItem $searchBase -Directory -EA Stop|Where-Object{$_.Name.Trim().ToUpperInvariant()-eq$to}|Select-Object -First 1;if(!$destRoot){throw 'Dossier statut destination correspondant introuvable'};$dst=Join-Path $destRoot.FullName $it.relativePath;if(!(Test-Path $src)){throw 'Dossier déjà déplacé'};if(Test-Path $dst){throw 'Destination existe déjà'};$p=Split-Path -Parent $dst;if(!(Test-Path $p)){New-Item -ItemType Directory -Force $p|Out-Null};Move-Item $src $dst;$j=RJ $Journal;$j+= [pscustomobject]@{date=(Get-Date).ToString('o');id=$it.id;entity=$it.entity;document=$it.name;from=$it.status;to=$to;source='INTERFACE'};A $Journal $j;[pscustomobject]@{ok=$true}}
function StartManualScan {
  $running=$false
  if(Test-Path -LiteralPath $PendingScan){try{$ps=R $PendingScan $null;if($ps -and $ps.running){$running=$true}}catch{}}
  if($running){return [pscustomobject]@{ok=$false;error='Un scan manuel est déjà en cours'}}
  $args="-NoProfile -ExecutionPolicy Bypass -File `"$Scanner`" -Pending"
  Start-Process powershell.exe -ArgumentList $args -WorkingDirectory $AppDir | Out-Null
  return [pscustomobject]@{ok=$true;message='Scan manuel lancé. L index actuel reste affiché.'}
}
function PendingInfo {
  [pscustomobject]@{scan=(R $PendingScan $null);items=if(Test-Path $PendingIndex){RJ $PendingIndex}else{@()};diagnostic=if(Test-Path $PendingDiag){RJ $PendingDiag}else{@()}}
}
function ApplyPending {
  if(!(Test-Path $PendingIndex)){throw 'Aucun nouveau scan disponible'}
  $ps=R $PendingScan $null;if($ps -and $ps.running){throw 'Le scan est encore en cours'}
  $candidate=RJ $PendingIndex
  if($null -eq $candidate){throw 'Index temporaire invalide'}
  Copy-Item -LiteralPath $PendingIndex -Destination $Index -Force
  if(Test-Path $PendingDiag){Copy-Item -LiteralPath $PendingDiag -Destination $Diag -Force}
  if(Test-Path $PendingScan){Copy-Item -LiteralPath $PendingScan -Destination $Scan -Force}
  [pscustomobject]@{ok=$true;documents=@($candidate).Count}
}
$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Write-Host "V4 Command Center: http://localhost:$Port" -ForegroundColor Green
while($l.IsListening){$c=$l.GetContext();try{$p=$c.Request.Url.AbsolutePath;if($p-eq'/api/items'){ItemsResponse $c}elseif($p-eq'/api/scan/start'-and$c.Request.HttpMethod-eq'POST'){J $c (StartManualScan)}elseif($p-eq'/api/scan/pending'){J $c (PendingInfo)}elseif($p-eq'/api/scan/apply'-and$c.Request.HttpMethod-eq'POST'){try{J $c (ApplyPending)}catch{J $c ([pscustomobject]@{ok=$false;error=$_.Exception.Message}) 409}}elseif($p-eq'/api/diagnostic'){J $c (RJ $Diag)}elseif($p-eq'/api/journal'){J $c (RJ $Journal)}elseif($p-eq'/api/move'-and$c.Request.HttpMethod-eq'POST'){try{J $c (MoveDoc (B $c))}catch{J $c ([pscustomobject]@{ok=$false;error=$_.Exception.Message}) 409}}elseif($p-eq'/'-or$p-eq'/index.html'){F $c (Join-Path $AppDir 'index.html') 'text/html;charset=utf-8'}elseif($p-eq'/style.css'){F $c (Join-Path $AppDir 'style.css') 'text/css;charset=utf-8'}elseif($p-eq'/app.js'){F $c (Join-Path $AppDir 'app.js') 'application/javascript;charset=utf-8'}else{$c.Response.StatusCode=404;$c.Response.Close()}}catch{try{J $c @{ok=$false;error=$_.Exception.Message} 500}catch{}}}
