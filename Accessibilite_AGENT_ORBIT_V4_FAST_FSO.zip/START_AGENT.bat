@echo off
cd /d "%~dp0"
start "" powershell.exe -NoProfile -WindowStyle Hidden -ExecutionPolicy Bypass -File "%~dp0agent_server.ps1"
timeout /t 3 /nobreak >nul
start "" "http://localhost:8788/agent.html"
exit
