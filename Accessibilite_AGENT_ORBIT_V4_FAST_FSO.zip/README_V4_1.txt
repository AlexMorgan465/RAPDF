V4.1 PROGRESSIVE SCAN
- Le scanner publie un heartbeat et le chemin courant environ chaque seconde.
- L'index est publie apres CHAQUE zone statut: les premiers resultats apparaissent avant la fin du DP.
- Detection rapide des statuts selon le TREE fourni: statut directement sous entite ou a 1 niveau intermediaire (CONTRATHEQUE).
- DIRCO\\OLD est exclu.
- Si un dossier contient des fichiers, ce dossier est compte une seule fois comme dossier metier.
- L'interface affiche phase, entite, statut et chemin courant.
Lancer START.bat puis http://localhost:8787
