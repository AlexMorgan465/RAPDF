ACCESSIBILITE TDB V4 - COMMAND CENTER

1. Extraire le dossier localement.
2. Lancer START.bat.
3. Ouvrir http://localhost:8787 si le navigateur ne s'ouvre pas.

SCAN:
- Recherche les dossiers de statut récursivement dans chaque entité.
- Exclut toute branche nommée OLD.
- Aucune profondeur maximale.
- Un dossier contenant au moins un fichier devient 1 dossier métier; ses sous-dossiers ne sont alors plus comptés séparément.
- CONTRATHEQUE est supportée: catégorie -> statut.
- Le scan n'écrit jamais dans le DP.

MOUVEMENTS:
- Seul un clic explicite de l'utilisateur déclenche Move-Item.
- Le déplacement conserve la sous-arborescence métier et cherche le statut destination dans la même branche (important pour CONTRATHEQUE).

REFERENCE DE CONTROLE UI:
A TRAITER 96 / EN COURS 2 / TRAITES 609 / NON CONFORME 16 / A PUBLIER 91 = 814.
Ces nombres ne remplacent JAMAIS le résultat du scan: ils servent seulement à afficher l'écart.
