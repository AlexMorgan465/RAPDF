V4.2 INSTRUMENTED SCANNER
- Lance START.bat.
- La fenêtre ACCESS SCANNER V4.2 reste visible volontairement.
- Le scanner n'utilise aucun Get-ChildItem -Recurse.
- Chaque dossier est annoncé AVANT sa lecture : si le partage bloque, la dernière ligne indique le chemin exact.
- data/scanner.log garde la trace complète.
- data/scan.json est mis à jour à chaque dossier pour alimenter le dashboard.
- DIRCO\OLD est ignoré.
- CONTRATHEQUE est géré avec son niveau intermédiaire avant les statuts.
