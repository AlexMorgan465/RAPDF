@echo off
cd /d "%~dp0"
echo Lancement du scan manuel dans un index temporaire...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scanner.ps1" -Pending
pause
