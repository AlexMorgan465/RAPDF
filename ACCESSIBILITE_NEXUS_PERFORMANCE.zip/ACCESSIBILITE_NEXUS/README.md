# Accessibilité Nexus

Application locale Windows avec deux espaces : **Agent** et **Manager**. Serveur PowerShell, interface HTML/CSS/JavaScript, sans installation de Node ni base de données.

## Démarrage

1. Décompressez le dossier sur un poste Windows ayant accès en lecture/écriture aux deux partages réseau.
2. Ouvrez `config.json` et vérifiez `sharedRoot` (racine DP) et `historyRoot` (dossier Historique distinct). Les antislashs sont doublés dans ce fichier JSON.
3. Lancez `START.bat`, puis ouvrez `http://localhost:8090/` dans Edge ou Chrome.
4. Laissez la fenêtre PowerShell ouverte pendant l’utilisation.

Les fichiers du journal sont créés dans `data/tasks.json` et `data/events.json`. Sauvegardez régulièrement le dossier `data` avec les documents. La page Manager propose un export CSV compatible Excel.

## Parcours

- Le serveur explore chaque entité et repère les dossiers `A TRAITER`, `EN COURS`, `NON CONFORME`, `TRAITES`, y compris à des profondeurs différentes. `A PUBLIER` est ignoré.
- Il repère les PDF, DOC et DOCX à tous les niveaux sous `A TRAITER`. La **prise en charge** déplace le document vers le dossier `EN COURS` correspondant à sa branche.
- À la fin, l’agent choisit depuis son Bureau un dossier portant exactement le nom du document sans extension (ou le nom complet). Le navigateur envoie ce dossier au serveur. Le dossier est copié sous `TRAITES` ou `NON CONFORME`; le document original est archivé sous `historyRoot/<entité>/<préfixe>/<branche>/` puis retiré de `EN COURS`. Une non-conformité exige le problème constaté et une proposition de solution.
- **Retraitement** copie un nouveau dossier choisi par l’agent dans `TRAITES`, vérifie la copie, puis supprime le dossier de `NON CONFORME`.
- L’agent peut télécharger le document source. Une analyse du partage tourne en arrière-plan à intervalles de 15 secondes minimum. Les nouveaux arrivants déclenchent une alerte dans la page et, si l’utilisateur l’active, une notification système. Le manager voit tous les statuts, toutes les entités et le journal des actions.

## Limites et précautions

- Le choix d’un dossier local nécessite Edge ou Chrome avec sélection de dossier (`webkitdirectory`). Un fichier ne doit pas dépasser 25 Mo, et un dossier 250 Mo.
- L’application écoute `localhost` par défaut. Chaque action sur les partages utilise les droits Windows du compte qui lance `START.bat`. L’identifiant agent est déclaratif, sans authentification. Pour un déploiement partagé avec plusieurs postes, prévoir un compte de service, des droits et une authentification avant de rendre le serveur accessible sur le réseau.
- Les dossiers de résultats existants sont recensés si leur niveau contient directement des fichiers. Les documents homonymes dans une même branche sont refusés si la destination est déjà présente. Une erreur réseau au moment d’une suppression peut laisser une copie à vérifier : le manager voit alors l’avertissement dans le registre.
- Le journal JSON et les opérations de fichiers ne constituent pas une transaction distribuée. En cas de panne réseau pendant une finalisation, contrôlez les destinations et l’historique avant de relancer l’action.

## Mise à jour depuis la première version

Conservez votre dossier `data` et votre `config.json`. Arrêtez le serveur, remplacez `server.ps1` et le contenu de `web`, puis relancez `START.bat`. La première recherche réseau continue en arrière-plan : la page peut d’abord afficher les données déjà enregistrées, puis ajouter les nouveaux documents lorsque l’analyse se termine.
