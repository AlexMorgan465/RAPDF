ACCESSIBILITY DESK SUITE
/agent = interface agent professionnelle
/tactical = Tactical Orbital Display personnel
/manager = traitements et KPI par agent
/scanner = scan manuel complet du DP + TDB

CORRECTION ORDRES:
La syntaxe PowerShell 'throw"Déjà déplacé..."' a été corrigée en 'throw "Déjà déplacé..."'.

HISTORIQUE:
.agent_orbit_logs\<WindowsUser>.jsonl sur le DP partagé.
