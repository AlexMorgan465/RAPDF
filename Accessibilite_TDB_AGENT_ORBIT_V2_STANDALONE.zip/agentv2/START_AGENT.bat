@echo off
cd /d "%~dp0"
start "ACCESSIBILITY AGENT ORBIT V2" powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0agent_server.ps1"
timeout /t 5 /nobreak >nul
start "" "http://localhost:8788/agent.html"
