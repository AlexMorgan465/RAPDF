﻿param(
  [string]$Root = "\\Uf11-a03\EIDS-EAA-PDF-STATIQUES\ACCESSIBILITE",
  [int]$Port = 8787,
  [int]$ScanSeconds = 5
)

$ErrorActionPreference = 'Stop'
$AppDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$DataDir = Join-Path $AppDir 'data'
$IndexFile = Join-Path $DataDir 'index.json'
$JournalFile = Join-Path $DataDir 'journal.json'
$StateFile = Join-Path $DataDir 'state.json'
New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
foreach($f in @($IndexFile,$JournalFile,$StateFile)){ if(!(Test-Path $f)){ '[]' | Set-Content -Encoding UTF8 $f } }

$Statuses = @('A TRAITER','EN COURS','TRAITES','NON CONFORME','A PUBLIER')
$Allowed = @{
 'A TRAITER'    = @('EN COURS')
 'EN COURS'     = @('A TRAITER','TRAITES','NON CONFORME')
 'TRAITES'      = @('A TRAITER')
 'NON CONFORME' = @('A TRAITER')
 'A PUBLIER'    = @()
}
$script:LastScan = [datetime]::MinValue
$script:Cache = @()
$script:Mutex = New-Object System.Threading.Mutex($false, 'AccessibiliteTdbMoveMutex')
$script:ScanMetrics = [pscustomobject]@{ percent=0; entitiesTotal=0; entitiesScanned=0; statusFoldersTotal=0; statusFoldersScanned=0; itemsFetched=0; errors=0; durationMs=0; startedAt=$null; completedAt=$null }

function Read-JsonArray([string]$Path){
  try { $x = Get-Content -Raw -Encoding UTF8 $Path | ConvertFrom-Json; if($null -eq $x){ return @() }; return @($x) } catch { return @() }
}
function Write-JsonAtomic([string]$Path, $Object){
  $tmp = "$Path.tmp"
  $Object | ConvertTo-Json -Depth 10 | Set-Content -Encoding UTF8 $tmp
  Move-Item -Force $tmp $Path
}
function Normalize-Status([string]$Name){
  $n = $Name.Trim().ToUpperInvariant()
  switch -Regex ($n) {
    '^A\s*TRAITER$' { 'A TRAITER'; break }
    '^EN\s*COURS$' { 'EN COURS'; break }
    '^TRAITE[S]?$' { 'TRAITES'; break }
    '^NON\s*CONFORME$' { 'NON CONFORME'; break }
    '^A\s*PUBLIER$' { 'A PUBLIER'; break }
    default { $null }
  }
}
function Get-Key([string]$Entity,[string]$Name){ "$Entity|$Name" }
function Load-State {
  $arr = Read-JsonArray $StateFile
  $h=@{}; foreach($s in $arr){ $h[$s.key]=$s }; return $h
}
function Save-State($h){ Write-JsonAtomic $StateFile @($h.Values) }
function Add-Journal($entry){
  $j = Read-JsonArray $JournalFile
  $j = @($j) + @($entry)
  if($j.Count -gt 10000){ $j = $j[($j.Count-10000)..($j.Count-1)] }
  Write-JsonAtomic $JournalFile $j
}
function Get-DocumentFolders([System.IO.DirectoryInfo]$StatusDir, [int]$MaxDepth = 5){
  # Règle métier : on descend jusqu'à 5 niveaux. Dès qu'un fichier est trouvé,
  # son dossier parent représente UN document, quel que soit le nombre de fichiers.
  $seen = @{}
  $stack = New-Object System.Collections.Stack
  $stack.Push([pscustomobject]@{ Dir=$StatusDir; Depth=0 })
  while($stack.Count -gt 0){
    $node = $stack.Pop(); $dir = $node.Dir; $depth = [int]$node.Depth
    try {
      $files = @(Get-ChildItem -LiteralPath $dir.FullName -File -Force -ErrorAction Stop)
      if($files.Count -gt 0 -and $depth -gt 0){
        if(!$seen.ContainsKey($dir.FullName)){ $seen[$dir.FullName] = [pscustomobject]@{ Dir=$dir; Files=$files; Depth=$depth } }
        # Un dossier métier est une feuille logique : si des fichiers sont présents ici,
        # on le compte une seule fois et on ne compte pas ses sous-dossiers comme doublons.
        continue
      }
      if($depth -lt $MaxDepth){
        $subs = @(Get-ChildItem -LiteralPath $dir.FullName -Directory -Force -ErrorAction Stop)
        foreach($sub in $subs){ $stack.Push([pscustomobject]@{ Dir=$sub; Depth=($depth+1) }) }
      }
    } catch { $script:CurrentScanErrors++ }
  }
  return @($seen.Values)
}
function Get-RelativePathCompat([string]$Base,[string]$Full){
  $b=$Base.TrimEnd('\\')+'\\'
  if($Full.StartsWith($b,[System.StringComparison]::OrdinalIgnoreCase)){ return $Full.Substring($b.Length) }
  return (Split-Path -Leaf $Full)
}
function Scan-Root {
  if(!(Test-Path -LiteralPath $Root)){ throw "Racine inaccessible: $Root" }
  $started=Get-Date; $state=Load-State; [System.Collections.ArrayList]$rows = @(); $now=Get-Date
  $script:CurrentScanErrors=0
  $entityDirs=@(Get-ChildItem -LiteralPath $Root -Directory -ErrorAction Stop)
  $metrics=[ordered]@{ percent=0; entitiesTotal=$entityDirs.Count; entitiesScanned=0; statusFoldersTotal=0; statusFoldersScanned=0; itemsFetched=0; filesFound=0; foldersVisited=0; errors=0; durationMs=0; startedAt=$started.ToString('o'); completedAt=$null }
  $statusMap=@{}
  foreach($entityDir in $entityDirs){
    try {
      $recognized=@(Get-ChildItem -LiteralPath $entityDir.FullName -Directory -ErrorAction Stop | Where-Object { $null -ne (Normalize-Status $_.Name) })
      $statusMap[$entityDir.FullName]=$recognized; $metrics.statusFoldersTotal += $recognized.Count
    } catch { $statusMap[$entityDir.FullName]=@(); $metrics.errors++ }
  }
  $totalUnits=[math]::Max(1,$metrics.entitiesTotal+$metrics.statusFoldersTotal)
  foreach($entityDir in $entityDirs){
    foreach($statusDir in @($statusMap[$entityDir.FullName])){
      $status=Normalize-Status $statusDir.Name; if(!$status){ continue }
      try {
        $docs=@(Get-DocumentFolders $statusDir 5)
        foreach($doc in $docs){
          $folder=$doc.Dir; $files=@($doc.Files); $metrics.filesFound += $files.Count; $metrics.foldersVisited++
          $relative=Get-RelativePathCompat $statusDir.FullName $folder.FullName
          # La clé inclut le chemin métier relatif pour éviter les collisions de noms identiques.
          $key="$($entityDir.Name)|$relative"
          $s=$state[$key]
          $modified=($files | Sort-Object LastWriteTime -Descending | Select-Object -First 1).LastWriteTime
          if(!$s){
            $s=[pscustomobject]@{ key=$key; entity=$entityDir.Name; name=$folder.Name; relativePath=$relative; firstSeen=$now.ToString('o'); currentStatus=$status; enteredInProgress=$null; accumulatedSeconds=0 }
            if($status -eq 'EN COURS'){ $s.enteredInProgress=$modified.ToString('o') }; $state[$key]=$s
          } elseif($s.currentStatus -ne $status){
            $old=$s.currentStatus
            if($old -eq 'EN COURS' -and $s.enteredInProgress){ $s.accumulatedSeconds += [math]::Max(0,($now-[datetime]$s.enteredInProgress).TotalSeconds); $s.enteredInProgress=$null }
            if($status -eq 'EN COURS'){ $s.enteredInProgress=$now.ToString('o') }; $s.currentStatus=$status
            Add-Journal ([pscustomobject]@{id=[guid]::NewGuid().ToString();date=$now.ToString('o');entity=$entityDir.Name;document=$folder.Name;relativePath=$relative;from=$old;to=$status;source='EXTERNE';dmtSeconds=[math]::Round([double]$s.accumulatedSeconds,0)})
          }
          $live=[double]$s.accumulatedSeconds; if($status -eq 'EN COURS' -and $s.enteredInProgress){$live += [math]::Max(0,($now-[datetime]$s.enteredInProgress).TotalSeconds)}
          [void]$rows.Add([pscustomobject]@{id=[Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes("$($entityDir.Name)|$status|$relative"));entity=$entityDir.Name;status=$status;name=$folder.Name;relativePath=$relative;type='Dossier';fileCount=$files.Count;depth=$doc.Depth;extension='';size=$null;modified=$modified.ToString('o');depositDate=$modified.ToString('o');firstSeen=$s.firstSeen;enteredInProgress=$s.enteredInProgress;dmtSeconds=[math]::Round($live,0)})
          $metrics.itemsFetched++
        }
      } catch { $metrics.errors++ }
      $metrics.statusFoldersScanned++; $metrics.percent=[math]::Round((($metrics.entitiesScanned+$metrics.statusFoldersScanned)/$totalUnits)*100,0); $metrics.errors += $script:CurrentScanErrors; $script:CurrentScanErrors=0; $script:ScanMetrics=[pscustomobject]$metrics
    }
    $metrics.entitiesScanned++; $metrics.percent=[math]::Round((($metrics.entitiesScanned+$metrics.statusFoldersScanned)/$totalUnits)*100,0); $script:ScanMetrics=[pscustomobject]$metrics
  }
  Save-State $state; $finalRows=@($rows.ToArray()); $script:Cache=$finalRows; $script:LastScan=$now; Write-JsonAtomic $IndexFile $finalRows
  $done=Get-Date; $metrics.completedAt=$done.ToString('o'); $metrics.durationMs=[math]::Round(($done-$started).TotalMilliseconds,0); $metrics.percent=100; $script:ScanMetrics=[pscustomobject]$metrics
  return $finalRows
}
function Ensure-Scan { if(((Get-Date)-$script:LastScan).TotalSeconds -ge $ScanSeconds){ try{ [void](Scan-Root) }catch{} }; return $script:Cache }
function Send-Json($ctx,$obj,[int]$code=200){
  $json=$obj|ConvertTo-Json -Depth 10; $bytes=[Text.Encoding]::UTF8.GetBytes($json); $ctx.Response.StatusCode=$code; $ctx.Response.ContentType='application/json; charset=utf-8'; $ctx.Response.ContentLength64=$bytes.Length; $ctx.Response.OutputStream.Write($bytes,0,$bytes.Length); $ctx.Response.Close()
}
function Send-File($ctx,[string]$path,[string]$type){
  if(!(Test-Path $path)){ $ctx.Response.StatusCode=404; $ctx.Response.Close(); return }
  $b=[IO.File]::ReadAllBytes($path); $ctx.Response.ContentType=$type; $ctx.Response.ContentLength64=$b.Length; $ctx.Response.OutputStream.Write($b,0,$b.Length); $ctx.Response.Close()
}
function Get-Body($ctx){ $r=New-Object IO.StreamReader($ctx.Request.InputStream,$ctx.Request.ContentEncoding); try{$r.ReadToEnd()|ConvertFrom-Json}finally{$r.Dispose()} }
function Move-Document($body){
  $entity=[string]$body.entity; $name=[string]$body.name; $relativePath=[string]$body.relativePath; $from=[string]$body.from; $to=[string]$body.to
  if(!$Allowed.ContainsKey($from) -or $Allowed[$from] -notcontains $to){ throw "Transition interdite: $from -> $to" }
  if($entity -match '[\\/:*?"<>|]' -or $name -match '[\\/]'){ throw 'Nom invalide' }; if([string]::IsNullOrWhiteSpace($relativePath)){ $relativePath=$name }; if($relativePath -match '(^|[\\/])\.\.([\\/]|$)'){ throw 'Chemin relatif invalide' }
  $entityPath=Join-Path $Root $entity; if(!(Test-Path -LiteralPath $entityPath)){ throw 'Entité introuvable' }
  $fromDir=Get-ChildItem -LiteralPath $entityPath -Directory | Where-Object { (Normalize-Status $_.Name) -eq $from } | Select-Object -First 1
  $toDir=Get-ChildItem -LiteralPath $entityPath -Directory | Where-Object { (Normalize-Status $_.Name) -eq $to } | Select-Object -First 1
  if(!$fromDir -or !$toDir){ throw 'Dossier statut source/destination introuvable' }
  $src=Join-Path $fromDir.FullName $relativePath; $dst=Join-Path $toDir.FullName $name
  if(!(Test-Path -LiteralPath $src)){ throw 'Document déjà déplacé ou introuvable' }
  if(Test-Path -LiteralPath $dst){ throw 'Un élément du même nom existe déjà dans la destination' }
  $state=Load-State; $key="$entity|$relativePath"; $s=$state[$key]; $now=Get-Date
  if(!$s){ $s=[pscustomobject]@{key=$key;entity=$entity;name=$name;firstSeen=$now.ToString('o');currentStatus=$from;enteredInProgress=$null;accumulatedSeconds=0} }
  if($from -eq 'EN COURS' -and $s.enteredInProgress){ $s.accumulatedSeconds += [math]::Max(0,($now-[datetime]$s.enteredInProgress).TotalSeconds); $s.enteredInProgress=$null }
  if($to -eq 'EN COURS'){ $s.enteredInProgress=$now.ToString('o') }
  Move-Item -LiteralPath $src -Destination $dst
  $s.currentStatus=$to; $newKey="$entity|$name"; $s.key=$newKey; $s.relativePath=$name; if($state.ContainsKey($key)){ $state.Remove($key) }; $state[$newKey]=$s; Save-State $state
  Add-Journal ([pscustomobject]@{id=[guid]::NewGuid().ToString();date=$now.ToString('o');entity=$entity;document=$name;from=$from;to=$to;source='INTERFACE';dmtSeconds=[math]::Round([double]$s.accumulatedSeconds,0)})
  $script:LastScan=[datetime]::MinValue; [void](Ensure-Scan)
  return [pscustomobject]@{ok=$true;message='Mouvement effectué'}
}

$listener=New-Object Net.HttpListener
$listener.Prefixes.Add("http://localhost:$Port/")
try{$listener.Start()}catch{ Write-Host "Échec http://localhost:$Port/ : $($_.Exception.Message)" -ForegroundColor Red; throw }
Write-Host "TDB Accessibilité : http://localhost:$Port" -ForegroundColor Green
Write-Host "Racine (lecture + déplacements demandés uniquement) : $Root" -ForegroundColor Cyan
try{ [void](Scan-Root) }catch{ Write-Warning $_.Exception.Message }
while($listener.IsListening){
  $ctx=$listener.GetContext(); try{
    $p=$ctx.Request.Url.AbsolutePath
    if($p -eq '/api/items'){ $current=@(Ensure-Scan); Send-Json $ctx ([pscustomobject]@{root=$Root;scannedAt=$script:LastScan.ToString('o');scan=$script:ScanMetrics;items=$current}) }
    elseif($p -eq '/api/journal'){ Send-Json $ctx (Read-JsonArray $JournalFile) }
    elseif($p -eq '/api/move' -and $ctx.Request.HttpMethod -eq 'POST'){
      $locked=$false; try{$locked=$script:Mutex.WaitOne(10000); if(!$locked){throw 'Serveur occupé'}; Send-Json $ctx (Move-Document (Get-Body $ctx))} finally{if($locked){$script:Mutex.ReleaseMutex()}}
    }
    elseif($p -eq '/' -or $p -eq '/index.html'){ Send-File $ctx (Join-Path $AppDir 'index.html') 'text/html; charset=utf-8' }
    elseif($p -eq '/style.css'){ Send-File $ctx (Join-Path $AppDir 'style.css') 'text/css; charset=utf-8' }
    elseif($p -eq '/app.js'){ Send-File $ctx (Join-Path $AppDir 'app.js') 'application/javascript; charset=utf-8' }
    else{$ctx.Response.StatusCode=404;$ctx.Response.Close()}
  }catch{ try{Send-Json $ctx ([pscustomobject]@{ok=$false;error=$_.Exception.Message}) 409}catch{} }
}
