# Accessibilité Nexus — mise à jour 2

Serveur PowerShell Windows, interface agent et manager, workflow du DP, historique séparé, journal et tableaux de bord. Aucun module Node ni base de données à installer.

## Mise à jour sans perdre les traitements

1. Fermez l’ancien serveur PowerShell avant la mise à jour.
2. Copiez les fichiers de cette archive dans le dossier `ACCESSIBILITE_NEXUS`, en remplaçant les anciens scripts et le dossier `web`.
3. **Conservez votre `data` et votre `config.json` existants.** Le nouveau fichier `data/users.json` est créé au premier démarrage. Ne supprimez jamais `data/tasks.json` et `data/events.json`.
4. Lancez `START.bat`. La fenêtre PowerShell se ferme immédiatement, le serveur continue en arrière-plan et ouvre l’interface dans le navigateur. Pour arrêter le serveur masqué, utilisez `STOP.bat`. Si la page ne s’ouvre pas, lancez `START_VISIBLE.bat` pour lire l’erreur. Le journal technique est `data/server.log`.
5. Le compte Windows qui lance le serveur devient **premier manager**. Ouvrez **Paramètres → Utilisateurs** pour ajouter les comptes des agents au format `DOMAINE\identifiant`. À partir d’un autre poste, Edge ou Chrome doit pouvoir présenter automatiquement les identifiants Windows au serveur ; selon la politique de l’entreprise, le navigateur peut demander les identifiants ou l’IT peut devoir autoriser l’authentification intégrée sur l’adresse utilisée.

La racine DP `sharedRoot`, le chemin distinct `historyRoot`, l’adresse `listenUrl` et l’intervalle `scanSeconds` sont dans `config.json`. Conservez l’adresse `http://localhost:8090/` pour un usage sur un seul poste. Pour un accès réseau, la configuration de l’URL HTTP et du pare-feu relève de l’IT. Le compte qui lance le serveur doit pouvoir lire et modifier les deux partages.

## Fonctions

- Démarrage avec ouverture automatique du navigateur ; serveur masqué, mode visible de diagnostic disponible.
- Session Windows automatique, compte affiché, bouton **Déconnecter**. Après déconnexion, la page ne se reconnecte pas tant que l’utilisateur ne clique pas sur **Se connecter avec Windows**. Le serveur continue à fonctionner. Les comptes et rôles sont vérifiés par le serveur : l’URL manager et ses API refusent les agents.
- Manager : gestion des comptes, priorité par document (Basse, Normale, Haute, Urgente), registre filtrable de 100 lignes par page, vue complète des statuts, répartition par entité, production par agent et par jour, taux de dossiers traités, journal d’audit paginé intégral et exportable, export CSV Excel. Les dossiers historiques sans agent peuvent être attribués manuellement par le manager ; cette attribution est journalisée et alimente les graphiques.
- Agent : file triée par priorité, historique personnel, graphiques de traitement par entité et des sept derniers jours, notifications des nouveaux documents, prise en charge, dossier final conforme/non conforme, problème et proposition de solution, retraitement.
- Analyse non bloquante de l’arborescence : tous les PDF/DOC/DOCX de `A TRAITER` et `EN COURS`, ainsi que les dossiers de résultats déjà présents sous `TRAITES` et `NON CONFORME`, avec profondeurs variables. `A PUBLIER` est exclu. Les résultats existants sont identifiés par les dossiers qui contiennent directement des fichiers ; une structure historique avec un dossier de résultat ne contenant que des sous-dossiers peut demander un ajustement spécifique.
- Les prises en charge déplacent le document dans `EN COURS`. La finalisation copie l’original vers `historyRoot/<entité>/<préfixe>/<branche>/`, place le dossier fourni par l’agent sous `TRAITES` ou `NON CONFORME`, puis retire l’original de `EN COURS`. Le retraitement copie le nouveau dossier vers `TRAITES` et supprime l’ancien dossier non conforme après vérification de la copie.

## Limites et contrôle

L’authentification intégrée Windows requiert un environnement Windows compatible et les droits réseau adaptés. Les sessions sont conservées en mémoire du serveur ; après redémarrage, reconnectez-vous. Le bouton Déconnecter ferme la session de l’application, mais ne ferme pas la session Windows du navigateur. Si l’ordinateur serveur est exécuté sous un autre compte que le manager souhaité, le premier manager est ce compte serveur : ajoutez ensuite le compte souhaité avec ce premier manager.

La sélection du dossier local passe par Edge/Chrome (`webkitdirectory`). Taille maximale : 25 Mo par fichier et 250 Mo par dossier. L’application ne possède pas de transaction distribuée entre les partages : en cas de coupure réseau pendant une finalisation, vérifiez les emplacements signalés et le journal avant de relancer. Sauvegardez régulièrement `data`.
