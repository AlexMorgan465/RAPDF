﻿$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$cfg=[IO.File]::ReadAllText((Join-Path $base 'config.json'),[Text.Encoding]::UTF8) | ConvertFrom-Json
$share=[string]$cfg.sharedRoot; $history=[string]$cfg.historyRoot
$db=Join-Path $base 'data\tasks.json'; $events=Join-Path $base 'data\events.json'
$usersFile=Join-Path $base 'data\users.json';$logFile=Join-Path $base 'data\server.log'
$staging=Join-Path $base 'data\staging'; New-Item -ItemType Directory -Force -Path $staging | Out-Null
if(!(Test-Path -LiteralPath $db)){[IO.File]::WriteAllText($db,'[]',[Text.UTF8Encoding]::new($false))}
if(!(Test-Path -LiteralPath $events)){[IO.File]::WriteAllText($events,'[]',[Text.UTF8Encoding]::new($false))}
$script:tasks=[Collections.ArrayList]::new()
foreach($item in @([IO.File]::ReadAllText($db,[Text.Encoding]::UTF8) | ConvertFrom-Json)){if($null -ne $item){[void]$script:tasks.Add($item)}}
$script:eventList=[Collections.ArrayList]::new()
foreach($item in @([IO.File]::ReadAllText($events,[Text.Encoding]::UTF8) | ConvertFrom-Json)){if($null -ne $item){[void]$script:eventList.Add($item)}}
$script:taskByKey=@{};$script:taskById=@{}
foreach($item in $script:tasks){
  if(!$item.PSObject.Properties['priority']){$item | Add-Member -NotePropertyName priority -NotePropertyValue 'Normale'}
  $script:taskByKey[[string]$item.key]=$item;$script:taskById[[string]$item.id]=$item
}
if(!(Test-Path -LiteralPath $usersFile)){
  $owner=[Security.Principal.WindowsIdentity]::GetCurrent().Name
  $seed=@([pscustomobject]@{account=$owner;role='manager';enabled=$true})
  [IO.File]::WriteAllText($usersFile,(ConvertTo-Json -InputObject $seed -Compress),[Text.UTF8Encoding]::new($false))
}
$script:users=[Collections.ArrayList]::new()
foreach($item in @([IO.File]::ReadAllText($usersFile,[Text.Encoding]::UTF8) | ConvertFrom-Json)){if($null -ne $item){[void]$script:users.Add($item)}}
$script:sessions=@{}
$script:uploads=@{}; $script:lastScan=[datetime]::MinValue;$script:scanHandle=$null;$script:scanPowerShell=$null;$script:scanError=''
function SaveJson($path,$value){$json=ConvertTo-Json -InputObject $value.ToArray() -Depth 12 -Compress;$tmp=$path+'.tmp';[IO.File]::WriteAllText($tmp,$json,[Text.UTF8Encoding]::new($false));Move-Item -LiteralPath $tmp -Destination $path -Force}
function SaveUsers{SaveJson $usersFile $script:users}
function SaveState{SaveJson $db $script:tasks;SaveJson $events $script:eventList;$script:stateBytes=$null}
function Event($task,$kind,$agent,$detail){$taskId=if($task){$task.id}else{''};[void]$script:eventList.Add([pscustomobject]@{id=[guid]::NewGuid().ToString();taskId=$taskId;at=(Get-Date).ToString('o');kind=$kind;agent=$agent;detail=$detail})}
function Account($name){return @($script:users | Where-Object {$_.account -ieq $name -and $_.enabled} | Select-Object -First 1)[0]}
function ActiveSession($context){
  $request=$context.Request
  $cookie=$request.Cookies['access_session'];if(!$cookie){return $null}
  $entry=$script:sessions[[string]$cookie.Value];if(!$entry){return $null}
  if($entry.expires -lt (Get-Date)){[void]$script:sessions.Remove([string]$cookie.Value);return $null}
  $windowsName=if($context.User -and $context.User.Identity.IsAuthenticated){[string]$context.User.Identity.Name}else{''}
  if($windowsName -ine $entry.account){return $null}
  $user=Account $windowsName;if(!$user){return $null}
  return $user
}
function ManagerOnly($user){if(!$user -or $user.role -ne 'manager'){throw 'Accès réservé au manager.'}}
function Audit($kind,$agent,$detail){Event $null $kind $agent $detail;SaveState}
function Status($name){switch -Regex ($name.Trim().ToUpperInvariant()){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}}
function Stem($name){[IO.Path]::GetFileNameWithoutExtension($name)}
function TaskKey($entity,$prefix,$branch,$stem){($entity+'|'+$prefix+'|'+$branch+'|'+$stem).ToUpperInvariant()}
function FindTask($id){return $script:taskById[$id]}
function SafeName($name){if([string]::IsNullOrWhiteSpace($name)-or $name -in @('.','..') -or $name.IndexOfAny([IO.Path]::GetInvalidFileNameChars()) -ge 0 -or $name.Contains('/') -or $name.Contains('\')){throw 'Nom de fichier ou dossier invalide.'};return $name}
function EnsureUnder($root,$relative){
  $full=[IO.Path]::GetFullPath((Join-Path $root $relative));$parent=[IO.Path]::GetFullPath($root).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
  if(!$full.StartsWith($parent,[StringComparison]::OrdinalIgnoreCase)){throw 'Chemin hors du dossier autorisé.'};return $full
}
function GroupPaths($x){
  $p=Join-Path $share $x.entity
  if($x.prefix){$p=Join-Path $p $x.prefix}
  return $p
}
function Destination($x,$status){
  $p=Join-Path (GroupPaths $x) $status
  if($x.branch){$p=Join-Path $p $x.branch}
  New-Item -ItemType Directory -Force -Path $p | Out-Null
  return $p
}
function Register($entity,$prefix,$status,$statusDir,$path,$isFolder,$modified){
  $rel=[IO.Path]::GetDirectoryName($path.Substring($statusDir.Length).TrimStart('\','/'))
  if($null -eq $rel -or $rel -eq '.'){ $rel='' }
  $name=[IO.Path]::GetFileName($path);$stem=if($isFolder -and [IO.Path]::GetExtension($name) -notin @('.pdf','.doc','.docx')){$name}else{Stem $name}
  $key=TaskKey $entity $prefix $rel $stem
  if($script:taskByKey.ContainsKey($key)){
    $existing=$script:taskByKey[$key]
    if($isFolder -and $existing.status -ne $status -and ([string]::IsNullOrWhiteSpace($existing.currentPath) -or !(Test-Path -LiteralPath $existing.currentPath))){
      $existing.status=$status;$existing.currentPath=$path;$existing.resultPath=$path
      Event $existing 'SYNCHRONISATION' '' ('Dossier existant : '+$path)
      return $true
    }
    return $false
  }
  $now=if($modified){[string]$modified}else{(Get-Date).ToString('o')}
  $task=[pscustomobject]@{id=[guid]::NewGuid().ToString();key=$key;entity=$entity;prefix=$prefix;branch=$rel;name=$name;stem=$stem;status=$status;priority='Normale';agent='';sourcePath=$(if($isFolder){''}else{$path});currentPath=$path;resultPath=$(if($isFolder){$path}else{''});historyPath='';createdAt=$now;startedAt=$null;finishedAt=$null;reworkedAt=$null;comment='';solution='';cleanupWarning=''}
  [void]$script:tasks.Add($task);$script:taskByKey[$key]=$task;$script:taskById[$task.id]=$task
  Event $task 'DECOUVERTE' '' $path
  return $true
}
# L'analyse du partage s'effectue dans un runspace indépendant du serveur HTTP.
# Elle renvoie les documents et les dossiers finaux, sans explorer les fichiers internes des résultats.
$scanner=@'
param([string]$root)
$ErrorActionPreference='Stop'
if(!(Test-Path -LiteralPath $root -PathType Container)){throw "Racine DP introuvable : $root"}
foreach($entity in (Get-ChildItem -LiteralPath $root -Directory)){
  $queue=[Collections.Queue]::new();$queue.Enqueue($entity)
  while($queue.Count){
    $parent=$queue.Dequeue()
    foreach($child in (Get-ChildItem -LiteralPath $parent.FullName -Directory)){
      $name=$child.Name.Trim().ToUpperInvariant()
      if($name -eq 'A PUBLIER'){continue}
      $status=switch -Regex ($name){'^A TRAITER$'{'A_TRAITER';break};'^EN COURS$'{'EN_COURS';break};'^NON CONFORME$'{'NON_CONFORME';break};'^TRAIT(ES|ÉS)$'{'TRAITES';break};default{$null}}
      if(!$status){$queue.Enqueue($child);continue}
$prefix=$parent.FullName.Substring($entity.FullName.Length).TrimStart('\','/')
      if($status -in @('A_TRAITER','EN_COURS')){
        foreach($file in (Get-ChildItem -LiteralPath $child.FullName -File -Recurse)){
          if($file.Extension -in @('.pdf','.doc','.docx')){
            [pscustomobject]@{entity=$entity.Name;prefix=$prefix;status=$status;statusDir=$child.FullName;path=$file.FullName;isFolder=$false;modified=$file.LastWriteTime.ToString('o')}
          }
        }
      }else{
        $folders=[Collections.Queue]::new();$folders.Enqueue($child.FullName)
        while($folders.Count){
          $folderPath=[string]$folders.Dequeue()
          foreach($folder in (Get-ChildItem -LiteralPath $folderPath -Directory)){
            $firstFile=Get-ChildItem -LiteralPath $folder.FullName -File | Select-Object -First 1
            if($firstFile){
              [pscustomobject]@{entity=$entity.Name;prefix=$prefix;status=$status;statusDir=$child.FullName;path=$folder.FullName;isFolder=$true;modified=$folder.LastWriteTime.ToString('o')}
            }else{$folders.Enqueue($folder.FullName)}
          }
        }
      }
    }
  }
}
'@
function StartScan{
  if($script:scanHandle){return}
  $script:stateBytes=$null
  $script:scanPowerShell=[PowerShell]::Create()
  [void]$script:scanPowerShell.AddScript($scanner).AddArgument($share)
  $script:scanHandle=$script:scanPowerShell.BeginInvoke()
}
function CompleteScan{
  if(!$script:scanHandle -or !$script:scanHandle.IsCompleted){return}
  try{
    $found=$script:scanPowerShell.EndInvoke($script:scanHandle)
    if($script:scanPowerShell.HadErrors){throw ([string]$script:scanPowerShell.Streams.Error[0])}
    $changed=$false
    foreach($f in $found){if((Register $f.entity $f.prefix $f.status $f.statusDir $f.path $f.isFolder $f.modified)){$changed=$true}}
    if($changed){SaveState}
    $script:scanError=''
  }catch{$script:scanError=$_.Exception.Message;Write-Host "SCAN : $script:scanError" -ForegroundColor Yellow}
  finally{$script:lastScan=Get-Date;$script:scanPowerShell.Dispose();$script:scanPowerShell=$null;$script:scanHandle=$null;$script:stateBytes=$null}
}
function Json($response,$value,$code=200){$bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $value -Depth 12 -Compress));$response.StatusCode=$code;$response.ContentType='application/json; charset=utf-8';$response.ContentLength64=$bytes.Length;$response.OutputStream.Write($bytes,0,$bytes.Length);$response.Close()}
function SendState($response){
  if(!$script:stateBytes){
    $n=[math]::Min(300,$script:eventList.Count)
    $recent=if($n){$script:eventList.GetRange($script:eventList.Count-$n,$n).ToArray()}else{@()}
    $data=@{tasks=$script:tasks.ToArray();events=$recent;lastScan=$script:lastScan.ToString('o');scanning=[bool]$script:scanHandle;scanError=$script:scanError}
    $script:stateBytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $data -Depth 12 -Compress))
  }
  $response.ContentType='application/json; charset=utf-8';$response.ContentLength64=$script:stateBytes.Length
  $response.OutputStream.Write($script:stateBytes,0,$script:stateBytes.Length);$response.Close()
}
function Body($request){if($request.ContentLength64 -gt 42000000){throw 'Fichier trop volumineux (25 Mo maximum par fichier).'};$reader=[IO.StreamReader]::new($request.InputStream,[Text.Encoding]::UTF8);try{$raw=$reader.ReadToEnd();return ($raw|ConvertFrom-Json)}finally{$reader.Dispose()}}
function CopyTree($src,$dest){
  if(!(Test-Path -LiteralPath $src -PathType Container)){throw 'Dossier de travail introuvable.'}
  if(Test-Path -LiteralPath $dest){throw "Destination déjà présente : $dest"}
  Copy-Item -LiteralPath $src -Destination $dest -Recurse -ErrorAction Stop
  $a=@(Get-ChildItem -LiteralPath $src -File -Recurse);$b=@(Get-ChildItem -LiteralPath $dest -File -Recurse)
  if(!$a.Count -or $a.Count -ne $b.Count -or (($a|Measure-Object Length -Sum).Sum -ne ($b|Measure-Object Length -Sum).Sum)){Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw 'Copie non vérifiée : dossier final annulé.'}
}
function UploadFolder($b,$x){
  $upload=$script:uploads[[string]$b.uploadId]
  if(!$upload -or $upload.agent -ne [string]$b.agent -or !$upload.files){throw 'Sélectionnez un dossier du Bureau et attendez la fin de son transfert.'}
  if($upload.root -ine $x.stem -and $upload.root -ine $x.name){throw "Le dossier choisi doit s’appeler $($x.stem) (ou $($x.name))."}
  return $upload
}
function SendFile($r,$path,$type){$bytes=[IO.File]::ReadAllBytes($path);$r.ContentType=$type;$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close()}
function ExistsFile($path){if([string]::IsNullOrWhiteSpace($path)){return $false};return (Test-Path -LiteralPath $path -PathType Leaf)}
function Csv($v){'"'+([string]$v).Replace('"','""')+'"'}
StartScan
$listener=[Net.HttpListener]::new();$listener.Prefixes.Add([string]$cfg.listenUrl)
$listener.AuthenticationSchemes=[Net.AuthenticationSchemes]::Negotiate -bor [Net.AuthenticationSchemes]::Ntlm
$listener.Start()
[IO.File]::WriteAllText((Join-Path $base 'data\server.pid'),[string]$PID,[Text.Encoding]::ASCII)
[IO.File]::AppendAllText($logFile,((Get-Date).ToString('o')+" DÉMARRAGE $($cfg.listenUrl)`r`n"),[Text.Encoding]::UTF8)
try{Start-Process ([string]$cfg.listenUrl)}catch{[IO.File]::AppendAllText($logFile,"Ouverture du navigateur : $($_.Exception.Message)`r`n")}
Write-Host "ACCESSIBILITÉ démarré : $($cfg.listenUrl)" -ForegroundColor Cyan
while($listener.IsListening){
  $c=$listener.GetContext();$q=$c.Request;$r=$c.Response;$path=$q.Url.AbsolutePath
  CompleteScan
  if(!$script:scanHandle -and (Get-Date)-$script:lastScan -ge [timespan]::FromSeconds([math]::Max(15,[int]$cfg.scanSeconds))){StartScan}
  try{
    $user=ActiveSession $c
    if($path -eq '/api/login' -and $q.HttpMethod -eq 'POST'){
      $windowsName=if($c.User -and $c.User.Identity.IsAuthenticated){[string]$c.User.Identity.Name}else{''}
      $account=Account $windowsName
      if(!$account){Json $r @{error="Compte Windows non autorisé : $windowsName. Demandez au manager de l’ajouter."} 403;continue}
      $token=[guid]::NewGuid().ToString('N')+[guid]::NewGuid().ToString('N')
      $script:sessions[$token]=@{account=$account.account;expires=(Get-Date).AddHours(12)}
      $cookie=[Net.Cookie]::new('access_session',$token,'/')
      $cookie.HttpOnly=$true;$r.Cookies.Add($cookie)
      Audit 'CONNEXION' $account.account $account.role
      Json $r @{ok=$true;account=$account.account;role=$account.role};continue
    }
    if($path -eq '/api/logout' -and $q.HttpMethod -eq 'POST'){
      if($q.Cookies['access_session']){[void]$script:sessions.Remove([string]$q.Cookies['access_session'].Value)}
      $cookie=[Net.Cookie]::new('access_session','','/');$cookie.Expires=(Get-Date).AddDays(-1);$cookie.HttpOnly=$true;$r.Cookies.Add($cookie)
      if($user){Audit 'DECONNEXION' $user.account ''}
      Json $r @{ok=$true};continue
    }
    if(!$user -and $path -notin @('/','/app.js','/style.css')){Json $r @{error='Session fermée. Connectez-vous.'} 401;continue}
    if($path -eq '/api/me'){Json $r @{account=$user.account;role=$user.role};continue}
    if(($path -eq '/manager' -or $path -in @('/api/users','/api/users/save','/api/priority','/api/assign','/api/audit','/api/audit/export','/api/export')) -and $user.role -ne 'manager'){Json $r @{error='Accès réservé au manager.'} 403;continue}
    if($path -eq '/api/users' -and $q.HttpMethod -eq 'GET'){
      Json $r @{users=$script:users.ToArray()};continue
    }
    if($path -eq '/api/users/save' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$accountName=([string]$b.account).Trim();$role=[string]$b.role
      if($accountName -notmatch '^[^\\/\s]+\\[^\\/\s]+$' -or $role -notin @('agent','manager')){throw 'Utilisez un compte DOMAINE\identifiant et choisissez son rôle.'}
      $existing=@($script:users | Where-Object {$_.account -ieq $accountName} | Select-Object -First 1)[0]
      if(($role -ne 'manager' -or -not ([bool]$b.enabled)) -and @($script:users | Where-Object {$_.account -ine $accountName -and $_.role -eq 'manager' -and $_.enabled}).Count -eq 0){throw 'Il faut conserver au moins un autre manager actif.'}
      if($existing){$existing.role=$role;$existing.enabled=[bool]$b.enabled}else{[void]$script:users.Add([pscustomobject]@{account=$accountName;role=$role;enabled=[bool]$b.enabled})}
      SaveUsers;Audit 'PARAMETRAGE_UTILISATEUR' $user.account "$accountName : $role / $([bool]$b.enabled)"
      Json $r @{ok=$true;users=$script:users.ToArray()};continue
    }
    if($path -eq '/api/priority' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$priority=[string]$b.priority
      if(!$x -or $priority -notin @('Basse','Normale','Haute','Urgente')){throw 'Document ou priorité invalide.'}
      $x.priority=$priority;Event $x 'PRIORITE' $user.account $priority;SaveState
      Json $r @{ok=$true};continue
    }
    if($path -eq '/api/assign' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$assigned=Account ([string]$b.account)
      if(!$x -or $x.status -notin @('TRAITES','NON_CONFORME') -or !$assigned){throw 'Choisissez un dossier finalisé et un compte actif.'}
      $x.agent=$assigned.account;Event $x 'ATTRIBUTION_HISTORIQUE' $user.account $assigned.account;SaveState
      Json $r @{ok=$true};continue
    }
    if($path -eq '/api/audit'){
      $offset=[math]::Max(0,[int]$q.QueryString['offset']);$limit=[math]::Min(100,[math]::Max(1,[int]$q.QueryString['limit']))
      $count=$script:eventList.Count;$n=[math]::Min($limit,[math]::Max(0,$count-$offset))
      $items=for($i=0;$i -lt $n;$i++){$script:eventList[$count-1-$offset-$i]}
      Json $r @{total=$count;items=@($items)};continue
    }
    if($path -eq '/api/audit/export'){
      $rows=[Collections.Generic.List[string]]::new()
      [void]$rows.Add('Horodatage;Action;Compte_Windows;Document;Details')
      foreach($e in $script:eventList){
        $doc='';if($e.taskId -and $script:taskById.ContainsKey([string]$e.taskId)){$doc=$script:taskById[[string]$e.taskId].name}
        [void]$rows.Add((@((Csv $e.at),(Csv $e.kind),(Csv $e.agent),(Csv $doc),(Csv $e.detail)) -join ';'))
      }
      $bytes=[Text.Encoding]::UTF8.GetBytes([char]0xFEFF+($rows -join "`r`n"));$r.ContentType='text/csv; charset=utf-8';$r.AddHeader('Content-Disposition','attachment; filename=journal_audit_accessibilite.csv');$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();continue
    }
    if($path -eq '/api/state'){
      SendState $r;continue
    }
    if($path -eq '/api/document' -and $q.HttpMethod -eq 'GET'){
      $x=FindTask ([string]$q.QueryString['id'])
      if(!$x -or (!(ExistsFile $x.currentPath) -and !(ExistsFile $x.historyPath))){throw 'Document introuvable.'}
      $source=if(ExistsFile $x.currentPath){$x.currentPath}else{$x.historyPath}
      $r.AddHeader('Content-Disposition',('attachment; filename="'+[uri]::EscapeDataString($x.name)+'"'))
      SendFile $r $source 'application/octet-stream';continue
    }
    if($path -eq '/api/take' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=[string]$user.account
      if(!$x -or $x.status -ne 'A_TRAITER' -or !$agent){throw 'Document ou agent invalide. Actualisez la liste.'}
      if(!(Test-Path -LiteralPath $x.currentPath -PathType Leaf)){throw 'Document absent du DP. Actualisez.'}
      $dest=Join-Path (Destination $x 'EN COURS') $x.name
      if(Test-Path -LiteralPath $dest){throw 'Un fichier existe déjà dans En cours.'}
      Move-Item -LiteralPath $x.currentPath -Destination $dest -ErrorAction Stop
      $old=$x.currentPath
      try{$x.currentPath=$dest;$x.status='EN_COURS';$x.agent=$agent;$x.startedAt=(Get-Date).ToString('o');Event $x 'PRISE_EN_CHARGE' $agent $dest;SaveState}
      catch{Move-Item -LiteralPath $dest -Destination $old -ErrorAction SilentlyContinue;throw}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/upload/start' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$rootName=SafeName ([string]$b.root);$agent=[string]$user.account;if(!$agent){throw 'Agent requis.'}
      $id=[guid]::NewGuid().ToString();$folder=Join-Path $staging $id;New-Item -ItemType Directory -Path $folder | Out-Null
      $script:uploads[$id]=@{root=$rootName;agent=$agent;folder=$folder;files=0;bytes=0}
      Json $r @{ok=$true;uploadId=$id};continue
    }
    if($path -eq '/api/upload/file' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$upload=$script:uploads[[string]$b.uploadId]
      if(!$upload -or $upload.agent -ne $user.account){throw 'Transfert introuvable.'}
      $segments=@(([string]$b.relative).Replace('\','/') -split '/')
      if(!$segments.Count -or $segments.Count -gt 15){throw 'Chemin relatif invalide.'}
      foreach($seg in $segments){[void](SafeName $seg)}
      $relative=($segments -join [IO.Path]::DirectorySeparatorChar)
      $dest=EnsureUnder $upload.folder $relative
      $bytes=[Convert]::FromBase64String([string]$b.data)
      if($bytes.Length -gt 25000000 -or $upload.bytes+$bytes.Length -gt 250000000){throw 'Dossier trop volumineux (25 Mo par fichier, 250 Mo au total).'}
      if(Test-Path -LiteralPath $dest){throw 'Nom en double dans le dossier choisi.'}
      New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest)|Out-Null
      [IO.File]::WriteAllBytes($dest,$bytes);$upload.files++;$upload.bytes+=$bytes.Length
      Json $r @{ok=$true;count=$upload.files};continue
    }
    if($path -eq '/api/finish' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=[string]$user.account
      if(!$x -or $x.status -ne 'EN_COURS' -or ($x.agent -ine $agent -and $x.agent -ine ($agent -split '\\')[-1])){throw 'Traitement introuvable ou attribué à un autre agent.'}
      if($b.status -notin @('TRAITES','NON_CONFORME')){throw 'Statut final invalide.'}
      if($b.status -eq 'NON_CONFORME' -and ([string]::IsNullOrWhiteSpace($b.comment) -or [string]::IsNullOrWhiteSpace($b.solution))){throw 'Décrivez le problème et une proposition de solution.'}
      $b | Add-Member -NotePropertyName agent -NotePropertyValue $agent -Force
      $u=UploadFolder $b $x
      $finalStatus=if($b.status -eq 'TRAITES'){'TRAITES'}else{'NON CONFORME'}
      $dest=Join-Path (Destination $x $finalStatus) $u.root
      $archive=Join-Path $history $x.entity;if($x.prefix){$archive=Join-Path $archive $x.prefix};if($x.branch){$archive=Join-Path $archive $x.branch}
      New-Item -ItemType Directory -Force -Path $archive|Out-Null
      $archived=Join-Path $archive $x.name
      if(Test-Path -LiteralPath $archived){$archived=Join-Path $archive (('{0}_{1}{2}' -f $x.stem,(Get-Date -Format yyyyMMddHHmmss),[IO.Path]::GetExtension($x.name)))}
      Copy-Item -LiteralPath $x.currentPath -Destination $archived -ErrorAction Stop
      if((Get-Item -LiteralPath $archived).Length -ne (Get-Item -LiteralPath $x.currentPath).Length){Remove-Item -LiteralPath $archived -Force;throw 'Archive non vérifiée.'}
      try{CopyTree $u.folder $dest}catch{Remove-Item -LiteralPath $archived -Force -ErrorAction SilentlyContinue;throw}
      $oldPath=$x.currentPath
      $x.agent=$agent;$x.historyPath=$archived;$x.resultPath=$dest;$x.currentPath=$dest;$x.status=[string]$b.status;$x.finishedAt=(Get-Date).ToString('o');$x.comment=[string]$b.comment;$x.solution=[string]$b.solution
      Event $x 'FIN_TRAITEMENT' $agent $finalStatus;SaveState
      try{Remove-Item -LiteralPath $oldPath -Force -ErrorAction Stop;Remove-Item -LiteralPath $u.folder -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.uploadId)}catch{$x.cleanupWarning=$_.Exception.Message;SaveState}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/rework' -and $q.HttpMethod -eq 'POST'){
      $b=Body $q;$x=FindTask ([string]$b.id);$agent=[string]$user.account
      if(!$x -or $x.status -ne 'NON_CONFORME' -or !$agent){throw 'Dossier non conforme introuvable.'}
      $b | Add-Member -NotePropertyName agent -NotePropertyValue $agent -Force
      $u=UploadFolder $b $x
      $dest=Join-Path (Destination $x 'TRAITES') $u.root
      CopyTree $u.folder $dest
      $old=$x.resultPath;$x.resultPath=$dest;$x.currentPath=$dest;$x.status='TRAITES';$x.reworkedAt=(Get-Date).ToString('o')
      Event $x 'RETRAITEMENT' $agent ('NON_CONFORME vers TRAITES : '+[string]$b.comment);SaveState
      try{if(Test-Path -LiteralPath $old){Remove-Item -LiteralPath $old -Recurse -Force -ErrorAction Stop};Remove-Item -LiteralPath $u.folder -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.uploadId)}catch{$x.cleanupWarning=$_.Exception.Message;SaveState}
      Json $r @{ok=$true;task=$x};continue
    }
    if($path -eq '/api/export'){
      $rows=@('NomFichier;Domaine;SousDomaine;Statut;Statut_2;Date_A_TRAITER;Date_FIN;Date_de_Retraitement;Agent;DMT_minutes;DMT2_minutes;Commentaire;Solution')
      foreach($x in $script:tasks){$dmt='';$dmt2='';if($x.startedAt -and $x.finishedAt){$dmt=[math]::Round(([datetime]$x.finishedAt-[datetime]$x.startedAt).TotalMinutes,2)};if($x.finishedAt -and $x.reworkedAt){$dmt2=[math]::Round(([datetime]$x.reworkedAt-[datetime]$x.finishedAt).TotalMinutes,2)}
        $rows+=(@((Csv $x.name),(Csv $x.entity),(Csv $x.branch),(Csv $x.status),(Csv $(if($x.reworkedAt){'NON_CONFORME -> TRAITES'}else{''})),(Csv $x.createdAt),(Csv $x.finishedAt),(Csv $x.reworkedAt),(Csv $x.agent),(Csv $dmt),(Csv $dmt2),(Csv $x.comment),(Csv $x.solution)) -join ';')}
      $bytes=[Text.Encoding]::UTF8.GetBytes([char]0xFEFF+($rows -join "`r`n"));$r.ContentType='text/csv; charset=utf-8';$r.AddHeader('Content-Disposition','attachment; filename=pilotage_accessibilite.csv');$r.ContentLength64=$bytes.Length;$r.OutputStream.Write($bytes,0,$bytes.Length);$r.Close();continue
    }
    if($path -eq '/' -or $path -in @('/agent','/manager','/app.js','/style.css')){
      $file=switch($path){'/'{'index.html'}'/agent'{'agent.html'}'/manager'{'manager.html'}'/app.js'{'app.js'}'/style.css'{'style.css'}}
      $type=if($file.EndsWith('.css')){'text/css; charset=utf-8'}elseif($file.EndsWith('.js')){'application/javascript; charset=utf-8'}else{'text/html; charset=utf-8'}
      SendFile $r (Join-Path (Join-Path $base 'web') $file) $type;continue
    }
    Json $r @{error='Route inconnue.'} 404
  }catch{Write-Host $_.Exception.Message -ForegroundColor Red;[IO.File]::AppendAllText($logFile,((Get-Date).ToString('o')+' '+$_.Exception.Message+"`r`n"),[Text.Encoding]::UTF8);try{Json $r @{error=$_.Exception.Message} 400}catch{}}
}
