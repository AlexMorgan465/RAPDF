﻿$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
$pidFile=Join-Path $base 'data\server.pid'
if(!(Test-Path -LiteralPath $pidFile)){Write-Host 'Aucun serveur enregistré.';exit}
$serverPid=[int]([IO.File]::ReadAllText($pidFile).Trim())
$process=Get-CimInstance Win32_Process -Filter "ProcessId=$serverPid"
if($process -and $process.CommandLine -and $process.CommandLine.Contains((Join-Path $base 'server.ps1'))){
  Stop-Process -Id $serverPid -ErrorAction Stop
  Remove-Item -LiteralPath $pidFile -Force
  Write-Host 'Serveur Accessibilité arrêté.'
}else{Write-Host 'Processus introuvable ou différent : aucune fermeture effectuée.'}
