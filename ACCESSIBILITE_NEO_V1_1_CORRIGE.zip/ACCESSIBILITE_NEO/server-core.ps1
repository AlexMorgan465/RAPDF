param([ValidateSet('agent','manager')][string]$Mode)
$ErrorActionPreference='Stop'
$base=Split-Path -Parent $MyInvocation.MyCommand.Path
. (Join-Path $base 'http.ps1')
. (Join-Path $base 'store.ps1')
$actor=Session-Name
if($Mode -eq 'manager' -and $script:cfg.managerAccounts -inotcontains $actor){throw "Accès manager refusé pour la session $actor"}
$port=if($Mode -eq 'manager'){[int]$script:cfg.managerPort}else{[int]$script:cfg.agentPort}
if($port -lt 1024 -or $port -gt 65535){throw 'Port invalide'}
$pidPath=Join-Path $script:data ("$Mode.pid")
$listener=[Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback,$port)
$listener.Start()
[IO.File]::WriteAllText($pidPath,[string]$PID,[Text.Encoding]::ASCII)
Write-Host "$Mode prêt sur http://localhost:$port/ — $actor"
$workerLimit=[math]::Max(1,[math]::Min(8,[int]$script:cfg.maxEntityWorkers))
$script:initialImport=(@((Load-Catalog).documents).Count -eq 0)
$script:imported=@{}
$dirty=[Collections.Generic.Queue[string]]::new();$queued=@{};$workers=@{};$watcher=$null;$watchJobs=@()
$script:lastDiscovery=[datetime]::MinValue;$script:discovery=$null;$script:discoveryHandle=$null;$script:lastError='';$script:run=$true
function Queue-Entity($name){if(!$name -or $queued.ContainsKey($name) -or $workers.ContainsKey($name)){return};$queued[$name]=$true;$dirty.Enqueue($name)}
function Discover{
 if($script:discovery){return}
 $script:discovery=[PowerShell]::Create()
 [void]$script:discovery.AddScript('param($root) @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction Stop | Select-Object -ExpandProperty Name)').AddArgument([string]$script:cfg.sharedRoot)
 $script:discoveryHandle=$script:discovery.BeginInvoke()
 $script:lastDiscovery=Get-Date
}
function Pump{
 if($script:discovery -and $script:discoveryHandle.IsCompleted){
   try{$names=@($script:discovery.EndInvoke($script:discoveryHandle));foreach($name in $names){Queue-Entity ([string]$name)};$script:lastError=''}
   catch{$script:lastError=$_.Exception.Message}
   finally{$script:discovery.Dispose();$script:discovery=$null;$script:discoveryHandle=$null}
 }
 foreach($name in @($workers.Keys)){
   $job=$workers[$name]
   if(!$job.handle.IsCompleted){continue}
   try{$entries=@($job.ps.EndInvoke($job.handle));Merge-Scan $name $entries;$script:lastError=''}
   catch{$script:lastError="${name}: $($_.Exception.Message)"}
   finally{$job.ps.Dispose();$workers.Remove($name)}
 }
 while($dirty.Count -and $workers.Count -lt $workerLimit){
   $name=$dirty.Dequeue();$queued.Remove($name)
   $ps=[PowerShell]::Create()
   $includeTreated=$script:initialImport -and !$script:imported.ContainsKey($name)
   $script:imported[$name]=$true
   [void]$ps.AddCommand((Join-Path $base 'scan-entity.ps1')).AddParameter('Root',[string]$script:cfg.sharedRoot).AddParameter('Entity',$name).AddParameter('IncludeTreated',[bool]$includeTreated)
   $workers[$name]=@{ps=$ps;handle=$ps.BeginInvoke()}
 }
 if(!$script:discovery -and (Get-Date)-$script:lastDiscovery -gt [timespan]::FromSeconds([math]::Max(30,[int]$script:cfg.reconcileSeconds))){Discover}
}
function Serve($client,$req){
 $path=$req.path;$method=$req.verb
 if($path -eq '/api/health'){Reply-Json $client @{ok=$true;mode=$Mode;session=$actor;scanning=$workers.Count;error=$lastError};return}
 if($path -eq '/api/state'){
   $catalog=Load-Catalog
   $etag='"'+$catalog.version+'"'
   if($req.headers['If-None-Match'] -eq $etag){Reply $client 304 'application/json' ([byte[]]@()) @{ETag=$etag};return}
   $rows=@($catalog.documents|Where-Object {$_.status -in @('A_TRAITER','EN_COURS','NON_CONFORME')})
   $counts=@{A_TRAITER=0;EN_COURS=0;NON_CONFORME=0;TRAITES=0;ABSENT=0}
   $byEntity=@{};$byAgent=@{}
   foreach($t in @($catalog.documents)){
     if($counts.ContainsKey([string]$t.status)){$counts[[string]$t.status]++}
     if(!$byEntity.ContainsKey([string]$t.entity)){$byEntity[[string]$t.entity]=0};$byEntity[[string]$t.entity]++
     if($t.agent){if(!$byAgent.ContainsKey([string]$t.agent)){$byAgent[[string]$t.agent]=0};$byAgent[[string]$t.agent]++}
   }
   $response=@{version=$catalog.version;documents=$rows;counts=$counts;byEntity=$byEntity;byAgent=$byAgent;scanning=$workers.Count;error=$lastError;session=($actor -split '\\')[-1]}
   $bytes=[Text.Encoding]::UTF8.GetBytes((ConvertTo-Json -InputObject $response -Depth 12 -Compress))
   Reply $client 200 'application/json; charset=utf-8' $bytes @{ETag=$etag};return
 }
 if($path -eq '/api/list'){
   $catalog=Load-Catalog;$page=[math]::Max(1,[int]$req.query['page']);$limit=[math]::Min(100,[math]::Max(1,[int]$req.query['limit']))
   $status=[string]$req.query['status'];$entity=[string]$req.query['entity'];$search=[string]$req.query['q'];$mine=[string]$req.query['mine'] -eq '1'
   $rows=@($catalog.documents|Where-Object {(!$status -or $_.status -eq $status) -and (!$entity -or $_.entity -eq $entity) -and (!$mine -or $_.agent -ieq $actor) -and (!$search -or ($_.name+' '+$_.entity+' '+$_.agent+' '+$_.branch).IndexOf($search,[StringComparison]::OrdinalIgnoreCase) -ge 0)}|Sort-Object -Property created -Descending)
   Reply-Json $client @{items=@($rows|Select-Object -Skip (($page-1)*$limit) -First $limit);total=$rows.Count;page=$page;limit=$limit};return
 }
 if($path -eq '/api/audit'){
   $page=[math]::Max(1,[int]$req.query['page']);$limit=100
   $all=if(Test-Path -LiteralPath $script:auditFile){@([IO.File]::ReadAllLines($script:auditFile)|Where-Object {$_}|ForEach-Object {try{$_|ConvertFrom-Json}catch{}})}else{@()}
   $sorted=@($all|Select-Object -Last ($page*$limit)|Select-Object -Last $limit)
   [array]::Reverse($sorted)
   Reply-Json $client @{items=$sorted;total=$all.Count;page=$page};return
 }
 if($path -eq '/api/file'){
   $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$req.query['id']);$file=if($t.currentPath -and (Test-Path -LiteralPath $t.currentPath -PathType Leaf)){$t.currentPath}else{$t.historyPath}
   Source-Allowed $t.currentPath
   if(!$file -or !(Test-Path -LiteralPath $file -PathType Leaf)){throw 'Original absent'}
   $bytes=[IO.File]::ReadAllBytes($file)
   Reply $client 200 'application/octet-stream' $bytes @{'Content-Disposition'=('attachment; filename="'+[uri]::EscapeDataString($t.name)+'"')};return
 }
 if($path -eq '/api/stop' -and $method -eq 'POST'){Reply-Json $client @{ok=$true};$script:run=$false;return}
 if($Mode -eq 'agent' -and $method -eq 'POST'){
   $b=Body-Json $req
   if($path -eq '/api/take'){
     $result=With-Store {
       $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
       if($t.status -ne 'A_TRAITER' -or !(Test-Path -LiteralPath $t.currentPath -PathType Leaf)){throw 'Document déjà pris ou absent'}
       $folder=Get-Destination $t 'EN COURS';$dest=Join-Path $folder $t.name
       if(Test-Path -LiteralPath $dest){throw 'Destination déjà présente'}
       Move-Item -LiteralPath $t.currentPath -Destination $dest -ErrorAction Stop
       $t.currentPath=$dest;$t.status='EN_COURS';$t.agent=$actor;$t.started=(Get-Date).ToString('o');Audit 'PRISE_EN_CHARGE' $t $actor $dest;Save-Catalog $catalog
       return $t
     }
     Reply-Json $client @{ok=$true;document=$result};return
   }
   if($path -eq '/api/upload/start'){Reply-Json $client @{id=(Upload-Start ([string]$b.name) $actor)};return}
   if($path -eq '/api/upload/file'){Upload-File ([string]$b.id) $actor ([string]$b.relative) ([string]$b.data);Reply-Json $client @{ok=$true};return}
   if($path -eq '/api/finish'){
     $result=With-Store {
       $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
       if($t.status -ne 'EN_COURS' -or $t.agent -ine $actor){throw 'Traitement attribué à un autre agent'}
       if($b.status -notin @('TRAITES','NON_CONFORME')){throw 'Statut invalide'}
       if($b.status -eq 'NON_CONFORME' -and (!$b.comment -or !$b.solution)){throw 'Problème et solution obligatoires'}
       if(!(Test-Path -LiteralPath $t.currentPath -PathType Leaf)){throw 'Original absent'}
       $u=Upload-Ready ([string]$b.upload) $actor $t.stem $t.name
       $folder=if($b.status -eq 'TRAITES'){'TRAITES'}else{'NON CONFORME'}
       $dest=Join-Path (Get-Destination $t $folder) $u.root
       if(Test-Path -LiteralPath $dest){throw 'Un résultat existe déjà'}
       $archive=Join-Path ([string]$script:cfg.historyRoot) $t.entity
       $entityRoot=Join-Path ([string]$script:cfg.sharedRoot) $t.entity
       $relative=[IO.Path]::GetRelativePath($entityRoot,$t.statusRoot)
       $parts=$relative -split '[\\/]';$parts[-1]='EN COURS'
       $archive=Join-Path $archive ($parts -join [IO.Path]::DirectorySeparatorChar)
       if($t.branch){$archive=Join-Path $archive $t.branch}
       [void][IO.Directory]::CreateDirectory($archive)
       $archived=Join-Path $archive $t.name
       if(Test-Path -LiteralPath $archived){$archived=Join-Path $archive ((Get-Date -Format yyyyMMddHHmmss)+'_'+$t.name)}
       try{Copy-Item -LiteralPath $u.path -Destination $dest -Recurse -ErrorAction Stop}
       catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw}
       try{
         Copy-Item -LiteralPath $t.currentPath -Destination $archived -ErrorAction Stop
         if((Get-Item -LiteralPath $archived).Length -ne (Get-Item -LiteralPath $t.currentPath).Length){throw 'Copie de l original incomplète'}
         Remove-Item -LiteralPath $t.currentPath -Force -ErrorAction Stop
       }catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;Remove-Item -LiteralPath $archived -Force -ErrorAction SilentlyContinue;throw}
       $t.currentPath=$dest;$t.resultPath=$dest;$t.historyPath=$archived;$t.status=[string]$b.status;$t.finished=(Get-Date).ToString('o');$t.comment=[string]$b.comment;$t.solution=[string]$b.solution
       Audit 'FIN_TRAITEMENT' $t $actor $folder;Save-Catalog $catalog
       Remove-Item -LiteralPath $u.path -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.upload)
       return $t
     }
     Reply-Json $client @{ok=$true;document=$result};return
   }
   if($path -eq '/api/rework'){
     $result=With-Store {
       $catalog=Load-Catalog;$t=Current-Task $catalog ([string]$b.id)
       if($t.status -ne 'NON_CONFORME'){throw 'Dossier non conforme absent'}
       $u=Upload-Ready ([string]$b.upload) $actor $t.stem $t.name
       $dest=Join-Path (Get-Destination $t 'TRAITES') $u.root
       if(Test-Path -LiteralPath $dest){throw 'Résultat déjà présent'}
       try{Copy-Item -LiteralPath $u.path -Destination $dest -Recurse -ErrorAction Stop}
       catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw}
       try{Remove-Item -LiteralPath $t.resultPath -Recurse -Force -ErrorAction Stop}catch{Remove-Item -LiteralPath $dest -Recurse -Force -ErrorAction SilentlyContinue;throw}
       $t.status='TRAITES';$t.resultPath=$dest;$t.currentPath=$dest;$t.reworked=(Get-Date).ToString('o')
       Audit 'RETRAITEMENT' $t $actor ([string]$b.note);Save-Catalog $catalog
       Remove-Item -LiteralPath $u.path -Recurse -Force -ErrorAction SilentlyContinue;$script:uploads.Remove([string]$b.upload)
       return $t
     }
     Reply-Json $client @{ok=$true;document=$result};return
   }
 }
 if($path -in @('/','/app.js','/style.css')){
   $file=switch($path){'/'{"$Mode.html"}'/app.js'{'app.js'}'/style.css'{'style.css'}}
   $content=Join-Path (Join-Path $base 'web') $file
   $type=if($file.EndsWith('.js')){'application/javascript; charset=utf-8'}elseif($file.EndsWith('.css')){'text/css; charset=utf-8'}else{'text/html; charset=utf-8'}
   Reply $client 200 $type ([IO.File]::ReadAllBytes($content));return
 }
 Reply-Json $client @{error='Route inconnue'} 404
}
try{
 Discover
 try{
   $watcher=[IO.FileSystemWatcher]::new([string]$script:cfg.sharedRoot)
   $watcher.IncludeSubdirectories=$true;$watcher.NotifyFilter=[IO.NotifyFilters]::FileName -bor [IO.NotifyFilters]::DirectoryName -bor [IO.NotifyFilters]::LastWrite;$watcher.InternalBufferSize=32768
   $watchQueue=[Collections.Concurrent.ConcurrentQueue[string]]::new()
   foreach($kind in @('Created','Changed','Deleted','Renamed','Error')){
     $watchJobs+=Register-ObjectEvent -InputObject $watcher -EventName $kind -SourceIdentifier ("AccessibiliteNeo-$Mode-$PID-$kind") -MessageData $watchQueue -Action {
       $name=if($Event.SourceEventArgs.PSObject.Properties['FullPath']){[string]$Event.SourceEventArgs.FullPath}else{''}
       [void]$Event.MessageData.Enqueue($name)
     }
   }
   $watcher.EnableRaisingEvents=$true
 }catch{$lastError='Surveillance DP : '+$_.Exception.Message}
 while($script:run){
   Pump
   if($watchQueue){
     for($i=0;$i -lt 30;$i++){
       $changed='';if(!$watchQueue.TryDequeue([ref]$changed)){break}
       if($changed){
         $prefix=[IO.Path]::GetFullPath([string]$script:cfg.sharedRoot).TrimEnd('\','/')+[IO.Path]::DirectorySeparatorChar
         if($changed.StartsWith($prefix,[StringComparison]::OrdinalIgnoreCase)){
           $relative=$changed.Substring($prefix.Length);$name=($relative -split '[\\/]')[0];Queue-Entity $name
         }
       }else{Discover}
     }
   }
   if(!$listener.Pending()){Start-Sleep -Milliseconds 250;continue}
   $client=$listener.AcceptTcpClient()
   try{$request=Read-Request $client $port;Serve $client $request}
   catch{
     $errorText=$_.Exception.Message
     try{Reply-Json $client @{error=$errorText} 400}catch{try{$client.Close()}catch{}}
     $lastError=$errorText
   }
 }
}finally{
 foreach($kind in @('Created','Changed','Deleted','Renamed','Error')){Unregister-Event -SourceIdentifier ("AccessibiliteNeo-$Mode-$PID-$kind") -ErrorAction SilentlyContinue}
 foreach($job in $watchJobs){Remove-Job $job -Force -ErrorAction SilentlyContinue}
 if($watcher){$watcher.Dispose()}
 $listener.Stop();Remove-Item -LiteralPath $pidPath -Force -ErrorAction SilentlyContinue
}
