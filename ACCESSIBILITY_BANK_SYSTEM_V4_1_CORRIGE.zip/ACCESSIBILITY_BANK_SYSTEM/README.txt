CORRECTIF V4.1 : File.Replace utilise un chemin de sauvegarde explicite.
Pour corriger V4 deja installee : remplacer COMMON\core.ps1 puis relancer
TESTS\TEST_LOCAL.bat. Aucun changement de configuration necessaire.

ACCESSIBILITE BANK SYSTEM — V4 ORBIT CIBLE

MISE A JOUR
- Fermer les anciennes sessions Manager et Agent, sur tous les postes.
- Extraire le ZIP. Les dossiers AGENT, MANAGER, COMMON et TESTS restent ensemble.
- Remplacer le dossier applicatif, en conservant COMMON\settings.ps1 si le
  chemin du DP a été personnalisé. Ne supprimer aucun fichier du DP.
- Alternative : MISE_A_JOUR.bat copie les fichiers et garde le chemin personnalisé.
- Lancer MANAGER\START_MANAGER.bat (localhost:8790), puis AGENT\START_AGENT.bat
  (localhost:8788). START_DEBUG.bat affiche les erreurs de lancement.
- Au premier lancement Manager, les anciens compteurs sont repris du registre,
  sans parcourir les dossiers. Un scan manuel complet les vérifie physiquement.
- Ne pas mélanger les serveurs V3 et V4 : les anciens lancent encore des scans.

ORBIT : AUCUN SCAN GLOBAL
Au démarrage : lecture du schema.json local et du petit état JSON central.
Aucun Start-Job de scan et aucun parcours de dossiers.
La synchronisation chaque seconde vérifie uniquement les versions des fichiers
JSON centraux. L'état léger est relu s'il a changé. Aucun /api/counts global.

1. Choisir Entité -> Statut -> Branche.
   Un comptage ciblé lit seulement les entrées directes de ce chemin.
   Le compteur est publié dans l'état central. Aucun nom de fichier n'est
   affiché ou enregistré dans le registre par le comptage.
2. ENGAGE : récupérer les noms et métadonnées uniquement dans cette branche.
   C'est ce bouton qui importe un nouveau document dans le registre.
3. PEC / déplacement : source + destination physiques, mise à jour du registre
   et ajustement des deux compteurs. Aucune énumération ou rescan après mouvement.
   L'interface change immédiatement après confirmation du serveur.
4. Autres agents : lecture du petit état central. Une branche déjà engagée peut
   relire ses documents enregistrés lors d'un changement : JSON seulement,
   aucun accès physique à ses fichiers. Double PEC refusée par le verrou commun.
5. Urgences et historique sont lus à l'ouverture de leurs onglets dans le registre,
   sans scan physique. Les priorités manager restent partagées.

Un compteur non vérifié est « ? », jamais un faux 0. Il affiche le minimum connu
si des mouvements ont ajouté des documents. Les totaux restent partiels tant
que certaines branches n'ont pas été comptées ou vérifiées par le manager.
« Synchroniser l'état » ne découvre pas les nouveaux dépôts physiques.
Pour voir un nouveau dépôt : compter la branche puis ENGAGE.

MANAGER : SCAN COMPLET REEL, EXPLICITE
« Scanner toutes les entités » lance un job asynchrone réservé au manager.
Ce job est déclenché uniquement par le bouton, jamais au démarrage ni par Orbit.
Il parcourt tous les statuts et branches des entités configurées. Il découvre
les nouvelles branches imbriquées et les documents PDF, DOC et DOCX déposés
à la racine d'un statut ou dans ses sous-dossiers. Il prend aussi en compte les
entités CATEGORY_FIRST comme CONTRATHEQUE et leurs sous-dossiers après statut.
Le serveur reste disponible pendant la collecte physique du scan.

Le bilan indique : chemins visités, nouveaux documents importés, déplacements
externes détectés, fichiers hors PDF/Word ignorés, branches modifiées pendant le
scan et avertissements. Exporter le bilan fournit chaque chemin effectivement
lu, son compteur, ses erreurs et les chemins absents. Aucun message « actualisé »
avant la fin du job. Les branches modifiées entre-temps par un agent ne sont
pas écrasées : elles sont conservées et signalées pour un prochain scan.
Un partage inaccessible provoque un échec explicite, sans inventer des compteurs.
Un chemin réellement absent sur un partage accessible est signalé avec 0.
Les entités non configurées et documents directement sous une entité, hors
statut, sont signalés : ils ne sont pas importés avec un statut inventé.
Pour ajouter une entité, modifier COMMON\schema.json sur les postes.

UNITES ET ARBORESCENCE
- AT / EC : fichiers PDF/Word directs ; nouveaux sous-dossiers = nouvelles branches.
- NC / TRAITES : les dossiers terminaux restent une unité document/dossier,
  comme dans V3. Les branches connues sont reconnues comme structure, sans double
  comptage de leur contenu.
- Un dossier document déjà enregistré dans V3, ou déplacé depuis NC, conserve
  son identité même lors d'un retour vers AT / EC.
- Pas de déplacement ou de suppression de branche structurelle par PEC.
- Un nom dupliqué dans deux statuts est signalé, sans fusion silencieuse.
- Renommer extérieurement un document donne une nouvelle identité ; les
  déplacements dans l'application conservent toujours son dépôt figé.
- Le séparateur | d'une branche CATEGORY_FIRST représente un sous-dossier situé
  APRES le statut ; il ne correspond jamais à un caractère du chemin Windows.

FONCTIONS V3 CONSERVEES
Dépôt = modification au premier import, inchangé aux actualisations et mouvements.
Facturation par mois de fin, prix par document, tarif entité mémorisé à la fin,
complexité commentée, priorités, mails NC par document/entité (brouillon validé
par l'utilisateur), durées cumulées, reporting ISO et exports CSV Excel.
Pour les documents déjà suivis, le registre V3 et l'ancien historique restent
intacts. Les dates et prix de référence existants ne sont pas recalculés.

Tarifs : 9 pour Bouygues telecom, CONTRATHEQUE, CMO, ACM, DIRCOM, MONABANQ,
CREATIS ; 4,5 pour DIRCO, CMMABN, CIC CIB ASSET SERVICING.
COFIDIS FRANCE non présent sur la capture : prix à renseigner.
Devise non indiquée : montants en unités. Prix individuel prioritaire, zéro accepté.
Dépôts et durées antérieurs à la première observation ne peuvent pas être inventés.

ETAT PARTAGE
<DP>\.accessibility_history\registry-v3.json : registre détaillé conservé.
<DP>\.accessibility_history\orbit-state-v4.json : compteurs et changements récents.
<DP>\.accessibility_history\fullscan-v4.json : progression légère.
<DP>\.accessibility_history\fullscan-report-v4.json : bilan complet, lu à l'export.
Le comptage cible ne charge pas le registre détaillé. ENGAGE, les fiches, urgences,
historiques et mouvements peuvent lire ce registre JSON : ils n'énumèrent aucune
autre branche physique. Verrou partagé et écritures JSON atomiques.
Toutes les interfaces ont besoin de droits lecture/écriture/déplacement sur le DP.
Aucun appel Internet ni bibliothèque externe.

VALIDATION
Tests JavaScript exécutés : démarrage et polling Orbit sans scan ni comptage,
comptage du seul chemin sélectionné, noms seulement après ENGAGE, PEC sans rescan,
synchronisation, urgences, vues manager, prix, durées et semaines ISO.
PowerShell n'est pas disponible dans l'environnement de préparation Linux.
TESTS\TEST_LOCAL.bat utilise le parseur Windows PowerShell et un répertoire
TEMP isolé : ciblage, conservation du dépôt, vraie double PEC entre deux processus,
ouveau document ajouté après scan, nouvelle branche imbriquée, CATEGORY_FIRST,
compteurs, prix, complexité et protection du registre. Il ne touche pas au DP.
Lancer ce test sous Windows avant production, puis essayer deux postes sur le DP.
