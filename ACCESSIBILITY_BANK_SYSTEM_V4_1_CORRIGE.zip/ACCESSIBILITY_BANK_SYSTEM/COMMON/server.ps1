﻿param([int]$Port,[string]$RootPath,[string]$Role,[string]$AppPath)
. (Join-Path $PSScriptRoot 'core.ps1') -RootPath $RootPath
# No startup job, no timer and no filesystem enumeration on Orbit startup.
$scanJob=$null
if($Role-eq'MANAGER'){try{SeedQuick}catch{Write-Warning $_.Exception.Message}}
$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Start-Process "http://localhost:$Port/"
try{$run=$true;while($run){$c=$l.GetContext();try{
 $r=$c.Request;$p=$r.Url.AbsolutePath
 if($r.HttpMethod-eq'POST'-and$r.Headers['X-Workflow']-ne'bank-v3'){Send $c 403 @{error='Requête non autorisée'};continue}
 if($p-in@('/','/app.js','/style.css')){$name=if($p-eq'/'){'index.html'}else{$p.TrimStart('/')};$file=Join-Path $AppPath $name;$bytes=[IO.File]::ReadAllBytes($file);$c.Response.ContentType=@{'index.html'='text/html; charset=utf-8';'app.js'='application/javascript; charset=utf-8';'style.css'='text/css; charset=utf-8'}[$name];$c.Response.Headers['Cache-Control']='no-store';$c.Response.ContentLength64=$bytes.Length;$c.Response.OutputStream.Write($bytes,0,$bytes.Length);$c.Response.Close();continue}
 if($p-eq'/api/schema'){$a=@();foreach($e in $Schema.Keys){$a+=@{entity=$e;mode=$Schema[$e].Mode;branches=@($Schema[$e].Branches)}};Send $c 200 @{entities=$a;statuses=$Statuses};continue}
 if($p-eq'/api/revision'){$file=if($Role-eq'AGENT'){$QuickFile}else{$DbFile};$info=New-Object IO.FileInfo($file);$revision=if($info.Exists){[string]$info.LastWriteTimeUtc.Ticks+':'+[string]$info.Length}else{'initial'};if($Role-eq'AGENT'){$revision+='|'+(DbRevision)};Send $c 200 @{revision=$revision};continue}
 if($p-eq'/api/orbit'){Send $c 200 (OrbitState);continue}
 if($p-eq'/api/scan/report'){if($Role-ne'MANAGER'){throw 'Réservé au manager'};Send $c 200 (ReadScanReport);continue}
 if($p-eq'/api/scan/status'){$status=ReadScanStatus
  if($scanJob -and $scanJob.State-in@('Failed','Stopped') -and $status.running){$status.running=$false;$status.phase='failed';$status.errors=@($status.errors)+@('Processus de scan interrompu');PublishScan $status}
  Send $c 200 $status;continue
 }
 if($p-eq'/api/state'){
  if($Role-ne'MANAGER'){Send $c 403 @{error='Utiliser le petit état Orbit'};continue}
  $db=ReadDb;Send $c 200 @{role=$Role;agent=[Environment]::UserName;root=$RootPath;documents=@($db.documents);history=@($db.history);rates=@($db.rates);scannedAt=$db.scannedAt;scanErrors=@($db.scanErrors)};continue
 }
 if($p-eq'/api/branch/cached'){$q=Q $r;Send $c 200 (CachedBranch $q.entity $q.status $q.branch);continue}
 if($p-eq'/api/document'){$q=Q $r;$db=ReadDb;Send $c 200 @{document=(FindDoc $db $q.id)};continue}
 if($p-eq'/api/urgent'){$db=ReadDb;Send $c 200 @{documents=@($db.documents|Where-Object{$_.present-and$_.priority-and$_.status-ne'TRAITES'})};continue}
 if($p-eq'/api/history'){$db=ReadDb;Send $c 200 @{history=@($db.history|Where-Object{$Role-eq'MANAGER'-or$_.agent-eq[Environment]::UserName})};continue}
 if($r.HttpMethod-ne'POST'){Send $c 405 @{error='Méthode invalide'};continue}
 $body=Body $r
 switch($p){
 '/api/branch/count' {Send $c 200 (TargetCount ([string]$body.entity) ([string]$body.status) ([string]$body.branch))}
 '/api/branch/engage' {Send $c 200 (EngageBranch ([string]$body.entity) ([string]$body.status) ([string]$body.branch))}
 '/api/fullscan' {
  if($Role-ne'MANAGER'){Send $c 403 @{error='Scan global interdit sur Orbit. Compter ou ENGAGE sur une branche.'};continue}
  if($scanJob -and $scanJob.State-eq'Running'){Send $c 202 @{ok=$true;running=$true;alreadyRunning=$true};continue}
  # Reserve one shared scan so two managers cannot scan simultaneously.
  $lk=LockDb
  try{$current=ReadScanStatus
   if($current.running -and $current.ownerHost-eq[Environment]::MachineName -and $current.ownerPid -and !(Get-Process -Id ([int]$current.ownerPid) -ErrorAction SilentlyContinue)){$current.running=$false}
   if($current.running -and $current.heartbeat -and ([datetime]$current.heartbeat).AddMinutes(10)-gt(Get-Date).ToUniversalTime()){Send $c 202 @{ok=$true;running=$true;alreadyRunning=$true};continue}
   $runId=[guid]::NewGuid().ToString('N');AtomicJson $ScanFile @{runId=$runId;running=$true;phase='queued';heartbeat=(NowIso);ownerHost=[Environment]::MachineName;ownerPid=$PID;startedAt=(NowIso);visited=0;added=0;changed=0;ignored=0;skipped=0;errors=@();paths=@()}
  }finally{$lk.Dispose()}
  if($scanJob){Remove-Job $scanJob -Force}
  try{$scanJob=Start-Job -ArgumentList (Join-Path $PSScriptRoot 'core.ps1'),$RootPath,$runId,$PID,([Environment]::MachineName) -ScriptBlock {param($core,$root,$id,$ownerPid,$ownerHost);. $core -RootPath $root;try{FullScanV4 $id $ownerPid $ownerHost|Out-Null}catch{PublishScan @{runId=$id;running=$false;phase='failed';startedAt=(NowIso);finishedAt=(NowIso);visited=0;added=0;errors=@($_.Exception.Message);paths=@()}}}}
  catch{PublishScan @{runId=$runId;running=$false;phase='failed';errors=@($_.Exception.Message);paths=@();visited=0;added=0};throw}
  Send $c 202 @{ok=$true;running=$true;runId=$runId}
 }
 '/api/move' {Send $c 200 (MoveDocument $body)}
 '/api/edit' {Send $c 200 (EditDocument $body $Role)}
 '/api/rate' {if($Role-ne'MANAGER'){throw 'Réservé au manager'};Send $c 200 (EditRate $body)}
 '/api/open' {Send $c 200 (OpenDocument $body)}
 '/api/leave' {Send $c 200 @{ok=$true};$run=$false}
 default {Send $c 404 @{error='Route inconnue'}}
 }
 }catch{try{Send $c 409 @{error=$_.Exception.Message}}catch{}}}}finally{
 if($scanJob){if($scanJob.State-eq'Running'){Stop-Job $scanJob;try{PublishScan @{running=$false;phase='stopped';visited=0;added=0;errors=@('Manager déconnecté pendant le scan');paths=@()}}catch{}};Remove-Job $scanJob -Force}
 $l.Stop();$l.Close()
}
