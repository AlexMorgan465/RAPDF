@echo off
setlocal
chcp 65001 >nul
echo Fermez les anciennes sessions Agent et Manager sur tous les postes.
echo Indiquez le dossier applicatif contenant AGENT, MANAGER et COMMON.
set "AppTarget="
set /p "AppTarget=Dossier a mettre a jour : "
if not defined AppTarget exit /b 1
for %%I in ("%AppTarget%\.") do set "AppTarget=%%~fI"
if "%AppTarget:~-1%"=="\" set "AppTarget=%AppTarget:~0,-1%"
if not exist "%AppTarget%\AGENT\server.ps1" goto invalid
if not exist "%AppTarget%\MANAGER\server.ps1" goto invalid
set "AppBackup=%AppTarget%_backup_%RANDOM%_%RANDOM%"
robocopy "%AppTarget%" "%AppBackup%" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
robocopy "%~dp0AGENT" "%AppTarget%\AGENT" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
robocopy "%~dp0MANAGER" "%AppTarget%\MANAGER" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
robocopy "%~dp0COMMON" "%AppTarget%\COMMON" /E /XF settings.ps1 schema.json /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
if not exist "%AppTarget%\COMMON\settings.ps1" (
 copy "%~dp0COMMON\settings.ps1" "%AppTarget%\COMMON\settings.ps1" >nul
 if errorlevel 1 goto failed
)
if not exist "%AppTarget%\COMMON\schema.json" (
 copy "%~dp0COMMON\schema.json" "%AppTarget%\COMMON\schema.json" >nul
 if errorlevel 1 goto failed
)
robocopy "%~dp0TESTS" "%AppTarget%\TESTS" /E /R:1 /W:1 /NFL /NDL /NJH /NJS
if errorlevel 8 goto failed
copy "%~dp0README.txt" "%AppTarget%\README.txt" >nul
if errorlevel 1 goto failed
echo Mise a jour terminee. Configuration conservee.
echo Sauvegarde : "%AppBackup%"
echo Lancez TESTS\TEST_LOCAL.bat, puis les fichiers START.
pause
exit /b 0
:invalid
echo Dossier invalide : attendu AGENT\server.ps1 et MANAGER\server.ps1.
pause
exit /b 1
:failed
echo Copie incomplete. Ne relancez pas les interfaces avant correction.
echo La sauvegarde precedente est disponible dans "%AppBackup%".
pause
exit /b 1
