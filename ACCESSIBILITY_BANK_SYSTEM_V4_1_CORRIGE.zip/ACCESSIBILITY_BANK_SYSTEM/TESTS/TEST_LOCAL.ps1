﻿$ErrorActionPreference='Stop'
# Parse with the installed Windows PowerShell parser before exercising code.
foreach($source in (Get-ChildItem -LiteralPath (Join-Path $PSScriptRoot '..') -Filter '*.ps1' -Recurse)){
 $tokens=$null;$parseErrors=$null
 [System.Management.Automation.Language.Parser]::ParseFile($source.FullName,[ref]$tokens,[ref]$parseErrors)|Out-Null
 if($parseErrors.Count){throw ($source.FullName+': '+($parseErrors.Message -join '; '))}
}
$testRoot=Join-Path ([IO.Path]::GetTempPath()) ('AccessibilityTest-'+[guid]::NewGuid().ToString('N'))
[IO.Directory]::CreateDirectory($testRoot)|Out-Null
try{
 . (Join-Path $PSScriptRoot '..\COMMON\core.ps1') -RootPath $testRoot
 function Assert($condition,$message){if(!$condition){throw ('ECHEC : '+$message)};Write-Host ('OK : '+$message) -ForegroundColor Green}
 $p=BranchPath 'DIRCO' 'A TRAITER' 'CM';[IO.Directory]::CreateDirectory($p)|Out-Null
 $f=Join-Path $p 'test.pdf';[IO.File]::WriteAllText($f,'Fixture');[IO.File]::SetLastWriteTimeUtc($f,[datetime]'2026-09-01T10:00:00Z')
 $writeDir=Join-Path $testRoot 'JSON avec espaces'
 [IO.Directory]::CreateDirectory($writeDir)|Out-Null
 $writeFile=Join-Path $writeDir 'etat.json'
 AtomicJson $writeFile @{sequence=1}
 AtomicJson $writeFile @{sequence=2}
 AtomicJson $writeFile @{sequence=3}
 $written=[IO.File]::ReadAllText($writeFile)|ConvertFrom-Json
 Assert ($written.sequence-eq 3) 'Remplacement JSON repete avec chemin de sauvegarde explicite'
 Assert (@(Get-ChildItem -LiteralPath $writeDir -Filter '*.tmp').Count-eq 0) 'Fichiers temporaires nettoyes apres succes'
 $startup=OrbitState
 Assert (![IO.File]::Exists($DbFile)) 'Demarrage Orbit ne cree ni registre ni scan'
 Assert (@($startup.branches|Where-Object{$_.known}).Count -eq 0) 'Compteurs inconnus avant comptage'
 $target=TargetCount 'DIRCO' 'A TRAITER' 'CM'
 Assert ($target.count -eq 1) 'Comptage uniquement branche choisie'
 Assert (![IO.File]::Exists($DbFile)) 'Compter ne charge pas les noms dans le registre'
 $result=EngageBranch 'DIRCO' 'A TRAITER' 'CM'
 Assert (@($result.items).Count -eq 1) 'ENGAGE charge la branche'
 $db=ReadDb;$d=@($db.documents)[0];$id=$d.id;$deposit=$d.depositAt
 Assert ($deposit -eq '2026-09-01T10:00:00.0000000Z') 'Depot = modification au premier scan'
 EditDocument ([pscustomobject]@{id=$id;complex=$true;complexComment='Tableau difficile';priority=$true;priorityComment='Urgent';unitPrice=0}) 'MANAGER'|Out-Null
 MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='EN COURS';comment='PEC'})|Out-Null
 $conflict=$false;try{MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='EN COURS'})|Out-Null}catch{$conflict=$true}
 Assert $conflict 'Double PEC refusee'
 Assert (Test-Path -LiteralPath (Join-Path (BranchPath 'DIRCO' 'EN COURS' 'CM') 'test.pdf')) 'Fichier deplace physiquement'
 MoveDocument ([pscustomobject]@{id=$id;from='EN COURS';to='NON CONFORME';comment='Contraste'})|Out-Null
 MoveDocument ([pscustomobject]@{id=$id;from='NON CONFORME';to='A TRAITER';comment='Retour'})|Out-Null
 MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='TRAITES';comment='Conforme'})|Out-Null
 $f=Join-Path (BranchPath 'DIRCO' 'TRAITES' 'CM') 'test.pdf';[IO.File]::SetLastWriteTimeUtc($f,[datetime]'2026-10-07T10:00:00Z')
 $scan=FullScanV4 ([guid]::NewGuid().ToString('N'));$db=ReadDb;$d=FindDoc $db $id
 Assert ($d.depositAt -eq $deposit) 'Depot conserve apres mouvements et scans'
 Assert ($d.complex -and $d.priority -and $d.complexComment -eq 'Tableau difficile') 'Complexite et priorite conservees'
 Assert ($d.unitPrice -eq 0) 'Prix individuel nul conserve'
 Assert ($d.billedPrice -eq 4.5) 'Tarif DIRCO memorise a la fin'
 Assert (@($d.periods).Count -eq 4) 'Durees de chaque passage historisees'
 Assert (@($db.history).Count -eq 4) 'Historique sans doublon de PEC'
 EditRate ([pscustomobject]@{entity='DIRCO';price=9})|Out-Null
 $d=FindDoc (ReadDb) $id;Assert ($d.billedPrice -eq 4.5) 'Modification du tarif ne change pas le tarif memorise'
 # An addition after a previous scan, in a previously unknown nested branch.
 $nested=Join-Path (BranchPath 'ACM' 'A TRAITER' 'ASS-BIENS') 'NOUVELLE-BRANCHE\SOUS-DOSSIER'
 [IO.Directory]::CreateDirectory($nested)|Out-Null
 [IO.File]::WriteAllText((Join-Path $nested 'nouveau.docx'),'Fixture')
 $scan=FullScanV4 ([guid]::NewGuid().ToString('N'));$db=ReadDb
 $new=@($db.documents|Where-Object{$_.name -eq 'nouveau.docx'})
 Assert ($scan.added -eq 1 -and $new.Count -eq 1) 'Full scan importe un nouveau document apres le scan precedent'
 Assert ($new[0].branch -eq 'ASS-BIENS\NOUVELLE-BRANCHE\SOUS-DOSSIER') 'Full scan decouvre les nouvelles branches imbriquees'
 Assert (@($scan.paths|Where-Object{$_.path -eq $nested -and $_.ok}).Count -eq 1) 'Bilan prouve le chemin visite'
 $oldDeposit=$d.depositAt
 FullScanV4 ([guid]::NewGuid().ToString('N'))|Out-Null
 Assert ((FindDoc (ReadDb) $id).depositAt -eq $oldDeposit) 'Full scan repete ne change pas le depot'
 # A selected count must not import a document from another entity.
 $other=BranchPath 'CREATIS' 'A TRAITER' '';[IO.Directory]::CreateDirectory($other)|Out-Null
 [IO.File]::WriteAllText((Join-Path $other 'hors-branche.pdf'),'Fixture')
 TargetCount 'DIRCO' 'A TRAITER' 'CM'|Out-Null
 Assert (@((ReadDb).documents|Where-Object{$_.name -eq 'hors-branche.pdf'}).Count -eq 0) 'Comptage cible ne scanne aucune autre entite'
 # Two separate PowerShell processes race for the same document.
 [IO.File]::WriteAllText((Join-Path $p 'race.pdf'),'Fixture')
 $race=EngageBranch 'DIRCO' 'A TRAITER' 'CM';$raceId=@($race.items|Where-Object{$_.name -eq 'race.pdf'})[0].id
 $corePath=Join-Path $PSScriptRoot '..\COMMON\core.ps1';$barrier=Join-Path $testRoot 'barrier';[IO.Directory]::CreateDirectory($barrier)|Out-Null
 $jobs=@();foreach($index in @(1,2)){$jobs+=Start-Job -ArgumentList $corePath,$testRoot,$raceId,$barrier,$index -ScriptBlock {
  param($core,$root,$id,$gate,$index);. $core -RootPath $root
  [IO.File]::WriteAllText((Join-Path $gate ([string]$index)),'ready');$until=(Get-Date).AddSeconds(10)
  while(@([IO.Directory]::EnumerateFiles($gate)).Count-lt 2 -and (Get-Date)-lt$until){Start-Sleep -Milliseconds 20}
  try{MoveDocument ([pscustomobject]@{id=$id;from='A TRAITER';to='EN COURS';comment='Race'})|Out-Null;@{won=$true}}catch{@{won=$false;error=$_.Exception.Message}}
 }}
 try{$jobs|Wait-Job -Timeout 30|Out-Null;$wins=@($jobs|Receive-Job);Assert (@($wins|Where-Object{$_.won}).Count -eq 1) 'Deux processus : une seule PEC autorisee'}finally{$jobs|Stop-Job;$jobs|Remove-Job -Force}
 # Category-first entities retain the position of status before a nested subfolder.
 $cat=Join-Path (BranchPath 'CONTRATHEQUE' 'A TRAITER' 'GARANTIES') 'Sous-dossier'
 [IO.Directory]::CreateDirectory($cat)|Out-Null;[IO.File]::WriteAllText((Join-Path $cat 'contrat.pdf'),'Fixture')
 FullScanV4 ([guid]::NewGuid().ToString('N'))|Out-Null
 $contract=@((ReadDb).documents|Where-Object{$_.name -eq 'contrat.pdf'})[0]
 Assert ($contract.branch -eq 'GARANTIES|Sous-dossier') 'Sous-dossier apres statut correctement importe pour CONTRATHEQUE'
 MoveDocument ([pscustomobject]@{id=$contract.id;from='A TRAITER';to='EN COURS';comment='Contrat'})|Out-Null
 $destination=Join-Path (Join-Path (BranchPath 'CONTRATHEQUE' 'EN COURS' 'GARANTIES') 'Sous-dossier') 'contrat.pdf'
 Assert ([IO.File]::Exists($destination)) 'Deplacement CATEGORY_FIRST conserve la structure physique'
 # Corruption: aucun remplacement silencieux du registre
 [IO.File]::WriteAllText($DbFile,'{INVALID');$rejected=$false;try{ReadDb|Out-Null}catch{$rejected=$true}
 Assert $rejected 'Registre invalide refuse sans ecrasement'
 Write-Host 'Tous les tests locaux ont reussi.' -ForegroundColor Green
}finally{Remove-Item -LiteralPath $testRoot -Recurse -Force}
