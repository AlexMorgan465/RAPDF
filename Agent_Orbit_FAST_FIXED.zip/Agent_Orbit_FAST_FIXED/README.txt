AGENT ORBIT FAST FIXED
- Repart du serveur validé Agent_Orbit_Final.
- Aucun scan global automatique.
- FULL RESCAN initialise/recalibre .agent_orbit_counts.json sur le DP.
- Ensuite les refresh lisent seulement ce petit JSON.
- ENGAGE lit uniquement la branche sélectionnée.
- Chaque déplacement met à jour le compteur partagé immédiatement.
- START_DEBUG.bat affiche l'erreur si Windows refuse le lancement caché.
