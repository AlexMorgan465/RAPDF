@echo off
cd /d "%~dp0"
title AGENT ORBIT DEBUG
powershell.exe -NoProfile -ExecutionPolicy Bypass -NoExit -File "%~dp0server.ps1"
