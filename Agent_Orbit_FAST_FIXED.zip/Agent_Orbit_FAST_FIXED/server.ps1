﻿param([int]$Port=8788,[string]$RootPath="\\UF11-a03\eids-eaa-pdf-statiques\ACCESSIBILITE")
$ErrorActionPreference="Stop"
$Schema=[ordered]@{
"ACM"=@{Mode="STATUS_FIRST";Branches=@("ASS-BIENS","ASS-COMPTA-CONTENTIEUX","ASS-EMPRUNTEURS","ASS-INDEMN-BIENS-PERS","ASS-PERS-COLL","ASS-PERS-IND","ASS-PROTECTION-JUR","ASS-VIE-EPARGNE-RET\MONABANQ - VIE","ASS-VIE-EPARGNE-RET\RETRAITE COLLECTIVE")}
"Bouygues telecom"=@{Mode="SIMPLE";Branches=@("")}
"CIC CIB ASSET SERVICING"=@{Mode="STATUS_FIRST";Branches=@("Agence Clientèle Déposée")}
"CMMABN"=@{Mode="SIMPLE";Branches=@("")}
"CMO"=@{Mode="STATUS_FIRST";Branches=@("BAD","Cartes bancaires","Compte courant","Epargne bancaire","Epargne financière","Packages","Tarif")}
"COFIDIS FRANCE"=@{Mode="STATUS_FIRST";Branches=@("COFIDIS FRANCE-DMA\DMA – Agence WEB","COFIDIS FRANCE-DMA\DMA – Marque et Stratégie","COFIDIS FRANCE-DMA\DMA – Performance Digitale","COFIDIS FRANCE-DPA\DPA – Domaine Marketing","COFIDIS FRANCE-DPA\DPA – Service Marketing","COFIDIS FRANCE-DPA\DPA – Service Relation")}
"CONTRATHEQUE"=@{Mode="CATEGORY_FIRST";Branches=@("CONDITIONS GENERALES","DOCUMENT D'INFORMATION TARIFAIRE","GARANTIES","POLITIQUE DE PROTECTION")}
"CREATIS"=@{Mode="SIMPLE";Branches=@("")}
"DIRCO"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"DIRCOM"=@{Mode="STATUS_FIRST";Branches=@("CIC","CM")}
"MONABANQ"=@{Mode="SIMPLE";Branches=@("")}
}
$Statuses=@("A TRAITER","EN COURS","NON CONFORME","TRAITES")
function J($o){$o|ConvertTo-Json -Depth 8 -Compress}
function Send($c,$code,$o){$b=[Text.Encoding]::UTF8.GetBytes((J $o));$c.Response.StatusCode=$code;$c.Response.ContentType="application/json; charset=utf-8";$c.Response.Headers["Cache-Control"]="no-store";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close()}
function Q($r){$h=@{};if($r.Url.Query.Length-gt 1){foreach($p in $r.Url.Query.Substring(1).Split("&")){$k=$p.Split("=",2);if($k.Count-eq 2){$h[[Uri]::UnescapeDataString($k[0])] = [Uri]::UnescapeDataString(($k[1]-replace '\+',' '))}}};$h}
function Body($r){$sr=New-Object IO.StreamReader($r.InputStream,$r.ContentEncoding);$t=$sr.ReadToEnd();$sr.Close();if(!$t){return @{}};$t|ConvertFrom-Json}
function BranchPath($e,$s,$b){
 if(!$Schema.Contains($e)){throw "Entité inconnue: $e"}; if($Statuses-notcontains$s){throw "Statut invalide"}
 $cfg=$Schema[$e];$p=Join-Path $RootPath $e
 if($cfg.Mode-eq"CATEGORY_FIRST"){if(!$b){throw "Sous-entité requise"};return Join-Path (Join-Path $p $b) $s}
 $p=Join-Path $p $s;if($b){$p=Join-Path $p $b};$p
}
$StateFile=Join-Path $RootPath ".agent_orbit_counts.json"
function CountBranch($e,$s,$b){$p=BranchPath $e $s $b;if(![IO.Directory]::Exists($p)){return 0};$n=0;try{foreach($x in [IO.Directory]::EnumerateFileSystemEntries($p)){$n++}}catch{};return $n}
function NewState(){$a=@();foreach($e in $Schema.Keys){$a+=@{entity=$e;counts=[ordered]@{"A TRAITER"=0;"EN COURS"=0;"NON CONFORME"=0};total=0}};return @{entities=$a;initialized=$false;at="JAMAIS"}}
function ReadState(){try{if([IO.File]::Exists($StateFile)){return (Get-Content -LiteralPath $StateFile -Raw -Encoding UTF8|ConvertFrom-Json)}}catch{};return (NewState)}
function WriteState($st){$tmp=$StateFile+"."+[Guid]::NewGuid().ToString("N")+".tmp";[IO.File]::WriteAllText($tmp,(J $st),(New-Object Text.UTF8Encoding($false)));if([IO.File]::Exists($StateFile)){try{[IO.File]::Replace($tmp,$StateFile,$null)}catch{Move-Item -LiteralPath $tmp -Destination $StateFile -Force}}else{Move-Item -LiteralPath $tmp -Destination $StateFile -Force}}
function Counts(){return (ReadState)}
function FullScan(){$a=@();foreach($e in $Schema.Keys){$c=[ordered]@{};foreach($s in @("A TRAITER","EN COURS","NON CONFORME")){$n=0;foreach($b in $Schema[$e].Branches){$n+=CountBranch $e $s $b};$c[$s]=$n};$a+=@{entity=$e;counts=$c;total=([int]$c["A TRAITER"]+[int]$c["EN COURS"]+[int]$c["NON CONFORME"])}};$st=@{entities=$a;initialized=$true;at=(Get-Date).ToString("dd/MM/yyyy HH:mm:ss")};WriteState $st;return $st}
function AdjustState($entity,$from,$to){$st=ReadState;if(-not $st.initialized){return};foreach($x in $st.entities){if($x.entity -eq $entity){if($from -ne "TRAITES"){$p=$x.counts.PSObject.Properties[$from];if($null -ne $p){$p.Value=[Math]::Max(0,[int]$p.Value-1)}};if($to -ne "TRAITES"){$p=$x.counts.PSObject.Properties[$to];if($null -ne $p){$p.Value=[int]$p.Value+1}};$x.total=[int]$x.counts.'A TRAITER'+[int]$x.counts.'EN COURS'+[int]$x.counts.'NON CONFORME'}};$st.at=(Get-Date).ToString("dd/MM/yyyy HH:mm:ss");WriteState $st}
function Items($p){if(![IO.Directory]::Exists($p)){return @()};@(Get-ChildItem -LiteralPath $p -Force|%{@{name=$_.Name;kind=$(if($_.PSIsContainer){"Dossier"}else{"Fichier"});modified=$_.LastWriteTime.ToString("dd/MM/yyyy HH:mm")}})}
function Safe($n){if(!$n-or$n.Contains("..")-or$n.Contains("\")-or$n.Contains("/")){throw"Nom invalide"};$n}
function MoveOne($b){
 $n=Safe ([string]$b.name);$srcD=BranchPath ([string]$b.entity) ([string]$b.from) ([string]$b.branch);$dstD=BranchPath ([string]$b.entity) ([string]$b.to) ([string]$b.branch)
 if(![IO.Directory]::Exists($dstD)){[IO.Directory]::CreateDirectory($dstD)|Out-Null};$src=Join-Path $srcD $n;$dst=Join-Path $dstD $n
 if(!([IO.Directory]::Exists($src)-or[IO.File]::Exists($src))){throw"Déjà déplacé ou introuvable"}
 if([IO.Directory]::Exists($dst)-or[IO.File]::Exists($dst)){throw"Existe déjà à destination"}
 if([IO.Directory]::Exists($src)){[IO.Directory]::Move($src,$dst)}else{[IO.File]::Move($src,$dst)}
 AdjustState ([string]$b.entity) ([string]$b.from) ([string]$b.to)
 @{ok=$true}
}
$l=New-Object Net.HttpListener;$l.Prefixes.Add("http://localhost:$Port/");$l.Start();Start-Process "http://localhost:$Port/"
try{$run=$true;while($run){$c=$l.GetContext();try{$r=$c.Request;$p=$r.Url.AbsolutePath
 if($p-eq"/"){ $f=Join-Path $PSScriptRoot "index.html";$b=[IO.File]::ReadAllBytes($f);$c.Response.ContentType="text/html; charset=utf-8";$c.Response.ContentLength64=$b.Length;$c.Response.OutputStream.Write($b,0,$b.Length);$c.Response.Close();continue}
 if($p-eq"/api/ping"){Send $c 200 @{ok=$true;root=$RootPath;exists=[IO.Directory]::Exists($RootPath)};continue}
 if($p-eq"/api/schema"){$x=@();foreach($e in $Schema.Keys){$x+=@{entity=$e;mode=$Schema[$e].Mode;branches=@($Schema[$e].Branches)}};Send $c 200 @{entities=$x};continue}
 if($p-eq"/api/counts"){Send $c 200 (Counts);continue}
 if($p-eq"/api/fullscan"-and$r.HttpMethod-eq"POST"){Send $c 200 (FullScan);continue}
 if($p-eq"/api/items"){$q=Q $r;$bp=BranchPath $q.entity $q.status $q.branch;Send $c 200 @{items=@(Items $bp);path=$bp};continue}
 if($p-eq"/api/move"-and$r.HttpMethod-eq"POST"){Send $c 200 (MoveOne (Body $r));continue}
 if($p-eq"/api/leave"-and$r.HttpMethod-eq"POST"){Send $c 200 @{ok=$true};$run=$false;continue}
 Send $c 404 @{error="Route inconnue"}
}catch{try{Send $c 500 @{error=$_.Exception.Message}}catch{}}}}finally{$l.Stop();$l.Close()}